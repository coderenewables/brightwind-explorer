"""Command-line interface for windkit."""

import argparse
import sys

from windkit import config

_LABELS = {"name": "Name", "email": "Email", "institution": "Institution"}


def _configure(args) -> int:
    """Write the user attribution file from flags, the existing file and prompts."""
    path = config._CONFIG_FILE
    existing = config._read_config_file(path)
    # sys.stdin is None when stdin is closed or under pythonw
    interactive = sys.stdin is not None and sys.stdin.isatty()

    values = {}
    missing = []
    for name in config._FIELD_NAMES:
        given = getattr(args, name)
        if given is not None:
            values[name] = config._clean(given)
        elif interactive:
            default = existing.get(name)
            suffix = f" [{default}]" if default else ""
            answer = input(f"{_LABELS[name]}{suffix}: ")
            values[name] = config._clean(answer) or default
        elif name in existing:
            values[name] = existing[name]
        else:
            missing.append(name)

    if missing:
        flags = ", ".join(f"--{name}" for name in missing)
        print(
            f"windkit configure: there is no terminal to prompt for {flags}. "
            "Pass them as flags; an empty value leaves a field unset.",
            file=sys.stderr,
        )
        return 1

    try:
        config._write_config_file(path, config.Config(**values))
    except (UnicodeEncodeError, OSError) as e:
        print(
            f"windkit configure: could not write {path}: {e}. The existing "
            "configuration is unchanged.",
            file=sys.stderr,
        )
        return 1
    config.get_config.cache_clear()
    print(f"Saved the windkit configuration to {path}")
    return 0


def main(argv: list[str] | None = None) -> int:
    """Run the windkit command-line interface.

    Parameters
    ----------
    argv : list of str, optional
        Command-line arguments, excluding the program name. Defaults to
        ``sys.argv[1:]``.

    Returns
    -------
    int
        Exit status.
    """
    parser = argparse.ArgumentParser(
        prog="windkit", description="windkit command-line interface"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    configure_parser = subparsers.add_parser(
        "configure",
        help="Set the user attribution stamped on windkit datasets",
        description=(
            "Write the name, email and institution that windkit stamps on the "
            "datasets it creates as author, author_email and institution. "
            "Fields not given as flags are prompted for, with the current "
            "values as defaults, and an empty answer keeps the current value. "
            "Without a terminal, fields not given as flags keep their current "
            'values. An empty flag value, such as --email "", leaves a field '
            "unset. The WINDKIT_NAME, WINDKIT_EMAIL and WINDKIT_INSTITUTION "
            "environment variables take precedence over the file."
        ),
    )
    for name in config._FIELD_NAMES:
        configure_parser.add_argument(f"--{name}", help=f"{_LABELS[name]} to stamp")
    configure_parser.set_defaults(func=_configure)

    args = parser.parse_args(argv)
    return args.func(args)
