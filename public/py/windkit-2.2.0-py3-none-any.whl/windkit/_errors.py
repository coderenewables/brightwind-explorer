# (c) 2026 DTU Wind Energy
"""
Package exceptions.

``WindkitError``, ``WindkitValidationError``, ``WindkitFileFormatError`` and
``UnsupportedFileTypeError`` are re-exported from the top-level ``windkit``
namespace and are the supported import path. The plotting-specific classes
are internal to :mod:`windkit.plot`.
"""


class WindkitError(Exception):
    """Base class for windkit errors"""

    pass


class UnsupportedFileTypeError(WindkitError):
    """A file extension or object type that no reader or writer handles."""

    pass


class WindkitFileFormatError(WindkitError, ValueError):
    """A file does not conform to the format it claims.

    Raised by the readers in :mod:`windkit.io.wasp` for a malformed file:
    truncated, holding a value that does not parse, or missing a required
    element or attribute. The message names the file and, where the format
    allows it, the line or element. Subclasses ``ValueError`` so existing
    ``except ValueError`` handlers keep working.
    """

    pass


class MultiPointError(WindkitError):
    """Error class to use when a single point is required, but multiple were applied"""

    def __init__(self):
        self.message = "Plotting multiple points is not supported now, please subset your dataset to a single point."
        super().__init__(self.message)


class IEC_type_error(WindkitError):
    """Error class to use when a single the IEC type is not well defined"""

    def __init__(self):
        self.message = "The IEC class is not correctly defined, please choose one between: IEC_I, IEC_II or IEC_III."
        super().__init__(self.message)


class PlottingAttrsError(WindkitError):
    """Error class to use when a single the IEC type is not well defined"""

    def __init__(self, errors, name):
        self.message = (
            f"The plot can't be displayed as the following attributes are not defined for '{name}' : \n"
            + "\n".join(errors)
            + "\nPlease, define a value for the empty attributes."
        )
        super().__init__(self.message)


class Missing_arguments(WindkitError):
    """Error class to use when no input in plotting function"""

    def __init__(self, func_name, errors):
        self.message = (
            f"{func_name} missing required positional argument:  \n" + "\n".join(errors)
        )
        super().__init__(self.message)


class WindkitValidationError(WindkitError):
    """Error class to use when an xarray wind climate object is not well defined.

    Parameters
    ----------
    msg : str
        Formatted, human-readable error message.
    errors : list of str, optional
        Unnumbered list of the individual validation failures that produced
        ``msg``. Defaults to an empty list.
    """

    def __init__(self, msg, errors=None):
        self.message = msg
        self.errors = list(errors) if errors is not None else []
        super().__init__(self.message)
