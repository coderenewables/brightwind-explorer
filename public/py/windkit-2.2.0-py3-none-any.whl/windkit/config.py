"""User attribution stamped on the datasets windkit creates.

windkit adds ``author``, ``author_email`` and ``institution`` attributes to its
datasets when the user has configured them, and omits them otherwise. Values
come from the ``WINDKIT_NAME``, ``WINDKIT_EMAIL`` and ``WINDKIT_INSTITUTION``
environment variables, which take precedence field by field over the
``windkit_config.toml`` file in the user configuration directory. Run
``windkit configure`` to write that file.

Reading the configuration never prompts, prints or writes files.
"""

import functools
import logging
import os
import tomllib
import warnings
from dataclasses import dataclass, fields
from pathlib import Path

import platformdirs

logger = logging.getLogger(__name__)

APPNAME = "windkit"
APPAUTHOR = "DTU Wind Energy"

_CONFIG_FILE = (
    platformdirs.user_config_path(appname=APPNAME, appauthor=APPAUTHOR, roaming=True)
    / "windkit_config.toml"
)
_ENV_PREFIX = "windkit_"


@dataclass(frozen=True)
class Config:
    """User attribution stamped on the datasets windkit creates.

    A field is ``None`` when it is not configured, and the corresponding
    dataset attribute is then omitted.

    Parameters
    ----------
    name : str or None
        Full name of the user, stamped as ``author``.
    email : str or None
        Email address of the user, stamped as ``author_email``.
    institution : str or None
        Institution or company of the user, stamped as ``institution``.
    """

    name: str | None = None
    email: str | None = None
    institution: str | None = None


_FIELD_NAMES = tuple(field.name for field in fields(Config))


def _clean(value: str) -> str | None:
    """Strip a configured value, treating an empty result as unset."""
    return value.strip() or None


def _read_env() -> dict[str, str]:
    """Configured values from the environment, matched case-insensitively.

    When several spellings of a variable are set, the first non-empty one
    wins, trying the upper-case spelling first and then the others in sorted
    order.
    """
    values = {}
    for name in _FIELD_NAMES:
        upper = (_ENV_PREFIX + name).upper()
        spellings = sorted(
            (key for key in os.environ if key.upper() == upper),
            key=lambda key: (key != upper, key),
        )
        for key in spellings:
            value = _clean(os.environ[key])
            if value is not None:
                values[name] = value
                break
    return values


def _read_config_file(path: Path) -> dict[str, str]:
    """Configured values from a TOML file.

    A missing file is not configured. An unreadable or malformed file, or a
    field that is not a string, is reported in a single ``UserWarning`` and
    ignored.
    """
    try:
        # utf-8-sig accepts the byte order mark some Windows editors write
        data = tomllib.loads(path.read_bytes().decode("utf-8-sig"))
    except FileNotFoundError:
        return {}
    except (OSError, ValueError, RecursionError) as e:
        # Decoding and parsing raise UnicodeDecodeError and TOMLDecodeError,
        # both ValueError; tomllib recurses once per level of nesting
        warnings.warn(
            f"Ignoring the windkit configuration file '{path}', which could not "
            f"be read: {e}. Run `windkit configure` to rewrite it.",
            UserWarning,
            stacklevel=2,
        )
        return {}

    values = {}
    invalid = []
    for name in _FIELD_NAMES:
        if name not in data:
            continue
        value = data[name]
        if not isinstance(value, str):
            invalid.append(name)
            continue
        value = _clean(value)
        if value is not None:
            values[name] = value
    if invalid:
        warnings.warn(
            f"Ignoring {', '.join(repr(name) for name in invalid)} in the windkit "
            f"configuration file '{path}': values must be strings. Run "
            "`windkit configure` to rewrite it.",
            UserWarning,
            stacklevel=2,
        )
    return values


def _toml_string(value: str) -> str:
    """Quote ``value`` as a TOML basic string."""
    chars = []
    for char in value:
        if char in '"\\':
            chars.append("\\" + char)
        elif char != "\t" and (ord(char) < 0x20 or ord(char) == 0x7F):
            chars.append(f"\\u{ord(char):04X}")
        else:
            chars.append(char)
    return '"' + "".join(chars) + '"'


def _write_config_file(path: Path, config: Config) -> None:
    """Write the configured fields of ``config`` to the TOML file at ``path``.

    The file is replaced atomically, so a failed write leaves any existing
    file unchanged.

    Raises
    ------
    UnicodeEncodeError
        If a value cannot be encoded as UTF-8.
    OSError
        If the file cannot be written.
    """
    data = "".join(
        f"{name} = {_toml_string(value)}\n"
        for name in _FIELD_NAMES
        if (value := getattr(config, name)) is not None
    ).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_bytes(data)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def _load_config(path: Path) -> Config:
    """Build the configuration from the environment and the file at ``path``."""
    values = {**_read_config_file(path), **_read_env()}
    config = Config(**values)
    if config == Config():
        logger.debug(
            "No windkit user attribution is configured; datasets will not carry "
            "author, author_email or institution attributes."
        )
    return config


@functools.cache
def get_config() -> Config:
    """Return the user attribution configuration.

    The configuration is read on the first call and cached for the rest of
    the process. Each field comes from the ``WINDKIT_<FIELD>`` environment
    variable if it is set and not empty, otherwise from the
    ``windkit_config.toml`` file in the user configuration directory.
    Environment variable names are case-insensitive. Unconfigured fields are
    ``None``. Call ``get_config.cache_clear()`` to read the sources again.

    Returns
    -------
    Config
        The configured name, email and institution.
    """
    return _load_config(_CONFIG_FILE)


def __getattr__(name):
    if name == "CONFIG":
        warnings.warn(
            "windkit.config.CONFIG is deprecated and will be removed in windkit "
            "3.0. Use windkit.config.get_config() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return get_config()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
