"""
Module for handling imports of optional dependencies.
"""

__all__ = []

import importlib

# Maps top-level import names to the pyproject.toml extras group that
# provides them. Used to build install hints in ImportError messages.
# test/test_optional_deps.py checks this stays in sync with pyproject.toml.
_PACKAGE_EXTRAS = {
    "matplotlib": "plots",
    "mpl_toolkits": "plots",
    "plotly": "plots",
    "kaleido": "plots",
    "dash": "plots",
    "numba": "performance",
    "pystac_client": "data_apis",
    "planetary_computer": "data_apis",
    "zarr": "data_apis",
    "fsspec": "data_apis",
    "adlfs": "data_apis",
    "ee": "data_apis",
}

# Import name -> distribution name, where they differ. The distribution
# name is what pip/conda install.
_DIST_NAMES = {
    "pystac_client": "pystac-client",
    "planetary_computer": "planetary-computer",
    "ee": "earthengine-api",
    "mpl_toolkits": "matplotlib",
}


def _import_optional_dependency(name: str, extra: str = ""):
    """
    Copyright (c) 2013-2022, GeoPandas developers.

    Import an optional dependency.

    Adapted from pandas.compat._optional::import_optional_dependency

    Raises a formatted ImportError if the module is not present. The error
    message includes the extras group that provides the module, looked up
    from the top-level portion of ``name`` in ``_PACKAGE_EXTRAS``.

    Parameters
    ----------
    name : str
        The module name.
    extra : str
        Additional text to include in the ImportError message.

    Returns
    -------
    module
    """
    if not isinstance(name, str):
        raise ValueError(
            "Invalid module name: '{name}'; must be a string".format(name=name)
        )

    top_level = name.split(".")[0]
    dist_name = _DIST_NAMES.get(top_level, top_level)
    extras_group = _PACKAGE_EXTRAS.get(top_level)
    if extras_group is not None:
        hint = (
            f'Install it with pip (pip install "windkit[{extras_group}]") '
            f"or conda (conda install {dist_name})."
        )
    else:
        hint = f"Use pip or conda to install {dist_name}."
    msg = f"Missing optional dependency '{top_level}'. {extra + ' ' if extra else ''}{hint}"

    try:
        module = importlib.import_module(name)

    except ModuleNotFoundError:
        raise ImportError(msg) from None
    except ImportError as err:
        # The package is present but failed to import (broken install, backend
        # issue): keep the hint but preserve the real cause in the chain.
        raise ImportError(msg) from err

    return module
