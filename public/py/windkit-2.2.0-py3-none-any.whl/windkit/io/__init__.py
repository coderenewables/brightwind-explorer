# (c) 2026 DTU Wind Energy
"""
I/O module for windkit.

This module provides functions for reading and writing wind data in various formats.
"""

import importlib
from typing import TYPE_CHECKING

__all__ = [
    "wasp",
    "windio",
]

if TYPE_CHECKING:
    from windkit.io import wasp, windio


def __getattr__(name):
    """Import subpackages lazily.

    ``windkit.io.windio`` imports ``RegulationType`` from
    ``windkit.wind_farm.wind_turbine_generator``, and the wind climate modules
    reach back into ``windkit.io.wasp``. Deferring both keeps either subpackage
    importable from anywhere, regardless of the order of the imports in
    ``windkit/__init__.py``, and keeps a bare ``import windkit`` from loading
    them at all.
    """
    if name in __all__:
        return importlib.import_module(f"{__name__}.{name}")
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | set(__all__))
