"""Common utilities for WAsP file I/O."""

import codecs

import numpy as np

from windkit._errors import WindkitFileFormatError

#: Byte-order marks, each with the encoding that reads its file and drops it.
_BOMS = (
    (codecs.BOM_UTF8, "utf_8_sig"),
    (codecs.BOM_UTF16_LE, "utf_16"),
    (codecs.BOM_UTF16_BE, "utf_16"),
)

#: Encodings tried in turn on a file with no byte-order mark that is not
#: UTF-16. ``cp1256`` (Windows Arabic) has been the Windows code-page fallback
#: since the first ``.tab`` reader, and it must stay last: it maps all 256 byte
#: values, so it decodes any file and ends the search. ``cp1252`` could not take
#: that role, as it leaves five bytes undefined. The numbers in a file survive,
#: being ASCII, but non-ASCII text saved in any other code page -- a Danish
#: description saved as ``cp1252``, say -- is read as the wrong characters.
_ENCODINGS = ("ascii", "utf_8", "cp1256")


def _utf16_without_bom(data):
    """Return the UTF-16 codec *data* is written in, or None if it is not UTF-16.

    A character below U+0100 -- every digit, space and line break -- is a code
    unit whose high byte is NUL: the second byte of the pair in little-endian,
    the first in big-endian. A WAsP file is mostly digits, so in UTF-16 more
    than half of its bytes on one side are NUL. Without this check such a file
    is read as ASCII, where NUL is a valid character. A stray NUL in a file
    that is not UTF-16 is far below the threshold.
    """
    n_per_side = len(data) / 2
    n_nul_even = data[0::2].count(0)
    n_nul_odd = data[1::2].count(0)
    if n_nul_odd > max(n_nul_even, n_per_side / 2):
        return "utf_16_le"
    if n_nul_even > max(n_nul_odd, n_per_side / 2):
        return "utf_16_be"
    return None


def _candidates(data):
    """Return the encodings the bytes *data* may be in, in the order to try."""
    for bom, encoding in _BOMS:
        if data.startswith(bom):
            return (encoding,)
    utf16 = _utf16_without_bom(data)
    return (utf16,) if utf16 else _ENCODINGS


def _encoding_of(data, final, filepath):
    """Return the encoding of *data*, the bytes of *filepath* or a prefix of them.

    With ``final=False``, *data* is a prefix, and a multi-byte character cut
    off at its end is not a decoding failure.
    """
    candidates = _candidates(data)
    for encoding in candidates:
        try:
            codecs.getincrementaldecoder(encoding)().decode(data, final=final)
        except UnicodeDecodeError:
            continue
        return encoding
    raise WindkitFileFormatError(
        f"Unknown encoding for {filepath}: it does not decode as "
        f"{' or '.join(candidates)}. Please save it as ASCII or UTF-8"
    )


def detect_encoding(filepath):
    """Detect the encoding of a file.

    A byte-order mark decides it: ``utf_8_sig`` or ``utf_16``, so that the mark
    is not read as part of the text. A file without one that is mostly NUL
    bytes on one side of each byte pair is UTF-16 in that byte order. Anything
    else takes the first of ``ascii``, ``utf_8`` and ``cp1256`` that decodes it.

    The whole file is read, once. A prefix would not do: a single non-ASCII
    byte anywhere changes the answer. A reader that cannot afford the full
    pass can guess with :func:`sniff_encoding` instead.

    Parameters
    ----------
    filepath : str or Path
        Path to the file to detect encoding for.

    Returns
    -------
    str
        The detected encoding.

    Raises
    ------
    WindkitFileFormatError
        If the file has a byte-order mark or looks like UTF-16 but does not
        decode as such. A file with neither always decodes as ``cp1256``.
    """
    with open(filepath, "rb") as fobj:
        return _encoding_of(fobj.read(), True, filepath)


def sniff_encoding(filepath, n_bytes):
    """Guess the encoding of a file from its first *n_bytes* bytes.

    As :func:`detect_encoding`, but a byte past the prefix may not decode under
    the guess, and reading on then raises ``UnicodeDecodeError``. Catch it and
    retry with :func:`detect_encoding`. A multi-byte character straddling the
    cutoff does not spoil the guess.

    Parameters
    ----------
    filepath : str or Path
        Path to the file to sniff.
    n_bytes : int
        How many bytes to read from the start of the file.

    Returns
    -------
    str
        The guessed encoding.

    Raises
    ------
    WindkitFileFormatError
        If the prefix has a byte-order mark or looks like UTF-16 but does not
        decode as such.
    """
    with open(filepath, "rb") as fobj:
        return _encoding_of(fobj.read(n_bytes), False, filepath)


def to_float(value, key, context):
    """Convert an XML attribute value to a float, reporting where it came from."""
    try:
        return np.float64(value)
    except ValueError:
        raise WindkitFileFormatError(
            f"{context}: attribute '{key}' is not a number: {value!r}"
        ) from None


def required_str(attrib, key, context):
    """Return ``attrib[key]``, raising if the attribute is absent.

    An attribute written as ``key=""`` counts as present: WAsP emits empty
    strings freely, including for ``Description``.
    """
    value = attrib.get(key)
    if value is None:
        raise WindkitFileFormatError(f"{context}: missing required attribute '{key}'")
    return value


def required_float(attrib, key, context):
    """Return ``attrib[key]`` as a float, raising if absent or unparseable."""
    return to_float(required_str(attrib, key, context), key, context)


def required_int(attrib, key, context):
    """Return ``attrib[key]`` as an int, raising if absent or unparseable."""
    value = required_str(attrib, key, context)
    try:
        return int(value)
    except ValueError:
        raise WindkitFileFormatError(
            f"{context}: attribute '{key}' is not an integer: {value!r}"
        ) from None


def float_or_none(attrib, key, context):
    """Return ``attrib[key]`` as a float, or None when absent or empty."""
    value = attrib.get(key)
    if value is None or value == "":
        return None
    return to_float(value, key, context)


def int_or_none(attrib, key, context):
    """Return ``attrib[key]`` as an int, or None when absent or empty."""
    value = attrib.get(key)
    if value is None or value == "":
        return None
    return required_int(attrib, key, context)
