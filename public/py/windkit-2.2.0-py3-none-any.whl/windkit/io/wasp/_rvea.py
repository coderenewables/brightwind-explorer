"""Parsers for XML fragments shared between WAsP file formats.

WAsP embeds a handful of small elements in many of its XML documents. Two of
them carry a location: ``RveaLatitudeLongitudeCoordinate`` (inside a
``.gwc``'s ``NominalLocation`` and inside ``RveaAnemometerSiteDetails``) and
``RveaAnemometerSiteDetails`` (a child of an ``.owc``'s
``RveaObservedWindClimate`` root, and anywhere in a ``.gwc`` or a workspace
inventory). Their parsers are tolerant: every field is optional and missing
ones are returned as ``None``, because WAsP has written these fragments with
different attribute sets over the years.

A sector rose is an element stating ``CountOfSectors`` with one child per
sector, found in a ``.gwc``'s mesoscale climate and throughout a workspace
inventory. :func:`parse_sector_rose` is strict: a missing sector or required
attribute raises ``WindkitFileFormatError``.
"""

import numpy as np

from windkit._errors import WindkitFileFormatError
from windkit.io.wasp._common import float_or_none, int_or_none, required_int

__all__ = [
    "parse_latitude_longitude_coordinate",
    "parse_anemometer_site_details",
    "parse_sector_rose",
]

_LATLON_TAG = "RveaLatitudeLongitudeCoordinate"
_SITE_DETAILS_TAG = "RveaAnemometerSiteDetails"


def parse_latitude_longitude_coordinate(element, context=_LATLON_TAG):
    """Parse a ``RveaLatitudeLongitudeCoordinate`` element.

    The coordinate is given either as ``LatitudeDegrees``/``LongitudeDegrees``
    attributes on the element itself, or as ``<Latitude Degrees="...">`` /
    ``<Longitude Degrees="...">`` child elements. The attribute form wins
    when both are present.

    Parameters
    ----------
    element : lxml.etree._Element or xml.etree.ElementTree.Element
        The ``RveaLatitudeLongitudeCoordinate`` element.
    context : str, optional
        Identifier used in error messages.

    Returns
    -------
    dict
        ``{"latitude": float or None, "longitude": float or None}``.

    Raises
    ------
    ValueError
        If a coordinate is present but not a number.
    """
    latitude = float_or_none(element.attrib, "LatitudeDegrees", context)
    longitude = float_or_none(element.attrib, "LongitudeDegrees", context)

    if latitude is None:
        child = element.find(".//Latitude")
        if child is not None:
            latitude = float_or_none(child.attrib, "Degrees", f"{context}: Latitude")

    if longitude is None:
        child = element.find(".//Longitude")
        if child is not None:
            longitude = float_or_none(child.attrib, "Degrees", f"{context}: Longitude")

    return {"latitude": latitude, "longitude": longitude}


def parse_anemometer_site_details(element, context=_SITE_DETAILS_TAG):
    """Parse a ``RveaAnemometerSiteDetails`` element.

    Parameters
    ----------
    element : lxml.etree._Element or xml.etree.ElementTree.Element
        The ``RveaAnemometerSiteDetails`` element.
    context : str, optional
        Identifier used in error messages.

    Returns
    -------
    dict
        Dictionary with keys ``"latitude"``, ``"longitude"``, ``"height"``
        (floats, or ``None`` when absent) and ``"description"`` (str, or
        ``None`` when absent).

    Raises
    ------
    ValueError
        If the element has another tag, or a numeric attribute is present but
        not a number.
    """
    if element.tag != _SITE_DETAILS_TAG:
        raise ValueError(f"{context}: expected {_SITE_DETAILS_TAG}, got {element.tag}")

    attrib = element.attrib
    latitude = float_or_none(attrib, "LatitudeDegrees", context)
    longitude = float_or_none(attrib, "LongitudeDegrees", context)

    # Newer files repeat the location as an embedded coordinate element; use
    # it when the attributes are missing.
    coordinate = element.find(f".//{_LATLON_TAG}")
    if coordinate is not None and (latitude is None or longitude is None):
        embedded = parse_latitude_longitude_coordinate(
            coordinate, f"{context}: {_LATLON_TAG}"
        )
        latitude = embedded["latitude"] if latitude is None else latitude
        longitude = embedded["longitude"] if longitude is None else longitude

    return {
        "latitude": latitude,
        "longitude": longitude,
        "height": float_or_none(attrib, "HeightAGL", context),
        "description": attrib.get("Description"),
    }


def parse_sector_rose(rose, tag, fields, context, index_key="Index"):
    """Collect the per-sector attributes of a sector rose into arrays ordered by sector.

    ``rose`` states the number of sectors in ``CountOfSectors``, and each of
    its ``tag`` children names its sector with the 1-based ``index_key``.
    Every sector in ``1..CountOfSectors`` must appear exactly once.

    Parameters
    ----------
    rose : lxml.etree._Element or xml.etree.ElementTree.Element
        The element holding the sectors.
    tag : str
        Tag of the per-sector child elements.
    fields : dict
        Maps an output key to an ``(attribute, reader)`` pair, where
        ``reader`` is ``required_float``, ``required_int``, ``float_or_none``
        or ``int_or_none`` from ``windkit.io.wasp._common``.
    context : str
        Identifier used in error messages.
    index_key : str, optional
        Attribute holding the sector index. Defaults to ``"Index"``.

    Returns
    -------
    dict
        Maps each key of ``fields`` to an array of shape (n_sectors,), int64
        for an integer attribute every sector carries and float64 otherwise.
        An optional attribute (read with ``float_or_none`` or
        ``int_or_none``) that no element carries gives None instead of an
        array, and one that only some elements carry is NaN where absent.

    Raises
    ------
    WindkitFileFormatError
        If ``CountOfSectors`` is missing or not positive, a sector index is
        missing, outside ``1..CountOfSectors`` or repeated, a sector has no
        element, or a required attribute is missing or does not parse.
    """
    n_sectors = required_int(rose.attrib, "CountOfSectors", context)
    if n_sectors < 1:
        raise WindkitFileFormatError(
            f"{context}: CountOfSectors must be positive, got {n_sectors}"
        )
    arrays = {
        key: (
            np.zeros(n_sectors, dtype=np.int64)
            if reader is required_int
            else np.full(n_sectors, np.nan, dtype=np.float64)
        )
        for key, (_, reader) in fields.items()
    }
    n_present = dict.fromkeys(fields, 0)
    seen = np.zeros(n_sectors, dtype=bool)

    for i, element in enumerate(rose.findall(tag)):
        element_context = f"{context}: {tag}[{i}]"
        sector = required_int(element.attrib, index_key, element_context) - 1
        if not 0 <= sector < n_sectors:
            raise WindkitFileFormatError(
                f"{element_context}: {index_key} {sector + 1} is outside "
                f"1..{n_sectors} (CountOfSectors)"
            )
        if seen[sector]:
            raise WindkitFileFormatError(
                f"{element_context}: {index_key} {sector + 1} appears more than once"
            )
        seen[sector] = True
        for key, (attribute, reader) in fields.items():
            value = reader(element.attrib, attribute, element_context)
            if value is not None:
                arrays[key][sector] = value
                n_present[key] += 1

    if not seen.all():
        raise WindkitFileFormatError(
            f"{context}: {int((~seen).sum())} of {n_sectors} sectors have no {tag}"
        )
    result = {}
    for key, array in arrays.items():
        if n_present[key] == 0:
            result[key] = None
        elif fields[key][1] is int_or_none and n_present[key] == n_sectors:
            result[key] = array.astype(np.int64)
        else:
            result[key] = array
    return result
