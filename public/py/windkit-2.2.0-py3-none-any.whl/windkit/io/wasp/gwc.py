"""Read WAsP .gwc files.

A ``.gwc`` file is an XML document carrying a ``RveaGeneralisedMeanWindClimate``
element: a generalized wind climate for one location, given as Weibull
parameters (A, k) and sector frequencies on a grid of reference roughness
lengths and reference heights. Each grid cell is one
``WindAtlasWeibullWindRose`` element holding one ``WeibullWind`` per sector.

WAsP writes the element either as the document root or nested inside a
``WaspHierarchyMember``, and has identified a wind rose's grid cell in several
ways over the years: by 1-based number (``ReferenceHeightNumber``,
``RoughnessLengthNumber`` / ``ReferenceRoughnessLengthNumber``), by value
(``ReferenceHeight``, ``RoughnessLength`` / ``ReferenceRoughnessLength``), or
by number alone with the values listed once in a ``StandardConditions``
element. All of these are accepted; whatever is missing is resolved from what
is present. A rose that cannot be placed on the grid, a grid cell without a
rose, a cell with two roses, and a rose missing a sector all raise
``ValueError``: the file declares a full grid, and a partial one would come
out as silent zeros.

Data contract: ``wdfreq`` is stored per (sector, height, roughness) in the
file -- unlike ``.lib``, where it varies with roughness only -- and is kept
3-D here. It is normalized along the sector axis to sum to 1, so
:func:`read_gwc` and :func:`~windkit.io.wasp.lib.read_lib` share the same
"fractions (0-1)" contract. A and k are raw Weibull parameters.

Besides the wind roses, the element can carry the mesoscale climate WAsP
generalized with: ``BarometricReferenceData`` (the reference pressure,
temperature and humidity behind the air density), ``StabilityInputs`` (the
sector-wise temperature and boundary-layer-height scales) and
``GeostrophicShearRose`` (the sector-wise baroclinicity). Only the barometric
block is written by older WAsP versions, and each is ``None`` when absent.
Their values are returned under the names PyWAsP and WindKit use for them,
not the WAsP attribute names, so that a file written from a PyWAsP
generalization reads back as what went in.

Location metadata is optional in the format. :func:`parse_gwc_element` reads
only what is inside the element (an embedded ``RveaLatitudeLongitudeCoordinate``
and the ``Description`` attribute); :func:`read_gwc` additionally falls back to
a ``RveaAnemometerSiteDetails`` element anywhere in the file, which is where
WAsP-exported hierarchies keep the mast position and height. Absent values are
``None``.

Error messages locate an element by bracketing a **zero-based index** into the
document order of the elements this module reads::

    site.gwc: WindAtlasWeibullWindRose[3]: WeibullWind[0]: missing required attribute 'WeibullA'
"""

import numpy as np
from lxml import etree

from windkit.io.wasp._common import (
    float_or_none,
    int_or_none,
    required_float,
    required_int,
    to_float,
)
from windkit.io.wasp._rvea import (
    _LATLON_TAG,
    _SITE_DETAILS_TAG,
    parse_anemometer_site_details,
    parse_latitude_longitude_coordinate,
    parse_sector_rose,
)

__all__ = ["read_gwc", "parse_gwc_element"]

_GWC_TAG = "RveaGeneralisedMeanWindClimate"

# Output key -> (attribute, reader) of a StabilityInputsTstarSector element
_STABILITY_FIELDS = {
    "sector": ("CentreAngleDegrees", required_float),
    "mean_temp_scale_land": ("TStarMeanLand", required_float),
    "rms_temp_scale_land": ("TStarStdDevLand", required_float),
    "mean_temp_scale_sea": ("TStarMeanWater", required_float),
    "rms_temp_scale_sea": ("TStarStdDevWater", required_float),
    "mean_pblh_scale_land": ("HstarMeanLand", required_float),
    "mean_pblh_scale_sea": ("HstarMeanWater", required_float),
}
# Output key -> (attribute, reader) of a GeostrophicShearVector element
_GEOSTROPHIC_SHEAR_FIELDS = {
    "sector": ("CentreAngleDegrees", required_float),
    "mean_dgdz": ("Magnitude", required_float),
    "mean_dgdz_dir": ("Direction", required_float),
}
# Output key -> required attribute of a BarometricReferenceData element
_BAROMETRIC_FIELDS = {
    "source_elevation": "AltitudeAslForReferencePressure",
    "source_elevation_temperature": "AltitudeAslForReferenceTemperature",
    "surface_pressure": "ReferencePressure",
    "temperature_celcius": "ReferenceTemperatureCelcius",
    "relative_humidity": "RelativeHumidity",
}


def _first_int_or_none(attrib, keys, context):
    """Return the first of ``keys`` present in ``attrib`` as an int, else None."""
    for key in keys:
        value = int_or_none(attrib, key, context)
        if value is not None:
            return value
    return None


def _first_float_or_none(attrib, keys, context):
    """Return the first of ``keys`` present in ``attrib`` as a float, else None."""
    for key in keys:
        value = float_or_none(attrib, key, context)
        if value is not None:
            return value
    return None


def _parse_standard_conditions(element, context):
    """Parse the reference tables of a ``StandardConditions`` element.

    Returns ``(reference_roughness, reference_height)``; either is ``None``
    when its table is absent.
    """
    reference_roughness, reference_height = None, None

    def table(parent, tag, key):
        # Entries without the value attribute are skipped, as they always were.
        return np.array(
            [
                to_float(e.attrib[key], key, f"{context}: {tag}[{i}]")
                for i, e in enumerate(parent.findall(f".//{tag}"))
                if key in e.attrib
            ],
            dtype=np.float64,
        )

    roughness_table = element.find(".//ReferenceRoughnessLengths")
    if roughness_table is not None:
        reference_roughness = table(
            roughness_table, "RoughnessLength", "AerodynamicRoughnessLengthMetres"
        )

    height_table = element.find(".//ReferenceHeights")
    if height_table is not None:
        reference_height = table(height_table, "Height", "HeightAglMetres")

    return reference_roughness, reference_height


def _parse_barometric_reference_data(element, context):
    """Parse a ``BarometricReferenceData`` element into the reference values for air density."""
    data = {
        key: required_float(element.attrib, attribute, context)
        for key, attribute in _BAROMETRIC_FIELDS.items()
    }
    # The temperature lapse rate is written by WAsP 12.6 and newer only
    data["lapse_rate"] = float_or_none(element.attrib, "TemperatureLapseRate", context)
    return data


def _resolve_grid_cell(number, value, reference, n_cells, what, context):
    """Turn whatever a wind rose says about one grid axis into (index, value).

    ``number`` is the file's 1-based number (or None), ``value`` the physical
    value (or None) and ``reference`` the ``StandardConditions`` table for the
    axis (or None). Returns a 0-based index and the value.
    """
    if number is None and value is None:
        raise ValueError(f"{context}: neither a {what} number nor a {what} is given")

    if number is None:
        if reference is None:
            raise ValueError(
                f"{context}: {what} {value} is given without a number and there "
                f"is no StandardConditions table of {what}s to look it up in"
            )
        matches = np.flatnonzero(np.isclose(reference, value))
        if len(matches) == 0:
            raise ValueError(
                f"{context}: {what} {value} is not in StandardConditions {reference}"
            )
        index = int(matches[0])
    else:
        index = number - 1

    if not 0 <= index < n_cells:
        raise ValueError(
            f"{context}: {what} number {index + 1} is outside 1..{n_cells}"
        )

    if value is None:
        if reference is None:
            raise ValueError(
                f"{context}: {what} number {index + 1} is given without a value "
                f"and there is no StandardConditions table of {what}s to look it "
                "up in"
            )
        if index >= len(reference):
            raise ValueError(
                f"{context}: {what} number {index + 1} is outside the "
                f"{len(reference)} entries of StandardConditions"
            )
        value = float(reference[index])

    return index, value


def _find_gwc_element(root, context):
    """Return the ``RveaGeneralisedMeanWindClimate`` at or below ``root``."""
    element = root if root.tag == _GWC_TAG else root.find(f".//{_GWC_TAG}")
    if element is None:
        raise ValueError(f"{context}: no {_GWC_TAG} element found")
    return element


def read_gwc(filepath):
    """Read a WAsP .gwc file and return parsed data.

    The ``RveaGeneralisedMeanWindClimate`` element may be the document root or
    nested anywhere below it. The horizontal position, the height and the
    description come from the element itself when it carries them, and
    otherwise from a ``RveaAnemometerSiteDetails`` element anywhere in the
    file. The position is taken from one source as a pair; an element that
    gives only a latitude is not completed with the site's longitude. An
    empty element ``Description`` defers to a non-empty site one.

    Parameters
    ----------
    filepath : str or Path
        Path to the ``.gwc`` file.

    Returns
    -------
    dict
        See :func:`parse_gwc_element`.

    Raises
    ------
    lxml.etree.XMLSyntaxError
        If the file is not well-formed XML. Subclasses ``SyntaxError``.
    ValueError
        If the file holds no ``RveaGeneralisedMeanWindClimate`` element, or a
        required element or attribute is missing, as described in
        :func:`parse_gwc_element`.
    """
    root = etree.parse(str(filepath)).getroot()
    context = str(filepath)

    data = parse_gwc_element(_find_gwc_element(root, context), context=context)

    site = root.find(f".//{_SITE_DETAILS_TAG}")
    if site is not None:
        site_data = parse_anemometer_site_details(
            site, f"{context}: {_SITE_DETAILS_TAG}"
        )
        coords = data["coords"]
        # The horizontal position is taken from one source as a pair, so a
        # half-given coordinate in the element is not completed from the site.
        if coords["west_east"] is None and coords["south_north"] is None:
            coords["west_east"] = site_data["longitude"]
            coords["south_north"] = site_data["latitude"]
        if coords["height"] is None:
            coords["height"] = site_data["height"]
        # WAsP writes Description="" freely; an empty one defers to the site.
        if not data["metadata"]["description"] and site_data["description"]:
            data["metadata"]["description"] = site_data["description"]

    return data


def parse_gwc_element(gwc, context="GWC element"):
    """Parse a ``RveaGeneralisedMeanWindClimate`` XML element.

    Only the ``.tag`` / ``.attrib`` / ``.find`` / ``.findall`` subset of the
    ElementTree interface is used, so both ``lxml.etree`` and
    ``xml.etree.ElementTree`` elements are accepted.

    Parameters
    ----------
    gwc : lxml.etree._Element or xml.etree.ElementTree.Element
        The ``RveaGeneralisedMeanWindClimate`` element.
    context : str, optional
        Identifier used in error messages, typically the source file path.

    Returns
    -------
    dict
        Dictionary with keys:

        - ``"A"`` : ndarray, shape (n_sectors, n_heights, n_roughnesses)
        - ``"k"`` : ndarray, same shape as *A*
        - ``"wdfreq"`` : ndarray, same shape as *A*, normalized along the
          sector axis (0-1)
        - ``"sector"`` : ndarray, shape (n_sectors,), sector centre angles in
          degrees
        - ``"gen_roughness"`` : ndarray, shape (n_roughnesses,)
        - ``"gen_height"`` : ndarray, shape (n_heights,)
        - ``"coords"`` : dict with ``"west_east"``, ``"south_north"``,
          ``"height"``; the first two come from an embedded
          ``RveaLatitudeLongitudeCoordinate`` and ``"height"`` is always
          ``None`` (the element does not carry one). Values are ``None`` when
          absent.
        - ``"metadata"`` : dict with ``"description"`` (the ``Description``
          attribute, or ``None`` when absent)
        - ``"barometric_reference"`` : dict with the floats
          ``"source_elevation"``, ``"source_elevation_temperature"``,
          ``"surface_pressure"`` (Pa), ``"temperature_celcius"``,
          ``"relative_humidity"`` (%) and ``"lapse_rate"`` (K/m, ``None``
          before WAsP 12.6), from ``BarometricReferenceData``
        - ``"stability_inputs"`` : dict with arrays of shape (n_sectors,)
          ``"sector"``, ``"mean_temp_scale_land"``, ``"rms_temp_scale_land"``,
          ``"mean_temp_scale_sea"``, ``"rms_temp_scale_sea"``,
          ``"mean_pblh_scale_land"`` and ``"mean_pblh_scale_sea"``, from
          ``StabilityInputs``
        - ``"geostrophic_shear"`` : dict with arrays of shape (n_sectors,)
          ``"sector"``, ``"mean_dgdz"`` (1/s) and ``"mean_dgdz_dir"``
          (degrees), from ``GeostrophicShearRose``

        The last three are ``None`` when the element does not carry them.

    Raises
    ------
    WindkitFileFormatError
        If a required attribute is missing or an attribute does not parse, or
        the stability inputs or geostrophic shear lack a sector or repeat one.
    ValueError
        If the element has another tag, holds no ``WindAtlasWeibullWindRose``,
        the grid size cannot be determined, a wind rose cannot be placed on
        the grid, a grid cell has no rose or more than one, or a rose lacks a
        sector or repeats one. ``WindkitFileFormatError`` subclasses it.
    """
    if gwc.tag != _GWC_TAG:
        raise ValueError(f"{context}: expected {_GWC_TAG}, got {gwc.tag}")

    attrib = gwc.attrib
    n_sectors = _first_int_or_none(attrib, ("CountOfSectors", "CountOfSector"), context)
    n_heights = int_or_none(attrib, "CountOfReferenceHeights", context)
    n_roughnesses = int_or_none(attrib, "CountOfReferenceRoughnessLengths", context)

    coords = {"west_east": None, "south_north": None, "height": None}
    coordinate = gwc.find(f".//{_LATLON_TAG}")
    if coordinate is not None:
        latlon = parse_latitude_longitude_coordinate(
            coordinate, f"{context}: {_LATLON_TAG}"
        )
        coords["west_east"] = latlon["longitude"]
        coords["south_north"] = latlon["latitude"]

    reference_roughness, reference_height = None, None
    standard = gwc.find(".//StandardConditions")
    if standard is not None:
        reference_roughness, reference_height = _parse_standard_conditions(
            standard, f"{context}: StandardConditions"
        )

    barometric = gwc.find(".//BarometricReferenceData")
    barometric_reference = (
        None
        if barometric is None
        else _parse_barometric_reference_data(
            barometric, f"{context}: BarometricReferenceData"
        )
    )

    stability = gwc.find(".//StabilityInputsTstarRose")
    stability_inputs = (
        None
        if stability is None
        else parse_sector_rose(
            stability,
            "StabilityInputsTstarSector",
            _STABILITY_FIELDS,
            f"{context}: StabilityInputsTstarRose",
        )
    )

    shear = gwc.find(".//GeostrophicShearRose")
    geostrophic_shear = (
        None
        if shear is None
        else parse_sector_rose(
            shear,
            "GeostrophicShearVector",
            _GEOSTROPHIC_SHEAR_FIELDS,
            f"{context}: GeostrophicShearRose",
        )
    )

    roses = gwc.findall(".//WindAtlasWeibullWindRose")
    if len(roses) == 0:
        raise ValueError(f"{context}: no WindAtlasWeibullWindRose elements found")

    if n_sectors is None:
        n_sectors = int_or_none(
            roses[0].attrib, "CountOfSectors", f"{context}: WindAtlasWeibullWindRose[0]"
        )
    if n_sectors is None:
        n_sectors = len(roses[0].findall(".//WeibullWind"))
    if n_heights is None and reference_height is not None:
        n_heights = len(reference_height)
    if n_roughnesses is None and reference_roughness is not None:
        n_roughnesses = len(reference_roughness)

    for count, name, what in (
        (n_heights, "CountOfReferenceHeights", "reference heights"),
        (n_roughnesses, "CountOfReferenceRoughnessLengths", "roughness lengths"),
    ):
        if count is None:
            raise ValueError(
                f"{context}: cannot determine the grid size: no '{name}' "
                f"attribute and no StandardConditions table of {what}"
            )

    shape = (n_sectors, n_heights, n_roughnesses)
    A = np.zeros(shape, dtype=np.float64)
    k = np.zeros(shape, dtype=np.float64)
    wdfreq = np.zeros(shape, dtype=np.float64)
    sector = np.zeros(n_sectors, dtype=np.float64)
    gen_roughness = np.zeros(n_roughnesses, dtype=np.float64)
    gen_height = np.zeros(n_heights, dtype=np.float64)
    filled = np.zeros((n_heights, n_roughnesses), dtype=bool)

    for i, rose in enumerate(roses):
        rose_context = f"{context}: WindAtlasWeibullWindRose[{i}]"
        rose_attrib = rose.attrib

        iz0, z0 = _resolve_grid_cell(
            _first_int_or_none(
                rose_attrib,
                ("ReferenceRoughnessLengthNumber", "RoughnessLengthNumber"),
                rose_context,
            ),
            _first_float_or_none(
                rose_attrib,
                ("RoughnessLength", "ReferenceRoughnessLength"),
                rose_context,
            ),
            reference_roughness,
            n_roughnesses,
            "roughness length",
            rose_context,
        )
        iz, z = _resolve_grid_cell(
            int_or_none(rose_attrib, "ReferenceHeightNumber", rose_context),
            float_or_none(rose_attrib, "ReferenceHeight", rose_context),
            reference_height,
            n_heights,
            "reference height",
            rose_context,
        )
        if filled[iz, iz0]:
            raise ValueError(
                f"{rose_context}: reference height {z} and roughness length {z0} "
                "already have a WindAtlasWeibullWindRose"
            )
        filled[iz, iz0] = True
        gen_roughness[iz0] = z0
        gen_height[iz] = z

        sectors_seen = np.zeros(n_sectors, dtype=bool)
        for j, wind in enumerate(rose.findall(".//WeibullWind")):
            wind_context = f"{rose_context}: WeibullWind[{j}]"
            wind_attrib = wind.attrib
            isec = required_int(wind_attrib, "Index", wind_context) - 1
            if not 0 <= isec < n_sectors:
                raise ValueError(
                    f"{wind_context}: Index {isec + 1} is outside 1..{n_sectors}"
                )
            if sectors_seen[isec]:
                raise ValueError(f"{wind_context}: Index {isec + 1} appears twice")
            sectors_seen[isec] = True
            sector[isec] = required_float(
                wind_attrib, "CentreAngleDegrees", wind_context
            )
            A[isec, iz, iz0] = required_float(wind_attrib, "WeibullA", wind_context)
            k[isec, iz, iz0] = required_float(wind_attrib, "WeibullK", wind_context)
            wdfreq[isec, iz, iz0] = required_float(
                wind_attrib, "SectorFrequency", wind_context
            )
        if not sectors_seen.all():
            n_missing = int((~sectors_seen).sum())
            raise ValueError(
                f"{rose_context}: {n_missing} of {n_sectors} sectors have no WeibullWind"
            )

    if not filled.all():
        n_missing = int((~filled).sum())
        raise ValueError(
            f"{context}: {n_missing} of {filled.size} grid cells have no "
            "WindAtlasWeibullWindRose"
        )

    wdfreq_sum = wdfreq.sum(axis=0, keepdims=True)
    wdfreq_sum[wdfreq_sum == 0] = 1.0  # avoid division by zero
    wdfreq = wdfreq / wdfreq_sum

    return {
        "A": A,
        "k": k,
        "wdfreq": wdfreq,
        "sector": sector,
        "gen_roughness": gen_roughness,
        "gen_height": gen_height,
        "coords": coords,
        "metadata": {"description": attrib.get("Description")},
        "barometric_reference": barometric_reference,
        "stability_inputs": stability_inputs,
        "geostrophic_shear": geostrophic_shear,
    }
