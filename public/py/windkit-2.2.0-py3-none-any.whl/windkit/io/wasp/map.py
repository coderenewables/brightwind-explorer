# (c) 2026 DTU Wind Energy
"""Read and write WAsP .map files.

The format is documented in the WAsP help facility, under "Technical
reference | WAsP file formats".

The .map format stores a vector map as a sequence of polylines. Each line is
introduced by a header holding its attributes and its point count, followed by
the coordinate pairs themselves, which may be spread over any number of
physical lines. A line header carries

============  ===================================  =========================
``n_fields``  contents                             meaning
============  ===================================  =========================
1             ``n_pts``                            no attributes
2             ``elev n_pts``                       elevation
3             ``z0_left z0_right n_pts``           roughness change
4             ``z0_left z0_right elev n_pts``      both, on one line
============  ===================================  =========================

The returned dict mirrors the file. Every line becomes one row, including the
ones that carry no attributes, and a row's absent attributes are ``nan``. No
line is filtered out and no attribute is derived. Nothing is converted to a
geometry or a CRS -- those belong to the layer above.

The four header lines are returned raw, and this module applies neither of the
transforms they define: lines 2 and 3 are fixed points giving a user-to-metric
transform of ``x`` and ``y``, and line 4 is a scale and offset such that
``z_metric = z_scale * (z_user + z_offset)``.

Malformed input raises ``WindkitFileFormatError`` naming the file and, where
the file's structure allows it, the line::

    site.map:6: line 0 declares 9 points but at least 10 were read
"""

import json
import math
import re
import warnings
from functools import lru_cache
from importlib.metadata import version
from importlib.resources import files
from types import MappingProxyType

import numpy as np

from windkit._errors import WindkitFileFormatError
from windkit.io.wasp._common import detect_encoding, sniff_encoding

__all__ = ["read_map", "write_map", "format_map"]

#: One of several spellings of the identity transform -- the WAsP GUI writes the
#: second point as ``1.0 1.0 1.0 1.0``. Test with :func:`_is_identity_fixed_points`.
_IDENTITY_FIXED_POINTS = np.array([[0.0, 0.0, 0.0, 0.0], [1.0, 0.0, 1.0, 0.0]])

_VERSION_RE = re.compile(r"\d+\.\d+(?:\.\d+)?")


def _validate_description(description):
    """Check that a description can be a ``.map`` file's first line."""
    if not description:
        raise ValueError("Description cannot be empty for a .map file.")
    if "\n" in description or "\r" in description:
        raise ValueError("Description cannot contain a line break.")
    return description


@lru_cache(maxsize=2)
def _epsg_table(mode):
    """Load the map-header-to-EPSG lookup table.

    Parameters
    ----------
    mode : {"r", "w"}
        Whether to load the projection strings used for reading or for writing
        ``.map`` files. More variants are recognised on read than are written,
        because only the strings the current WAsP GUI understands are safe to
        write.

    Returns
    -------
    mappingproxy
        Mapping of map-editor projection string to EPSG code. Read-only: the
        cache hands the same object to every caller.
    """
    suffix = "" if mode == "w" else "_read"
    path = files("windkit.data") / f"map_file_header_to_epsg{suffix}.json"
    return MappingProxyType(json.loads(path.read_text(encoding="utf-8")))


def _is_identity_fixed_points(fixed_points):
    """Return whether the fixed points leave ``x`` and ``y`` unchanged.

    Each point gives a user coordinate and a metric one. The transform is the
    identity exactly when both points name the same coordinate twice, so the
    rows themselves may differ: the WAsP GUI writes ``1.0 1.0 1.0 1.0`` where
    windkit writes ``1.0 0.0 1.0 0.0``.

    Parameters
    ----------
    fixed_points : ndarray, shape (2, 4)
        Lines 2 and 3 of a ``.map`` header, as ``read_map`` returns them.

    Returns
    -------
    bool
    """
    user, metric = fixed_points[:, :2], fixed_points[:, 2:]
    return bool(np.array_equal(user, metric))


def _epsg_from_header(header_line):
    """Return the EPSG code named in a ``.map`` header line.

    Parameters
    ----------
    header_line : str
        The first line of a ``.map`` file.

    Returns
    -------
    int or None
        The EPSG code, or None when the line names no CRS this module knows.
    """
    for crs_string, epsg in _epsg_table("r").items():
        if crs_string in header_line:
            return epsg
    return None


def _header_from_epsg(epsg):
    """Return the WAsP map-editor projection string for an EPSG code.

    Parameters
    ----------
    epsg : int
        EPSG code.

    Returns
    -------
    str or None
        The projection string the WAsP GUI writes for this CRS, or None when
        the WAsP GUI has no name for it.
    """
    for crs_string, code in _epsg_table("w").items():
        if code == epsg:
            return crs_string
    return None


def _epsg_codes():
    """Return the EPSG codes the WAsP map editor can name.

    These are the codes :func:`_header_from_epsg` resolves.

    Returns
    -------
    tuple of int
    """
    return tuple(dict.fromkeys(_epsg_table("w").values()))


def _format_header(description, epsg):
    """Build the first line of a ``.map`` file.

    Parameters
    ----------
    description : str
        Free text describing the map. Must be non-empty, because the WAsP map
        editor will not open a file whose description is blank.
    epsg : int or None
        EPSG code of the map's CRS.

    Returns
    -------
    str
        A line of the form ``+{description} | {crs} | windkit v{version}``.

    Raises
    ------
    ValueError
        If *description* is empty or contains a line break.

    Warns
    -----
    UserWarning
        If *epsg* is None, or has no WAsP map-editor name. The CRS field is then
        written empty, and neither WAsP nor :func:`read_map` can recover the CRS
        from the resulting file.
    """
    _validate_description(description)

    crs_string = None if epsg is None else _header_from_epsg(epsg)
    if crs_string is None:
        cause = (
            "The map has no CRS"
            if epsg is None
            else f"EPSG:{epsg} has no WAsP map-editor name"
        )
        warnings.warn(
            f"{cause}; the CRS field will be written empty and the file's CRS "
            "cannot be detected on read.",
            UserWarning,
            stacklevel=2,
        )
        crs_string = ""

    match = _VERSION_RE.match(version("windkit"))
    wk_version = match.group() if match else ""
    return f"+{description} | {crs_string} | windkit v{wk_version}"


def _floats(fields, filepath, lineno):
    """Convert a whitespace-split line to floats, reporting where it came from."""
    try:
        return [float(field) for field in fields]
    except ValueError:
        raise WindkitFileFormatError(
            f"{filepath}:{lineno}: line contains a value that is not a number: "
            f"{' '.join(fields)!r}"
        ) from None


def _count(value, filepath, lineno):
    """Interpret a line header's last field as a point count.

    Finiteness is checked first: ``int(inf)`` raises ``OverflowError``, not the
    ``WindkitFileFormatError`` this module promises.
    """
    if not math.isfinite(value) or value < 0 or value != int(value):
        raise WindkitFileFormatError(
            f"{filepath}:{lineno}: point count must be a non-negative integer, "
            f"got {value}"
        )
    return int(value)


def _next_fields(reader, filepath, what):
    """Return the next non-blank line's fields, raising at end of file."""
    for lineno, raw in reader:
        fields = raw.split()
        if fields:
            return lineno, fields
    raise WindkitFileFormatError(f"{filepath}: unexpected end of file, expected {what}")


def _next_floats(reader, filepath, what, n_expected):
    """Return the next non-blank line as exactly *n_expected* floats.

    Raises ``WindkitFileFormatError`` naming *what* at end of file or when the
    line does not hold *n_expected* numbers.
    """
    lineno, fields = _next_fields(reader, filepath, what)
    values = _floats(fields, filepath, lineno)
    if len(values) != n_expected:
        raise WindkitFileFormatError(
            f"{filepath}:{lineno}: {what} must have {n_expected} values, "
            f"got {len(values)}"
        )
    return values


def _read_file_header(reader, filepath):
    """Parse the four header lines of a ``.map`` file."""
    try:
        _, raw = next(reader)
    except StopIteration:
        raise WindkitFileFormatError(f"{filepath}: file is empty") from None
    description = raw.rstrip("\r\n")

    fixed_points = np.empty((2, 4), dtype=np.float64)
    for i in range(2):
        fixed_points[i] = _next_floats(reader, filepath, f"fixed point #{i + 1}", 4)

    z_scale, z_offset = _next_floats(reader, filepath, "z scale and offset", 2)

    return {
        "description": description,
        "epsg": _epsg_from_header(description),
        "fixed_points": fixed_points,
        "z_scale": z_scale,
        "z_offset": z_offset,
    }


def _read_points(reader, n_pts, filepath, index):
    """Read exactly *n_pts* coordinate pairs for line *index*."""
    if n_pts == 0:
        return np.empty((0, 2), dtype=np.float64)

    n_values = 2 * n_pts
    buffer = []
    for lineno, raw in reader:
        fields = raw.split()
        if not fields:
            continue
        values = _floats(fields, filepath, lineno)
        if len(values) % 2:
            raise WindkitFileFormatError(
                f"{filepath}:{lineno}: coordinate line has an odd number of "
                f"values ({len(values)}); coordinates come in x y pairs"
            )
        buffer.extend(values)
        if len(buffer) > n_values:
            raise WindkitFileFormatError(
                f"{filepath}:{lineno}: line {index} declares {n_pts} points but "
                f"at least {len(buffer) // 2} were read"
            )
        if len(buffer) == n_values:
            return np.array(buffer, dtype=np.float64).reshape(n_pts, 2)

    raise WindkitFileFormatError(
        f"{filepath}: unexpected end of file; line {index} declares {n_pts} "
        f"points, {len(buffer) // 2} were read"
    )


def _parse_line_header(values, filepath, lineno):
    """Split a line header into ``(elev, z0_left, z0_right, n_pts)``."""
    nan = np.nan
    n_fields = len(values)
    if n_fields == 1:
        elev, z0_left, z0_right, n_pts = nan, nan, nan, values[0]
    elif n_fields == 2:
        elev, n_pts = values
        z0_left, z0_right = nan, nan
    elif n_fields == 3:
        z0_left, z0_right, n_pts = values
        elev = nan
    elif n_fields == 4:
        z0_left, z0_right, elev, n_pts = values
    elif n_fields == 5:
        raise WindkitFileFormatError(
            f"{filepath}:{lineno}: line header has 5 fields; .map files with "
            "displacement heights are not supported"
        )
    else:
        raise WindkitFileFormatError(
            f"{filepath}:{lineno}: line header has {n_fields} fields, expected 1 to 4"
        )
    return elev, z0_left, z0_right, _count(n_pts, filepath, lineno)


#: Bytes of a ``.map`` sniffed to choose an encoding. Covers the first line,
#: the only free text a well-formed ``.map`` holds, unless the description is
#: itself longer than this -- hence :func:`_with_inferred_encoding`'s fallback.
_SNIFF_CHUNK_BYTES = 8192


def _sniff_encoding(filepath):
    """Guess the encoding of *filepath* from its first chunk.

    The chunk may not hold every non-ASCII byte in the file, so the answer is a
    guess: read through :func:`_with_inferred_encoding`, which corrects it.

    Raises
    ------
    WindkitFileFormatError
        If the chunk has a byte-order mark or looks like UTF-16 but does not
        decode as such.
    """
    return sniff_encoding(filepath, _SNIFF_CHUNK_BYTES)


def _with_inferred_encoding(filepath, parse):
    """Call ``parse(encoding)`` under the encoding inferred for *filepath*.

    The first chunk picks the encoding. A file holding a non-ASCII byte the
    chunk did not see fails to decode under that guess, and *parse* is retried
    under the full :func:`detect_encoding` scan, so *parse* must be safe to run
    twice. Only a decode failure triggers the retry; a ``WindkitFileFormatError``
    from *parse* means a malformed file and propagates.

    Raises
    ------
    WindkitFileFormatError
        If no candidate encoding can decode the file.
    """
    try:
        return parse(_sniff_encoding(filepath))
    except (UnicodeDecodeError, UnicodeError):
        return parse(detect_encoding(filepath))


def _epsg_from_map_file(filepath, encoding="infer"):
    """Return the EPSG code named in a ``.map`` file's first line.

    Reads that one line and nothing else. The rest of the header is neither
    parsed nor validated, so a file that is not a ``.map`` at all -- a WAsP
    workspace holds Surfer ``DSAA`` grids under the same ``.tmp`` extension --
    yields None rather than raising.

    Parameters
    ----------
    filepath : str or Path
        Path to the ``.map`` file.
    encoding : str, optional
        File encoding. If ``"infer"`` (default), the encoding is detected
        automatically.

    Returns
    -------
    int or None
        The EPSG code, or None when the first line names no CRS this module
        knows.
    """

    def parse(enc):
        with open(filepath, encoding=enc, newline=None) as fobj:
            return _epsg_from_header(fobj.readline())

    if encoding != "infer":
        return parse(encoding)
    return _with_inferred_encoding(filepath, parse)


def _parse_map(filepath, encoding):
    """Parse a ``.map`` file in a single pass, decoding it as *encoding*."""
    elev, z0_left, z0_right, points = [], [], [], []
    with open(filepath, encoding=encoding, newline=None) as fobj:
        reader = enumerate(fobj, start=1)
        header = _read_file_header(reader, filepath)

        for lineno, raw in reader:
            fields = raw.split()
            if not fields:
                continue
            values = _floats(fields, filepath, lineno)
            line_elev, line_z0l, line_z0r, n_pts = _parse_line_header(
                values, filepath, lineno
            )
            points.append(_read_points(reader, n_pts, filepath, len(points)))
            elev.append(line_elev)
            z0_left.append(line_z0l)
            z0_right.append(line_z0r)

    return {
        "points": points,
        "elev": np.array(elev, dtype=np.float64),
        "z0_left": np.array(z0_left, dtype=np.float64),
        "z0_right": np.array(z0_right, dtype=np.float64),
        "header": header,
    }


def read_map(filepath, encoding="infer"):
    """Read a WAsP ``.map`` file and return parsed data.

    Any line ending is accepted: CRLF as WAsP writes it, and the LF or CR a
    file picks up from version control or a text editor.

    Parameters
    ----------
    filepath : str or Path
        Path to the ``.map`` file.
    encoding : str, optional
        File encoding. If ``"infer"`` (default), the encoding is detected
        automatically.

    Returns
    -------
    dict
        Dictionary with keys:

        - ``"points"`` : list of ndarray, shape (n_pts, 2), one per line
        - ``"elev"`` : ndarray, shape (n_lines,), nan where the line carries
          no elevation
        - ``"z0_left"`` : ndarray, shape (n_lines,), nan where the line
          carries no roughness change
        - ``"z0_right"`` : ndarray, same as *z0_left*
        - ``"header"`` : dict with ``"description"`` (the first line, verbatim),
          ``"epsg"`` (int or None), ``"fixed_points"`` (ndarray, shape (2, 4)),
          ``"z_scale"`` and ``"z_offset"``

    Raises
    ------
    WindkitFileFormatError
        If the file is empty or its four header lines are malformed; if a line
        header does not hold 1 to 4 fields; if a line header declares a
        displacement height; if a point count is not a non-negative integer;
        if a coordinate line holds an odd number of values; if a line supplies
        more points than it declares; or if the file ends inside a line.

    Notes
    -----
    Only over-supply is detected. A line's coordinates may wrap across any
    number of physical lines, so a header declaring *more* points than its
    coordinates carry cannot be told from one whose coordinates wrap. Such a
    file yields corrupted geometry, and raises only if the field counts of what
    follows happen not to line up.

    Examples
    --------
    >>> data = read_map("site.map")  # doctest: +SKIP
    >>> is_elevation = ~np.isnan(data["elev"])  # doctest: +SKIP
    """
    if encoding != "infer":
        return _parse_map(filepath, encoding)
    return _with_inferred_encoding(filepath, lambda enc: _parse_map(filepath, enc))


def _line_attrs(elev, z0_left, z0_right, n_lines):
    """Normalise the optional attribute arrays to (n_lines,) float arrays."""
    out = []
    for name, values in (
        ("elev", elev),
        ("z0_left", z0_left),
        ("z0_right", z0_right),
    ):
        if values is None:
            out.append(np.full(n_lines, np.nan))
            continue
        values = np.asarray(values, dtype=np.float64)
        if values.shape != (n_lines,):
            raise ValueError(
                f"'{name}' has shape {values.shape}, expected ({n_lines},) to "
                f"match the {n_lines} lines in 'points'"
            )
        out.append(values)
    return out


def _format_transform(value, width=3):
    """Format a header transform value, right-justified, without losing precision.

    One decimal, as the WAsP GUI writes them. A value that one decimal cannot
    represent -- ``z_scale = 0.3048``, a map digitised in feet -- gets as many
    digits as it takes to read back unchanged.
    """
    text = f"{value:.1f}"
    if float(text) != value:
        text = repr(float(value))
    return f"{text:>{width}}"


def _iter_map_lines(points, header, elev, z0_left, z0_right, coord_decimals):
    """Yield the lines of a ``.map`` file, without their line terminators."""
    n_lines = len(points)
    elev, z0_left, z0_right = _line_attrs(elev, z0_left, z0_right, n_lines)

    if header is None or "description" not in header:
        raise ValueError(
            "'header' must be a dict holding a 'description', the file's first "
            "line -- for example the 'header' that read_map() returned."
        )
    description = _validate_description(header["description"])

    fixed_points = np.asarray(
        header.get("fixed_points", _IDENTITY_FIXED_POINTS), dtype=np.float64
    )
    if fixed_points.shape != (2, 4):
        raise ValueError(
            f"'fixed_points' has shape {fixed_points.shape}, expected (2, 4)"
        )

    yield description
    for row in fixed_points:
        yield " ".join(_format_transform(value) for value in row)
    yield (
        f"{_format_transform(header.get('z_scale', 1.0))} "
        f"{_format_transform(header.get('z_offset', 0.0), width=15)}"
    )

    for i, line_points in enumerate(points):
        line_points = np.asarray(line_points, dtype=np.float64)
        if line_points.ndim != 2 or line_points.shape[1] != 2:
            raise ValueError(
                f"points[{i}] has shape {line_points.shape}, expected (n_pts, 2)"
            )
        n_pts = line_points.shape[0]

        has_elev = not np.isnan(elev[i])
        left_is_nan, right_is_nan = np.isnan(z0_left[i]), np.isnan(z0_right[i])
        if left_is_nan != right_is_nan:
            raise ValueError(
                f"line {i} has only one of z0_left and z0_right; a roughness "
                "change line needs both"
            )
        has_z0 = not left_is_nan

        if has_z0 and has_elev:
            yield (
                f"{z0_left[i]:10.4f} {z0_right[i]:10.4f} {elev[i]:10.4f} {n_pts:10d}"
            )
        elif has_z0:
            yield f"{z0_left[i]:10.4f} {z0_right[i]:10.4f} {n_pts:10d}"
        elif has_elev:
            yield f"{elev[i]:10.4f} {n_pts:10d}"
        else:
            yield f"{n_pts:10d}"

        # A zero-point line has no coordinate line; "" would write a blank one.
        if n_pts:
            yield " ".join(
                f"{x:10.{coord_decimals}f} {y:10.{coord_decimals}f}"
                for x, y in line_points
            )


def format_map(
    points, header, elev=None, z0_left=None, z0_right=None, coord_decimals=1
):
    """Format vector map data as ``.map`` file content.

    Parameters
    ----------
    points : sequence of array_like, shape (n_pts, 2)
        Coordinates of each line.
    header : dict
        Must hold ``"description"``, the file's first line, which carries the
        map's CRS. May hold ``"fixed_points"``, ``"z_scale"`` and
        ``"z_offset"``, which default to the identity transform. Every other
        key is ignored, including the ``"epsg"`` that :func:`read_map` returns:
        the CRS is written only as part of ``"description"``, so changing
        ``"epsg"`` alone changes nothing.
    elev : array_like, shape (n_lines,), optional
        Elevation of each line, nan where the line has none. Defaults to all nan.
    z0_left, z0_right : array_like, shape (n_lines,), optional
        Roughness lengths either side of each line, nan where the line has
        none. Defaults to all nan. A line must have both or neither.
    coord_decimals : int, optional
        Decimal places written for each coordinate. Defaults to 1, which is
        what the WAsP GUI writes for a map in metres. This module cannot see
        the CRS, so a caller writing a geographic map must raise this itself:
        one decimal of a degree is roughly 11 km.

    Returns
    -------
    str
        The ``.map`` file content, with ``\\n`` line endings.

    Raises
    ------
    ValueError
        If *header* has no description, or an empty one, or one holding a line
        break; if ``header["fixed_points"]`` is not of shape (2, 4); if an
        attribute array's length does not match *points*; if a line has only one
        of *z0_left* and *z0_right*; or if a member of *points* is not of shape
        (n_pts, 2).

    See Also
    --------
    write_map : Write the same content to a file, without building the string.
    _format_header : Build the ``"description"`` that *header* needs.
    """
    lines = _iter_map_lines(points, header, elev, z0_left, z0_right, coord_decimals)
    return "\n".join(lines) + "\n"


def write_map(
    filepath, points, header, elev=None, z0_left=None, z0_right=None, coord_decimals=1
):
    """Write vector map data to a WAsP ``.map`` file.

    The file is written with CRLF line endings, which the WAsP GUI requires.
    A line with both an elevation and a roughness change is written as a
    four-field combination line; one with neither is written with a bare point
    count. :func:`read_map` reads back what this writes.

    The file is written as UTF-8, one of the encodings :func:`read_map` sniffs
    for. The WAsP map editor reads the header in the Windows ANSI code page, so
    keep descriptions ASCII when the file is meant to be opened there.

    Parameters
    ----------
    filepath : str or Path
        Path to the output file.
    points : sequence of array_like, shape (n_pts, 2)
        Coordinates of each line.
    header : dict
        Must hold ``"description"``. See :func:`format_map`.
    elev : array_like, shape (n_lines,), optional
        Elevation of each line, nan where the line has none.
    z0_left, z0_right : array_like, shape (n_lines,), optional
        Roughness lengths either side of each line, nan where the line has none.
    coord_decimals : int, optional
        Decimal places written for each coordinate. Defaults to 1. See
        :func:`format_map`.

    Raises
    ------
    ValueError
        If *header* has no description, or an empty one, or one holding a line
        break; if ``header["fixed_points"]`` is not of shape (2, 4); if an
        attribute array's length does not match *points*; if a line has only one
        of *z0_left* and *z0_right*; or if a member of *points* is not of shape
        (n_pts, 2).

    Examples
    --------
    Round-trip a ``.map``. The coordinates are written with one decimal, so
    pass ``coord_decimals`` too if the map is in degrees rather than metres.

    >>> data = read_map("in.map")  # doctest: +SKIP
    >>> write_map("out.map", **data)  # doctest: +SKIP
    """
    # Drain the generator before open() truncates the target, so a rejected
    # write does not leave a valid but shorter map behind.
    lines = list(
        _iter_map_lines(points, header, elev, z0_left, z0_right, coord_decimals)
    )
    with open(filepath, "w", newline="\r\n", encoding="utf-8") as fobj:
        for line in lines:
            fobj.write(line + "\n")
