"""Read WAsP .owc/.omwc files.

The .owc/.omwc format stores observed (binned) wind climate data as wind
speed frequency distributions per sector in XML. This module provides
low-level I/O functions that work with normalized (0-1) frequency values.

Required elements and attributes are validated at the file boundary: a
missing or unparseable one raises ``WindkitFileFormatError`` naming the file
and the attribute, in the style of :mod:`windkit.io.wasp.wtg`. Error messages
locate an element by bracketing a zero-based index into the file order::

    site.omwc: ObservedWind[3]: missing required attribute 'SectorFrequency'
"""

import numpy as np
from lxml import etree

from windkit._errors import WindkitFileFormatError
from windkit.io.wasp._common import required_float, required_int, required_str


def read_owc(filepath):
    """Read an .owc/.omwc XML file and return parsed data with normalized frequencies.

    Parameters
    ----------
    filepath : str or Path
        Path to the .owc or .omwc file.

    Returns
    -------
    dict
        See :func:`parse_owc_element`.

    Raises
    ------
    lxml.etree.XMLSyntaxError
        If the file is not well-formed XML. Subclasses ``SyntaxError``.
    WindkitFileFormatError
        If a required element or attribute is missing or unparseable, as
        described in :func:`parse_owc_element`.
    """
    tree = etree.parse(str(filepath))
    return parse_owc_element(tree.getroot(), context=str(filepath))


def _distribution(obs_wind, context):
    """Return an ``ObservedWind``'s ``SpeedFrequencyDistribution`` element."""
    distribution = obs_wind.find("SpeedFrequencyDistribution")
    if distribution is None:
        raise WindkitFileFormatError(f"{context}: missing SpeedFrequencyDistribution")
    return distribution


def _bins(distribution):
    """Return a distribution's bin elements, whatever their tag, skipping comments."""
    return [child for child in distribution if isinstance(child.tag, str)]


def parse_owc_element(owc, context="OWC element"):
    """Parse an lxml XML element for an observed wind climate.

    Parameters
    ----------
    owc : lxml.etree._Element
        The ``<RveaObservedWindClimate>`` root element.
    context : str, optional
        Identifier used in error messages, typically the source file path.

    Returns
    -------
    dict
        Dictionary with keys:
        - "wsfreq": ndarray(n_wsbins, n_sectors) - wind speed frequencies (0-1)
        - "wdfreq": ndarray(n_sectors) - wind direction frequencies (0-1)
        - "wsbins": ndarray(n_wsbins+1) - wind speed bin edges
        - "coords": dict with "south_north", "west_east", "height"
        - "metadata": dict with "description"

    Raises
    ------
    WindkitFileFormatError
        If ``CountOfSectors`` is absent or not an integer; if
        ``RveaAnemometerSiteDetails`` or one of its ``LatitudeDegrees``,
        ``LongitudeDegrees``, ``HeightAGL`` or ``Description`` attributes is
        absent; if there is no ``ObservedWind`` element; if the first sector's
        ``NumberOfBins`` is absent or negative; if an ``ObservedWind`` has no
        ``SpeedFrequencyDistribution``, an ``Index`` outside
        ``1..CountOfSectors`` or one already used, or a number of bins that
        differs from the first sector's ``NumberOfBins``; or if a numeric
        attribute does not parse.
    """
    n_sectors = required_int(owc.attrib, "CountOfSectors", context)

    site_details = owc.find("RveaAnemometerSiteDetails")
    if site_details is None:
        raise WindkitFileFormatError(f"{context}: missing RveaAnemometerSiteDetails")
    site_context = f"{context}: RveaAnemometerSiteDetails"
    site = site_details.attrib
    lat = required_float(site, "LatitudeDegrees", site_context)
    lon = required_float(site, "LongitudeDegrees", site_context)
    height = required_float(site, "HeightAGL", site_context)
    description = required_str(site, "Description", site_context)

    observed = owc.findall("ObservedWind")
    if not observed:
        raise WindkitFileFormatError(f"{context}: contains no ObservedWind elements")

    # Every sector shares the first sector's bin layout.
    first_context = f"{context}: ObservedWind[0]"
    n_wsbins = required_int(
        _distribution(observed[0], first_context).attrib,
        "NumberOfBins",
        f"{first_context}: SpeedFrequencyDistribution",
    )
    if n_wsbins < 0:
        raise WindkitFileFormatError(
            f"{first_context}: NumberOfBins must be non-negative, got {n_wsbins}"
        )
    ws_freq = np.zeros((n_wsbins, n_sectors))
    wd_freq = np.zeros(n_sectors)
    ws_bins = np.zeros(n_wsbins)

    seen = set()
    for i, obs_wind in enumerate(observed):
        obs_context = f"{context}: ObservedWind[{i}]"
        sec = required_int(obs_wind.attrib, "Index", obs_context) - 1
        if not 0 <= sec < n_sectors:
            raise WindkitFileFormatError(
                f"{obs_context}: Index {sec + 1} is outside 1..{n_sectors} "
                "(CountOfSectors)"
            )
        if sec in seen:
            raise WindkitFileFormatError(
                f"{obs_context}: Index {sec + 1} appears more than once"
            )
        seen.add(sec)

        bins = _bins(_distribution(obs_wind, obs_context))
        if len(bins) != n_wsbins:
            raise WindkitFileFormatError(
                f"{obs_context}: holds {len(bins)} speed bins, expected {n_wsbins}"
            )

        wd_freq[sec] = required_float(obs_wind.attrib, "SectorFrequency", obs_context)
        for ws_bin, ws in enumerate(bins):
            bin_context = f"{obs_context}: bin[{ws_bin}]"
            ws_bins[ws_bin] = required_float(ws.attrib, "UpperSpeedBound", bin_context)
            ws_freq[ws_bin, sec] = required_float(ws.attrib, "Frequency", bin_context)

    ws_bins = np.insert(ws_bins, 0, 0.0)

    return {
        "wsfreq": ws_freq,
        "wdfreq": wd_freq,
        "wsbins": ws_bins,
        "coords": {
            "south_north": lat,
            "west_east": lon,
            "height": height,
        },
        "metadata": {
            "description": description,
        },
    }
