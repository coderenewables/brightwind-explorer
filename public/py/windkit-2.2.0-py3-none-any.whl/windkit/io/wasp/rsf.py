# (c) 2026 DTU Wind Energy
"""Read and write WAsP .rsf/.wrg resource files.

The resource file format stores, for each site in a (possibly gridded)
set of sites, the location, height, sector-wise and combined Weibull
wind climate, and a power column. A ``.wrg`` file is a ``.rsf`` file
with one extra header line describing the regular grid::

    Nx Ny Xmin Ymin cell_size

Each data record is a fixed-width line (values always fall inside their
field, but the number format within a field is free)::

    Column  Width  Contents
    01-10   10     Site/grid point name (text)
    11-20   10     X-coordinate (easting) of the site [m]
    21-30   10     Y-coordinate (northing) of the site [m]
    31-38    8     Z-coordinate (elevation) of the site [m]
    39-43    5     Height above ground level [m a.g.l.]
    44-48    5     Weibull A-parameter for the total distribution [m/s]
    49-54    6     Weibull k-parameter for the total distribution
    55-69   15     Power density [W/m2] or power production [Wh/y]
    70-72    3     Number of sectors
    73-76    4     Frequency of occurrence for sector #1 [per mille]
    77-80    4     Weibull A-parameter for sector #1 [m/s * 10]
    81-85    5     Weibull k-parameter for sector #1 [* 100]
    86-...  13     As columns 73-85 for each further sector

Data contract: the sector-wise values are descaled on read and rescaled
on write by the format's fixed factors — ``A`` by 10, ``k`` by 100 and
``wdfreq`` by 1000 (per mille to 0-1 fraction). The power column is
returned raw, without interpretation: whether it holds power density or
power production cannot be determined from the file, so interpreting
(and unit-converting) it is left to the caller.
"""

import re

import numpy as np

from windkit._errors import WindkitFileFormatError
from windkit.io.wasp._common import detect_encoding

_WRG_HEADER_PATTERN = re.compile(
    r"\s*(\d+)\s+(\d+)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s*"
)

# (start, stop) string slices of the fixed-width fields before the sector data
_MAIN_FIELDS = {
    "name": (0, 10),
    "west_east": (10, 20),
    "south_north": (20, 30),
    "site_elev": (30, 38),
    "height": (38, 43),
    "A_combined": (43, 48),
    "k_combined": (48, 54),
    "power": (54, 69),
    "n_sectors": (69, 72),
}
_SECTOR_WIDTHS = (4, 4, 5)  # wdfreq, A, k


def _parse_wrg_header(line):
    """Parse a WRG grid-header line into a dict, or return None."""
    match = _WRG_HEADER_PATTERN.fullmatch(line)
    if match is None:
        return None
    nx, ny, xmin, ymin, cell_size = match.groups()
    return {
        "nx": int(nx),
        "ny": int(ny),
        "xmin": float(xmin),
        "ymin": float(ymin),
        "cell_size": float(cell_size),
    }


def _to_float(field, context):
    """Convert a fixed-width field to float, mapping blank fields to NaN."""
    field = field.strip()
    if not field:
        return float("nan")
    try:
        return float(field)
    except ValueError:
        raise WindkitFileFormatError(
            f"{context}: field is not a number: {field!r}"
        ) from None


def read_rsf(filepath, encoding="infer"):
    """Read a WAsP .rsf or .wrg resource file and return parsed data.

    The WRG grid header is detected automatically, so both formats are
    read by this one function.

    Parameters
    ----------
    filepath : str, Path or file-like
        Path to the ``.rsf``/``.wrg`` file, or an open text stream.
    encoding : str, optional
        File encoding. If ``"infer"`` (default), the encoding is detected
        automatically. Ignored for file-like input.

    Returns
    -------
    dict
        Dictionary with keys:

        - ``"name"`` : ndarray, shape (n_points,), site names
        - ``"coords"`` : dict with ``"west_east"``, ``"south_north"``,
          ``"height"`` arrays of shape (n_points,)
        - ``"site_elev"`` : ndarray, shape (n_points,)
        - ``"A"`` : ndarray, shape (n_points, n_sectors), Weibull A [m/s]
        - ``"k"`` : ndarray, shape (n_points, n_sectors), Weibull k
        - ``"wdfreq"`` : ndarray, shape (n_points, n_sectors), sector
          frequencies as 0-1 fractions
        - ``"A_combined"`` : ndarray, shape (n_points,)
        - ``"k_combined"`` : ndarray, shape (n_points,)
        - ``"power"`` : ndarray, shape (n_points,), the power column
          exactly as stored in the file (power density [W/m2] or power
          production [Wh/y] — the file does not say which)
        - ``"header"`` : dict with ``"nx"``, ``"ny"``, ``"xmin"``,
          ``"ymin"``, ``"cell_size"`` when the file has a WRG grid
          header, otherwise None

    Raises
    ------
    WindkitFileFormatError
        If the file contains no data lines, the sector count cannot be
        read, or a fixed-width field holds a value that is not a number.
    """
    if hasattr(filepath, "read"):
        text = filepath.read()
        context = getattr(filepath, "name", "<file object>")
    else:
        context = str(filepath)
        if encoding == "infer":
            encoding = detect_encoding(filepath)
        with open(filepath, encoding=encoding) as fobj:
            text = fobj.read()

    lines = [line for line in text.splitlines() if line.strip()]
    if not lines:
        raise WindkitFileFormatError("The resource file contains no data lines")

    header = _parse_wrg_header(lines[0])
    data_lines = lines[1:] if header is not None else lines
    if not data_lines:
        raise WindkitFileFormatError("The resource file contains no data lines")

    try:
        start, stop = _MAIN_FIELDS["n_sectors"]
        n_sectors = int(data_lines[0][start:stop])
    except ValueError:
        raise WindkitFileFormatError(
            "Could not read the number of sectors from columns 70-72 of the "
            "first data line; the line is neither a WRG grid header nor a "
            "valid data record"
        ) from None

    sector_slices = []
    offset = _MAIN_FIELDS["n_sectors"][1]
    for _ in range(n_sectors):
        for width in _SECTOR_WIDTHS:
            sector_slices.append((offset, offset + width))
            offset += width

    float_fields = {
        key: bounds
        for key, bounds in _MAIN_FIELDS.items()
        if key not in ("name", "n_sectors")
    }
    n_points = len(data_lines)
    name = np.empty(n_points, dtype=object)
    main = {key: np.empty(n_points) for key in float_fields}
    sector_values = np.empty((n_points, n_sectors, 3))

    sector_labels = ("wdfreq", "A", "k")
    for i, line in enumerate(data_lines):
        line_context = f"{context}: data line[{i}]"
        name[i] = line[slice(*_MAIN_FIELDS["name"])].strip()
        for key, (start, stop) in float_fields.items():
            main[key][i] = _to_float(line[start:stop], f"{line_context}: {key}")
        for j, (start, stop) in enumerate(sector_slices):
            sector_values[i, j // 3, j % 3] = _to_float(
                line[start:stop],
                f"{line_context}: sector {j // 3} {sector_labels[j % 3]}",
            )

    return {
        "name": name,
        "coords": {
            "west_east": main["west_east"],
            "south_north": main["south_north"],
            "height": main["height"],
        },
        "site_elev": main["site_elev"],
        "A": sector_values[:, :, 1] / 10.0,
        "k": sector_values[:, :, 2] / 100.0,
        "wdfreq": sector_values[:, :, 0] / 1000.0,
        "A_combined": main["A_combined"],
        "k_combined": main["k_combined"],
        "power": main["power"],
        "header": header,
    }


def _fit_decimals(values, width, candidates, label, hint=""):
    """Pick the most decimals from candidates where every value fits the field.

    The number format inside a field is free, so wide values are written
    with fewer decimals (e.g. coordinates beyond 9999999.9 m or heights
    beyond 99.9 m become integers).
    """
    for decimals in candidates:
        if all(len(f"{value:.{decimals}f}") <= width for value in values):
            return decimals
    raise ValueError(
        f"The {label} of one or more points is too wide for the "
        f"{width}-character .rsf/.wrg field. Please check the {label}.{hint}"
    )


def _format_wrg_header(header):
    """Format the WRG grid-header line."""

    def _num(value):
        value = float(value)
        return str(int(value)) if value.is_integer() else f"{value:.1f}"

    nx = int(header["nx"])
    ny = int(header["ny"])
    xmin = _num(header["xmin"])
    ymin = _num(header["ymin"])
    cell_size = _num(header["cell_size"])
    return f" {nx:<13} {ny:<13} {xmin:>9} {ymin:>13} {cell_size:>8}"


def format_rsf(
    A,
    k,
    wdfreq,
    A_combined,
    k_combined,
    power,
    site_elev,
    coords,
    name=None,
    header=None,
    power_decimals=4,
):
    """Format resource-file data as .rsf/.wrg file content string.

    Sector-wise values are rescaled to the format's storage units
    (``A`` * 10, ``k`` * 100, ``wdfreq`` * 1000), rounding to the
    format's precision first as WAsP does.

    Parameters
    ----------
    A : array_like, shape (n_points, n_sectors)
        Sector-wise Weibull A parameters [m/s].
    k : array_like, shape (n_points, n_sectors)
        Sector-wise Weibull k parameters.
    wdfreq : array_like, shape (n_points, n_sectors)
        Sector frequencies as 0-1 fractions.
    A_combined : array_like, shape (n_points,)
        Weibull A of the total distribution [m/s].
    k_combined : array_like, shape (n_points,)
        Weibull k of the total distribution.
    power : array_like, shape (n_points,)
        The power column, in the units it should be stored in (power
        density [W/m2] or power production [Wh/y]).
    site_elev : array_like, shape (n_points,)
        Site elevation [m].
    coords : dict
        Dictionary with ``"west_east"``, ``"south_north"`` and
        ``"height"`` arrays of shape (n_points,).
    name : array_like of str, optional
        Site names, at most 10 characters each. Defaults to
        ``"GridPoint"`` for every site.
    header : dict, optional
        WRG grid header with ``"nx"``, ``"ny"``, ``"xmin"``, ``"ymin"``
        and ``"cell_size"``. When given, the header line is prepended
        (producing .wrg content). No grid consistency check is made —
        computing the header from the data is the caller's job.
    power_decimals : int, optional
        Preferred number of decimals for the power column: 4 suits power
        density, 0 suits power production. Fewer decimals are used when
        needed to fit the field. When every value is the ``-9999``
        missing-value sentinel the column is written as integers, as
        WAsP does (a column merely containing some ``-9999`` values is
        not treated specially). Defaults to 4.

    Returns
    -------
    str
        File content string (with ``\\n`` line endings and no trailing
        newline).

    Raises
    ------
    ValueError
        If a name is longer than 10 characters, there are more than 99
        sectors, array shapes are inconsistent, ``power_decimals`` is
        negative, or a value cannot fit its fixed-width field.
    """
    A = np.atleast_2d(np.asarray(A, dtype=float))
    k = np.atleast_2d(np.asarray(k, dtype=float))
    wdfreq = np.atleast_2d(np.asarray(wdfreq, dtype=float))
    if A.ndim != 2:
        raise ValueError(
            f"A must be 2-D with shape (n_points, n_sectors), got shape {A.shape}"
        )
    for label, arr in (("k", k), ("wdfreq", wdfreq)):
        if arr.shape != A.shape:
            raise ValueError(
                f"{label} has shape {arr.shape}, expected {A.shape} to match A"
            )
    if power_decimals < 0:
        raise ValueError(f"power_decimals must be non-negative, got {power_decimals}")
    A_combined = np.atleast_1d(np.asarray(A_combined, dtype=float))
    k_combined = np.atleast_1d(np.asarray(k_combined, dtype=float))
    power = np.atleast_1d(np.asarray(power, dtype=float))
    site_elev = np.atleast_1d(np.asarray(site_elev, dtype=float))
    west_east = np.atleast_1d(np.asarray(coords["west_east"], dtype=float))
    south_north = np.atleast_1d(np.asarray(coords["south_north"], dtype=float))
    height = np.atleast_1d(np.asarray(coords["height"], dtype=float))

    n_points, n_sectors = A.shape
    if name is None:
        name = np.full(n_points, "GridPoint")
    else:
        name = np.atleast_1d(np.asarray(name, dtype=str))

    lengths = {
        "A": len(A),
        "k": len(k),
        "wdfreq": len(wdfreq),
        "A_combined": len(A_combined),
        "k_combined": len(k_combined),
        "power": len(power),
        "site_elev": len(site_elev),
        "west_east": len(west_east),
        "south_north": len(south_north),
        "height": len(height),
        "name": len(name),
    }
    if len(set(lengths.values())) != 1:
        raise ValueError(f"Arrays have inconsistent numbers of points: {lengths}")

    if max(len(nm) for nm in name) > 10:
        raise ValueError(
            "The name of one or more points is longer than 10 characters. "
            "Please shorten the names."
        )
    if n_sectors > 99:
        raise ValueError(f"The number of sectors is larger than 99: {n_sectors}")

    # Rescale to storage units, rounding first to match WAsP
    sec_wdfreq = np.round(wdfreq, 3) * 1000.0
    sec_A = np.round(A, 1) * 10.0
    sec_k = np.round(k, 2) * 100.0

    we_dec = _fit_decimals(west_east, 9, (1, 0), "west_east")
    sn_dec = _fit_decimals(south_north, 9, (1, 0), "south_north")
    elev_dec = _fit_decimals(site_elev, 7, (0,), "site_elev")
    height_dec = _fit_decimals(height, 4, (1, 0), "height")
    ac_dec = _fit_decimals(A_combined, 4, (2, 1, 0), "A_combined")
    kc_dec = _fit_decimals(k_combined, 5, (3, 2, 1, 0), "k_combined")
    # WAsP writes the missing-value sentinel as an integer
    if np.all(power == -9999):
        power_decimals = 0
    power_dec = _fit_decimals(power, 14, tuple(range(power_decimals, -1, -1)), "power")
    _fit_decimals(
        sec_wdfreq.ravel(),
        4,
        (0,),
        "wdfreq",
        hint=" Note wdfreq is stored as per mille (value * 1000).",
    )
    _fit_decimals(
        sec_A.ravel(), 4, (0,), "A", hint=" Note sector A is stored scaled by 10."
    )
    _fit_decimals(
        sec_k.ravel(), 5, (0,), "k", hint=" Note sector k is stored scaled by 100."
    )

    width_expected = 72 + n_sectors * 13
    lines = []
    if header is not None:
        lines.append(_format_wrg_header(header))
    for i in range(n_points):
        parts = [
            f"{name[i]:<10}",
            f"{west_east[i]:>9.{we_dec}f}",
            f"{south_north[i]:>9.{sn_dec}f}",
            f"{site_elev[i]:>7.{elev_dec}f}",
            f"{height[i]:>4.{height_dec}f}",
            f"{A_combined[i]:>4.{ac_dec}f}",
            f"{k_combined[i]:>5.{kc_dec}f}",
            f"{power[i]:>14.{power_dec}f}",
            f"{n_sectors:>2d}",
        ]
        # sector fields use their full spec widths (4, 4, 5), so a
        # full-field value like 1000 per mille stays writable
        line = " ".join(parts)
        for isec in range(n_sectors):
            line += (
                f"{sec_wdfreq[i, isec]:>4.0f}"
                f"{sec_A[i, isec]:>4.0f}"
                f"{sec_k[i, isec]:>5.0f}"
            )
        if len(line) != width_expected:
            raise ValueError(
                f".rsf/.wrg row width is {len(line)}. Expected {width_expected} "
                f"for {n_sectors} sectors!"
            )
        lines.append(line)

    return "\n".join(lines)


def write_rsf(
    filepath,
    A,
    k,
    wdfreq,
    A_combined,
    k_combined,
    power,
    site_elev,
    coords,
    name=None,
    header=None,
    power_decimals=4,
):
    """Write resource-file data to a WAsP .rsf/.wrg file.

    Delegates to :func:`format_rsf`; lines are terminated with CRLF as
    WAsP expects.

    Parameters
    ----------
    filepath : str or Path
        Path to the output file.
    A : array_like, shape (n_points, n_sectors)
        Sector-wise Weibull A parameters [m/s].
    k : array_like, shape (n_points, n_sectors)
        Sector-wise Weibull k parameters.
    wdfreq : array_like, shape (n_points, n_sectors)
        Sector frequencies as 0-1 fractions.
    A_combined : array_like, shape (n_points,)
        Weibull A of the total distribution [m/s].
    k_combined : array_like, shape (n_points,)
        Weibull k of the total distribution.
    power : array_like, shape (n_points,)
        The power column, in the units it should be stored in (power
        density [W/m2] or power production [Wh/y]).
    site_elev : array_like, shape (n_points,)
        Site elevation [m].
    coords : dict
        Dictionary with ``"west_east"``, ``"south_north"`` and
        ``"height"`` arrays of shape (n_points,).
    name : array_like of str, optional
        Site names, at most 10 characters each. Defaults to
        ``"GridPoint"`` for every site.
    header : dict, optional
        WRG grid header with ``"nx"``, ``"ny"``, ``"xmin"``, ``"ymin"``
        and ``"cell_size"``. When given, the header line is prepended
        (producing a .wrg file).
    power_decimals : int, optional
        Preferred number of decimals for the power column, see
        :func:`format_rsf`. Defaults to 4.
    """
    content = format_rsf(
        A,
        k,
        wdfreq,
        A_combined,
        k_combined,
        power,
        site_elev,
        coords,
        name=name,
        header=header,
        power_decimals=power_decimals,
    )
    with open(filepath, "w", newline="\r\n") as fobj:
        fobj.write(content)
