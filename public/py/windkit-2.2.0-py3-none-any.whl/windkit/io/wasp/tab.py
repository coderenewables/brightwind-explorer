"""Read and write WAsP .tab files.

The .tab format stores binned wind climate data as wind speed frequency
distributions per sector. This module provides low-level I/O functions
that work with normalized (0-1) frequency values.
"""

import io

import numpy as np

from windkit._errors import WindkitFileFormatError
from windkit.io.wasp._common import detect_encoding


def _line_floats(fobj, filepath, what):
    """Read the next line of *fobj* as floats, reporting where they came from."""
    fields = fobj.readline().split()
    try:
        return [float(x) for x in fields]
    except ValueError:
        raise WindkitFileFormatError(
            f"{filepath}: {what} holds a value that is not a number: "
            f"{' '.join(fields)!r}"
        ) from None


def read_tab(filepath, encoding="infer"):
    """Read a .tab file and return parsed data with normalized frequencies.

    Parameters
    ----------
    filepath : str or Path
        Path to the .tab file.
    encoding : str, optional
        File encoding. If "infer", the encoding is detected automatically.
        Defaults to "infer".

    Returns
    -------
    dict
        Dictionary with keys:
        - "wsfreq": ndarray(n_wsbins, n_sectors) - wind speed frequencies (0-1)
        - "wdfreq": ndarray(n_sectors) - wind direction frequencies (0-1)
        - "wsbins": ndarray(n_wsbins+1) - wind speed bin edges
        - "coords": dict with "south_north", "west_east", "height"
        - "metadata": dict with "description"

    Raises
    ------
    WindkitFileFormatError
        If the encoding cannot be detected; if the coordinate line does not
        hold three numbers; if a header, sector frequency or wind speed value
        is not a number; if the tabfile type is not supported; or if no wind
        speed rows follow the sector frequency line.
    """
    if encoding == "infer":
        encoding = detect_encoding(filepath)

    with open(filepath, encoding=encoding) as fobj:
        header = fobj.readline().strip()
        coords = _line_floats(fobj, filepath, "coordinate line")
        if len(coords) != 3:
            raise WindkitFileFormatError(
                f"{filepath}: coordinate line must hold 3 values (south_north, "
                f"west_east, height), got {len(coords)}"
            )
        south_north, west_east, height = coords
        tuple_header = tuple(_line_floats(fobj, filepath, "bin header line"))
        if len(tuple_header) == 4:
            _, _, _, tabfile_type = tuple_header
            if tabfile_type != 0:
                raise WindkitFileFormatError(
                    f"Tabfiles of type {tabfile_type} are not supported"
                )
        wdfreq = np.array(_line_floats(fobj, filepath, "sector frequency line"))
        rows = fobj.read()

    if not rows.strip():
        raise WindkitFileFormatError(
            f"{filepath}: no wind speed rows follow the sector frequency line"
        )
    try:
        wsdata = np.atleast_2d(np.genfromtxt(io.StringIO(rows)))
    except ValueError as err:
        raise WindkitFileFormatError(
            f"{filepath}: wind speed table is malformed: {err}"
        ) from None

    wsfreq = wsdata[:, 1:] / 1000.0
    wdfreq = wdfreq / 100.0
    wsbins = np.append(0, wsdata[:, 0])

    return {
        "wsfreq": wsfreq,
        "wdfreq": wdfreq,
        "wsbins": wsbins,
        "coords": {
            "south_north": south_north,
            "west_east": west_east,
            "height": height,
        },
        "metadata": {
            "description": header,
        },
    }


def format_tab(wsfreq, wdfreq, wsbins, coords, metadata=None):
    """Format tab data as a .tab file content string.

    Accepts normalized (0-1) frequency values and converts them to
    per-mille (wsfreq) and percent (wdfreq) for the file format.

    Parameters
    ----------
    wsfreq : ndarray(n_wsbins, n_sectors)
        Wind speed frequencies, normalized 0-1.
    wdfreq : ndarray(n_sectors)
        Wind direction frequencies, normalized 0-1.
    wsbins : ndarray(n_wsbins+1)
        Wind speed bin edges (first element should be 0).
    coords : dict
        Dictionary with "south_north", "west_east", "height".
    metadata : dict, optional
        Dictionary with "description". Defaults to {"description": "No Header"}.

    Returns
    -------
    str
        The formatted .tab file content.
    """
    if metadata is None:
        metadata = {"description": "No Header"}

    n_wsbins, n_sectors = wsfreq.shape
    wsceil = wsbins[1:]

    wdfreq_pct = np.asarray(wdfreq) * 100.0
    wsfreq_pm = np.round(np.asarray(wsfreq) * 1000.0, 3)

    header = metadata.get("description", "No Header")
    coord_line = "\t".join(
        str(coords[k]) for k in ("south_north", "west_east", "height")
    )
    dim_line = "\t".join(str(v) for v in (n_sectors, 1.0, 0.0))
    wdfreq_line = "    \t" + "\t".join(f"{f:6.2f}" for f in wdfreq_pct)

    lines = [header, coord_line, dim_line, wdfreq_line]
    for iws in range(n_wsbins):
        ws_line = f"{wsceil[iws]:4.1f}\t" + "\t".join(
            f"{f:6.2f}" for f in wsfreq_pm[iws, :]
        )
        lines.append(ws_line)

    return "\n".join(lines)


def write_tab(filepath, wsfreq, wdfreq, wsbins, coords, metadata=None):
    """Write tab data to a .tab file.

    Accepts normalized (0-1) frequency values.

    Parameters
    ----------
    filepath : str or Path
        Path to the output file.
    wsfreq : ndarray(n_wsbins, n_sectors)
        Wind speed frequencies, normalized 0-1.
    wdfreq : ndarray(n_sectors)
        Wind direction frequencies, normalized 0-1.
    wsbins : ndarray(n_wsbins+1)
        Wind speed bin edges (first element should be 0).
    coords : dict
        Dictionary with "south_north", "west_east", "height".
    metadata : dict, optional
        Dictionary with "description". Defaults to {"description": "No Header"}.
    """
    content = format_tab(wsfreq, wdfreq, wsbins, coords, metadata)
    with open(filepath, "w", newline="\r\n") as fobj:
        fobj.write(content)
