"""Read WAsP .wtg files.

The .wtg format stores a wind turbine generator's geometry and one or more
performance tables (power and thrust curves) as XML. Each ``PerformanceTable``
describes the turbine in a single operating mode, at a single air density.

Data contract: the returned dict mirrors the file. Every ``PerformanceTable``
becomes one entry in ``modes``, carrying its **own** ``wind_speed`` array, so
the arrays may differ in length and range between modes. Nothing is
interpolated onto a common grid, and no derived quantity (rated power, hub
height, regulation type) is computed here -- those belong to the layer that
builds an :class:`xarray.Dataset`.

Required attributes are validated at the file boundary: a missing one raises
``WindkitFileFormatError`` naming the file and the attribute. Attributes the
format marks as optional are always present as keys, valued ``None`` when
absent, which distinguishes an omitted ``ManufacturerName`` from one written
as ``""``.

Error messages locate an element by bracketing a **zero-based index** into the
structure this module returns: ``PerformanceTable[1]`` is ``modes[1]``. It is
not an ordinal count of the elements in the file::

    turbine.wtg: PerformanceTable[0]: DataPoint[1]: missing required attribute 'WindSpeed'
"""

import re

import numpy as np
from lxml import etree

from windkit._errors import WindkitFileFormatError
from windkit.io.wasp._common import (
    float_or_none,
    required_float,
    required_str,
)

__all__ = ["read_wtg", "parse_wtg_element"]

_VERSION_RE = re.compile(r"^\d+(\.\d+)*$")


def _required_version(attrib, key, context):
    """Return ``attrib[key]``, raising unless it looks like a version number.

    The regulation type is decided by comparing this value against ``"1.02"``.
    A value that is not a version -- ``""`` above all -- compares as *older*
    than 1.02 and silently discards the file's ``ControlSystem``, so a turbine
    declaring ``Stall`` would be read as pitch-regulated.
    """
    value = required_str(attrib, key, context)
    if not _VERSION_RE.match(value):
        raise WindkitFileFormatError(
            f"{context}: {key} is not a version number: {value!r}"
        )
    return value


def _stripped_text(element):
    """Return an element's text with surrounding whitespace removed.

    Returns None when the element itself is absent, and "" when it is present
    but empty -- WAsP writes ``<Comments>\\n  </Comments>`` for "no comment".
    """
    if element is None:
        return None
    return (element.text or "").strip()


def read_wtg(filepath):
    """Read a WAsP .wtg file and return parsed data.

    Parameters
    ----------
    filepath : str or Path
        Path to the ``.wtg`` file.

    Returns
    -------
    dict
        See :func:`parse_wtg_element`.

    Raises
    ------
    lxml.etree.XMLSyntaxError
        If the file is not well-formed XML. Subclasses ``SyntaxError``.
    WindkitFileFormatError
        If a required element or attribute is missing, as described in
        :func:`parse_wtg_element`.
    """
    tree = etree.parse(str(filepath))
    return parse_wtg_element(tree.getroot(), context=str(filepath))


def parse_wtg_element(wtg, context="WTG element"):
    """Parse an XML element for a wind turbine generator.

    Only the ``.attrib`` / ``.find`` / ``.findall`` / ``.iter`` / ``.text``
    subset of the ElementTree interface is used, so both ``lxml.etree`` and
    ``xml.etree.ElementTree`` elements are accepted.

    Parameters
    ----------
    wtg : lxml.etree._Element or xml.etree.ElementTree.Element
        The ``<WindTurbineGenerator>`` element.
    context : str, optional
        Identifier used in error messages, typically the source file path.

    Returns
    -------
    dict
        Dictionary with keys:

        - ``"name"`` : str, from the ``Description`` attribute
        - ``"manufacturer"`` : str or None
        - ``"reference_uri"`` : str or None
        - ``"rotor_diameter"`` : float
        - ``"control_system"`` : str or None, raw ``ControlSystem`` attribute
          (only written by files of ``FormatVersion`` 1.02 and later)
        - ``"format_version"`` : str
        - ``"lowest_compatible_format_version"`` : str or None
        - ``"suggested_heights"`` : ndarray, shape (n_heights,)
        - ``"comments"`` : str or None
        - ``"modes"`` : list of dict, one per ``PerformanceTable``, each with
          the required ``"air_density"``, ``"wind_speed_cutin"`` and
          ``"wind_speed_cutout"`` floats; the optional
          ``"stationary_thrust_coefficient"``, ``"maximum_noise_level"``,
          ``"blade_pitch_angle"``, ``"low_speed_cutout"``,
          ``"high_speed_cutin"``, ``"data_status"``, ``"data_source"``,
          ``"reference_uri"``, ``"release_date"`` and ``"comments"``; and the
          arrays ``"wind_speed"``, ``"power_output"`` and
          ``"thrust_coefficient"``. The arrays of different modes may differ
          in length.

    Raises
    ------
    WindkitFileFormatError
        If ``SuggestedHeights`` is absent, holds no ``Height`` elements, or
        holds one that is empty or not a number; if there is no
        ``PerformanceTable``; if a required attribute (``Description``,
        ``RotorDiameter``, ``FormatVersion``) is absent or unparseable; or if
        ``FormatVersion`` is not a version number.
    """
    attrs = wtg.attrib

    suggested_heights_elem = wtg.find("SuggestedHeights")
    if suggested_heights_elem is None:
        raise WindkitFileFormatError(
            f"{context}: WTG element is missing SuggestedHeights"
        )
    suggested_heights = []
    for i, elem in enumerate(suggested_heights_elem.findall("Height")):
        text = (elem.text or "").strip()
        try:
            suggested_heights.append(np.float64(text))
        except ValueError:
            raise WindkitFileFormatError(
                f"{context}: SuggestedHeights: Height[{i}] is not a number: {text!r}"
            ) from None
    suggested_heights = np.array(suggested_heights, dtype=np.float64)
    if suggested_heights.size == 0:
        raise WindkitFileFormatError(
            f"{context}: SuggestedHeights contains no Height elements"
        )

    modes = [
        _parse_performance_table(table, f"{context}: PerformanceTable[{i}]")
        for i, table in enumerate(wtg.iter("PerformanceTable"))
    ]
    if not modes:
        raise WindkitFileFormatError(
            f"{context}: WTG element contains no PerformanceTable elements"
        )

    return {
        "name": required_str(attrs, "Description", context),
        "manufacturer": attrs.get("ManufacturerName"),
        "reference_uri": attrs.get("ReferenceURI"),
        "rotor_diameter": required_float(attrs, "RotorDiameter", context),
        "control_system": attrs.get("ControlSystem"),
        "format_version": _required_version(attrs, "FormatVersion", context),
        "lowest_compatible_format_version": attrs.get("LowestCompatibleFormatVersion"),
        "suggested_heights": suggested_heights,
        "comments": _stripped_text(wtg.find("Comments")),
        "modes": modes,
    }


def _parse_performance_table(table, context):
    """Parse a single ``<PerformanceTable>`` element into a dict.

    Parameters
    ----------
    table : lxml.etree._Element or xml.etree.ElementTree.Element
        A ``<PerformanceTable>`` element.
    context : str
        Identifier used in error messages.

    Returns
    -------
    dict
        One entry of the ``"modes"`` list described in
        :func:`parse_wtg_element`.

    Raises
    ------
    WindkitFileFormatError
        If ``StartStopStrategy`` is absent, if the table holds no
        ``DataPoint`` elements, or if a required attribute is absent or
        unparseable.
    """
    attrs = table.attrib

    strategy = table.find("StartStopStrategy")
    if strategy is None:
        raise WindkitFileFormatError(f"{context}: missing StartStopStrategy")
    strategy_attrs = strategy.attrib

    wind_speed = []
    power_output = []
    thrust_coefficient = []
    for i, row in enumerate(table.iter("DataPoint")):
        row_context = f"{context}: DataPoint[{i}]"
        wind_speed.append(required_float(row.attrib, "WindSpeed", row_context))
        power_output.append(required_float(row.attrib, "PowerOutput", row_context))
        thrust_coefficient.append(
            required_float(row.attrib, "ThrustCoEfficient", row_context)
        )
    if not wind_speed:
        raise WindkitFileFormatError(f"{context}: contains no DataPoint elements")

    return {
        "air_density": required_float(attrs, "AirDensity", context),
        "stationary_thrust_coefficient": float_or_none(
            attrs, "StationaryThrustCoEfficient", context
        ),
        "maximum_noise_level": float_or_none(attrs, "MaximumNoiseLevel", context),
        "blade_pitch_angle": float_or_none(attrs, "BladePitchAngle", context),
        "data_status": attrs.get("DataStatus"),
        "data_source": attrs.get("DataSource"),
        "reference_uri": attrs.get("ReferenceURI"),
        "release_date": attrs.get("ReleaseDate"),
        # WAsP models start/stop as a hysteresis loop: the turbine starts at
        # LowSpeedCutIn and stops at HighSpeedCutOut as the wind rises, then
        # restarts at HighSpeedCutIn and stops at LowSpeedCutOut as it falls.
        # windkit's Dataset carries only the rising-wind pair -- the cut-in and
        # cut-out speeds of a spec sheet -- so those two are required; the
        # falling-wind pair stays optional so files omitting it keep loading.
        "wind_speed_cutin": required_float(strategy_attrs, "LowSpeedCutIn", context),
        "wind_speed_cutout": required_float(strategy_attrs, "HighSpeedCutOut", context),
        "low_speed_cutout": float_or_none(strategy_attrs, "LowSpeedCutOut", context),
        "high_speed_cutin": float_or_none(strategy_attrs, "HighSpeedCutIn", context),
        "comments": _stripped_text(table.find("Comments")),
        "wind_speed": np.array(wind_speed, dtype=np.float64),
        "power_output": np.array(power_output, dtype=np.float64),
        "thrust_coefficient": np.array(thrust_coefficient, dtype=np.float64),
    }
