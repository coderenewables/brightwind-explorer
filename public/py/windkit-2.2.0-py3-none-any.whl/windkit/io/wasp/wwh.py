"""Read WAsP workspace (.wwh) files.

A ``.wwh`` file is a zip archive. Its ``Inventory.xml`` holds the workspace
hierarchy: ``WaspHierarchyMember`` elements (projects, met stations,
generalised wind climates, turbine sites, maps, ...) nested through their
``ChildMembers``. The other entries of the archive are files that members
refer to by name, such as the vector map of a ``Vector map data layer``.

Besides its inputs, a workspace stores what WAsP calculated from them: the
predicted wind climate and site effects at every met station, reference site
and turbine site, the annual energy production of every turbine site, and
WAsP's Weibull fit of the observed wind climate at the met station. This
module reads the hierarchy and, for each member, the parts listed in
:func:`parse_wwh_member_element`.

Data contract: the returned dicts mirror the file. Numbers are parsed from the
text WAsP wrote (up to 7 significant digits) straight into float64, so reading
adds no rounding of its own. Frequencies, ``Rix`` and wake losses are fractions
(0-1) and energies are in Wh/y, as stored; turnings are in degrees. Nothing is
renormalized: the sector frequencies of a wind rose sum to 1 only to within
the rounding of the stored values. Observed and generalised wind climates and
wind turbine generators are parsed by
:func:`~windkit.io.wasp.parse_owc_element`,
:func:`~windkit.io.wasp.parse_gwc_element` and
:func:`~windkit.io.wasp.parse_wtg_element`, under their own data contracts.

Every member dict has the same keys, and a part the member does not hold is
``None``. Within a part that is present, required elements and attributes are
validated at the file boundary: a missing or unparseable one raises
``WindkitFileFormatError``. Attributes that older workspaces do not write are
optional and read as None: ``DisplacementHeight`` and ``SiteRoughness`` before
format 4.01.0006, and ``Rix``, ``TotalRix``, ``RoughnessChanges`` and the
separate roughness and orographic speed-ups and turnings in format 4.01.0002
and older, which store combined ``TerrainSpeedMultiplier`` and
``TerrainDeflection`` instead (not read), and ``MeanAirDensity`` in format 3.03.
The settings are optional too. Which WAsP versions a workspace may come from is
not checked here.

Error messages name the member by its class and description, then locate an
element by bracketing a **zero-based index** into the document order of the
elements this module reads::

    site.wwh: Turbine site 'T1': SiteAssessment: SectorAssessment[3]: missing required attribute 'Rix'
"""

import zipfile

import numpy as np
from lxml import etree

from windkit._errors import WindkitFileFormatError
from windkit.io.wasp._common import (
    float_or_none,
    int_or_none,
    required_float,
    required_int,
    required_str,
)
from windkit.io.wasp._rvea import parse_sector_rose
from windkit.io.wasp.gwc import parse_gwc_element
from windkit.io.wasp.owc import parse_owc_element
from windkit.io.wasp.wtg import parse_wtg_element

__all__ = ["read_wwh", "parse_wwh_element", "parse_wwh_member_element"]

_INVENTORY = "Inventory.xml"
_ROOT_TAG = "WaspHierarchyFile"
_MEMBER_TAG = "WaspHierarchyMember"
_GWC_TAG = "RveaGeneralisedMeanWindClimate"

# Paths below a WaspHierarchyMember
_MEMBER_DATA = "MemberData"
_RESULTS = "MemberData/CalculationResults"
_SETTINGS = "Settings"
_GWC = f"MemberData/{_GWC_TAG}"

# Output key -> (attribute, reader) of a per-sector element, see parse_sector_rose
_WEIBULL_WIND_FIELDS = {
    "sector": ("CentreAngleDegrees", required_float),
    "sector_width": ("SectorWidthDegrees", required_float),
    "A": ("WeibullA", required_float),
    "k": ("WeibullK", required_float),
    "wdfreq": ("SectorFrequency", required_float),
}
_SECTOR_ASSESSMENT_FIELDS = {
    "sector": ("CentreAngleDegrees", required_float),
    "z0meso": ("MesoRoughness", required_float),
    "slfmeso": ("MesoSurfaceLandFraction", required_float),
    "displ": ("DisplacementHeight", float_or_none),
    "roughness_changes": ("RoughnessChanges", int_or_none),
    "dirrix": ("Rix", float_or_none),
    "roughness_speedups": ("RoughnessSpeedMultiplier", float_or_none),
    "roughness_turnings": ("RoughnessDeflection", float_or_none),
    "orographic_speedups": ("OrographicSpeedMultiplier", float_or_none),
    "orographic_turnings": ("OrographicDeflection", float_or_none),
    "obstacle_speedups": ("ObstaclesSpeedMultiplier", required_float),
    "obstacle_turnings": ("ObstaclesDeflection", required_float),
}
_PRODUCTION_FIELDS = {
    "sector": ("CentreAngleDegrees", required_float),
    "wdfreq": ("Frequency", required_float),
    "gross": ("Gross", required_float),
    "net": ("Net", required_float),
    "wake_loss": ("WakeLoss", required_float),
}
_DECAY_COEFFICIENT_FIELDS = {
    "decay_coefficient": ("WakeDecayCoEfficient", required_float),
}


def read_wwh(filepath):
    """Read a WAsP .wwh workspace and return parsed data.

    Parameters
    ----------
    filepath : str or Path
        Path to the ``.wwh`` file.

    Returns
    -------
    dict
        See :func:`parse_wwh_element`.

    Raises
    ------
    zipfile.BadZipFile
        If the file is not a zip archive.
    lxml.etree.XMLSyntaxError
        If the inventory is not well-formed XML. Subclasses ``SyntaxError``.
    WindkitFileFormatError
        If the archive holds no ``Inventory.xml``, or a required element or
        attribute is missing, as described in :func:`parse_wwh_element`.
    ValueError
        If a generalised wind climate is malformed, as described in
        :func:`~windkit.io.wasp.parse_gwc_element`.
    """
    root = _parse_inventory(filepath).getroot()
    return parse_wwh_element(root, context=str(filepath))


def _parse_inventory(filepath):
    """Parse the ``Inventory.xml`` of a workspace archive into an lxml element tree."""
    with zipfile.ZipFile(filepath) as archive:
        try:
            inventory = archive.open(_INVENTORY)
        except KeyError:
            raise WindkitFileFormatError(
                f"{filepath}: archive holds no {_INVENTORY}"
            ) from None
        with inventory:
            return etree.parse(inventory)


def parse_wwh_element(root, context="WWH element"):
    """Parse the root element of a workspace inventory.

    Only the ``.tag`` / ``.attrib`` / ``.find`` / ``.findall`` / ``.iter``
    subset of the ElementTree interface is used, so both ``lxml.etree`` and
    ``xml.etree.ElementTree`` elements are accepted.

    Parameters
    ----------
    root : lxml.etree._Element or xml.etree.ElementTree.Element
        The ``<WaspHierarchyFile>`` root element of ``Inventory.xml``.
    context : str, optional
        Identifier used in error messages, typically the source file path.

    Returns
    -------
    dict
        Dictionary with keys:

        - ``"format_version"`` : str
        - ``"lowest_compatible_format_version"`` : str or None
        - ``"saving_component"`` : str or None
        - ``"saved_at"`` : str or None
        - ``"members"`` : list of dict, one per ``WaspHierarchyMember`` in
          document order, so a member comes before its children. Each is the
          dict of :func:`parse_wwh_member_element` with two more keys:
          ``"parent"`` (index into ``members`` of the member whose
          ``ChildMembers`` holds it, or None) and ``"children"`` (list of
          indices).

    Raises
    ------
    WindkitFileFormatError
        If the element is not a ``WaspHierarchyFile`` or has no
        ``FormatVersion``, or a member fails as described in
        :func:`parse_wwh_member_element`.
    ValueError
        If a generalised wind climate is malformed, as described in
        :func:`~windkit.io.wasp.parse_gwc_element`.
    """
    if root.tag != _ROOT_TAG:
        raise WindkitFileFormatError(f"{context}: expected {_ROOT_TAG}, got {root.tag}")
    attrib = root.attrib
    format_version = required_str(attrib, "FormatVersion", context)

    elements, parents, children = _walk_hierarchy(root)
    members = []
    for element, parent, element_children in zip(elements, parents, children):
        member = parse_wwh_member_element(element, context=context)
        member["parent"] = parent
        member["children"] = element_children
        members.append(member)

    return {
        "format_version": format_version,
        "lowest_compatible_format_version": attrib.get("LowestCompatibleFormatVersion"),
        "saving_component": attrib.get("SavingComponent"),
        "saved_at": attrib.get("SavedAt"),
        "members": members,
    }


def _walk_hierarchy(root):
    """Walk the members of a workspace inventory.

    Parameters
    ----------
    root : lxml.etree._Element or xml.etree.ElementTree.Element
        The ``<WaspHierarchyFile>`` root element of ``Inventory.xml``.

    Returns
    -------
    list
        The ``WaspHierarchyMember`` elements in document order.
    list of int or None
        For each element, the index of the member whose ``ChildMembers``
        holds it, or None.
    list of list of int
        For each element, the indices of the members its ``ChildMembers``
        holds.
    """
    elements = list(root.iter(_MEMBER_TAG))
    positions = {element: i for i, element in enumerate(elements)}
    parents = [None] * len(elements)
    children = [[] for _ in elements]
    for i, element in enumerate(elements):
        for child in element.findall(f"ChildMembers/{_MEMBER_TAG}"):
            parents[positions[child]] = i
            children[i].append(positions[child])
    return elements, parents, children


def parse_wwh_member_element(member, context="WWH member"):
    """Parse one ``WaspHierarchyMember`` element of a workspace inventory.

    Only the member's own data and settings are read, not those of the members
    in its ``ChildMembers``. Only the ``.tag`` / ``.attrib`` / ``.find`` /
    ``.findall`` / ``.iter`` / ``.text`` subset of the ElementTree interface is
    used, so both ``lxml.etree`` and ``xml.etree.ElementTree`` elements are
    accepted.

    Parameters
    ----------
    member : lxml.etree._Element or xml.etree.ElementTree.Element
        A ``<WaspHierarchyMember>`` element.
    context : str, optional
        Identifier used in error messages, typically the source file path.

    Returns
    -------
    dict
        Dictionary with keys:

        - ``"id"`` : str, the member's GUID as written, braces included
        - ``"class_id"`` : int
        - ``"class_description"`` : str, e.g. ``"Turbine site"``
        - ``"description"`` : str, the member's name as written (WAsP may
          leave trailing spaces)
        - ``"results_dirty"`` : dict mapping each calculation of the
          member's ``CalculationInformation`` (``"Calculation1"``, ...) to
          True when WAsP marked its results as not up to date; empty when
          there is none
        - ``"coords"`` : dict with ``"west_east"``, ``"south_north"`` and
          ``"height"`` (working height above ground) of a site, from
          ``SiteInformation``
        - ``"site_assessment"`` : dict of the site effects, from
          ``SiteAssessment``, with arrays of shape (n_sectors,):
          ``"sector"`` (centre angles in degrees), ``"z0meso"``,
          ``"slfmeso"``, ``"displ"``, ``"roughness_changes"`` (int),
          ``"roughness_speedups"``, ``"roughness_turnings"``,
          ``"orographic_speedups"``, ``"orographic_turnings"``,
          ``"obstacle_speedups"``, ``"obstacle_turnings"`` and ``"dirrix"``;
          and floats ``"site_elev"``, ``"rix"`` and ``"site_roughness"``.
          ``"sector"``, ``"z0meso"``, ``"slfmeso"``, the obstacle effects
          and ``"site_elev"`` are required; the others are None when not
          stored. The CFD ``Turbulence`` and ``FlowInclination`` attributes
          are not read.
        - ``"predicted_wind_climate"`` : dict with arrays of shape
          (n_sectors,) ``"sector"``, ``"sector_width"``, ``"A"``, ``"k"`` and
          ``"wdfreq"``, and the float ``"air_density"`` (None when not
          stored, as in format 3.03), from ``PredictedWindClimate``
        - ``"observed_wind_climate_weibull_fit"`` : dict with the same
          arrays, WAsP's Weibull fit of the observed wind climate, from
          ``ObservedWindClimateWeibullRose``
        - ``"production"`` : dict with arrays of shape (n_sectors,)
          ``"sector"``, ``"wdfreq"``, ``"gross"`` and ``"net"`` (Wh/y) and
          ``"wake_loss"`` (0-1); and floats ``"sum_of_sectors_gross"``,
          ``"sum_of_sectors_net"`` and ``"omnidirectional_gross"`` (Wh/y),
          from ``Production``
        - ``"observed_wind_climate"`` : dict, see
          :func:`~windkit.io.wasp.parse_owc_element`
        - ``"generalized_wind_climate"`` : dict, see
          :func:`~windkit.io.wasp.parse_gwc_element`
        - ``"wind_turbine_generator"`` : dict, see
          :func:`~windkit.io.wasp.parse_wtg_element`
        - ``"data_layer"`` : dict with ``"phenomenon"`` (e.g.
          ``"ElevationContours"``) and ``"archive_file"`` (the archive entry
          holding the layer), each None when not stored
        - ``"parameters"`` : dict mapping the ID of each parameter in
          ``Settings/RveaConfiguration`` (e.g. ``"DSECTORS"``) to a dict with
          ``"value"`` (float, or the raw string when it is not a number) and
          ``"is_default"`` (bool)
        - ``"profile_model_parameters"`` : the same, for the parameters a
          generalised wind climate records in
          ``Provenance/ProfileModelParameters``
        - ``"wake_modelling"`` : dict with ``"is_active"`` (bool),
          ``"model"`` (str), ``"n_sub_sectors"`` (int),
          ``"speed_resolution"`` and ``"default_decay_coefficient"`` (floats)
          and ``"decay_coefficient"`` (array, shape (n_sectors,)); all but
          ``"is_active"`` are None when not stored
        - ``"air_density_correction"`` : dict with ``"svenningsen_factor"``
          (float) and ``"table_air_density"`` (array, the air densities of
          the performance tables used), each None when not stored

        A part the member does not hold is ``None``.

    Raises
    ------
    WindkitFileFormatError
        If ``ID``, ``ClassID``, ``ClassDescription`` or ``Description`` is
        absent or unparseable; or if a part that is present lacks a required
        element or attribute, holds a number or flag that does not parse, or
        has a sector ``Index`` outside ``1..CountOfSectors``, repeated, or
        missing, or a parameter ID repeated.
    ValueError
        If the generalised wind climate is malformed, as described in
        :func:`~windkit.io.wasp.parse_gwc_element`.
    """
    return _parse_member(member, context)


def _parse_member(member, context, parts=None):
    """Parse the identity of a member and the given parts of its data.

    Parameters
    ----------
    member : lxml.etree._Element or xml.etree.ElementTree.Element
        A ``<WaspHierarchyMember>`` element.
    context : str
        Identifier used in error messages, typically the source file path.
    parts : iterable of str, optional
        Keys of the parts to parse, as returned by
        :func:`parse_wwh_member_element`. Defaults to None, which parses all
        of them.

    Returns
    -------
    dict
        ``"id"``, ``"class_id"``, ``"class_description"``, ``"description"``
        and the requested parts, see :func:`parse_wwh_member_element`.
    """
    attrib = member.attrib
    class_description = required_str(attrib, "ClassDescription", context)
    description = required_str(attrib, "Description", context)
    context = f"{context}: {class_description} '{description.strip()}'"

    parsed = {
        "id": required_str(attrib, "ID", context),
        "class_id": required_int(attrib, "ClassID", context),
        "class_description": class_description,
        "description": description,
    }
    for part in _PART_PARSERS if parts is None else parts:
        parsed[part] = _PART_PARSERS[part](member, context)
    return parsed


def _part(parse, container, path, label=None):
    """A part parser reading the element at ``path`` below a member's ``container``.

    ``label`` names the container in error messages.
    """

    def parse_part(member, context):
        return _parse_child(
            parse,
            member.find(container),
            path,
            context if label is None else f"{context}: {label}",
        )

    return parse_part


def _parse_member_results_dirty(member, context):
    return _parse_calculation_information(
        member.find("CalculationInformation"), context
    )


def _parse_member_gwc(member, context):
    gwc = member.find(_GWC)
    if gwc is None:
        return None
    return parse_gwc_element(gwc, context=f"{context}: {_GWC_TAG}")


def _parse_member_data_layer(member, context):
    data = member.find(_MEMBER_DATA)
    return None if data is None else _parse_data_layer(data, context)


def _parse_child(parse, parent, path, context):
    """Parse the first element at ``path`` below ``parent`` with ``parse``.

    Returns None when ``parent`` is None or holds no such element.
    """
    element = None if parent is None else parent.find(path)
    return None if element is None else parse(element, f"{context}: {path}")


def _required_child(element, tag, context):
    """Return ``element``'s first ``tag`` child, raising if there is none."""
    child = element.find(tag)
    if child is None:
        raise WindkitFileFormatError(f"{context}: missing {tag}")
    return child


def _required_flag(attrib, key, context):
    """Return ``attrib[key]`` as a bool, raising unless it is ``"0"`` or ``"1"``."""
    value = required_str(attrib, key, context)
    if value not in ("0", "1"):
        raise WindkitFileFormatError(
            f"{context}: attribute '{key}' is not 0 or 1: {value!r}"
        )
    return value == "1"


def _parse_calculation_information(info, context):
    """Map each calculation of a ``CalculationInformation`` to its dirty flag."""
    if info is None:
        return {}
    info_context = f"{context}: CalculationInformation"
    return {
        calculation.tag: _required_flag(
            calculation.attrib, "ResultsDirty", f"{info_context}: {calculation.tag}"
        )
        for calculation in info
        if isinstance(calculation.tag, str)
    }


def _parse_site_information(info, context):
    """Parse a ``SiteInformation`` element into a coords dict."""
    location = _required_child(info, "Location", context)
    location_context = f"{context}: Location"
    return {
        "west_east": required_float(location.attrib, "x-Location", location_context),
        "south_north": required_float(location.attrib, "y-Location", location_context),
        "height": required_float(info.attrib, "WorkingHeightAgl", context),
    }


def _parse_weibull_wind_rose(container, context):
    """Parse the ``RveaWeibullWindRose`` inside ``container``."""
    rose = _required_child(container, "RveaWeibullWindRose", context)
    return parse_sector_rose(
        rose,
        "WeibullWind",
        _WEIBULL_WIND_FIELDS,
        f"{context}: RveaWeibullWindRose",
    )


def _parse_predicted_wind_climate(element, context):
    """Parse a ``PredictedWindClimate`` element."""
    data = _parse_weibull_wind_rose(element, context)
    data["air_density"] = float_or_none(element.attrib, "MeanAirDensity", context)
    return data


def _parse_site_assessment(assessment, context):
    """Parse a ``SiteAssessment`` element into the site effects of one site."""
    data = parse_sector_rose(
        assessment, "SectorAssessment", _SECTOR_ASSESSMENT_FIELDS, context
    )
    point = _required_child(assessment, "SitePointInformation", context)
    point_context = f"{context}: SitePointInformation"
    data["site_elev"] = required_float(point.attrib, "Elevation", point_context)
    data["rix"] = float_or_none(point.attrib, "TotalRix", point_context)
    data["site_roughness"] = float_or_none(point.attrib, "SiteRoughness", point_context)
    return data


def _parse_production(production, context):
    """Parse a ``Production`` element into the AEP of one turbine site."""
    data = parse_sector_rose(
        production, "ProductionRoseSector", _PRODUCTION_FIELDS, context
    )
    totals = _required_child(production, "TotalsData", context)
    totals_context = f"{context}: TotalsData"
    data["sum_of_sectors_gross"] = required_float(
        totals.attrib, "SumOfSectorsGrossAEP", totals_context
    )
    data["sum_of_sectors_net"] = required_float(
        totals.attrib, "SumOfSectorsNetAEP", totals_context
    )
    data["omnidirectional_gross"] = required_float(
        totals.attrib, "OmniDirectionalGrossAEP", totals_context
    )
    return data


def _parse_data_layer(data, context):
    """Parse the ``DataLayer`` and ``ExternalArchive`` of a ``MemberData``, or return None."""
    layer = data.find("DataLayer")
    archive = data.find("ExternalArchive")
    if layer is None and archive is None:
        return None
    return {
        "phenomenon": (
            None
            if layer is None
            else required_str(layer.attrib, "DataPhenomenon", f"{context}: DataLayer")
        ),
        "archive_file": (
            None
            if archive is None
            else required_str(
                archive.attrib, "ArchiveTagID", f"{context}: ExternalArchive"
            )
        ),
    }


def _parse_parameters(configuration, context):
    """Parse the ``RveaParameter`` elements of an ``RveaConfiguration``."""
    parameters = {}
    for i, parameter in enumerate(configuration.findall("RveaParameter")):
        parameter_context = f"{context}: RveaParameter[{i}]"
        parameter_id = required_str(parameter.attrib, "ID", parameter_context)
        if parameter_id in parameters:
            raise WindkitFileFormatError(
                f"{parameter_context}: ID '{parameter_id}' appears more than once"
            )
        raw = required_str(parameter.attrib, "Value", parameter_context)
        try:
            value = np.float64(raw)
        except ValueError:
            value = raw
        parameters[parameter_id] = {
            "value": value,
            "is_default": _required_flag(
                parameter.attrib, "IsDefault", parameter_context
            ),
        }
    return parameters


def _parse_wake_modelling(wake, context):
    """Parse a ``WakeModelling`` element."""
    model = wake.find("Model")
    model_context = f"{context}: Model"
    decay = wake.find("DecayCoefficients")
    decay_context = f"{context}: DecayCoefficients"
    default = None if decay is None else decay.find("Default")
    values = None if decay is None else decay.find("CoefficientValues")

    decay_coefficient = None
    if values is not None:
        decay_coefficient = parse_sector_rose(
            values,
            "SectorCoEfficient",
            _DECAY_COEFFICIENT_FIELDS,
            f"{decay_context}: CoefficientValues",
            index_key="SectorIndex",
        )["decay_coefficient"]

    return {
        "is_active": _required_flag(wake.attrib, "IsActive", context),
        "model": None if model is None else model.attrib.get("ModelOption"),
        "n_sub_sectors": (
            None
            if model is None
            else int_or_none(model.attrib, "NumberOfSubSectors", model_context)
        ),
        "speed_resolution": (
            None
            if model is None
            else float_or_none(model.attrib, "SpeedResolution", model_context)
        ),
        "default_decay_coefficient": (
            None
            if default is None
            else float_or_none(default.attrib, "Value", f"{decay_context}: Default")
        ),
        "decay_coefficient": decay_coefficient,
    }


def _parse_air_density_correction(policy, context):
    """Parse an ``AirDensityCorrectionPolicy`` element."""
    selection = policy.find("MultipleTableSelection")
    if selection is None:
        return {"svenningsen_factor": None, "table_air_density": None}
    selection_context = f"{context}: MultipleTableSelection"
    return {
        "svenningsen_factor": float_or_none(
            selection.attrib, "SvenningsenFactor", selection_context
        ),
        "table_air_density": np.array(
            [
                required_float(
                    table.attrib,
                    "AuditAirDensityOfTable",
                    f"{selection_context}: IncludedTable[{i}]",
                )
                for i, table in enumerate(selection.findall("IncludedTable"))
            ],
            dtype=np.float64,
        ),
    }


# Key of a part of a member -> parser called as parser(member, context), in the
# order of the keys parse_wwh_member_element returns
_PART_PARSERS = {
    "results_dirty": _parse_member_results_dirty,
    "coords": _part(_parse_site_information, _MEMBER_DATA, "SiteInformation"),
    "site_assessment": _part(_parse_site_assessment, _RESULTS, "SiteAssessment"),
    "predicted_wind_climate": _part(
        _parse_predicted_wind_climate, _RESULTS, "PredictedWindClimate"
    ),
    "observed_wind_climate_weibull_fit": _part(
        _parse_weibull_wind_rose, _RESULTS, "ObservedWindClimateWeibullRose"
    ),
    "production": _part(_parse_production, _RESULTS, "Production"),
    "observed_wind_climate": _part(
        parse_owc_element, _MEMBER_DATA, "RveaObservedWindClimate"
    ),
    "generalized_wind_climate": _parse_member_gwc,
    "wind_turbine_generator": _part(
        parse_wtg_element, _MEMBER_DATA, "WindTurbineGenerator"
    ),
    "data_layer": _parse_member_data_layer,
    "parameters": _part(_parse_parameters, _SETTINGS, "RveaConfiguration", "Settings"),
    "profile_model_parameters": _part(
        _parse_parameters,
        _GWC,
        "Provenance/ProfileModelParameters/RveaConfiguration",
        _GWC_TAG,
    ),
    "wake_modelling": _part(
        _parse_wake_modelling, _SETTINGS, "WakeModelling", "Settings"
    ),
    "air_density_correction": _part(
        _parse_air_density_correction,
        _SETTINGS,
        "AirDensityCorrectionPolicy",
        "Settings",
    ),
}
