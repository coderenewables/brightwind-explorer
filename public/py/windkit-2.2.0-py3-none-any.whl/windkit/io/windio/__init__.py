# (c) 2026 DTU Wind Energy
"""
windIO format support for windkit.

This module provides functions for reading and writing wind data in the windIO
YAML format (https://github.com/IEAWindSystems/windIO).

.. warning::
    windIO support is experimental. API may change in future versions.

Example
-------
>>> from windkit.io import windio
>>> data = windio.read_plant("site.yaml")
>>> windio.write_plant(data, "output.yaml")
"""

__all__ = [
    # Reading
    "read_plant",
    "read_turbine",
    "read_site",
    "read_energy_resource",
    "read_wind_resource",
    "read_wind_farm",
    "read_layout",
    # Writing
    "write_plant",
    "export_site",
    "write_turbine",
    "write_wind_farm",
    "write_wind_resource",
    # Utilities
    "resolve_includes",
    # Translation - Wind Climates
    "wwc_from_windio",
    "wwc_to_windio",
    "bwc_from_windio",
    "bwc_to_windio",
    "tswc_from_windio",
    "tswc_to_windio",
    # Translation - Wind Turbines
    "wind_turbines_from_windio",
    "wind_turbines_to_windio",
    "wtg_from_windio",
    "wtg_from_windio_turbine",
    "wtg_dict_from_windio",
    "wtg_to_windio",
    # Composition
    "compose_plant",
    "compose_wind_farm",
]

from windkit.io.windio.readers import (
    read_energy_resource,
    read_layout,
    read_plant,
    read_site,
    read_turbine,
    read_wind_farm,
    read_wind_resource,
)
from windkit.io.windio.translate import (
    bwc_from_windio,
    bwc_to_windio,
    compose_plant,
    compose_wind_farm,
    tswc_from_windio,
    tswc_to_windio,
    wind_turbines_from_windio,
    wind_turbines_to_windio,
    wtg_dict_from_windio,
    wtg_from_windio,
    wtg_from_windio_turbine,
    wtg_to_windio,
    wwc_from_windio,
    wwc_to_windio,
)
from windkit.io.windio.utils import resolve_includes
from windkit.io.windio.writers import (
    export_site,
    write_plant,
    write_turbine,
    write_wind_farm,
    write_wind_resource,
)
