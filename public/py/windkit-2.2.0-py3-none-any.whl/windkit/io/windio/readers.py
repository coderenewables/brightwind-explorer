# (c) 2026 DTU Wind Energy
"""
YAML reading functions for windIO format.

This module provides low-level functions for parsing windIO YAML files
into Python dictionaries.
"""

__all__ = [
    "read_plant",
    "read_turbine",
    "read_site",
    "read_energy_resource",
    "read_wind_resource",
    "read_wind_farm",
    "read_layout",
]

from pathlib import Path

import yaml


def _create_include_loader(base_path):
    """Create a YAML loader that handles !include directives.

    The !include directive is preserved as a special marker dict
    rather than being resolved, allowing for lazy loading.

    Parameters
    ----------
    base_path : Path
        Base path for resolving relative includes.

    Returns
    -------
    type
        Custom YAML Loader class.
    """

    class IncludeLoader(yaml.SafeLoader):
        pass

    def include_constructor(loader, node):
        """Handle !include directive by preserving it as a marker."""
        include_path = loader.construct_scalar(node)
        return {"__windio_include__": include_path, "__base_path__": str(base_path)}

    IncludeLoader.add_constructor("!include", include_constructor)

    return IncludeLoader


def _read_windio_yaml(path, file_type, resolve=False):
    """Parse a windIO YAML file.

    Parameters
    ----------
    path : str or pathlib.Path
        Path to windIO YAML file.
    file_type : str
        Type of file for error messages (e.g., "plant", "turbine").
    resolve : bool, optional
        If True, eagerly resolve all ``!include`` markers after parsing.
        Default is False (markers are preserved for lazy resolution).

    Returns
    -------
    dict
        Parsed YAML as nested dictionary.

    Raises
    ------
    FileNotFoundError
        If file does not exist.
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"windIO {file_type} file not found: {path}")

    loader = _create_include_loader(path.parent)

    with open(path, "r", encoding="utf-8") as f:
        data = yaml.load(f, Loader=loader)

    if resolve:
        from windkit.io.windio.utils import _resolve_includes_recursive

        data = _resolve_includes_recursive(data, path.parent)

    return data


def read_plant(path, resolve=False):
    """Parse a windIO plant YAML file.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    path : str or pathlib.Path
        Path to windIO plant YAML file.
    resolve : bool, optional
        If True, eagerly resolve all ``!include`` markers.
        Default is False (markers are preserved for lazy resolution).

    Returns
    -------
    dict
        Parsed YAML as nested dictionary. ``!include`` directives
        are preserved as-is (not resolved) unless *resolve* is True.

    Raises
    ------
    FileNotFoundError
        If file does not exist.
    yaml.YAMLError
        If YAML parsing fails.

    Examples
    --------
    >>> from windkit.io.windio import read_plant
    >>> data = read_plant("site.yaml")
    >>> print(data["name"])
    'My Wind Farm'
    """
    return _read_windio_yaml(path, "plant", resolve=resolve)


def read_turbine(path, resolve=False):
    """Parse a windIO turbine YAML file.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    path : str or pathlib.Path
        Path to windIO turbine YAML file.
    resolve : bool, optional
        If True, eagerly resolve all ``!include`` markers.
        Default is False (markers are preserved for lazy resolution).

    Returns
    -------
    dict
        Parsed YAML as nested dictionary. ``!include`` directives
        are preserved as-is (not resolved) unless *resolve* is True.

    Raises
    ------
    FileNotFoundError
        If file does not exist.
    yaml.YAMLError
        If YAML parsing fails.

    Examples
    --------
    >>> from windkit.io.windio import read_turbine
    >>> data = read_turbine("turbine.yaml")
    >>> print(data["assembly"]["rotor_diameter"])
    130.0
    """
    return _read_windio_yaml(path, "turbine", resolve=resolve)


def _wrap_in_plant(site=None, wind_farm=None, name="windkit_import"):
    """Wrap partial windIO data in a minimal plant structure.

    Parameters
    ----------
    site : dict, optional
        Site dictionary. If None, creates minimal site with empty boundaries.
    wind_farm : dict, optional
        Wind farm dictionary. If None, creates minimal wind_farm with empty layouts.
    name : str
        Name for the plant.

    Returns
    -------
    dict
        Plant-like dictionary structure.
    """
    return {
        "name": name,
        "site": site
        if site is not None
        else {
            "name": "site",
            "boundaries": {"polygons": []},
        },
        "wind_farm": wind_farm
        if wind_farm is not None
        else {
            "name": "wind_farm",
            "layouts": [],
        },
    }


def read_site(path, resolve=False):
    """Parse a windIO site YAML file and wrap in plant structure.

    .. warning::
        windIO support is experimental. API may change in future versions.

    This function reads a standalone site file and wraps it in a minimal
    plant structure so it can be used with the from_windio translation
    functions.

    Parameters
    ----------
    path : str or pathlib.Path
        Path to windIO site YAML file.
    resolve : bool, optional
        If True, eagerly resolve all ``!include`` markers.
        Default is False (markers are preserved for lazy resolution).

    Returns
    -------
    dict
        Plant-like dictionary with the site data.

    Raises
    ------
    FileNotFoundError
        If file does not exist.

    Examples
    --------
    >>> from windkit.io.windio import read_site
    >>> from windkit.io.windio.translate import wwc_from_windio
    >>> plant_data = read_site("site.yaml")
    >>> wwc = wwc_from_windio(plant_data, crs="EPSG:32632")
    """
    site_data = _read_windio_yaml(path, "site", resolve=resolve)
    return _wrap_in_plant(site=site_data, name=site_data.get("name", "windkit_import"))


def read_energy_resource(path, resolve=False):
    """Parse a windIO energy_resource YAML file and wrap in plant structure.

    .. warning::
        windIO support is experimental. API may change in future versions.

    This function reads a standalone energy_resource file and wraps it in a
    minimal plant structure so it can be used with the from_windio translation
    functions.

    Parameters
    ----------
    path : str or pathlib.Path
        Path to windIO energy_resource YAML file.
    resolve : bool, optional
        If True, eagerly resolve all ``!include`` markers.
        Default is False (markers are preserved for lazy resolution).

    Returns
    -------
    dict
        Plant-like dictionary with the energy_resource data.

    Raises
    ------
    FileNotFoundError
        If file does not exist.

    Examples
    --------
    >>> from windkit.io.windio import read_energy_resource
    >>> from windkit.io.windio.translate import wwc_from_windio
    >>> plant_data = read_energy_resource("energy_resource.yaml")
    >>> wwc = wwc_from_windio(plant_data, crs="EPSG:32632")
    """
    er_data = _read_windio_yaml(path, "energy_resource", resolve=resolve)
    site = {
        "name": "site",
        "energy_resource": er_data,
        "boundaries": {"polygons": []},
    }
    return _wrap_in_plant(site=site)


def read_wind_resource(path, resolve=False):
    """Parse a windIO wind_resource YAML file and wrap in plant structure.

    .. warning::
        windIO support is experimental. API may change in future versions.

    This function reads a standalone wind_resource file and wraps it in a
    minimal plant structure so it can be used with the from_windio translation
    functions.

    Parameters
    ----------
    path : str or pathlib.Path
        Path to windIO wind_resource YAML file.
    resolve : bool, optional
        If True, eagerly resolve all ``!include`` markers.
        Default is False (markers are preserved for lazy resolution).

    Returns
    -------
    dict
        Plant-like dictionary with the wind_resource data.

    Raises
    ------
    FileNotFoundError
        If file does not exist.

    Examples
    --------
    >>> from windkit.io.windio import read_wind_resource
    >>> from windkit.io.windio.translate import wwc_from_windio
    >>> plant_data = read_wind_resource("wind_resource.yaml")
    >>> wwc = wwc_from_windio(plant_data, crs="EPSG:32632")
    """
    wr_data = _read_windio_yaml(path, "wind_resource", resolve=resolve)
    site = {
        "name": "site",
        "energy_resource": {"name": "wind_resource", "wind_resource": wr_data},
        "boundaries": {"polygons": []},
    }
    return _wrap_in_plant(site=site)


def read_wind_farm(path, resolve=False):
    """Parse a windIO wind_farm YAML file and wrap in plant structure.

    .. warning::
        windIO support is experimental. API may change in future versions.

    This function reads a standalone wind_farm file and wraps it in a minimal
    plant structure so it can be used with the from_windio translation
    functions.

    Parameters
    ----------
    path : str or pathlib.Path
        Path to windIO wind_farm YAML file.
    resolve : bool, optional
        If True, eagerly resolve all ``!include`` markers.
        Default is False (markers are preserved for lazy resolution).

    Returns
    -------
    dict
        Plant-like dictionary with the wind_farm data.

    Raises
    ------
    FileNotFoundError
        If file does not exist.

    Examples
    --------
    >>> from windkit.io.windio import read_wind_farm
    >>> from windkit.io.windio.translate import wind_turbines_from_windio
    >>> plant_data = read_wind_farm("wind_farm.yaml")
    >>> turbines = wind_turbines_from_windio(plant_data, crs="EPSG:32632")
    """
    wf_data = _read_windio_yaml(path, "wind_farm", resolve=resolve)
    return _wrap_in_plant(wind_farm=wf_data)


def read_layout(path, resolve=False):
    """Parse a windIO layout YAML file and wrap in plant structure.

    .. warning::
        windIO support is experimental. API may change in future versions.

    This function reads a standalone layout file (with coordinates and
    turbine_types) and wraps it in a minimal plant structure so it can be
    used with the from_windio translation functions.

    Parameters
    ----------
    path : str or pathlib.Path
        Path to windIO layout YAML file.
    resolve : bool, optional
        If True, eagerly resolve all ``!include`` markers.
        Default is False (markers are preserved for lazy resolution).

    Returns
    -------
    dict
        Plant-like dictionary with the layout data.

    Raises
    ------
    FileNotFoundError
        If file does not exist.

    Examples
    --------
    >>> from windkit.io.windio import read_layout
    >>> from windkit.io.windio.translate import wind_turbines_from_windio
    >>> plant_data = read_layout("layout.yaml")
    >>> turbines = wind_turbines_from_windio(plant_data, crs="EPSG:32632")
    """
    layout_data = _read_windio_yaml(path, "layout", resolve=resolve)
    wind_farm = {
        "name": "wind_farm",
        "layouts": [layout_data],
        "turbine_types": {},
    }
    return _wrap_in_plant(wind_farm=wind_farm)
