# (c) 2026 DTU Wind Energy
"""
Translation functions between windIO format and windkit data structures.

This module provides functions to convert between windIO dictionary structures
and windkit xarray datasets.

The implementation is split across submodules:
- wwc: Weibull Wind Climate (WWC) functions
- bwc: Binned Wind Climate (BWC) functions
- tswc: Time Series Wind Climate (TSWC) functions
- wind_turbines: Wind turbine layout functions
- wtg: Wind Turbine Generator (WTG) functions
"""

from .bwc import bwc_from_windio, bwc_to_windio
from .common import compose_plant, compose_wind_farm
from .tswc import tswc_from_windio, tswc_to_windio
from .wind_turbines import wind_turbines_from_windio, wind_turbines_to_windio
from .wtg import (
    wtg_dict_from_windio,
    wtg_from_windio,
    wtg_from_windio_turbine,
    wtg_to_windio,
)
from .wwc import wwc_from_windio, wwc_to_windio

__all__ = [
    # WWC
    "wwc_from_windio",
    "wwc_to_windio",
    # BWC
    "bwc_from_windio",
    "bwc_to_windio",
    # TSWC
    "tswc_from_windio",
    "tswc_to_windio",
    # Wind turbines
    "wind_turbines_from_windio",
    "wind_turbines_to_windio",
    # WTG
    "wtg_from_windio",
    "wtg_from_windio_turbine",
    "wtg_dict_from_windio",
    "wtg_to_windio",
    # Composition
    "compose_plant",
    "compose_wind_farm",
]
