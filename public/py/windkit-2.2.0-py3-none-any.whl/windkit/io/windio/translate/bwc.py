# (c) 2026 DTU Wind Energy
"""
Translation functions for Binned Wind Climate (BWC) data.

This module provides functions to convert between windIO dictionary structures
and windkit BWC xarray datasets.
"""

__all__ = ["bwc_from_windio", "bwc_to_windio"]

import numpy as np
import xarray as xr

from windkit.spatial import set_crs
from windkit.xarray_structures.metadata import (
    _BWC_ATTRS,
    _update_history,
    _update_var_attrs,
)
from windkit.xarray_structures.sector import create_sector_coords
from windkit.xarray_structures.wsbin import create_wsbin_coords

from .common import (
    WINDIO_DIRECTION_DIM,
    WINDIO_SPEED_DIM,
    _build_plant_structure,
    _detect_multi_height,
    _extract_data,
    _extract_dataset_coords_multi_height,
    _extract_level,
    _get_coordinates,
    _get_coords_for_stacked_point,
    _get_coords_with_defaults,
    _get_n_points_and_dims,
    _get_wind_resource,
    _get_windio_dims_multi_height,
    _infer_n_points,
    _require_crs,
    _reshape_to_sector_height_stacked_point,
    _reshape_to_sector_point,
    _reshape_to_target,
    _values_to_list,
    _values_to_list_multi_height,
)


def _reshape_to_wsbin_sector_point(data, n_wsbins, n_sectors, n_points):
    """Reshape windIO data to windkit (wsbin, sector, point) format.

    Parameters
    ----------
    data : numpy.ndarray
        Input data array.
    n_wsbins : int
        Number of wind speed bins.
    n_sectors : int
        Number of wind direction sectors.
    n_points : int
        Number of spatial points.

    Returns
    -------
    numpy.ndarray
        Data reshaped to (n_wsbins, n_sectors, n_points).
    """
    return _reshape_to_target(data, (n_wsbins, n_sectors, n_points))


def _reshape_to_wsbin_sector_height_stacked_point(
    data, n_wsbins, n_sectors, n_heights, n_points
):
    """Reshape windIO data to windkit (wsbin, sector, height, stacked_point) format.

    This is used for stacked_point spatial structure which supports multiple
    heights per location.

    Parameters
    ----------
    data : numpy.ndarray
        Input data array.
    n_wsbins : int
        Number of wind speed bins.
    n_sectors : int
        Number of wind direction sectors.
    n_heights : int
        Number of height levels.
    n_points : int
        Number of spatial points (stacked_point dimension).

    Returns
    -------
    numpy.ndarray
        Data reshaped to (n_wsbins, n_sectors, n_heights, n_points).
    """
    return _reshape_to_target(data, (n_wsbins, n_sectors, n_heights, n_points))


def bwc_from_windio(plant_data, crs=None, wind_dir_crs=None):
    """Convert windIO plant data to windkit Binned Wind Climate.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary containing site.energy_resource with
        binned wind distribution parameters.
    crs : int, dict, str, pyproj.CRS, or None
        Coordinate reference system. Required.
    wind_dir_crs : CRS-like, optional
        CRS that defines the wind-direction frame. A projected CRS denotes
        grid north and a geographic CRS denotes true north.

    Returns
    -------
    xarray.Dataset
        Binned Wind Climate dataset with point or stacked_point spatial
        structure. Uses stacked_point when multi-height data is detected.

    Raises
    ------
    ValueError
        If CRS is not provided.
        If required binned distribution parameters are missing.

    Examples
    --------
    >>> from windkit.io.windio import read_plant
    >>> from windkit.io.windio.translate import bwc_from_windio
    >>> plant_data = read_plant("site.yaml")
    >>> bwc = bwc_from_windio(plant_data, crs="EPSG:32632")
    """
    from windkit.io.windio.utils import _maybe_resolve_includes

    plant_data = _maybe_resolve_includes(plant_data)
    _require_crs(crs)

    wind_resource = _get_wind_resource(plant_data)

    # Extract binned distribution parameters
    wind_speed_dict = wind_resource.get("wind_speed")
    probability_dict = wind_resource.get("probability")
    wind_dir_data = _extract_data(wind_resource.get("wind_direction"))

    if wind_speed_dict is None or probability_dict is None:
        raise ValueError(
            "windIO wind_resource must contain wind_speed (bins) and probability. "
            f"Found keys: {list(wind_resource.keys())}"
        )

    # Extract data arrays
    wind_speed_data = _extract_data(wind_speed_dict)
    prob_data, prob_dims = _extract_data(probability_dict, with_dims=True)

    if wind_speed_data is None or prob_data is None:
        raise ValueError("wind_speed and probability must contain data.")

    # Extract sector probability
    wdfreq_data = _extract_data(wind_resource.get("sector_probability"))

    # Determine dimensions
    n_wsbins = len(wind_speed_data)
    if wind_dir_data is not None:
        n_sectors = len(wind_dir_data)
    else:
        # Try to infer from probability dims
        n_sectors = 12  # Default
        for dim_name in [WINDIO_DIRECTION_DIM, "sector"]:
            if dim_name in prob_dims:
                n_sectors = prob_data.shape[prob_dims.index(dim_name)]
                break

    # Detect multi-height data
    is_multi, n_heights, height_values = _detect_multi_height(
        wind_resource, prob_dims, prob_data.shape
    )

    # Determine number of points
    x_coords, y_coords, _ = _get_coordinates(plant_data, wind_resource)
    if x_coords is not None and y_coords is not None:
        n_points = len(x_coords)
    else:
        n_points = _infer_n_points(prob_dims, prob_data.shape)

    # Create sector coordinates
    if wind_dir_data is not None:
        sector_values = wind_dir_data
        sector_width = 360.0 / n_sectors
        sector_floor = (sector_values - sector_width / 2) % 360
        sector_ceil = (sector_values + sector_width / 2) % 360
    else:
        sector_coords = create_sector_coords(n_sectors)
        sector_values = sector_coords.values
        sector_floor = sector_coords.sector_floor.values
        sector_ceil = sector_coords.sector_ceil.values

    # Create wind speed bin coordinates
    if len(wind_speed_data) > 1:
        bin_width = np.diff(wind_speed_data).mean()
    else:
        bin_width = 1.0
    ws_edges = np.concatenate(
        [[wind_speed_data[0] - bin_width / 2], wind_speed_data + bin_width / 2]
    )
    if ws_edges[0] < 0.01:
        ws_edges[0] = 0.0
    wsbin_coords = create_wsbin_coords(ws_edges)

    if is_multi and n_heights > 1:
        # Multi-height: create stacked_point structure
        bwc = _create_bwc_stacked_point(
            plant_data,
            wind_resource,
            prob_data,
            wdfreq_data,
            sector_values,
            sector_floor,
            sector_ceil,
            wsbin_coords,
            n_wsbins,
            n_sectors,
            n_heights,
            n_points,
            height_values,
            crs,
        )
    else:
        # Single height: create point structure
        bwc = _create_bwc_point(
            plant_data,
            wind_resource,
            prob_data,
            wdfreq_data,
            sector_values,
            sector_floor,
            sector_ceil,
            wsbin_coords,
            n_wsbins,
            n_sectors,
            n_points,
            crs,
        )

    from windkit.wind_climate.binned_wind_climate import _assign_wind_dir_crs

    return _assign_wind_dir_crs(bwc, wind_dir_crs)


def _create_bwc_point(
    plant_data,
    wind_resource,
    prob_data,
    wdfreq_data,
    sector_values,
    sector_floor,
    sector_ceil,
    wsbin_coords,
    n_wsbins,
    n_sectors,
    n_points,
    crs,
):
    """Create BWC dataset with point spatial structure."""
    # Build coordinates with defaults
    x_coords, y_coords, height_data = _get_coords_with_defaults(
        plant_data, wind_resource, n_points
    )

    # Reshape probability data to (wsbin, sector, point)
    wsfreq_reshaped = _reshape_to_wsbin_sector_point(
        prob_data, n_wsbins, n_sectors, n_points
    )

    # Handle wind direction frequency
    if wdfreq_data is not None:
        wdfreq_reshaped = _reshape_to_sector_point(wdfreq_data, n_sectors, n_points)
    else:
        wdfreq_reshaped = np.full((n_sectors, n_points), 1.0 / n_sectors)

    # Create dataset
    ds = xr.Dataset(
        {
            "wsfreq": (
                ["wsbin", "sector", "point"],
                wsfreq_reshaped.astype(np.float64),
            ),
            "wdfreq": (["sector", "point"], wdfreq_reshaped.astype(np.float64)),
        },
        coords={
            "wsbin": wsbin_coords.values,
            "sector": sector_values,
            "point": np.arange(n_points),
        },
    )

    # Add additional coordinates
    ds = ds.assign_coords(
        {
            "west_east": ("point", x_coords),
            "south_north": ("point", y_coords),
            "height": ("point", height_data),
            "sector_ceil": ("sector", sector_ceil),
            "sector_floor": ("sector", sector_floor),
            "wsceil": ("wsbin", wsbin_coords.wsceil.values),
            "wsfloor": ("wsbin", wsbin_coords.wsfloor.values),
        }
    )

    # Normalize frequencies
    ds["wdfreq"] = ds["wdfreq"] / ds["wdfreq"].sum(dim="sector")
    wsfreq_sum = ds["wsfreq"].sum(dim="wsbin")
    wsfreq_normalized = xr.where(wsfreq_sum > 0, ds["wsfreq"] / wsfreq_sum, 0.0)
    ds["wsfreq"] = wsfreq_normalized.transpose("wsbin", "sector", "point")

    # Set CRS
    ds = set_crs(ds, crs)

    # Apply standard metadata
    ds = _update_var_attrs(ds, _BWC_ATTRS)
    ds = _update_history(ds)

    return ds


def _create_bwc_stacked_point(
    plant_data,
    wind_resource,
    prob_data,
    wdfreq_data,
    sector_values,
    sector_floor,
    sector_ceil,
    wsbin_coords,
    n_wsbins,
    n_sectors,
    n_heights,
    n_points,
    height_values,
    crs,
):
    """Create BWC dataset with stacked_point spatial structure for multi-height data."""
    # Get coordinates for stacked_point
    x_coords, y_coords, height_coords = _get_coords_for_stacked_point(
        plant_data, wind_resource, n_points, n_heights
    )

    # Use provided height values if available
    if height_values is not None and len(height_values) == n_heights:
        height_coords = height_values

    # Reshape probability data to (wsbin, sector, height, stacked_point)
    wsfreq_reshaped = _reshape_to_wsbin_sector_height_stacked_point(
        prob_data, n_wsbins, n_sectors, n_heights, n_points
    )

    # Handle wind direction frequency
    if wdfreq_data is not None:
        wdfreq_reshaped = _reshape_to_sector_height_stacked_point(
            wdfreq_data, n_sectors, n_heights, n_points
        )
    else:
        wdfreq_reshaped = np.full((n_sectors, n_heights, n_points), 1.0 / n_sectors)

    # Create stacked_point dataset
    ds = xr.Dataset(
        {
            "wsfreq": (
                ["wsbin", "sector", "height", "stacked_point"],
                wsfreq_reshaped.astype(np.float64),
            ),
            "wdfreq": (
                ["sector", "height", "stacked_point"],
                wdfreq_reshaped.astype(np.float64),
            ),
        },
        coords={
            "wsbin": wsbin_coords.values,
            "sector": sector_values,
            "height": ("height", height_coords),
            "stacked_point": np.arange(n_points),
        },
    )

    # Add additional coordinates
    ds = ds.assign_coords(
        {
            "west_east": ("stacked_point", x_coords),
            "south_north": ("stacked_point", y_coords),
            "sector_ceil": ("sector", sector_ceil),
            "sector_floor": ("sector", sector_floor),
            "wsceil": ("wsbin", wsbin_coords.wsceil.values),
            "wsfloor": ("wsbin", wsbin_coords.wsfloor.values),
        }
    )

    # Normalize frequencies
    ds["wdfreq"] = ds["wdfreq"] / ds["wdfreq"].sum(dim="sector")
    wsfreq_sum = ds["wsfreq"].sum(dim="wsbin")
    wsfreq_normalized = xr.where(wsfreq_sum > 0, ds["wsfreq"] / wsfreq_sum, 0.0)
    ds["wsfreq"] = wsfreq_normalized.transpose(
        "wsbin", "sector", "height", "stacked_point"
    )

    # Set CRS
    ds = set_crs(ds, crs)

    # Apply standard metadata
    ds = _update_var_attrs(ds, _BWC_ATTRS)
    ds = _update_history(ds)

    return ds


def bwc_to_windio(bwc, level="plant"):
    """Convert windkit Binned Wind Climate to windIO data structure.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Handles both point and stacked_point spatial structures. For stacked_point
    datasets (with height dimension), the height information is preserved in
    the windIO output.

    Parameters
    ----------
    bwc : xarray.Dataset
        Binned Wind Climate dataset with point or stacked_point structure.
    level : str
        Export level controlling what part of the windIO structure to return.
        Options:

        - 'plant': Complete plant structure (default)
        - 'site': Site dict with boundaries and energy_resource
        - 'energy_resource': Energy resource dict with wind_resource
        - 'wind_resource': Just the wind_resource dict with climate data

    Returns
    -------
    dict
        Dictionary at the specified level of the windIO schema structure.

    Raises
    ------
    ValueError
        If level is not one of the valid options.

    Examples
    --------
    >>> import windkit as wk
    >>> from windkit.io.windio.translate import bwc_to_windio
    >>> bwc = wk.read_bwc("histogram.tab", crs="EPSG:4326")
    >>>
    >>> # Full plant structure (default)
    >>> plant_data = bwc_to_windio(bwc)
    >>>
    >>> # Just the wind_resource dict
    >>> wind_resource = bwc_to_windio(bwc, level="wind_resource")
    """
    # Extract coordinates and check if stacked_point
    x_coords, y_coords, sector_values, heights, is_stacked = (
        _extract_dataset_coords_multi_height(bwc)
    )
    wsbin_values = bwc.wsbin.values.tolist()

    n_heights = len(heights) if is_stacked else 1
    n_points = len(x_coords)

    # Build wind_resource
    if is_stacked and n_heights > 1:
        # Multi-height export
        squeeze = n_points == 1 and n_heights == 1
        wsfreq_dims = _get_windio_dims_multi_height(
            n_points, n_heights, [WINDIO_SPEED_DIM, WINDIO_DIRECTION_DIM]
        )
        wdfreq_dims = _get_windio_dims_multi_height(
            n_points, n_heights, [WINDIO_DIRECTION_DIM]
        )

        wind_resource = {
            "wind_direction": sector_values,
            "wind_speed": wsbin_values,
            "height": heights.tolist(),
            "probability": {
                "data": _values_to_list_multi_height(
                    bwc.wsfreq, n_points, n_heights, squeeze
                ),
                "dims": wsfreq_dims,
            },
            "sector_probability": {
                "data": _values_to_list_multi_height(
                    bwc.wdfreq, n_points, n_heights, squeeze
                ),
                "dims": wdfreq_dims,
            },
        }
    else:
        # Single height export (original behavior)
        n_points_check, wsfreq_dims = _get_n_points_and_dims(
            bwc.wsfreq, [WINDIO_SPEED_DIM, WINDIO_DIRECTION_DIM]
        )
        _, wdfreq_dims = _get_n_points_and_dims(bwc.wdfreq, [WINDIO_DIRECTION_DIM])
        squeeze = n_points_check == 1

        wind_resource = {
            "wind_direction": sector_values,
            "wind_speed": wsbin_values,
            "probability": {
                "data": _values_to_list(bwc.wsfreq, squeeze),
                "dims": wsfreq_dims,
            },
            "sector_probability": {
                "data": _values_to_list(bwc.wdfreq, squeeze),
                "dims": wdfreq_dims,
            },
            "reference_height": float(heights[0]) if len(heights) > 0 else 10.0,
        }

    plant_data = _build_plant_structure(
        wind_resource, x_coords, y_coords, bwc.attrs.get("name", "windkit_export")
    )
    return _extract_level(plant_data, level)
