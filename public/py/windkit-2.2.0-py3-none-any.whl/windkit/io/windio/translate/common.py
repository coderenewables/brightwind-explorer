# (c) 2026 DTU Wind Energy
"""
Common utilities for windIO translation functions.

This module contains shared helper functions used by the WWC, BWC, and TSWC
translation modules.
"""

import numpy as np

# Dimension name constants
WINDIO_HEIGHT_DIM = "height"
WINDIO_TURBINE_DIM = "wind_turbine"
WINDIO_DIRECTION_DIM = "wind_direction"
WINDIO_SPEED_DIM = "wind_speed"


def _extract_name_from_xarray(data_var):
    """Extract string name from xarray scalar variable.

    Handles both scalar and 0-d array cases that arise from xarray
    coordinate/variable access.

    Parameters
    ----------
    data_var : xarray.DataArray or similar
        Data variable containing a name value.

    Returns
    -------
    str
        The name as a string.
    """
    name_val = data_var.values
    if hasattr(name_val, "item"):
        return str(name_val.item())
    return str(name_val)


def _datetime_to_iso_strings(time_values):
    """Convert datetime values to ISO 8601 format strings.

    Handles both pandas Timestamps (with isoformat method) and numpy
    datetime64 arrays.

    Parameters
    ----------
    time_values : array-like
        Array of datetime values (numpy datetime64 or pandas Timestamp).

    Returns
    -------
    list
        List of ISO 8601 formatted datetime strings.
    """
    import pandas as pd

    if len(time_values) > 0 and hasattr(time_values[0], "isoformat"):
        return [t.isoformat() for t in time_values]
    return pd.to_datetime(time_values).strftime("%Y-%m-%dT%H:%M:%S").tolist()


def _extract_xy_coords(ds):
    """Extract x and y coordinates from a windkit dataset.

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset with west_east and south_north coordinates.

    Returns
    -------
    tuple
        (x_coords, y_coords) as lists.
    """
    x_coords = np.atleast_1d(ds.west_east.values).flatten().tolist()
    y_coords = np.atleast_1d(ds.south_north.values).flatten().tolist()
    return x_coords, y_coords


def _require_crs(crs):
    """Validate that CRS is provided.

    Parameters
    ----------
    crs : any
        Coordinate reference system.

    Raises
    ------
    ValueError
        If CRS is None.
    """
    if crs is None:
        raise ValueError(
            "CRS is required for windIO import. Provide via 'crs' parameter."
        )


def _extract_data(data_dict, with_dims=False):
    """Extract data from windIO data structure.

    Parameters
    ----------
    data_dict : dict, list, or None
        windIO data structure. Can be:
        - dict with 'data' and optional 'dims' keys
        - list/array (direct data without wrapper)
        - None
    with_dims : bool
        If True, also return dimension names.

    Returns
    -------
    numpy.ndarray or None
        The data array, or None if not present.
    list (only if with_dims=True)
        List of dimension names.
    """
    if data_dict is None:
        return (None, []) if with_dims else None

    # Handle direct list/array (windIO often stores coordinates this way)
    if isinstance(data_dict, (list, np.ndarray)):
        arr = np.array(data_dict)
        return (arr, []) if with_dims else arr

    # Handle dict with "data" key
    if isinstance(data_dict, dict):
        data = data_dict.get("data")
        if data is None:
            return (None, data_dict.get("dims", [])) if with_dims else None
        arr = np.array(data)
        return (arr, data_dict.get("dims", [])) if with_dims else arr

    # Handle scalar or other types
    arr = np.array(data_dict)
    return (arr, []) if with_dims else arr


def _get_wind_resource(plant_data):
    """Extract wind_resource from plant data, handling nested structure.

    The windIO schema nests data as: site.energy_resource.wind_resource

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary.

    Returns
    -------
    dict
        The wind_resource dictionary containing Weibull parameters.

    Raises
    ------
    ValueError
        If wind_resource is not found.
    """
    site = plant_data.get("site", {})
    energy_resource = site.get("energy_resource", {})

    # wind_resource is nested under energy_resource
    wind_resource = energy_resource.get("wind_resource")

    if wind_resource is None:
        raise ValueError(
            "Cannot find wind_resource in windIO plant data. "
            "Expected structure: site.energy_resource.wind_resource"
        )

    return wind_resource


def _get_coordinates(plant_data, wind_resource):
    """Extract spatial coordinates, preferring wind_resource over layouts.

    windIO wind_resource can contain x, y, height directly when data varies
    spatially. These take priority over wind_farm.layouts coordinates.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary.
    wind_resource : dict
        The wind_resource dictionary.

    Returns
    -------
    tuple
        (x_coords, y_coords, height_coords) - any may be None if not present.
    """
    # Try wind_resource coordinates first (takes priority)
    x_coords = _extract_data(wind_resource.get("x"))
    y_coords = _extract_data(wind_resource.get("y"))
    height_coords = _extract_data(wind_resource.get("height"))

    # Fall back to wind_farm.layouts if wind_resource has no coordinates
    if x_coords is None or y_coords is None:
        layouts = plant_data.get("wind_farm", {}).get("layouts", [])
        if layouts:
            coordinates = layouts[0].get("coordinates", {})
            x_coords = x_coords or _extract_data(coordinates.get("x"))
            y_coords = y_coords or _extract_data(coordinates.get("y"))

    # Fall back to reference_height if height not present
    if height_coords is None:
        ref_height = wind_resource.get("reference_height")
        if ref_height is not None:
            height_coords = np.array([ref_height])

    return x_coords, y_coords, height_coords


def _broadcast_coord(arr, default, n):
    """Broadcast coordinate array to target length, or fill with default.

    Parameters
    ----------
    arr : numpy.ndarray or None
        Coordinate array to broadcast.
    default : float
        Default value if arr is None or empty.
    n : int
        Target length.

    Returns
    -------
    numpy.ndarray
        Array of length n.
    """
    if arr is None or len(arr) == 0:
        return np.full(n, default)
    return arr if len(arr) == n else np.full(n, arr[0])


# Valid level values for partial export (private module constants)
_VALID_CLIMATE_LEVELS = ("plant", "site", "energy_resource", "wind_resource")
_VALID_TURBINE_LEVELS = ("wind_farm", "layout")


def _build_boundaries(x_coords, y_coords):
    """Build windIO boundaries from coordinate extents.

    Parameters
    ----------
    x_coords : list
        X coordinates (easting).
    y_coords : list
        Y coordinates (northing).

    Returns
    -------
    dict
        Boundaries dictionary with a bounding box polygon.
    """
    return {
        "polygons": [
            {
                "x": [min(x_coords), max(x_coords), max(x_coords), min(x_coords)],
                "y": [min(y_coords), min(y_coords), max(y_coords), max(y_coords)],
            }
        ]
    }


def _build_plant_structure(wind_resource, x_coords, y_coords, name="windkit_export"):
    """Build windIO plant data structure from wind_resource and coordinates.

    Parameters
    ----------
    wind_resource : dict
        The wind_resource dictionary with climate data.
    x_coords : list
        X coordinates (easting).
    y_coords : list
        Y coordinates (northing).
    name : str
        Name for the plant.

    Returns
    -------
    dict
        Complete windIO plant data structure.
    """
    return {
        "name": name,
        "site": {
            "name": "site",
            "energy_resource": {
                "name": "wind_resource",
                "wind_resource": wind_resource,
            },
            "boundaries": _build_boundaries(x_coords, y_coords),
        },
        "wind_farm": {
            "name": "wind_farm",
            "layouts": [{"coordinates": {"x": x_coords, "y": y_coords}}],
        },
    }


def _extract_level(plant_data, level):
    """Extract the specified level from a plant data structure.

    Parameters
    ----------
    plant_data : dict
        Complete windIO plant dictionary.
    level : str
        Export level: 'plant', 'site', 'energy_resource', or 'wind_resource'.

    Returns
    -------
    dict
        The extracted level data structure.

    Raises
    ------
    ValueError
        If level is not a valid option.
    """
    if level not in _VALID_CLIMATE_LEVELS:
        raise ValueError(
            f"Invalid level '{level}'. Must be one of: {_VALID_CLIMATE_LEVELS}"
        )

    if level == "plant":
        return plant_data
    if level == "site":
        return plant_data["site"]
    if level == "energy_resource":
        return plant_data["site"]["energy_resource"]
    # level == "wind_resource"
    return plant_data["site"]["energy_resource"]["wind_resource"]


def _reshape_to_target(data, target_sizes):
    """Reshape data array to match target dimension sizes.

    This unified reshape function handles broadcasting and transposing data
    from various input shapes to a target shape. It works by:
    1. Matching input dimensions to target dimensions by size
    2. Broadcasting missing dimensions
    3. Transposing to achieve the target dimension order

    Parameters
    ----------
    data : numpy.ndarray
        Input data array of any shape.
    target_sizes : tuple of int
        Target dimension sizes in order, e.g., (n_sectors, n_points) or
        (n_wsbins, n_sectors, n_heights, n_points).

    Returns
    -------
    numpy.ndarray
        Data reshaped to target_sizes shape.

    Examples
    --------
    >>> data = np.array([1, 2, 3])  # shape (3,)
    >>> _reshape_to_target(data, (3, 5))  # broadcast to (3, 5)
    >>> _reshape_to_target(data, (12, 3, 2))  # broadcast to (12, 3, 2)
    """
    target_shape = tuple(target_sizes)
    n_target_dims = len(target_shape)

    # Scalar - broadcast to full shape
    if data.ndim == 0:
        return np.full(target_shape, float(data))

    # If shapes already match, return as-is
    if data.shape == target_shape:
        return data

    # Try to find a permutation that matches
    if data.ndim == n_target_dims:
        perm = _find_permutation(data.shape, target_shape)
        if perm is not None:
            return data.transpose(perm)

    # Handle cases where we need to broadcast
    if data.ndim < n_target_dims:
        return _broadcast_to_target(data, target_shape)

    # Higher dimensions than target - flatten and reshape
    total = int(np.prod(target_shape))
    return data.flatten()[:total].reshape(target_shape)


def _find_permutation(source_shape, target_shape):
    """Find permutation to transform source_shape to target_shape.

    Parameters
    ----------
    source_shape : tuple
        Shape of the source array.
    target_shape : tuple
        Desired target shape.

    Returns
    -------
    tuple or None
        Permutation indices, or None if no valid permutation exists.
    """
    if len(source_shape) != len(target_shape):
        return None

    # Build a mapping from target dimension sizes to their indices
    source_list = list(source_shape)
    perm = []

    for target_size in target_shape:
        if target_size in source_list:
            idx = source_list.index(target_size)
            perm.append(idx)
            # Mark as used (set to -1 to avoid reuse for identical sizes)
            source_list[idx] = -1
        else:
            return None

    return tuple(perm)


def _broadcast_to_target(data, target_shape):
    """Broadcast lower-dimensional data to target shape.

    Matches input dimensions to target dimensions by size, then broadcasts.

    Parameters
    ----------
    data : numpy.ndarray
        Input data array with fewer dimensions than target.
    target_shape : tuple
        Target shape to broadcast to.

    Returns
    -------
    numpy.ndarray
        Data broadcast to target shape.
    """
    n_target = len(target_shape)

    # Find which target dimensions this data matches
    matched_dims = []
    data_shape_list = list(data.shape)

    for i, target_size in enumerate(target_shape):
        if target_size in data_shape_list:
            idx = data_shape_list.index(target_size)
            matched_dims.append((idx, i))  # (data_dim_idx, target_dim_idx)
            data_shape_list[idx] = -1  # Mark as used

    if not matched_dims:
        # No dimension matches - use first value
        return np.full(target_shape, data.flatten()[0])

    # Sort by data dimension index to maintain relative order
    matched_dims.sort(key=lambda x: x[0])

    # Build the broadcast shape: insert size-1 dims where needed
    broadcast_shape = [1] * n_target
    for data_idx, target_idx in matched_dims:
        broadcast_shape[target_idx] = data.shape[data_idx]

    # Reorder data dimensions to match their target positions
    # First, create a transposed view with dims in target order
    data_dim_order = [d[0] for d in matched_dims]
    if data_dim_order != list(range(len(data_dim_order))):
        data = data.transpose(data_dim_order)

    # Reshape and broadcast
    reshaped = data.reshape(broadcast_shape)
    result = np.broadcast_to(reshaped, target_shape)

    # Return a copy to ensure the array is writable
    return result.copy()


def _reshape_to_sector_point(data, n_sectors, n_points):
    """Reshape windIO data to windkit (sector, point) format.

    Parameters
    ----------
    data : numpy.ndarray
        Input data array.
    n_sectors : int
        Number of wind direction sectors.
    n_points : int
        Number of spatial points.

    Returns
    -------
    numpy.ndarray
        Data reshaped to (n_sectors, n_points).
    """
    return _reshape_to_target(data, (n_sectors, n_points))


def _reshape_to_sector_height_stacked_point(data, n_sectors, n_heights, n_points):
    """Reshape windIO data to windkit (sector, height, stacked_point) format.

    This is used for stacked_point spatial structure which supports multiple
    heights per location.

    Parameters
    ----------
    data : numpy.ndarray
        Input data array.
    n_sectors : int
        Number of wind direction sectors.
    n_heights : int
        Number of height levels.
    n_points : int
        Number of spatial points (stacked_point dimension).

    Returns
    -------
    numpy.ndarray
        Data reshaped to (n_sectors, n_heights, n_points).
    """
    return _reshape_to_target(data, (n_sectors, n_heights, n_points))


def _get_coords_with_defaults(plant_data, wind_resource, n_points):
    """Get coordinates, broadcasting to n_points with defaults.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary.
    wind_resource : dict
        The wind_resource dictionary.
    n_points : int
        Number of spatial points.

    Returns
    -------
    tuple
        (x_coords, y_coords, height_coords) as numpy arrays.
    """
    x_coords, y_coords, height_coords = _get_coordinates(plant_data, wind_resource)
    return (
        _broadcast_coord(x_coords, 0.0, n_points),
        _broadcast_coord(y_coords, 0.0, n_points),
        _broadcast_coord(height_coords, 10.0, n_points),
    )


def _extract_height(ds, default=10.0):
    """Extract first height value from xarray dataset.

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset with height coordinate.
    default : float
        Default value if height not present.

    Returns
    -------
    float
        Height value.
    """
    if "height" not in ds.coords:
        return default
    return float(np.atleast_1d(ds.height.values).flatten()[0])


def _extract_dataset_coords(ds):
    """Extract common coordinates from a windkit dataset.

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset with west_east, south_north, height, and sector coordinates.

    Returns
    -------
    tuple
        (x_coords, y_coords, sector_values, height) as lists/float.
    """
    x_coords, y_coords = _extract_xy_coords(ds)
    sector_values = ds.sector.values.tolist()
    height = _extract_height(ds)
    return x_coords, y_coords, sector_values, height


def _get_n_points_and_dims(data_var, base_dims):
    """Determine number of points and windIO dimension names from data variable.

    Parameters
    ----------
    data_var : xarray.DataArray
        Data variable to analyze (e.g., ds.A or ds.wsfreq).
    base_dims : list
        Base dimension names to use (without spatial dimension).

    Returns
    -------
    tuple
        (n_points, dims) where dims includes "wind_turbine" if n_points > 1.
    """
    if data_var.ndim > len(base_dims):
        n_points = data_var.shape[-1]
    else:
        n_points = 1

    dims = base_dims + ["wind_turbine"] if n_points > 1 else base_dims
    return n_points, dims


def _values_to_list(data_var, squeeze_single_point):
    """Convert data variable to list format for windIO export.

    Parameters
    ----------
    data_var : xarray.DataArray
        Data variable to convert.
    squeeze_single_point : bool
        If True and only 1 point, squeeze the point dimension.

    Returns
    -------
    list
        Data as nested list.
    """
    n_points = data_var.shape[-1] if data_var.ndim > 1 else 1
    if squeeze_single_point and n_points == 1 and data_var.ndim > 1:
        return data_var.values[..., 0].tolist()
    return data_var.values.tolist()


def _infer_n_points(dims, data_shape, dim_names=("x", "y", "point", "wind_turbine")):
    """Infer number of spatial points from dimension info.

    Parameters
    ----------
    dims : list
        Dimension names.
    data_shape : tuple
        Shape of the data array.
    dim_names : tuple
        Possible spatial dimension names to look for.

    Returns
    -------
    int
        Number of points (minimum 1).
    """
    n_points = 1
    for name in dim_names:
        if name in dims:
            idx = dims.index(name)
            n_points = max(n_points, data_shape[idx])
    return n_points


def _get_turbine_def(type_idx, turbine_types_dict):
    """Look up turbine definition by type index.

    Handles both int and string keys (windIO format varies).

    Parameters
    ----------
    type_idx : int or str
        Turbine type index/key.
    turbine_types_dict : dict
        Dictionary mapping type indices to turbine definitions.

    Returns
    -------
    dict
        Turbine definition dictionary, or empty dict if not found.
    """
    type_key = str(type_idx) if isinstance(type_idx, int) else type_idx
    return turbine_types_dict.get(type_key, turbine_types_dict.get(type_idx, {}))


def _is_multi_height(wind_resource, dims=None):
    """Check if wind_resource contains multi-height data.

    Multi-height data has height as a dimension (not just a scalar coordinate),
    meaning data varies across multiple height levels.

    Parameters
    ----------
    wind_resource : dict
        The wind_resource dictionary.
    dims : list, optional
        Dimension names from a data variable (e.g., A_dims).

    Returns
    -------
    bool
        True if multi-height data is detected.
    int
        Number of heights (1 if single height).
    numpy.ndarray
        Array of height values.
    """
    height_data = _extract_data(wind_resource.get("height"))

    # Check if height is explicitly provided as an array with multiple values
    if height_data is not None and len(height_data) > 1:
        return True, len(height_data), height_data

    # Check if "height" appears in dimension names
    if dims is not None and WINDIO_HEIGHT_DIM in dims:
        # Height dimension present but we need to find the size
        # This case is handled by checking data shape
        return True, None, None

    # Single height case
    if height_data is not None:
        return False, 1, height_data

    # No height info - check reference_height
    ref_height = wind_resource.get("reference_height")
    if ref_height is not None:
        return False, 1, np.array([ref_height])

    return False, 1, np.array([10.0])  # Default


def _detect_multi_height(wind_resource, data_dims, data_shape):
    """Detect multi-height data and return height information.

    Consolidates the repeated multi-height detection pattern used across
    wwc, bwc, and tswc modules.

    Parameters
    ----------
    wind_resource : dict
        The wind_resource dictionary.
    data_dims : list
        Dimension names from a data variable.
    data_shape : tuple
        Shape of the data array.

    Returns
    -------
    bool
        True if multi-height data is detected.
    int
        Number of heights.
    numpy.ndarray
        Array of height values.
    """
    # Check coordinate-based multi-height
    is_multi, n_heights_from_coord, height_values = _is_multi_height(
        wind_resource, data_dims
    )

    # Check dimension-based multi-height
    n_heights_from_dims, _ = _get_height_info_from_dims(data_dims, data_shape)

    if n_heights_from_dims is not None:
        is_multi = True
        n_heights = n_heights_from_dims
        # Ensure height_values matches n_heights
        if height_values is None or len(height_values) != n_heights:
            height_values = _extract_data(wind_resource.get("height"))
            if height_values is None or len(height_values) != n_heights:
                height_values = np.linspace(10.0, 100.0, n_heights)
    else:
        n_heights = n_heights_from_coord if n_heights_from_coord else 1

    return is_multi, n_heights, height_values


def _get_height_info_from_dims(dims, data_shape):
    """Extract height dimension info from windIO dimension names and data shape.

    Parameters
    ----------
    dims : list
        Dimension names from windIO data.
    data_shape : tuple
        Shape of the data array.

    Returns
    -------
    int or None
        Number of heights if height dimension found, None otherwise.
    int or None
        Index of height dimension in data shape, None if not found.
    """
    if WINDIO_HEIGHT_DIM in dims:
        idx = dims.index(WINDIO_HEIGHT_DIM)
        return data_shape[idx], idx
    return None, None


def _get_coords_for_stacked_point(plant_data, wind_resource, n_points, n_heights):
    """Get coordinates for stacked_point structure.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary.
    wind_resource : dict
        The wind_resource dictionary.
    n_points : int
        Number of spatial points (stacked_point dimension).
    n_heights : int
        Number of height levels.

    Returns
    -------
    tuple
        (x_coords, y_coords, height_coords) as numpy arrays.
        x_coords and y_coords have length n_points.
        height_coords has length n_heights.
    """
    x_coords, y_coords, height_coords = _get_coordinates(plant_data, wind_resource)

    # Broadcast x/y to n_points
    x_coords = _broadcast_coord(x_coords, 0.0, n_points)
    y_coords = _broadcast_coord(y_coords, 0.0, n_points)

    # Height should already be the right length, but ensure it
    if height_coords is None or len(height_coords) != n_heights:
        if height_coords is not None and len(height_coords) == 1:
            # Single height - broadcast
            height_coords = np.full(n_heights, height_coords[0])
        else:
            height_coords = np.linspace(10.0, 100.0, n_heights)

    return x_coords, y_coords, height_coords


def _extract_heights_from_dataset(ds):
    """Extract height values from a windkit dataset.

    Handles both point structure (height per point) and stacked_point
    structure (height as separate dimension).

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset with height coordinate.

    Returns
    -------
    numpy.ndarray
        Array of unique height values.
    bool
        True if dataset is stacked_point structure (height is dimension).
    """
    from windkit.spatial import is_stacked_point

    if "height" not in ds.coords:
        return np.array([10.0]), False

    is_stacked = is_stacked_point(ds)

    if is_stacked:
        # Height is a dimension - return all unique heights
        heights = ds.height.values
        return np.atleast_1d(heights), True
    else:
        # Height is a coordinate on point dimension - return unique values
        heights = np.unique(ds.height.values)
        return heights, False


def _extract_dataset_coords_multi_height(ds):
    """Extract coordinates from a windkit dataset, handling multi-height.

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset with west_east, south_north, height, and sector coordinates.

    Returns
    -------
    tuple
        (x_coords, y_coords, sector_values, height_values, is_stacked) as lists/arrays.
    """
    x_coords, y_coords = _extract_xy_coords(ds)
    sector_values = ds.sector.values.tolist()
    heights, is_stacked = _extract_heights_from_dataset(ds)

    return x_coords, y_coords, sector_values, heights, is_stacked


def _get_windio_dims_multi_height(n_points, n_heights, base_dims):
    """Determine windIO dimension names for multi-height data.

    Parameters
    ----------
    n_points : int
        Number of spatial points.
    n_heights : int
        Number of height levels.
    base_dims : list
        Base dimension names (e.g., ["wind_direction"]).

    Returns
    -------
    list
        Full dimension list for windIO export.
    """
    dims = list(base_dims)
    if n_heights > 1:
        dims.append(WINDIO_HEIGHT_DIM)
    if n_points > 1:
        dims.append(WINDIO_TURBINE_DIM)
    return dims


def _values_to_list_multi_height(data_var, n_points, n_heights, squeeze_single):
    """Convert data variable to list format for windIO export, handling multi-height.

    Parameters
    ----------
    data_var : xarray.DataArray
        Data variable to convert.
    n_points : int
        Number of spatial points.
    n_heights : int
        Number of height levels.
    squeeze_single : bool
        If True, squeeze dimensions with size 1.

    Returns
    -------
    list
        Data as nested list.
    """
    values = data_var.values

    # Handle squeezing
    if squeeze_single:
        if n_points == 1 and n_heights == 1:
            # Squeeze both - just take the first spatial slice
            while values.ndim > 1:
                values = values[..., 0]
        elif n_points == 1:
            # Squeeze point dimension only (last dim)
            if values.ndim > 2:
                values = values[..., 0]
        elif n_heights == 1:
            # Squeeze height dimension (second to last for stacked_point)
            # For point structure, height is part of point dim, no squeeze needed
            pass

    return values.tolist()


def _convert_climate_to_windio(wwc=None, bwc=None, tswc=None):
    """Convert a wind climate dataset to windIO format.

    Helper function that dispatches to the appropriate converter based on
    which climate type is provided.

    Parameters
    ----------
    wwc : xarray.Dataset, optional
        Weibull Wind Climate dataset.
    bwc : xarray.Dataset, optional
        Binned Wind Climate dataset.
    tswc : xarray.Dataset, optional
        Time Series Wind Climate dataset.

    Returns
    -------
    dict or None
        windIO plant dictionary with climate data, or None if no climate provided.
    """
    if wwc is not None:
        from .wwc import wwc_to_windio

        return wwc_to_windio(wwc)

    if bwc is not None:
        from .bwc import bwc_to_windio

        return bwc_to_windio(bwc)

    if tswc is not None:
        from .tswc import tswc_to_windio

        return tswc_to_windio(tswc)

    return None


# ---- Direct xarray → xarray conversion (avoids dict roundtrip) ----

# Mapping from windkit names to windIO names per climate type
_WINDIO_CLIMATE_MAPPINGS = {
    "wwc": {
        "vars": ["A", "k", "wdfreq"],
        "var_renames": {
            "A": "weibull_a",
            "k": "weibull_k",
            "wdfreq": "sector_probability",
        },
        "dim_renames": {"sector": "wind_direction"},
        "valid_coords": {"wind_direction", "wind_turbine", "height"},
    },
    "bwc": {
        "vars": ["wsfreq", "wdfreq"],
        "var_renames": {"wsfreq": "probability", "wdfreq": "sector_probability"},
        "dim_renames": {"sector": "wind_direction", "wsbin": "wind_speed"},
        "valid_coords": {"wind_direction", "wind_speed", "wind_turbine", "height"},
    },
    "tswc": {
        "vars": ["wind_speed", "wind_direction"],
        "optional_vars": ["air_density", "turbulence_intensity", "operating"],
        "var_renames": {"air_density": "density"},
        "dim_renames": {},
        "valid_coords": {"time", "wind_turbine", "height"},
    },
}


def _to_windio_dataset(ds, mapping):
    """Convert a windkit climate dataset to a windIO-formatted xarray Dataset.

    Transforms windkit variable/dimension names to windIO equivalents,
    squeezes or renames spatial dimensions, handles height, and strips
    windkit-specific metadata.

    Parameters
    ----------
    ds : xarray.Dataset
        Windkit climate dataset (WWC, BWC, or TSWC).
    mapping : dict
        Entry from ``_WINDIO_CLIMATE_MAPPINGS`` with keys *vars*,
        *var_renames*, and *dim_renames*.

    Returns
    -------
    xarray.Dataset
        Dataset ready to be written as windIO netCDF.
    """
    # 1. Select required + present optional variables
    vars_to_select = list(mapping["vars"])
    for opt_var in mapping.get("optional_vars", []):
        if opt_var in ds.data_vars:
            vars_to_select.append(opt_var)
    out = ds[vars_to_select]

    # 2. Rename dimensions (sector → wind_direction, wsbin → wind_speed)
    dim_renames = {k: v for k, v in mapping["dim_renames"].items() if k in out.dims}
    if dim_renames:
        out = out.rename(dim_renames)

    # 3. Handle point/stacked_point spatial dimension
    for spatial_dim in ("point", "stacked_point"):
        if spatial_dim in out.dims:
            if out.sizes[spatial_dim] == 1:
                out = out.squeeze(spatial_dim, drop=True)
            else:
                out = out.rename({spatial_dim: "wind_turbine"})
                # Ensure wind_turbine has an integer coordinate (0..n-1)
                if "wind_turbine" not in out.coords:
                    out = out.assign_coords(
                        wind_turbine=np.arange(out.sizes["wind_turbine"])
                    )
            break

    # 4. Rename data variables (A → weibull_a, etc.)
    var_renames = {
        k: v for k, v in mapping["var_renames"].items() if k in out.data_vars
    }
    if var_renames:
        out = out.rename(var_renames)

    # 5. Drop any coords not in the windIO whitelist for this type
    valid_coords = mapping["valid_coords"]
    coords_to_drop = [c for c in out.coords if c not in valid_coords]
    if coords_to_drop:
        out = out.drop_vars(coords_to_drop)

    # 6. Handle height
    if "height" in out.dims:
        if out.sizes["height"] == 1:
            ref_height = float(out.height.values)
            out = out.squeeze("height", drop=True)
            out.attrs["reference_height"] = ref_height
        # Multi-height: keep height as dimension
    elif "height" in out.coords:
        ref_height = float(np.atleast_1d(out.height.values).flatten()[0])
        out = out.drop_vars("height")
        out.attrs["reference_height"] = ref_height
    else:
        out.attrs["reference_height"] = 10.0

    # 7. Convert datetime time coordinate to ISO 8601 strings
    if "time" in out.coords and np.issubdtype(out.time.dtype, np.datetime64):
        out = out.assign_coords(time=_datetime_to_iso_strings(out.time.values))

    # 8. Strip non-windIO attrs from dataset and variables
    out.attrs = {k: v for k, v in out.attrs.items() if k == "reference_height"}
    for var in out.data_vars:
        out[var].attrs = {}

    return out


def _climate_to_windio_dataset(wwc=None, bwc=None, tswc=None):
    """Convert a windkit wind climate dataset to a windIO-formatted xarray Dataset.

    Dispatches to ``_to_windio_dataset`` with the appropriate mapping.
    Unlike ``_convert_climate_to_windio`` (which returns a dict), this
    returns an xarray Dataset suitable for direct ``.to_netcdf()`` export.

    Parameters
    ----------
    wwc : xarray.Dataset, optional
        Weibull Wind Climate dataset.
    bwc : xarray.Dataset, optional
        Binned Wind Climate dataset.
    tswc : xarray.Dataset, optional
        Time Series Wind Climate dataset.

    Returns
    -------
    xarray.Dataset or None
        windIO-formatted dataset, or None if no climate provided.
    """
    if wwc is not None:
        return _to_windio_dataset(wwc, _WINDIO_CLIMATE_MAPPINGS["wwc"])
    if bwc is not None:
        return _to_windio_dataset(bwc, _WINDIO_CLIMATE_MAPPINGS["bwc"])
    if tswc is not None:
        return _to_windio_dataset(tswc, _WINDIO_CLIMATE_MAPPINGS["tswc"])
    return None


def compose_wind_farm(wind_turbines, wtgs, name="wind_farm"):
    """Compose windIO wind_farm data from windkit objects.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Creates a wind_farm-level windIO dictionary by combining turbine layouts
    with full WTG definitions. The result can be written directly with
    ``write_wind_farm()`` for use as an ``!include`` target, or embedded in
    a plant structure.

    This is a convenience wrapper around
    ``wind_turbines_to_windio(wind_turbines, wtgs, level="wind_farm")``.

    Parameters
    ----------
    wind_turbines : xarray.Dataset
        Wind turbines dataset with turbine positions and wtg_key assignments.
    wtgs : dict
        Dictionary mapping wtg_key strings to WTG datasets. All wtg_key
        values in wind_turbines must exist as keys in this dictionary.
    name : str
        Name for the wind farm (default: "wind_farm").

    Returns
    -------
    dict
        windIO wind_farm dictionary with layouts and turbine_types,
        ready to be written with ``write_wind_farm()``.

    Raises
    ------
    ValueError
        If wtg_key values in wind_turbines are missing from wtgs dict.

    Examples
    --------
    >>> import windkit as wk
    >>> from windkit.io.windio.translate import compose_wind_farm
    >>> from windkit.io.windio import write_wind_farm
    >>>
    >>> turbines = wk.read_wind_turbines("layout.csv", crs="EPSG:32632")
    >>> wtg = wk.read_wtg("turbine.wtg")
    >>>
    >>> wind_farm = compose_wind_farm(
    ...     wind_turbines=turbines,
    ...     wtgs={"IEA_10MW": wtg},
    ... )
    >>> write_wind_farm(wind_farm, "wind_farm.yaml")
    """
    from .wind_turbines import wind_turbines_to_windio

    wind_farm = wind_turbines_to_windio(wind_turbines, wtgs, level="wind_farm")
    wind_farm["name"] = name
    return wind_farm


def compose_plant(
    name="windkit_export",
    wwc=None,
    bwc=None,
    tswc=None,
    wind_turbines=None,
    wtgs=None,
):
    """Compose windIO plant data from multiple windkit objects.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Creates a complete windIO plant dictionary by combining wind climate data,
    turbine layouts, and turbine definitions. This is the primary function for
    building exportable plant files from windkit objects.

    Parameters
    ----------
    name : str
        Name for the plant (default: "windkit_export").
    wwc : xarray.Dataset, optional
        Weibull Wind Climate dataset. Mutually exclusive with bwc and tswc.
    bwc : xarray.Dataset, optional
        Binned Wind Climate dataset. Mutually exclusive with wwc and tswc.
    tswc : xarray.Dataset, optional
        Time Series Wind Climate dataset. Mutually exclusive with wwc and bwc.
    wind_turbines : xarray.Dataset, optional
        Wind turbines dataset with turbine positions and wtg_key assignments.
    wtgs : dict, optional
        Dictionary mapping wtg_key strings to WTG datasets. Required if
        wind_turbines is provided. All wtg_key values in wind_turbines must
        exist as keys in this dictionary.

    Returns
    -------
    dict
        Complete windIO plant dictionary ready to be written with write_plant().

    Raises
    ------
    ValueError
        If more than one wind climate is provided.
        If wind_turbines is provided without wtgs.
        If wtg_key values in wind_turbines are missing from wtgs dict.

    Examples
    --------
    >>> import windkit as wk
    >>> from windkit.io.windio.translate import compose_plant
    >>> from windkit.io.windio import write_plant
    >>>
    >>> # Load or create windkit objects
    >>> tswc = wk.read_tswc("timeseries.csv", crs="EPSG:32632")
    >>> turbines = wk.read_wind_turbines("layout.csv", crs="EPSG:32632")
    >>> wtg = wk.read_wtg("turbine.wtg")
    >>>
    >>> # Compose plant
    >>> plant = compose_plant(
    ...     name="My Wind Farm",
    ...     tswc=tswc,
    ...     wind_turbines=turbines,
    ...     wtgs={"IEA_10MW": wtg}
    ... )
    >>>
    >>> # Write to file
    >>> write_plant(plant, "wind_farm.yaml")
    """
    # Validate wind climate input (only one allowed)
    climate_count = sum([wwc is not None, bwc is not None, tswc is not None])
    if climate_count > 1:
        raise ValueError(
            "Only one wind climate can be provided. Choose one of: wwc, bwc, or tswc."
        )

    # Validate wind_turbines + wtgs combination
    if wind_turbines is not None and wtgs is None:
        raise ValueError(
            "wtgs dict is required when wind_turbines is provided. "
            "Provide a dict mapping wtg_key strings to WTG datasets."
        )

    # Initialize empty plant structure
    plant = {
        "name": name,
        "site": {"name": "site"},
        "wind_farm": {"name": "wind_farm"},
    }

    # Process wind climate (creates energy_resource and basic coordinates)
    climate_data = _convert_climate_to_windio(wwc=wwc, bwc=bwc, tswc=tswc)
    if climate_data is not None:
        plant["site"]["energy_resource"] = climate_data["site"]["energy_resource"]
        plant["site"]["boundaries"] = climate_data["site"]["boundaries"]

    # Process wind turbines (creates layouts and turbine_types)
    if wind_turbines is not None:
        plant["wind_farm"] = compose_wind_farm(wind_turbines, wtgs)

        # Update boundaries from turbines if no climate provided
        if climate_data is None:
            x_coords, y_coords = _extract_xy_coords(wind_turbines)
            plant["site"]["boundaries"] = _build_boundaries(x_coords, y_coords)

    return plant
