# (c) 2026 DTU Wind Energy
"""
Translation functions for Time Series Wind Climate (TSWC) data.

This module provides functions to convert between windIO dictionary structures
and windkit TSWC xarray datasets.
"""

__all__ = ["tswc_from_windio", "tswc_to_windio"]

import numpy as np
import xarray as xr

from windkit.spatial import set_crs
from windkit.xarray_structures.metadata import (
    _TS_ATTRS,
    _update_history,
    _update_var_attrs,
)

from .common import (
    WINDIO_TURBINE_DIM,
    _build_plant_structure,
    _datetime_to_iso_strings,
    _detect_multi_height,
    _extract_data,
    _extract_heights_from_dataset,
    _extract_level,
    _extract_xy_coords,
    _get_coordinates,
    _get_coords_for_stacked_point,
    _get_coords_with_defaults,
    _get_wind_resource,
    _get_windio_dims_multi_height,
    _infer_n_points,
    _require_crs,
    _reshape_to_target,
    _values_to_list,
    _values_to_list_multi_height,
)


def tswc_from_windio(plant_data, crs=None):
    """Convert windIO plant data to windkit Time Series Wind Climate.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary containing site.energy_resource with
        time series wind data.
    crs : int, dict, str, pyproj.CRS, or None
        Coordinate reference system. Required.

    Returns
    -------
    xarray.Dataset
        Time Series Wind Climate dataset with point or stacked_point spatial
        structure. Uses stacked_point when multi-height data is detected.

    Raises
    ------
    ValueError
        If CRS is not provided.
        If required time series parameters are missing.

    Examples
    --------
    >>> from windkit.io.windio import read_plant
    >>> from windkit.io.windio.translate import tswc_from_windio
    >>> plant_data = read_plant("timeseries.yaml")
    >>> tswc = tswc_from_windio(plant_data, crs="EPSG:32632")
    """
    import pandas as pd

    from windkit.io.windio.utils import _maybe_resolve_includes

    plant_data = _maybe_resolve_includes(plant_data)
    _require_crs(crs)

    wind_resource = _get_wind_resource(plant_data)

    # Extract time series parameters
    time_dict = wind_resource.get("time")
    ws_dict = wind_resource.get("wind_speed")
    wd_dict = wind_resource.get("wind_direction")

    if time_dict is None or ws_dict is None or wd_dict is None:
        raise ValueError(
            "windIO wind_resource must contain time, wind_speed, and wind_direction. "
            f"Found keys: {list(wind_resource.keys())}"
        )

    # Extract data arrays
    time_data = _extract_data(time_dict)
    ws_data, ws_dims = _extract_data(ws_dict, with_dims=True)
    wd_data = _extract_data(wd_dict)

    if time_data is None or ws_data is None or wd_data is None:
        raise ValueError("time, wind_speed, and wind_direction must contain data.")

    # Convert time to pandas DatetimeIndex
    time_index = pd.to_datetime(time_data)
    n_times = len(time_index)

    # Detect multi-height data
    is_multi, n_heights, height_values = _detect_multi_height(
        wind_resource, ws_dims, ws_data.shape
    )

    # Determine number of points
    x_coords, y_coords, _ = _get_coordinates(plant_data, wind_resource)
    if x_coords is not None and y_coords is not None:
        n_points = len(x_coords)
    else:
        n_points = _infer_n_points(ws_dims, ws_data.shape)

    if is_multi and n_heights > 1:
        # Multi-height: create stacked_point structure
        return _create_tswc_stacked_point(
            plant_data,
            wind_resource,
            ws_data,
            wd_data,
            time_index,
            n_times,
            n_heights,
            n_points,
            height_values,
            crs,
        )

    # Single height: create point structure
    return _create_tswc_point(
        plant_data,
        wind_resource,
        ws_data,
        wd_data,
        time_index,
        n_times,
        n_points,
        crs,
    )


def _finalize_dataset(ds, crs):
    """Apply CRS and standard metadata to a TSWC dataset."""
    ds = set_crs(ds, crs)
    ds = _update_var_attrs(ds, _TS_ATTRS)
    ds = _update_history(ds)
    return ds


def _create_tswc_point(
    plant_data,
    wind_resource,
    ws_data,
    wd_data,
    time_index,
    n_times,
    n_points,
    crs,
):
    """Create TSWC dataset with point spatial structure."""
    x_coords, y_coords, height_data = _get_coords_with_defaults(
        plant_data, wind_resource, n_points
    )

    target_shape = (n_times, n_points)
    ds = xr.Dataset(
        {
            "wind_speed": (
                ["time", "point"],
                _reshape_to_target(ws_data, target_shape).astype(np.float64),
            ),
            "wind_direction": (
                ["time", "point"],
                _reshape_to_target(wd_data, target_shape).astype(np.float64),
            ),
        },
        coords={
            "time": time_index,
            "point": np.arange(n_points),
            "west_east": ("point", x_coords),
            "south_north": ("point", y_coords),
            "height": ("point", height_data),
        },
    )

    return _finalize_dataset(ds, crs)


def _create_tswc_stacked_point(
    plant_data,
    wind_resource,
    ws_data,
    wd_data,
    time_index,
    n_times,
    n_heights,
    n_points,
    height_values,
    crs,
):
    """Create TSWC dataset with stacked_point spatial structure for multi-height data."""
    x_coords, y_coords, height_coords = _get_coords_for_stacked_point(
        plant_data, wind_resource, n_points, n_heights
    )

    if height_values is not None and len(height_values) == n_heights:
        height_coords = height_values

    target_shape = (n_times, n_heights, n_points)
    dims = ["time", "height", "stacked_point"]
    ds = xr.Dataset(
        {
            "wind_speed": (
                dims,
                _reshape_to_target(ws_data, target_shape).astype(np.float64),
            ),
            "wind_direction": (
                dims,
                _reshape_to_target(wd_data, target_shape).astype(np.float64),
            ),
        },
        coords={
            "time": time_index,
            "height": ("height", height_coords),
            "stacked_point": np.arange(n_points),
            "west_east": ("stacked_point", x_coords),
            "south_north": ("stacked_point", y_coords),
        },
    )

    return _finalize_dataset(ds, crs)


def tswc_to_windio(tswc, level="plant"):
    """Convert windkit Time Series Wind Climate to windIO data structure.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Handles both point and stacked_point spatial structures. For stacked_point
    datasets (with height dimension), the height information is preserved in
    the windIO output.

    Parameters
    ----------
    tswc : xarray.Dataset
        Time Series Wind Climate dataset with point or stacked_point structure.
    level : str
        Export level controlling what part of the windIO structure to return.
        Options:

        - 'plant': Complete plant structure (default)
        - 'site': Site dict with boundaries and energy_resource
        - 'energy_resource': Energy resource dict with wind_resource
        - 'wind_resource': Just the wind_resource dict with climate data

    Returns
    -------
    dict
        Dictionary at the specified level of the windIO schema structure.

    Raises
    ------
    ValueError
        If level is not one of the valid options.

    Examples
    --------
    >>> import windkit as wk
    >>> from windkit.io.windio.translate import tswc_to_windio
    >>> tswc = wk.read_tswc("timeseries.csv", crs="EPSG:32632")
    >>>
    >>> # Full plant structure (default)
    >>> plant_data = tswc_to_windio(tswc)
    >>>
    >>> # Just the wind_resource dict
    >>> wind_resource = tswc_to_windio(tswc, level="wind_resource")
    """
    # Extract coordinates and check if stacked_point
    heights, is_stacked = _extract_heights_from_dataset(tswc)
    x_coords, y_coords = _extract_xy_coords(tswc)

    n_heights = len(heights) if is_stacked else 1
    n_points = len(x_coords)

    time_list = _datetime_to_iso_strings(tswc.time.values)

    # Determine windIO dimensions
    dims = _get_windio_dims_multi_height(n_points, n_heights, ["time"])
    squeeze = n_points == 1 and n_heights == 1

    # Build wind_resource
    if is_stacked and n_heights > 1:
        # Multi-height export
        wind_resource = {
            "time": time_list,
            "height": heights.tolist(),
            "wind_speed": {
                "data": _values_to_list_multi_height(
                    tswc.wind_speed, n_points, n_heights, squeeze
                ),
                "dims": dims,
            },
            "wind_direction": {
                "data": _values_to_list_multi_height(
                    tswc.wind_direction, n_points, n_heights, squeeze
                ),
                "dims": dims,
            },
        }
    else:
        # Single height export
        single_dims = ["time"]
        if n_points > 1:
            single_dims.append(WINDIO_TURBINE_DIM)

        wind_resource = {
            "time": time_list,
            "wind_speed": {
                "data": _values_to_list(tswc.wind_speed, squeeze),
                "dims": single_dims,
            },
            "wind_direction": {
                "data": _values_to_list(tswc.wind_direction, squeeze),
                "dims": single_dims,
            },
            "reference_height": float(heights[0]) if len(heights) > 0 else 10.0,
        }

    plant_data = _build_plant_structure(
        wind_resource, x_coords, y_coords, tswc.attrs.get("name", "windkit_export")
    )
    return _extract_level(plant_data, level)
