# (c) 2026 DTU Wind Energy
"""
Translation functions for wind turbine layouts.

This module provides functions to convert between windIO wind_farm layouts
and windkit wind_turbines xarray datasets.
"""

__all__ = [
    "wind_turbines_from_windio",
    "wind_turbines_to_windio",
]

import numpy as np

from windkit.wind_farm.wind_turbines import create_wind_turbines_from_arrays

from .common import (
    _VALID_TURBINE_LEVELS,
    _extract_xy_coords,
    _get_turbine_def,
    _require_crs,
)


def _get_wind_farm(plant_data):
    """Extract wind_farm from plant data.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary.

    Returns
    -------
    dict
        The wind_farm dictionary.

    Raises
    ------
    ValueError
        If wind_farm is not found.
    """
    wind_farm = plant_data.get("wind_farm")
    if wind_farm is None:
        raise ValueError(
            "Cannot find wind_farm in windIO plant data. Expected key: wind_farm"
        )
    return wind_farm


def wind_turbines_from_windio(plant_data, crs=None):
    """Convert windIO plant data to windkit wind_turbines dataset.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Extracts turbine locations from wind_farm.layouts and maps turbine_types
    to wtg_key coordinates.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary containing wind_farm.layouts with
        coordinates and turbine_types.
    crs : int, dict, str, pyproj.CRS, or None
        Coordinate reference system. Required.

    Returns
    -------
    xarray.Dataset
        Wind turbines dataset with point spatial structure, including
        coordinates turbine_id, group_id, and wtg_key.

    Raises
    ------
    ValueError
        If CRS is not provided.
        If wind_farm or layouts are missing.

    Examples
    --------
    >>> from windkit.io.windio import read_plant
    >>> from windkit.io.windio.translate import wind_turbines_from_windio
    >>> plant_data = read_plant("wind_farm.yaml")
    >>> turbines = wind_turbines_from_windio(plant_data, crs="EPSG:32632")
    """
    from windkit.io.windio.utils import _maybe_resolve_includes

    plant_data = _maybe_resolve_includes(plant_data)
    _require_crs(crs)

    wind_farm = _get_wind_farm(plant_data)

    # Get layouts
    layouts = wind_farm.get("layouts", [])
    if not layouts:
        raise ValueError("wind_farm.layouts is empty or missing.")

    # Extract coordinates from first layout
    # (windIO typically uses first layout for primary positions)
    layout = layouts[0]
    coordinates = layout.get("coordinates", {})

    x_coords = np.array(coordinates.get("x", []))
    y_coords = np.array(coordinates.get("y", []))

    if len(x_coords) == 0 or len(y_coords) == 0:
        raise ValueError(
            "wind_farm.layouts[0].coordinates must contain x and y arrays."
        )

    n_turbines = len(x_coords)

    # Get heights - from layout, turbine_types, or default
    heights = _extract_heights(layout, wind_farm, n_turbines)

    # Get turbine type mapping
    turbine_types_array = layout.get("turbine_types", [0] * n_turbines)
    turbine_types_dict = wind_farm.get("turbine_types", {})

    # Map turbine_types to wtg_key names
    wtg_keys = _map_turbine_types_to_keys(
        turbine_types_array, turbine_types_dict, n_turbines
    )

    # Get turbine identifiers (layout-level per windIO schema, fall back to
    # wind_farm-level for older files). Use key presence rather than
    # truthiness to avoid treating an empty list as absent.
    if "turbine_identifiers" in layout:
        turbine_ids = layout["turbine_identifiers"]
    elif "turbine_identifiers" in wind_farm:
        turbine_ids = wind_farm["turbine_identifiers"]
    else:
        turbine_ids = None
    if not turbine_ids:
        turbine_ids = [f"WT{i:02d}" for i in range(n_turbines)]

    return create_wind_turbines_from_arrays(
        west_east=x_coords,
        south_north=y_coords,
        height=heights,
        wtg_keys=wtg_keys,
        turbine_ids=turbine_ids,
        group_ids=[0] * n_turbines,
        crs=crs,
    )


def _extract_heights(layout, wind_farm, n_turbines):
    """Extract hub heights from layout or turbine_types.

    Parameters
    ----------
    layout : dict
        Layout dictionary.
    wind_farm : dict
        Wind farm dictionary.
    n_turbines : int
        Number of turbines.

    Returns
    -------
    numpy.ndarray
        Array of hub heights.
    """
    # Try to get heights from layout coordinates
    coordinates = layout.get("coordinates", {})
    if "z" in coordinates:
        return np.array(coordinates["z"])

    # Get heights from turbine_types definitions
    turbine_types_array = layout.get("turbine_types", [0] * n_turbines)
    turbine_types_dict = wind_farm.get("turbine_types", {})

    heights = [
        _get_turbine_def(idx, turbine_types_dict).get("hub_height", 100.0)
        for idx in turbine_types_array
    ]
    return np.array(heights)


def _map_turbine_types_to_keys(turbine_types_array, turbine_types_dict, n_turbines):
    """Map turbine type indices to WTG key names.

    Parameters
    ----------
    turbine_types_array : list
        Array of turbine type indices per turbine.
    turbine_types_dict : dict
        Dictionary mapping indices to turbine definitions.
    n_turbines : int
        Number of turbines.

    Returns
    -------
    list
        List of WTG key strings.
    """
    if not turbine_types_array:
        return ["default"] * n_turbines

    return [
        _get_turbine_def(idx, turbine_types_dict).get("name", f"type_{idx}")
        for idx in turbine_types_array
    ]


def wind_turbines_to_windio(wind_turbines, wtgs=None, level="wind_farm"):
    """Convert windkit wind_turbines dataset to windIO data structure.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Combines turbine layout positions with full WTG definitions to produce
    schema-valid windIO output. When exporting at the ``"wind_farm"`` level,
    ``wtgs`` is required so that the exported ``turbine_types`` contain the
    ``performance`` data mandated by the windIO turbine schema. For
    ``"layout"`` level, ``wtgs`` is not needed.

    Parameters
    ----------
    wind_turbines : xarray.Dataset
        Wind turbines dataset with point spatial structure.
    wtgs : dict, optional
        Dictionary mapping wtg_key strings to WTG datasets. Required when
        ``level="wind_farm"`` (the default). Not needed for
        ``level="layout"``.
    level : str
        Export level controlling what part of the windIO structure to return.
        Options:

        - 'wind_farm': Wind farm dict with layouts and turbine_types (default)
        - 'layout': Just the layout dict with coordinates and turbine_types

    Returns
    -------
    dict
        Dictionary at the specified level of the windIO schema structure.

    Raises
    ------
    ValueError
        If level is not one of the valid options.
        If wtg_key values in wind_turbines are missing from wtgs dict.
    TypeError
        If wtgs is not a dict when required.

    Examples
    --------
    >>> import windkit as wk
    >>> from windkit.io.windio.translate import wind_turbines_to_windio
    >>> turbines = wk.create_wind_turbines_from_arrays(...)
    >>> wtg = wk.read_wtg("turbine.wtg")
    >>>
    >>> # Wind farm dict (default)
    >>> wind_farm = wind_turbines_to_windio(turbines, {"IEA_10MW": wtg})
    >>>
    >>> # Just the layout dict (wtgs not needed)
    >>> layout = wind_turbines_to_windio(turbines, level="layout")
    """
    # Backward compat: old signature was (wind_turbines, level="plant").
    # If wtgs is a string, treat it as the level argument.
    if isinstance(wtgs, str):
        level = wtgs
        wtgs = None

    # Backward compat: level="plant" wraps wind_farm in a plant structure
    _wrap_plant = False
    if level == "plant":
        level = "wind_farm"
        _wrap_plant = True

    if level not in _VALID_TURBINE_LEVELS:
        raise ValueError(
            f"Invalid level '{level}'. Must be one of: {_VALID_TURBINE_LEVELS}"
        )

    # Extract coordinates
    x_coords, y_coords = _extract_xy_coords(wind_turbines)

    # Extract turbine metadata
    turbine_ids = wind_turbines.turbine_id.values.tolist()
    wtg_keys = wind_turbines.wtg_key.values.tolist()

    # Build type index mapping (preserve insertion order)
    unique_wtg_keys = list(dict.fromkeys(wtg_keys))
    type_to_idx = {key: idx for idx, key in enumerate(unique_wtg_keys)}
    turbine_types = [type_to_idx[key] for key in wtg_keys]

    # Build layout dict
    layout = {
        "coordinates": {"x": x_coords, "y": y_coords},
        "turbine_types": turbine_types,
        "turbine_identifiers": turbine_ids,
    }

    if level == "layout":
        return layout

    # wind_farm level requires wtgs for full turbine definitions
    if wtgs is not None and not isinstance(wtgs, dict):
        raise TypeError(
            f"wtgs must be a dict mapping wtg_key strings to WTG datasets, "
            f"got {type(wtgs).__name__}"
        )
    if wtgs is None:
        raise ValueError(
            "wtgs is required for level='wind_farm'. Provide a dict mapping "
            "wtg_key strings to WTG datasets, or use level='layout'."
        )

    from .wtg import wtg_to_windio

    # Validate all wtg_keys exist in provided wtgs dict
    missing_keys = set(unique_wtg_keys) - set(wtgs.keys())
    if missing_keys:
        raise ValueError(
            f"Missing WTG definitions for wtg_key values: {sorted(missing_keys)}. "
            f"Provided wtgs keys: {sorted(wtgs.keys())}"
        )

    # Build turbine_types dict with full WTG data
    turbine_types_dict = {
        type_to_idx[key]: wtg_to_windio(wtgs[key], name=key) for key in unique_wtg_keys
    }

    # Build wind_farm dict
    wind_farm = {
        "name": "wind_farm",
        "layouts": [layout],
        "turbine_types": turbine_types_dict,
    }

    if _wrap_plant:
        return {"wind_farm": wind_farm}

    return wind_farm
