# (c) 2026 DTU Wind Energy
"""
Translation functions for Wind Turbine Generator (WTG) data.

This module provides functions to convert between windIO turbine definitions
and windkit WTG xarray datasets.
"""

__all__ = [
    "wtg_from_windio",
    "wtg_from_windio_turbine",
    "wtg_dict_from_windio",
    "wtg_to_windio",
]

import numpy as np
import xarray as xr

from windkit.wind_farm.wind_turbine_generator import RegulationType

from .common import _extract_name_from_xarray, _get_turbine_def


def _compute_power_from_cp(cp_values, wind_speeds, rotor_diameter, air_density=1.225):
    """Compute power output from Cp curve.

    Parameters
    ----------
    cp_values : array-like
        Power coefficient values.
    wind_speeds : array-like
        Wind speed values.
    rotor_diameter : float
        Rotor diameter in meters.
    air_density : float
        Air density in kg/m³.

    Returns
    -------
    numpy.ndarray
        Power output in Watts.
    """
    area = np.pi * (rotor_diameter / 2) ** 2
    cp_values = np.array(cp_values)
    wind_speeds = np.array(wind_speeds)

    # P = 0.5 * rho * A * U^3 * Cp
    return 0.5 * air_density * area * wind_speeds**3 * cp_values


def _extract_curve_data(curve_dict, value_key, speed_key):
    """Extract curve values and wind speeds from a windIO curve dict.

    Parameters
    ----------
    curve_dict : dict
        Dictionary with curve values and wind speeds.
    value_key : str
        Key for the values (e.g., 'Ct_values', 'Cp_values', 'power_values').
    speed_key : str
        Key for the wind speeds (e.g., 'Ct_wind_speeds', 'Cp_wind_speeds').

    Returns
    -------
    tuple
        (values, wind_speeds) as numpy arrays, or (None, None) if not found.
    """
    if curve_dict is None:
        return None, None

    values = curve_dict.get(value_key)
    wind_speeds = curve_dict.get(speed_key)

    if values is None or wind_speeds is None:
        return None, None

    return np.array(values), np.array(wind_speeds)


def _interpolate_to_common_wind_speeds(curves_data, target_wind_speeds):
    """Interpolate curve data to common wind speed array.

    Parameters
    ----------
    curves_data : list of tuples
        List of (values, wind_speeds) tuples.
    target_wind_speeds : numpy.ndarray
        Target wind speeds to interpolate to.

    Returns
    -------
    list
        List of interpolated values arrays (or None for missing curves).
    """
    return [
        np.interp(target_wind_speeds, speeds, values)
        if values is not None and speeds is not None
        else None
        for values, speeds in curves_data
    ]


def _build_wtg_dataset(turbine_data, air_density=1.225):
    """Build a WTG dataset from turbine data.

    This is the core conversion logic, without experimental warnings or
    include resolution. Use ``wtg_from_windio_turbine`` as the public entry
    point when calling from external code.

    Parameters
    ----------
    turbine_data : dict
        windIO turbine dictionary (already resolved).
    air_density : float
        Air density for power calculations (default: 1.225 kg/m³).

    Returns
    -------
    xarray.Dataset
        WTG dataset with power_output, thrust_coefficient, and metadata.

    Raises
    ------
    ValueError
        If required performance data is missing.
    """
    name = turbine_data.get("name", "Unknown")
    hub_height = turbine_data.get("hub_height", 100.0)
    rotor_diameter = turbine_data.get("rotor_diameter", 100.0)

    # Get performance data
    performance = turbine_data.get("performance", turbine_data)

    # Extract curves
    ct_values, ct_wind_speeds = _extract_curve_data(
        performance.get("Ct_curve"), "Ct_values", "Ct_wind_speeds"
    )
    cp_values, cp_wind_speeds = _extract_curve_data(
        performance.get("Cp_curve"), "Cp_values", "Cp_wind_speeds"
    )
    power_values, power_wind_speeds = _extract_curve_data(
        performance.get("power_curve"), "power_values", "power_wind_speeds"
    )

    # Determine wind speeds from first available curve
    common_ws = next(
        (
            s
            for s in (ct_wind_speeds, cp_wind_speeds, power_wind_speeds)
            if s is not None
        ),
        None,
    )
    if common_ws is None:
        raise ValueError(
            "windIO turbine must contain Ct_curve, Cp_curve, or power_curve."
        )

    # Interpolate all curves to common wind speeds
    ct_interp, cp_interp, power_interp = _interpolate_to_common_wind_speeds(
        [
            (ct_values, ct_wind_speeds),
            (cp_values, cp_wind_speeds),
            (power_values, power_wind_speeds),
        ],
        common_ws,
    )

    # Compute power from Cp if not provided directly, or use zeros as fallback
    if power_interp is None:
        if cp_interp is not None:
            power_interp = _compute_power_from_cp(
                cp_interp, common_ws, rotor_diameter, air_density
            )
        else:
            power_interp = np.zeros_like(common_ws)

    # Use default Ct if not provided
    if ct_interp is None:
        ct_interp = np.full_like(common_ws, 0.8)

    # Get rated values
    rated_power = performance.get("rated_power", float(power_interp.max()))
    cutin_ws = performance.get("cutin_wind_speed", float(common_ws.min()))
    cutout_ws = performance.get("cutout_wind_speed", float(common_ws.max()))

    # Create WTG dataset with dims: (mode, wind_speed)
    return xr.Dataset(
        {
            "power_output": (["mode", "wind_speed"], power_interp[np.newaxis, :]),
            "thrust_coefficient": (["mode", "wind_speed"], ct_interp[np.newaxis, :]),
            "air_density": (["mode"], [air_density]),
            "stationary_thrust_coefficient": (["mode"], [0.0]),
            "wind_speed_cutin": (["mode"], [cutin_ws]),
            "wind_speed_cutout": (["mode"], [cutout_ws]),
            "rated_power": (["mode"], [rated_power]),
            "name": name,
            "rotor_diameter": rotor_diameter,
            "hub_height": hub_height,
            "regulation_type": RegulationType.PITCH.value,
        },
        coords={
            "mode": [0],
            "wind_speed": common_ws,
        },
    )


def wtg_from_windio_turbine(turbine_data, air_density=1.225):
    """Convert windIO turbine definition to windkit WTG dataset.

    .. warning::
        windIO support is experimental. API may change in future versions.

    This handles turbine definitions from the plant schema (plant_energy_turbine)
    which contain performance curves.

    Parameters
    ----------
    turbine_data : dict
        windIO turbine dictionary containing performance data with
        Ct_curve and/or Cp_curve, hub_height, rotor_diameter.
    air_density : float
        Air density for power calculations (default: 1.225 kg/m³).

    Returns
    -------
    xarray.Dataset
        WTG dataset with power_output, thrust_coefficient, and metadata.

    Raises
    ------
    ValueError
        If required performance data is missing.

    Examples
    --------
    >>> from windkit.io.windio.translate import wtg_from_windio_turbine
    >>> turbine = {"name": "MyTurbine", "hub_height": 100, ...}
    >>> wtg = wtg_from_windio_turbine(turbine)
    """
    from windkit.io.windio.utils import _maybe_resolve_includes

    turbine_data = _maybe_resolve_includes(turbine_data)

    return _build_wtg_dataset(turbine_data, air_density=air_density)


def wtg_from_windio(plant_data, turbine_type=0, air_density=1.225):
    """Extract WTG from windIO plant data by turbine type.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary containing wind_farm.turbine_types.
    turbine_type : int or str
        The turbine type key to extract (default: 0).
    air_density : float
        Air density for power calculations (default: 1.225 kg/m³).

    Returns
    -------
    xarray.Dataset
        WTG dataset.

    Raises
    ------
    ValueError
        If turbine_type is not found.

    Examples
    --------
    >>> from windkit.io.windio import read_plant
    >>> from windkit.io.windio.translate import wtg_from_windio
    >>> plant_data = read_plant("wind_farm.yaml")
    >>> wtg = wtg_from_windio(plant_data, turbine_type=0)
    """
    from windkit.io.windio.utils import _maybe_resolve_includes

    plant_data = _maybe_resolve_includes(plant_data)

    wind_farm = plant_data.get("wind_farm", {})
    turbine_types = wind_farm.get("turbine_types", {})

    turbine_data = _get_turbine_def(turbine_type, turbine_types)

    if not turbine_data:
        available = list(turbine_types.keys())
        raise ValueError(
            f"Turbine type '{turbine_type}' not found. Available types: {available}"
        )

    return _build_wtg_dataset(turbine_data, air_density=air_density)


def wtg_dict_from_windio(plant_data, air_density=1.225):
    """Extract all WTGs from windIO plant data as a dictionary.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary containing wind_farm.turbine_types.
    air_density : float
        Air density for power calculations (default: 1.225 kg/m³).

    Returns
    -------
    dict
        Dictionary mapping WTG names to WTG datasets.

    Examples
    --------
    >>> from windkit.io.windio import read_plant
    >>> from windkit.io.windio.translate import wtg_dict_from_windio
    >>> plant_data = read_plant("wind_farm.yaml")
    >>> wtg_dict = wtg_dict_from_windio(plant_data)
    """
    from windkit.io.windio.utils import _maybe_resolve_includes

    plant_data = _maybe_resolve_includes(plant_data)

    wind_farm = plant_data.get("wind_farm", {})
    turbine_types = wind_farm.get("turbine_types", {})

    return {
        _extract_name_from_xarray(wtg["name"]): wtg
        for turbine_data in turbine_types.values()
        for wtg in [_build_wtg_dataset(turbine_data, air_density=air_density)]
    }


def wtg_to_windio(wtg, name=None, air_density=None):
    """Convert windkit WTG dataset to windIO turbine definition.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    wtg : xarray.Dataset
        WTG dataset with power_output, thrust_coefficient, and metadata.
    name : str, optional
        Override the turbine name. If None, uses the name from the WTG dataset.
    air_density : float, optional
        Deprecated. Previously used for Cp curve calculation, which is no
        longer part of windIO turbine schema output. Ignored if provided.

    Returns
    -------
    dict
        windIO turbine definition dictionary suitable for
        wind_farm.turbine_types in plant schema.

    Examples
    --------
    >>> import windkit as wk
    >>> from windkit.io.windio.translate import wtg_to_windio
    >>> wtg = wk.read_wtg("turbine.wtg")
    >>> turbine_def = wtg_to_windio(wtg)
    >>> # turbine_def can be used in compose_plant() or added to plant dict
    """
    if name is None:
        name = _extract_name_from_xarray(wtg["name"])

    hub_height = float(wtg["hub_height"].values)
    rotor_diameter = float(wtg["rotor_diameter"].values)

    wind_speeds = wtg.wind_speed.values.tolist()
    power_values = wtg.power_output.isel(mode=0).values.tolist()
    ct_values = wtg.thrust_coefficient.isel(mode=0).values.tolist()

    rated_power = float(wtg.rated_power.isel(mode=0).values)
    cutin_ws = float(wtg.wind_speed_cutin.isel(mode=0).values)
    cutout_ws = float(wtg.wind_speed_cutout.isel(mode=0).values)

    return {
        "name": name,
        "hub_height": hub_height,
        "rotor_diameter": rotor_diameter,
        "performance": {
            "Ct_curve": {
                "Ct_values": ct_values,
                "Ct_wind_speeds": wind_speeds,
            },
            "power_curve": {
                "power_values": power_values,
                "power_wind_speeds": wind_speeds,
            },
            "rated_power": rated_power,
            "cutin_wind_speed": cutin_ws,
            "cutout_wind_speed": cutout_ws,
        },
    }
