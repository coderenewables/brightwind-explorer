# (c) 2026 DTU Wind Energy
"""
Translation functions for Weibull Wind Climate (WWC) data.

This module provides functions to convert between windIO dictionary structures
and windkit WWC xarray datasets.
"""

__all__ = ["wwc_from_windio", "wwc_to_windio"]

import numpy as np
import xarray as xr

from windkit.spatial import set_crs
from windkit.xarray_structures.metadata import (
    _WEIB_ATTRS,
    _update_history,
    _update_var_attrs,
)
from windkit.xarray_structures.sector import create_sector_coords

from .common import (
    WINDIO_DIRECTION_DIM,
    _build_plant_structure,
    _detect_multi_height,
    _extract_data,
    _extract_dataset_coords_multi_height,
    _extract_level,
    _get_coordinates,
    _get_coords_for_stacked_point,
    _get_coords_with_defaults,
    _get_wind_resource,
    _get_windio_dims_multi_height,
    _infer_n_points,
    _require_crs,
    _reshape_to_sector_height_stacked_point,
    _reshape_to_sector_point,
    _values_to_list,
    _values_to_list_multi_height,
)


def wwc_from_windio(plant_data, crs=None):
    """Convert windIO plant data to windkit Weibull Wind Climate.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    plant_data : dict
        windIO plant dictionary containing site.energy_resource with
        Weibull parameters.
    crs : int, dict, str, pyproj.CRS, or None
        Coordinate reference system. Required if not present in windIO data.

    Returns
    -------
    xarray.Dataset
        Weibull Wind Climate dataset with point or stacked_point spatial
        structure. Uses stacked_point when multi-height data is detected.

    Raises
    ------
    ValueError
        If CRS is not provided and not present in windIO data.
        If required Weibull parameters are missing.

    Examples
    --------
    >>> from windkit.io.windio import read_plant
    >>> from windkit.io.windio.translate import wwc_from_windio
    >>> plant_data = read_plant("site.yaml")
    >>> wwc = wwc_from_windio(plant_data, crs="EPSG:32632")
    """
    from windkit.io.windio.utils import _maybe_resolve_includes

    plant_data = _maybe_resolve_includes(plant_data)
    _require_crs(crs)

    wind_resource = _get_wind_resource(plant_data)

    # Extract Weibull parameters
    weibull_a_dict = wind_resource.get("weibull_a")
    weibull_k_dict = wind_resource.get("weibull_k")

    if weibull_a_dict is None or weibull_k_dict is None:
        raise ValueError(
            "windIO wind_resource must contain weibull_a and weibull_k. "
            f"Found keys: {list(wind_resource.keys())}"
        )

    # Extract data arrays
    A_data, A_dims = _extract_data(weibull_a_dict, with_dims=True)
    k_data, k_dims = _extract_data(weibull_k_dict, with_dims=True)

    if A_data is None or k_data is None:
        raise ValueError("weibull_a and weibull_k must contain data.")

    # Extract sector probability (wind direction frequency)
    wdfreq_data = _extract_data(wind_resource.get("sector_probability"))

    # Extract wind direction (sector centers)
    wind_dir_data = _extract_data(wind_resource.get("wind_direction"))

    # Determine number of sectors
    if wind_dir_data is not None:
        n_sectors = len(wind_dir_data)
    elif WINDIO_DIRECTION_DIM in A_dims:
        n_sectors = A_data.shape[A_dims.index(WINDIO_DIRECTION_DIM)]
    else:
        n_sectors = 1  # Single sector / omnidirectional

    # Detect multi-height data
    is_multi, n_heights, height_values = _detect_multi_height(
        wind_resource, A_dims, A_data.shape
    )

    # Determine number of points
    x_coords, y_coords, _ = _get_coordinates(plant_data, wind_resource)
    if x_coords is not None and y_coords is not None:
        n_points = len(x_coords)
    else:
        n_points = _infer_n_points(A_dims, A_data.shape)

    # Create sector coordinates
    if wind_dir_data is not None:
        sector_coords = create_sector_coords(n_sectors, start=wind_dir_data[0])
        sector_coords = sector_coords.assign_coords(sector=wind_dir_data)
    else:
        sector_coords = create_sector_coords(n_sectors)

    if is_multi and n_heights > 1:
        # Multi-height: create stacked_point structure
        return _create_wwc_stacked_point(
            plant_data,
            wind_resource,
            A_data,
            k_data,
            wdfreq_data,
            sector_coords,
            n_sectors,
            n_heights,
            n_points,
            height_values,
            crs,
        )
    else:
        # Single height: create point structure
        return _create_wwc_point(
            plant_data,
            wind_resource,
            A_data,
            k_data,
            wdfreq_data,
            sector_coords,
            n_sectors,
            n_points,
            crs,
        )


def _create_wwc_point(
    plant_data,
    wind_resource,
    A_data,
    k_data,
    wdfreq_data,
    sector_coords,
    n_sectors,
    n_points,
    crs,
):
    """Create WWC dataset with point spatial structure."""
    # Build coordinates with defaults
    x_coords, y_coords, height_data = _get_coords_with_defaults(
        plant_data, wind_resource, n_points
    )

    # Reshape data to (sector, point) format expected by windkit
    A_reshaped = _reshape_to_sector_point(A_data, n_sectors, n_points)
    k_reshaped = _reshape_to_sector_point(k_data, n_sectors, n_points)

    if wdfreq_data is not None:
        wdfreq_reshaped = _reshape_to_sector_point(wdfreq_data, n_sectors, n_points)
    else:
        # Equal frequency for all sectors
        wdfreq_reshaped = np.full((n_sectors, n_points), 1.0 / n_sectors)

    # Create dataset
    coords = {
        "point": np.arange(n_points),
        "west_east": ("point", x_coords),
        "south_north": ("point", y_coords),
        "height": ("point", height_data),
        **sector_coords.coords,
    }

    ds = xr.Dataset(
        {
            "A": (["sector", "point"], A_reshaped.astype(np.float64)),
            "k": (["sector", "point"], k_reshaped.astype(np.float64)),
            "wdfreq": (["sector", "point"], wdfreq_reshaped.astype(np.float64)),
        },
        coords=coords,
    )

    # Normalize wdfreq to sum to 1
    ds["wdfreq"] = ds["wdfreq"] / ds["wdfreq"].sum(dim="sector")

    # Set CRS
    ds = set_crs(ds, crs)

    # Apply standard metadata
    ds = _update_var_attrs(ds, _WEIB_ATTRS)
    ds = _update_history(ds)

    return ds


def _create_wwc_stacked_point(
    plant_data,
    wind_resource,
    A_data,
    k_data,
    wdfreq_data,
    sector_coords,
    n_sectors,
    n_heights,
    n_points,
    height_values,
    crs,
):
    """Create WWC dataset with stacked_point spatial structure for multi-height data."""
    # Get coordinates for stacked_point
    x_coords, y_coords, height_coords = _get_coords_for_stacked_point(
        plant_data, wind_resource, n_points, n_heights
    )

    # Use provided height values if available
    if height_values is not None and len(height_values) == n_heights:
        height_coords = height_values

    # Reshape data to (sector, height, stacked_point) format
    A_reshaped = _reshape_to_sector_height_stacked_point(
        A_data, n_sectors, n_heights, n_points
    )
    k_reshaped = _reshape_to_sector_height_stacked_point(
        k_data, n_sectors, n_heights, n_points
    )

    if wdfreq_data is not None:
        wdfreq_reshaped = _reshape_to_sector_height_stacked_point(
            wdfreq_data, n_sectors, n_heights, n_points
        )
    else:
        # Equal frequency for all sectors
        wdfreq_reshaped = np.full((n_sectors, n_heights, n_points), 1.0 / n_sectors)

    # Create stacked_point dataset
    coords = {
        "stacked_point": np.arange(n_points),
        "height": ("height", height_coords),
        "west_east": ("stacked_point", x_coords),
        "south_north": ("stacked_point", y_coords),
        **sector_coords.coords,
    }

    ds = xr.Dataset(
        {
            "A": (
                ["sector", "height", "stacked_point"],
                A_reshaped.astype(np.float64),
            ),
            "k": (
                ["sector", "height", "stacked_point"],
                k_reshaped.astype(np.float64),
            ),
            "wdfreq": (
                ["sector", "height", "stacked_point"],
                wdfreq_reshaped.astype(np.float64),
            ),
        },
        coords=coords,
    )

    # Normalize wdfreq to sum to 1 along sector dimension
    ds["wdfreq"] = ds["wdfreq"] / ds["wdfreq"].sum(dim="sector")

    # Set CRS
    ds = set_crs(ds, crs)

    # Apply standard metadata
    ds = _update_var_attrs(ds, _WEIB_ATTRS)
    ds = _update_history(ds)

    return ds


def wwc_to_windio(wwc, level="plant"):
    """Convert windkit Weibull Wind Climate to windIO data structure.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Handles both point and stacked_point spatial structures. For stacked_point
    datasets (with height dimension), the height information is preserved in
    the windIO output.

    Parameters
    ----------
    wwc : xarray.Dataset
        Weibull Wind Climate dataset with point or stacked_point structure.
    level : str
        Export level controlling what part of the windIO structure to return.
        Options:

        - 'plant': Complete plant structure (default)
        - 'site': Site dict with boundaries and energy_resource
        - 'energy_resource': Energy resource dict with wind_resource
        - 'wind_resource': Just the wind_resource dict with climate data

    Returns
    -------
    dict
        Dictionary at the specified level of the windIO schema structure.

    Raises
    ------
    ValueError
        If level is not one of the valid options.

    Examples
    --------
    >>> import windkit as wk
    >>> from windkit.io.windio.translate import wwc_to_windio
    >>> wwc = wk.read_wwc("resource.rsf", crs="EPSG:32632")
    >>>
    >>> # Full plant structure (default)
    >>> plant_data = wwc_to_windio(wwc)
    >>>
    >>> # Just the wind_resource dict
    >>> wind_resource = wwc_to_windio(wwc, level="wind_resource")
    >>>
    >>> # Energy resource level for modular files
    >>> energy_resource = wwc_to_windio(wwc, level="energy_resource")
    """
    # Extract coordinates and check if stacked_point
    x_coords, y_coords, sector_values, heights, is_stacked = (
        _extract_dataset_coords_multi_height(wwc)
    )

    n_heights = len(heights) if is_stacked else 1
    n_points = len(x_coords)

    # Determine windIO dimensions
    dims = _get_windio_dims_multi_height(n_points, n_heights, [WINDIO_DIRECTION_DIM])
    squeeze = n_points == 1 and n_heights == 1

    # Build wind_resource
    if is_stacked and n_heights > 1:
        # Multi-height export
        wind_resource = {
            "wind_direction": sector_values,
            "height": heights.tolist(),
            "weibull_a": {
                "data": _values_to_list_multi_height(
                    wwc.A, n_points, n_heights, squeeze
                ),
                "dims": dims,
            },
            "weibull_k": {
                "data": _values_to_list_multi_height(
                    wwc.k, n_points, n_heights, squeeze
                ),
                "dims": dims,
            },
            "sector_probability": {
                "data": _values_to_list_multi_height(
                    wwc.wdfreq, n_points, n_heights, squeeze
                ),
                "dims": dims,
            },
        }
    else:
        # Single height export (original behavior)
        single_dims = [WINDIO_DIRECTION_DIM]
        if n_points > 1:
            single_dims.append("wind_turbine")

        wind_resource = {
            "wind_direction": sector_values,
            "weibull_a": {
                "data": _values_to_list(wwc.A, squeeze),
                "dims": single_dims,
            },
            "weibull_k": {
                "data": _values_to_list(wwc.k, squeeze),
                "dims": single_dims,
            },
            "sector_probability": {
                "data": _values_to_list(wwc.wdfreq, squeeze),
                "dims": single_dims,
            },
            "reference_height": float(heights[0]) if len(heights) > 0 else 10.0,
        }

    plant_data = _build_plant_structure(
        wind_resource, x_coords, y_coords, wwc.attrs.get("name", "windkit_export")
    )
    return _extract_level(plant_data, level)
