# (c) 2026 DTU Wind Energy
"""
Utility functions for windIO format support.
"""

__all__ = [
    "resolve_includes",
]

from pathlib import Path

import numpy as np
import xarray as xr
import yaml


def _fmt(v):
    """Format a value for YAML compatibility.

    Converts tuples to lists and filters empty dicts recursively.
    This matches the windIO library's _fmt function.

    Parameters
    ----------
    v : Any
        Value to format.

    Returns
    -------
    dict, list, or other
        Formatted value.
    """
    if isinstance(v, dict):
        result = {}
        for k, val in v.items():
            formatted = _fmt(val)
            if formatted != {}:
                result[k] = formatted
        return result
    if isinstance(v, tuple):
        return list(v)
    return v


def _netcdf_to_dict(ds):
    """Convert an xarray Dataset to a windIO-compatible dictionary.

    This implementation matches the windIO library's _ds2yml function.
    See: https://github.com/IEAWindSystems/windIO/blob/main/windIO/yaml.py

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset to convert.

    Returns
    -------
    dict
        Dictionary with data variables and coordinates in windIO format.
        Coordinates are stored as plain data arrays.
        Data variables include dims, data, and attrs.
    """
    d = ds.to_dict()
    # Build result dict with coords and data_vars first
    result = {
        # Coordinates: just the data values (not wrapped in a dict)
        **{k: v["data"] for k, v in d["coords"].items()},
        # Data variables: full structure with dims, data, attrs
        **d["data_vars"],
    }
    # Dataset attributes: only add if they don't collide with existing keys
    for k, v in d.get("attrs", {}).items():
        if k not in result:
            result[k] = v
    return _fmt(result)


def _dict_to_netcdf_dataset(d):
    """Convert a windIO-compatible dictionary to an xarray Dataset.

    Inverse of ``_netcdf_to_dict``. Classification rules:

    * ``{"data": [...], "dims": [...]}`` → xarray **data variable**
    * ``list`` / ``np.ndarray`` → xarray **coordinate** (dim name = key)
    * scalar (``int``, ``float``, ``str``, ``bool``) → dataset **attribute**

    Parameters
    ----------
    d : dict
        Dictionary in windIO format (as produced by ``_netcdf_to_dict``).

    Returns
    -------
    xarray.Dataset
        Dataset suitable for ``.to_netcdf()``.
    """
    coords = {}
    data_vars = {}
    attrs = {}

    for key, value in d.items():
        if isinstance(value, dict) and "data" in value:
            # Data variable: has "data" and usually "dims"
            dims = value.get("dims", [key])
            var_attrs = value.get("attrs", {})
            data_vars[key] = (dims, value["data"], var_attrs)
        elif isinstance(value, (list, np.ndarray)):
            # Coordinate: plain list/array
            coords[key] = np.asarray(value)
        elif isinstance(value, (int, float, str, bool, np.generic)):
            # Scalar → dataset attribute (includes numpy scalar types)
            attrs[key] = value

    return xr.Dataset(data_vars, coords=coords, attrs=attrs)


def _resolve_includes_recursive(data, base_path):
    """Recursively resolve !include markers in a data structure.

    Parameters
    ----------
    data : dict, list, or other
        Data structure potentially containing include markers.
    base_path : Path
        Base path for resolving relative includes.

    Returns
    -------
    dict, list, or other
        Data structure with includes resolved.
    """
    if isinstance(data, dict):
        if "__windio_include__" in data:
            # This is an include marker - resolve it
            include_path = data["__windio_include__"]
            include_base = Path(data.get("__base_path__", base_path))
            full_path = include_base / include_path

            if not full_path.exists():
                raise FileNotFoundError(
                    f"windIO include file not found: {full_path} "
                    f"(referenced from {include_base})"
                )

            # Check file extension to determine how to load
            suffix = full_path.suffix.lower()

            if suffix in (".nc", ".nc4", ".netcdf"):
                # Load netCDF file and convert to dict
                ds = xr.open_dataset(full_path)
                try:
                    included_data = _netcdf_to_dict(ds)
                finally:
                    ds.close()
                return included_data
            else:
                # Assume YAML file – use IncludeLoader so nested
                # !include tags are preserved as markers.
                from windkit.io.windio.readers import _create_include_loader

                loader = _create_include_loader(full_path.parent)
                with open(full_path, "r", encoding="utf-8") as f:
                    included_data = yaml.load(f, Loader=loader)

                # Recursively resolve includes in the included file
                return _resolve_includes_recursive(included_data, full_path.parent)
        else:
            # Regular dict - recurse into values
            return {
                k: _resolve_includes_recursive(v, base_path) for k, v in data.items()
            }
    elif isinstance(data, list):
        return [_resolve_includes_recursive(item, base_path) for item in data]
    else:
        return data


def _has_includes(data):
    """Check if a data structure contains any ``__windio_include__`` markers.

    Fast recursive check that short-circuits on the first marker found.

    Parameters
    ----------
    data : dict, list, or other
        Data structure to check.

    Returns
    -------
    bool
        True if any include markers are present.
    """
    if isinstance(data, dict):
        if "__windio_include__" in data:
            return True
        return any(_has_includes(v) for v in data.values())
    if isinstance(data, list):
        return any(_has_includes(item) for item in data)
    return False


def _maybe_resolve_includes(data):
    """Resolve ``__windio_include__`` markers if present.

    Entry point for translator functions. Returns ``data`` unchanged (same
    object) when no markers are present; otherwise resolves all includes.

    Parameters
    ----------
    data : dict, list, or other
        Data structure potentially containing include markers.

    Returns
    -------
    dict, list, or other
        Data with includes resolved, or original data if none found.
    """
    if not isinstance(data, dict) or not _has_includes(data):
        return data
    return _resolve_includes_recursive(data, Path("."))


def resolve_includes(path):
    """Parse a windIO YAML file and resolve all ``!include`` directives.

    Parameters
    ----------
    path : str or pathlib.Path
        Path to windIO YAML file with potential ``!include`` directives.

    Returns
    -------
    dict
        Fully resolved/merged dictionary with all includes expanded.

    Raises
    ------
    FileNotFoundError
        If the main file or any included file does not exist.
    yaml.YAMLError
        If YAML parsing fails.

    Notes
    -----
    Resolves includes relative to the directory containing the YAML file.
    Handles nested includes recursively.

    Examples
    --------
    >>> from windkit.io.windio import resolve_includes
    >>> # If site.yaml contains: turbine: !include turbine.yaml
    >>> data = resolve_includes("site.yaml")
    >>> # data["turbine"] now contains the full turbine.yaml contents
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"windIO file not found: {path}")

    # First, read the file with include markers preserved
    from windkit.io.windio.readers import _create_include_loader

    loader = _create_include_loader(path.parent)

    with open(path, "r", encoding="utf-8") as f:
        data = yaml.load(f, Loader=loader)

    # Then recursively resolve all includes
    return _resolve_includes_recursive(data, path.parent)


def _read_windio_climate(windiofile, translator_func, crs=None, level="plant"):
    """Read windIO file and translate to windkit climate dataset.

    Common helper for reading wwc, bwc, and tswc from windIO format.

    Parameters
    ----------
    windiofile : str or pathlib.Path
        Path to windIO YAML file.
    translator_func : callable
        Translation function (e.g., wwc_from_windio, bwc_from_windio).
    crs : int, dict, str or CRS
        Coordinate reference system.
    level : str
        windIO hierarchy level: 'plant', 'site', 'energy_resource', or 'wind_resource'.

    Returns
    -------
    xarray.Dataset
        Translated wind climate dataset.

    Raises
    ------
    ValueError
        If level is not valid.
    """
    from windkit.io.windio.readers import (
        read_energy_resource,
        read_plant,
        read_site,
        read_wind_resource,
    )
    from windkit.io.windio.translate.common import _VALID_CLIMATE_LEVELS

    if level not in _VALID_CLIMATE_LEVELS:
        raise ValueError(
            f"Invalid level '{level}'. Must be one of: {_VALID_CLIMATE_LEVELS}"
        )

    readers = {
        "plant": read_plant,
        "site": read_site,
        "energy_resource": read_energy_resource,
        "wind_resource": read_wind_resource,
    }
    plant_data = readers[level](windiofile, resolve=True)
    return translator_func(plant_data, crs=crs)


def _write_windio_climate(climate_ds, windiofile, translator_func, level="plant"):
    """Write windkit climate dataset to windIO format.

    Common helper for writing wwc, bwc, and tswc to windIO format.

    Parameters
    ----------
    climate_ds : xarray.Dataset
        Wind climate dataset (wwc, bwc, or tswc).
    windiofile : str or pathlib.Path
        Path to output windIO YAML file.
    translator_func : callable
        Translation function (e.g., wwc_to_windio, bwc_to_windio).
    level : str
        Export level: 'plant', 'site', 'energy_resource', or 'wind_resource'.
    """
    from windkit.io.windio.writers import write_plant

    plant_data = translator_func(climate_ds, level=level)
    write_plant(plant_data, windiofile)


_VALID_TURBINE_READ_LEVELS = ("plant", "wind_farm", "layout")


def _read_windio_turbines(windiofile, translator_func, crs=None, level="plant"):
    """Read windIO file and translate to windkit turbines dataset.

    Common helper for reading wind turbine layouts from windIO format.

    Parameters
    ----------
    windiofile : str or pathlib.Path
        Path to windIO YAML file.
    translator_func : callable
        Translation function (e.g., wind_turbines_from_windio).
    crs : int, dict, str or CRS
        Coordinate reference system.
    level : str
        windIO hierarchy level: 'plant', 'wind_farm', or 'layout'.

    Returns
    -------
    xarray.Dataset
        Wind turbines dataset.

    Raises
    ------
    ValueError
        If level is not valid.
    """
    from windkit.io.windio.readers import read_layout, read_plant, read_wind_farm

    if level not in _VALID_TURBINE_READ_LEVELS:
        raise ValueError(
            f"Invalid level '{level}'. Must be one of: {_VALID_TURBINE_READ_LEVELS}"
        )

    readers = {
        "plant": read_plant,
        "wind_farm": read_wind_farm,
        "layout": read_layout,
    }
    plant_data = readers[level](windiofile, resolve=True)
    return translator_func(plant_data, crs=crs)
