# (c) 2026 DTU Wind Energy
"""
YAML writing functions for windIO format.

This module provides low-level functions for writing Python dictionaries
to windIO YAML format.
"""

__all__ = [
    "export_site",
    "write_plant",
    "write_turbine",
    "write_wind_farm",
    "write_wind_resource",
]

from pathlib import Path

import yaml

from windkit.io.windio.translate.common import (
    _build_boundaries,
    _climate_to_windio_dataset,
    _convert_climate_to_windio,
    _extract_xy_coords,
)


def _create_include_representer():
    """Create a YAML representer that handles include markers.

    Returns
    -------
    type
        Custom YAML Dumper class.
    """

    class IncludeDumper(yaml.SafeDumper):
        def ignore_aliases(self, data):
            # Never use YAML anchors/aliases (&id001, *id001)
            # This makes output cleaner and more compatible
            return True

    def include_representer(dumper, data):
        """Handle include marker dicts by converting back to !include."""
        if isinstance(data, dict) and "__windio_include__" in data:
            return dumper.represent_scalar("!include", data["__windio_include__"])
        return dumper.represent_dict(data)

    IncludeDumper.add_representer(dict, include_representer)

    return IncludeDumper


def _write_windio_yaml(data, path):
    """Write a dictionary to windIO YAML format.

    Parameters
    ----------
    data : dict
        Dictionary following windIO schema structure.
    path : str or pathlib.Path
        Output file path.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    dumper = _create_include_representer()

    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, Dumper=dumper, default_flow_style=False, sort_keys=False)


def write_plant(data, path, modular=False):
    """Write a dictionary to windIO plant YAML format.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    data : dict
        Dictionary following windIO plant schema structure.
    path : str or pathlib.Path
        Output file path. When modular=True, this becomes a directory path
        and the main plant file is written as plant.yaml inside it.
    modular : bool
        If True, write modular files with !include references:
        - plant.yaml (main file with !include references)
        - site.yaml
        - energy_resource.yaml (if present)
        - wind_resource.yaml (if present)
        - wind_farm.yaml (if present)

    Returns
    -------
    dict or None
        When modular=True, returns the plant dict with !include markers.
        When modular=False (default), returns None.

    Examples
    --------
    >>> from windkit.io.windio import write_plant
    >>> data = {
    ...     "name": "My Wind Farm",
    ...     "site": {...},
    ...     "wind_farm": {...}
    ... }
    >>>
    >>> # Single file output
    >>> write_plant(data, "output.yaml")
    >>>
    >>> # Modular output with !include references
    >>> write_plant(data, "output_dir/", modular=True)
    >>> # Creates: output_dir/plant.yaml, output_dir/site.yaml, etc.
    """
    if not modular:
        _write_windio_yaml(data, path)
        return None

    return _write_modular_plant(data, path)


def _write_modular_plant(data, dir_path):
    """Write plant data as modular YAML files with !include references.

    Parameters
    ----------
    data : dict
        Dictionary following windIO plant schema structure.
    dir_path : str or pathlib.Path
        Directory path for output files.

    Returns
    -------
    dict
        Plant dict with !include markers replacing sub-components.
    """
    dir_path = Path(dir_path)
    dir_path.mkdir(parents=True, exist_ok=True)

    # Build modular plant dict with include markers
    modular_plant = {"name": data.get("name", "windkit_export")}

    # Write site and sub-components
    if "site" in data:
        site_data = data["site"]
        modular_site = {"name": site_data.get("name", "site")}

        # Write energy_resource as separate file
        if "energy_resource" in site_data:
            er_data = site_data["energy_resource"]
            modular_er = {"name": er_data.get("name", "wind_resource")}

            # Write wind_resource as separate file
            if "wind_resource" in er_data:
                _write_windio_yaml(
                    er_data["wind_resource"], dir_path / "wind_resource.yaml"
                )
                modular_er["wind_resource"] = {
                    "__windio_include__": "wind_resource.yaml"
                }

            _write_windio_yaml(modular_er, dir_path / "energy_resource.yaml")
            modular_site["energy_resource"] = {
                "__windio_include__": "energy_resource.yaml"
            }

        # Include boundaries directly (small, doesn't need separate file)
        if "boundaries" in site_data:
            modular_site["boundaries"] = site_data["boundaries"]

        _write_windio_yaml(modular_site, dir_path / "site.yaml")
        modular_plant["site"] = {"__windio_include__": "site.yaml"}

    # Write wind_farm as separate file
    if "wind_farm" in data:
        _write_windio_yaml(data["wind_farm"], dir_path / "wind_farm.yaml")
        modular_plant["wind_farm"] = {"__windio_include__": "wind_farm.yaml"}

    # Write the main plant file
    _write_windio_yaml(modular_plant, dir_path / "plant.yaml")

    return modular_plant


def write_wind_farm(data, path):
    """Write a dictionary to windIO wind_farm YAML format.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Writes a wind_farm-level dictionary suitable for use as a standalone
    file that can be referenced via ``!include`` from a plant file.

    Parameters
    ----------
    data : dict
        Dictionary following the windIO wind_farm schema structure,
        containing layouts, turbine_types, etc.
    path : str or pathlib.Path
        Output file path.

    Examples
    --------
    >>> from windkit.io.windio import write_wind_farm, compose_wind_farm
    >>> wind_farm = compose_wind_farm(turbines, wtgs={"IEA_10MW": wtg})
    >>> write_wind_farm(wind_farm, "wind_farm.yaml")
    """
    _write_windio_yaml(data, path)


def write_wind_resource(data, path):
    """Write a dictionary to windIO wind_resource YAML format.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Writes a wind_resource-level dictionary suitable for use as a standalone
    file that can be referenced via ``!include`` from an energy_resource file.

    Parameters
    ----------
    data : dict
        Dictionary following the windIO wind_resource schema structure,
        containing wind climate data (Weibull parameters, binned distributions,
        or time series).
    path : str or pathlib.Path
        Output file path.

    Examples
    --------
    >>> from windkit.io.windio import write_wind_resource, wwc_to_windio
    >>> wind_resource = wwc_to_windio(wwc, level="wind_resource")
    >>> write_wind_resource(wind_resource, "wind_resource.yaml")
    """
    _write_windio_yaml(data, path)


def export_site(
    path, wwc=None, bwc=None, tswc=None, name="site", wind_resource_format="netcdf"
):
    """Export a windkit wind climate dataset to a windIO site YAML.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Converts the given wind climate to windIO format, computes site boundaries
    from the dataset's spatial extent, and writes the result to YAML.

    Parameters
    ----------
    path : str or pathlib.Path
        Output file path (e.g. ``"output_dir/site.yaml"``).
    wwc : xarray.Dataset, optional
        Weibull Wind Climate dataset. Mutually exclusive with bwc and tswc.
    bwc : xarray.Dataset, optional
        Binned Wind Climate dataset. Mutually exclusive with wwc and tswc.
    tswc : xarray.Dataset, optional
        Time Series Wind Climate dataset. Mutually exclusive with wwc and bwc.
    name : str
        Name for the site (default: ``"site"``).
    wind_resource_format : str, optional
        How to store the wind_resource data. Default is ``"netcdf"``.

        * ``"netcdf"`` — wind_resource is written as ``wind_resource.nc``
          next to the YAML file and referenced via ``!include``.
        * ``"yaml"`` — wind_resource data is embedded inline
          (single-file output).

    Raises
    ------
    ValueError
        If *wind_resource_format* is not ``"netcdf"`` or ``"yaml"``.
    ValueError
        If zero or more than one wind climate is provided.

    Examples
    --------
    >>> from windkit.io.windio import export_site
    >>> export_site("output_dir/site.yaml", wwc=wwc)
    >>> # Creates: output_dir/site.yaml, output_dir/wind_resource.nc

    Single-file YAML output:

    >>> export_site("output_dir/site.yaml", wwc=wwc, wind_resource_format="yaml")
    >>> # Creates: output_dir/site.yaml (with inline wind_resource)
    """
    if wind_resource_format not in ("netcdf", "yaml"):
        raise ValueError(
            f"wind_resource_format must be 'netcdf' or 'yaml', "
            f"got {wind_resource_format!r}"
        )

    # Validate: exactly one climate required
    climate_count = sum([wwc is not None, bwc is not None, tswc is not None])
    if climate_count == 0:
        raise ValueError(
            "Exactly one wind climate must be provided. "
            "Choose one of: wwc, bwc, or tswc."
        )
    if climate_count > 1:
        raise ValueError(
            "Only one wind climate can be provided. Choose one of: wwc, bwc, or tswc."
        )

    path = Path(path)

    if wind_resource_format == "yaml":
        # YAML path still needs the dict representation
        plant_data = _convert_climate_to_windio(wwc=wwc, bwc=bwc, tswc=tswc)
        site = plant_data["site"]
        site["name"] = name
        _write_windio_yaml(site, path)
        return

    # netCDF path: convert directly from windkit xarray to windIO xarray
    climate = wwc if wwc is not None else bwc if bwc is not None else tswc
    x_coords, y_coords = _extract_xy_coords(climate)
    ds_windio = _climate_to_windio_dataset(wwc=wwc, bwc=bwc, tswc=tswc)

    path.parent.mkdir(parents=True, exist_ok=True)
    ds_windio.to_netcdf(path.parent / "wind_resource.nc")

    # Build site YAML with !include reference for wind_resource
    site_yaml = {
        "name": name,
        "energy_resource": {
            "name": "wind_resource",
            "wind_resource": {"__windio_include__": "wind_resource.nc"},
        },
        "boundaries": _build_boundaries(x_coords, y_coords),
    }
    _write_windio_yaml(site_yaml, path)


def write_turbine(data, path):
    """Write a dictionary to windIO turbine YAML format.

    .. warning::
        windIO support is experimental. API may change in future versions.

    Parameters
    ----------
    data : dict
        Dictionary following windIO turbine schema structure.
    path : str or pathlib.Path
        Output file path.

    Examples
    --------
    >>> from windkit.io.windio import write_turbine
    >>> data = {
    ...     "name": "IEA 3.4 MW",
    ...     "assembly": {"rotor_diameter": 130.0},
    ...     ...
    ... }
    >>> write_turbine(data, "turbine.yaml")
    """
    _write_windio_yaml(data, path)
