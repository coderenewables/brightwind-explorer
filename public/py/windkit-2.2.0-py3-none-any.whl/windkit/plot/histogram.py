# (c) 2026 DTU Wind Energy
"""
Weibull distribution and histograms plotting
All sector distribution plotting
"""

import numpy as np

from windkit.import_manager import _import_optional_dependency
from windkit.plot._helpers import (
    _get_num_rows_cols,
    check_multipoint,
    check_plotting_attrs,
)
from windkit.plot.wind_rose import wind_rose
from windkit.weibull import get_weibull_probability
from windkit.wind_climate.binned_wind_climate import validate_bwc, weibull_fit
from windkit.wind_climate.weibull_wind_climate import (
    is_wwc,
    weibull_combined,
    wwc_to_bwc,
)
from windkit.wind_climate.wind_climate import mean_power_density, mean_wind_speed


def _plot_weibull(df_sector, da_sector, sector, uniform_color, weibull, gap):
    """
    Plots the weibull distribution and histogram for a sector
    """
    px = _import_optional_dependency("plotly.express")
    go = _import_optional_dependency("plotly.graph_objects")

    # Weibull plot properties
    plot_fun_histogram = px.bar
    plot_histogram_dict = {
        "x": "wsbin",
        "y": "wsfreq",
        "custom_data": ["wsbin", "wsfreq"],
        "title": f"{sector}°",
        "color_discrete_sequence": [uniform_color],
    }

    # Histogram
    fig_weibull = plot_fun_histogram(df_sector, **plot_histogram_dict)
    yaxes_title = check_plotting_attrs(da_sector)
    xaxes_title = check_plotting_attrs(da_sector["wsbin"])

    hovertemplate_hist = (
        yaxes_title
        + ": %{customdata[1]:.2f}<br>"
        + xaxes_title
        + ": %{customdata[0]:.2f}"
    )

    fig_weibull.update_yaxes(title_text=yaxes_title)
    fig_weibull.update_xaxes(title_text=xaxes_title)
    fig_weibull.update_traces(hovertemplate=hovertemplate_hist)

    if not gap:
        fig_weibull = fig_weibull.update_layout(bargap=0)

    # Weibull
    if weibull or (weibull is None and "A" in df_sector):
        A = float(df_sector.A.sample(1).iloc[0])
        k = float(df_sector.k.sample(1).iloc[0])
        speeds, prob = get_weibull_probability(
            A, k, [np.floor(df_sector.wsbin.min()), np.ceil(df_sector.wsbin.max())]
        )
        name = f"A = {A:.2f}, k = {k:.2f}"

        hovertemplate_weib = yaxes_title + ": %{y:.2f}<br>" + xaxes_title + ": %{x:.2f}"

        fig_weibull.add_trace(
            go.Scatter(x=speeds, y=prob, name=name, hovertemplate=hovertemplate_weib)
        )

    fig_weibull = fig_weibull.update_layout(hovermode="closest")
    return fig_weibull


def _emergent_weibull_pdf(A, k, wdfreq, speeds):
    """Compute the emergent (all-sector weighted) Weibull PDF.

    Parameters
    ----------
    A : numpy.ndarray
        Per-sector Weibull scale parameters, shape (n_sectors,).
    k : numpy.ndarray
        Per-sector Weibull shape parameters, shape (n_sectors,).
    wdfreq : numpy.ndarray
        Per-sector direction frequencies, shape (n_sectors,).
    speeds : numpy.ndarray
        Wind speeds at which to evaluate, shape (n_speeds,).

    Returns
    -------
    numpy.ndarray
        Emergent PDF values, shape (n_speeds,).
    """
    A = np.atleast_1d(A)
    k = np.atleast_1d(k)
    wdfreq = np.atleast_1d(wdfreq)
    s = np.maximum(speeds[:, np.newaxis], 1e-6)  # (n_speeds, 1)
    A_safe = np.where(A == 0, 1.0, A)
    A_r = A_safe[np.newaxis, :]  # (1, n_sectors)
    k_r = k[np.newaxis, :]  # (1, n_sectors)
    pdf = (k_r / A_r) * (s / A_r) ** (k_r - 1.0) * np.exp(-((s / A_r) ** k_r))
    pdf = np.where(A[np.newaxis, :] == 0, 0.0, pdf)
    return (pdf * wdfreq[np.newaxis, :]).sum(axis=1)


def _plot_emergent_curve(ds):
    """
    Calculate and plot the emergent probability from a Binned wind climate at
    a single point.
    """
    go = _import_optional_dependency("plotly.graph_objects")

    speeds_vect = np.linspace(
        float(np.floor(ds.wsbin.min())), float(np.ceil(ds.wsbin.max())), 250
    )

    wwc = weibull_fit(ds)
    wwc_sq = wwc.squeeze()
    ds_sq = ds.squeeze()

    tot_prob_speed_all_Sect = _emergent_weibull_pdf(
        wwc_sq["A"].values,
        wwc_sq["k"].values,
        ds_sq["wdfreq"].values,
        speeds_vect,
    )

    # Plotting
    yaxes_title = "Emergent frequency per wind_speed [1]"
    xaxes_title = check_plotting_attrs(
        ds["wsbin"]
    )  # Just checking for "wsbin" attrs, not for the calculated "emergent_prob".
    hovertemplate_emerg = yaxes_title + ": %{y:.2f}<br>" + xaxes_title + ": %{x:.2f}"
    title = "All sectors"
    fig_emergent = go.Figure()
    fig_emergent.add_trace(
        go.Scatter(
            x=speeds_vect,
            y=tot_prob_speed_all_Sect,
            name="Emergent distribution",
            hovertemplate=hovertemplate_emerg,
        )
    )

    fig_emergent.update_layout(
        title=title,
        xaxis_title=xaxes_title,
        yaxis_title=yaxes_title,
        hovermode="closest",
        showlegend=False,
    )

    return fig_emergent


def _plot_combined(ds, color, weibull):
    """Plot a combined wind speed distribution with per-sector overlays.

    Creates a single-panel plot with the marginal (all-sector average) wind speed
    distribution as a stepped line, per-sector conditional distributions as faint
    stepped lines, and an optional emergent Weibull curve overlay. A metrics
    annotation box is shown in the top-right corner.

    Parameters
    ----------
    ds : xarray.Dataset
        BWC dataset at a single point (will be squeezed internally).
    color : str
        CSS color for the average distribution line.
    weibull : bool or None
        Whether to overlay the emergent Weibull curve.
    """
    go = _import_optional_dependency("plotly.graph_objects")

    ds_sq = ds.squeeze()
    # Preserve sector dimension even for single-sector datasets
    if "sector" not in ds_sq.dims:
        ds_sq = ds_sq.expand_dims("sector")
    n_sectors = ds_sq.sizes["sector"]

    # Use bin floor edges for proper step function; close with last ceiling
    wsfloor = ds_sq.coords["wsfloor"].values
    wsceil_last = ds_sq.coords["wsceil"].values[-1]
    x_steps = np.concatenate(([0.0], wsfloor, [wsceil_last]))

    # Marginal distribution: P(ws) = sum_sector(wdfreq * wsfreq)
    avg_freq_raw = (ds_sq["wsfreq"] * ds_sq["wdfreq"]).sum(dim="sector").values
    avg_freq = np.concatenate(([0.0], avg_freq_raw, [0.0]))

    # Short axis labels; attr-derived titles kept for hover templates
    xaxes_title = "Wind speed [m/s]"
    yaxes_title = "Frequency"

    fig = go.Figure()

    # 1. Per-sector stepped lines (background, faint)
    for i in range(n_sectors):
        sector_val = float(ds_sq.sector.values[i])
        sector_raw = ds_sq.isel(sector=i).wsfreq.values
        sector_freq = np.concatenate(([0.0], sector_raw, [0.0]))
        fig.add_trace(
            go.Scatter(
                x=x_steps,
                y=sector_freq,
                mode="lines",
                line=dict(color="rgba(150,150,150,0.3)", width=1, shape="hv"),
                name=f"Sector {sector_val:.0f}\u00b0",
                showlegend=False,
                hovertemplate=(
                    f"Sector: {sector_val:.0f}\u00b0<br>"
                    + xaxes_title
                    + ": %{x:.1f}<br>"
                    + yaxes_title
                    + ": %{y:.4f}"
                    + "<extra></extra>"
                ),
            )
        )

    # 2. Average distribution stepped line (middle layer)
    fig.add_trace(
        go.Scatter(
            x=x_steps,
            y=avg_freq,
            mode="lines",
            line=dict(color=color, width=2.5, shape="hv"),
            name="Average distribution",
            hovertemplate=(
                xaxes_title
                + ": %{x:.1f}<br>"
                + yaxes_title
                + ": %{y:.4f}"
                + "<extra></extra>"
            ),
        )
    )

    # 3. Weibull overlay (foreground, on top)
    show_weibull = weibull or (
        weibull is None and "A" in ds.data_vars and "k" in ds.data_vars
    )

    if show_weibull:
        # Use existing A & k if present, otherwise fit
        if "A" in ds.data_vars and "k" in ds.data_vars:
            wwc = ds[["A", "k", "wdfreq"]]
        else:
            wwc = weibull_fit(ds)

        wwc_sq = wwc.squeeze()
        speeds_vect = np.linspace(
            float(np.floor(ds_sq.wsbin.min())),
            float(np.ceil(ds_sq.wsbin.max())),
            250,
        )
        emergent_prob = _emergent_weibull_pdf(
            wwc_sq["A"].values,
            wwc_sq["k"].values,
            ds_sq["wdfreq"].values,
            speeds_vect,
        )

        # Combined A & k for legend label and annotation
        A_combined, k_combined = weibull_combined(wwc)
        A_val = float(A_combined.values.item())
        k_val = float(k_combined.values.item())

        fig.add_trace(
            go.Scatter(
                x=speeds_vect,
                y=emergent_prob,
                mode="lines",
                line=dict(color="crimson", width=2),
                name=f"Weibull (A={A_val:.2f}, k={k_val:.2f})",
                hovertemplate=(
                    xaxes_title
                    + ": %{x:.1f}<br>"
                    + yaxes_title
                    + ": %{y:.4f}"
                    + "<extra></extra>"
                ),
            )
        )

    # Metrics annotation box (top-right)
    mws = float(mean_wind_speed(ds).values.item())
    mpd = float(mean_power_density(ds).values.item())

    annotation_lines = [f"Mean WS: {mws:.2f} m/s"]
    if show_weibull:
        annotation_lines.append(f"A: {A_val:.2f} m/s")
        annotation_lines.append(f"k: {k_val:.2f}")
    annotation_lines.append(f"Power density: {mpd:.1f} W/m\u00b2")
    annotation_lines.append(f"Sectors: {n_sectors}")
    annotation_text = "<br>".join(annotation_lines)

    fig.add_annotation(
        text=annotation_text,
        xref="paper",
        yref="paper",
        x=0.98,
        y=0.98,
        xanchor="right",
        yanchor="top",
        showarrow=False,
        font=dict(size=11, family="monospace"),
        bgcolor="rgba(255,255,255,0.7)",
        bordercolor="rgba(0,0,0,0.3)",
        borderwidth=1,
        borderpad=6,
        align="left",
    )

    # Layout
    fig.update_layout(
        xaxis_title=xaxes_title,
        yaxis_title=yaxes_title,
        xaxis_rangemode="tozero",
        yaxis_rangemode="tozero",
        hovermode="closest",
        showlegend=True,
        legend=dict(yanchor="top", y=0.99, xanchor="left", x=0.01),
    )

    return fig


def _dash_app_layout(df, app):
    dcc = _import_optional_dependency("dash.dcc")
    html = _import_optional_dependency("dash.html")

    app.layout = html.Div(
        [
            html.Div(
                [
                    html.Br(),
                    html.Div(
                        "Select or deselect the sectors to be displayed on the wind rose:"
                    ),
                    html.Br(),
                    dcc.Dropdown(
                        id="sector_selection",
                        options=[{"label": f"{i}", "value": i} for i in df["sector"]],
                        value=df["sector"],
                        multi=True,
                        style={"width": "75%"},
                    ),
                ]
            ),
            html.Br(),
            html.Br(),
            html.Div(
                [
                    dcc.Graph(
                        id="wind_rose",
                        hoverData={"points": [{"theta": 0}]},
                        figure={},
                    )
                ],
                style={
                    "width": "50%",
                    "display": "inline-block",
                    "padding": "0.20",
                },
            ),
            html.Div(
                [
                    dcc.Graph(id="weibull_distribution"),
                ],
                style={
                    "width": "50%",
                    "display": "inline-block",
                    "padding": "0.20",
                },
            ),
        ]
    )
    return app


def histogram_lines(ds, colors="Phase", gap=False):
    """
    Create a "distribution" plot and matching frequency wind rose for binned wind climate.

    The distribution plot is created by drawing lines across the wind speed bins for each
    sector.

    Parameters
    ----------
    ds : xarray.Dataset
        WindKit Dataset at a single point representing either a binned or weibull wind
        climate.

    colors : str, optional
        str defining a valid plotly built-in color scale (preferred cyclical) name
        By default is defined as "Phase".

    gap : bool, optional
        Include or not gap between sectors
        By default is defined no False.

    Returns
    -------
    plotly.graph_objects.Figure
        Plotly figure for display, additional modification, or output.
    """

    check_multipoint(ds)
    px = _import_optional_dependency("plotly.express")
    _import_optional_dependency("plotly.subplots")
    plotly = _import_optional_dependency("plotly")
    make_subplots = plotly.subplots.make_subplots

    if is_wwc(ds):  # wwc (wwc) to bwc if wwc (wwc) as input
        wwc_pt = ds.squeeze()
        ds = wwc_to_bwc(wwc_pt, np.array(range(31)))
    if "wsfloor" in ds:
        ds = ds.drop_vars("wsfloor")

    # Prepare data
    ds = ds.squeeze()
    dff = ds.to_dataframe().reset_index().dropna()

    ## Wind rose plot ##
    color_scale = [i[1] for i in px.colors.get_colorscale(colors)]
    adjusted_color_scale = px.colors.sample_colorscale(color_scale, len(ds.sector) + 1)
    fig_rose = wind_rose(ds, uniform_color=adjusted_color_scale)

    ## Wind distribution plot ##
    # Plot propertiees
    plot_fun_lines = px.line
    plot_lines_dict = {
        "x": "wsbin",
        "y": "wsfreq",
        "custom_data": ["wsbin", "wsfreq", "sector"],
        "color": "sector",
    }

    plot_lines_dict["color"] = [str(i) for i in dff["sector"]]
    plot_lines_dict["color_discrete_sequence"] = adjusted_color_scale

    fig_distr = plot_fun_lines(dff, **plot_lines_dict)

    da_sector = ds.isel(sector=0).wsfreq  # All the sectors have same attrs for wsfreq
    yaxes_title = check_plotting_attrs(da_sector)
    xaxes_title = check_plotting_attrs(da_sector["wsbin"])

    hovertemplate = (
        "Sector center angle: %{customdata[2]}°<br>"
        + yaxes_title
        + ": %{customdata[1]:.2f}<br>"
        + xaxes_title
        + ": %{customdata[0]:.2f}"
    )

    # Subplots
    fig_subplots = make_subplots(
        rows=1, cols=2, specs=[[{"type": "polar"}, {"type": "xy"}]]
    )

    for traces in fig_rose["data"]:
        fig_subplots.add_trace(traces, row=1, col=1)
    for traces in fig_distr["data"]:
        fig_subplots.add_trace(traces, row=1, col=2)

    if not gap:
        fig_withoutWeibull = fig_subplots.update_polars(
            angularaxis_rotation=90, angularaxis_direction="clockwise", bargap=0
        )

    else:
        fig_withoutWeibull = fig_subplots.update_polars(
            angularaxis_rotation=90, angularaxis_direction="clockwise"
        )

    fig_withoutWeibull.update_yaxes(title_text=yaxes_title, row=1, col=2)
    fig_withoutWeibull.update_xaxes(title_text=xaxes_title, row=1, col=2)
    fig_withoutWeibull.update_traces(hovertemplate=hovertemplate, row=1, col=2)

    fig_withoutWeibull.update_layout(
        legend=dict(
            title="Sector center angle [°]",
            yanchor="top",
            y=0.99,
            xanchor="right",
            x=0.99,
        ),
        hovermode="closest",
    )
    return fig_withoutWeibull


def histogram(
    ds,
    style="faceted",
    color="dodgerblue",
    weibull=None,
    emergent_distribution=False,
    gap=False,
    share_yaxes=True,
    share_xaxes=True,
):
    """
    Plot the histogram represented in a binned wind climate.

    Has the option to include the weibull distribution represented as a line over top of
    the histogram to qualitatively evaluate the goodness of fit.

    Parameters
    ----------
    ds : xarray.Dataset
        WindKit Binned wind climate at a single point, optionally with weibull parameters
        (A & k) if the weibull fit overlay is desired.

    style : str, optional
        Can take the following values, default is "faceted" (note that "list" is enforced for
        single sector datasets, returning the first plot):

        - "combined" : A single plot showing the average (marginal) wind speed
          distribution as a stepped line, with per-sector conditional distributions
          as faint stepped lines. Optionally overlays an emergent Weibull curve and
          shows a metrics annotation box with mean wind speed, power density, and
          number of sectors.

        - "faceted" :  A single plot showing each sector as a separate sub-plot. The
          layout of the plot is designed to keep the plot "square".

        - "interactive" : Creates a Dash interactive plot that shows both the distribution
          and wind rose, hovering over different sectors in the wind rose will show
          the corresponding distribution plot

        - "list" : Returns a list of plotly figures, one for each sector

    color : str, optional
        Determines the color used for the histogram bars, default is "dodgerblue".
        Strings should define valid CSS-colors.

    weibull : bool, optional
        Should the weibull plot be drawn, default is None:

        - True : Add weibull using A & k from dataset if there, otherwise fit a weibull
          and use that for plotting

        - False : Don't add weibull to plot

        - None : Add weibull if A & k are in dataset

    emergent_distribution : bool, optional
        Should the emergent distribution be drawn, default is False:

        - True : Returns only the emergent distribution plot, ignoring the style
          and weibull arguments

        - False : Don't plot the emergent distribution

    gap : bool, optional
        Include a gap between sectors (True), default is False

    share_yaxes : bool, optional
        Link y-axis values and labels across subplots?, default True

    share_xaxes : bool, optional
        Link x-axis values and labels across subplots?, default True

    Returns
    -------
    plotly.graph_objects.Figure
        If style is "combined", "faceted", or "emergent_distribution" is True.
        Plotly figure for display, additional modification, or output.

    dash.dash.Dash
        If style is "interactive".
        Dash app (interactive plot) for display, additional modification, or output.

    list of plotly.graph_objects.Figure
        If style is "list".
        List of Plotly figures for display, additional modification, or output.
    """
    check_multipoint(ds)

    # Structural check only: a plotted slice (e.g. a single sector) need not
    # satisfy full wind-climate semantics like wdfreq summing to 1.
    validate_bwc(ds, run_extra_checks=False)

    if emergent_distribution:
        return _plot_emergent_curve(ds)

    if style == "combined":
        return _plot_combined(ds, color, weibull)

    plotly_subplots = _import_optional_dependency("plotly.subplots")
    make_subplots = plotly_subplots.make_subplots

    if weibull and ("A" not in ds.data_vars or "k" not in ds.data_vars):
        wwc = weibull_fit(ds)  # wwc of same spatial extent as the input
        ds["A"] = wwc["A"]
        ds["k"] = wwc["k"]

    is_single_sector = ds.sizes["sector"] == 1
    if not is_single_sector:
        ds = ds.squeeze()

    # Prepare data
    dss = ds.drop_vars("wsfreq")
    dss = dss.drop_vars("wsbin")
    dss = dss.drop_vars("wsceil")
    if "wsfloor" in dss:
        dss = dss.drop_vars("wsfloor")

    df = dss.to_dataframe().reset_index().dropna()
    dff = ds.to_dataframe().reset_index().dropna()

    if style == "list" or is_single_sector:
        figs = []
        for i in range(len(ds.sector)):
            df_sector = dff.copy()
            df_sector = df_sector[df_sector["sector"] == dss.sector[i].item()]
            da_sector = ds.isel(sector=i).wsfreq
            fig_weibull = _plot_weibull(
                df_sector, da_sector, dss.sector[i].item(), color, weibull, gap
            )

            fig_weibull.update_layout(
                legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99)
            )

            figs.append(fig_weibull)

        return figs if not is_single_sector else figs[0]

    elif style == "interactive":
        dash = _import_optional_dependency("dash")
        Input = dash.dependencies.Input
        Output = dash.dependencies.Output

        #### Interactive dash Weibull distribution plots #####
        app = dash.Dash(__name__)

        # App layout
        app = _dash_app_layout(df, app)

        # Connect Plotly graphs with Dash Components
        @app.callback(
            Output(component_id="wind_rose", component_property="figure"),
            [Input(component_id="sector_selection", component_property="value")],
        )
        def update_wind_rose(sectors_selected):
            dsss = ds.sel(sector=sectors_selected)
            fig_wind_rose = wind_rose(dsss, uniform_color=color, gap=gap)

            fig_wind_rose.update_layout(margin={"l": 0, "b": 0, "t": 90, "r": 0})

            if gap:
                fig_wind_rose.update_polars(bargap=1)

            return fig_wind_rose

        @app.callback(
            Output(component_id="weibull_distribution", component_property="figure"),
            [Input(component_id="wind_rose", component_property="hoverData")],
        )
        def update_weibull_distribution(hoverData):
            sector = hoverData["points"][0]["theta"]
            df_sector = dff.copy()
            df_sector = df_sector[df_sector["sector"] == sector]
            indx = np.where(ds.sector.values == sector)
            da_sector = ds.isel(sector=indx[0][0]).wsfreq

            fig_weibull = _plot_weibull(
                df_sector, da_sector, sector, color, weibull, gap
            )
            fig_weibull.update_layout(
                legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99)
            )

            fig_weibull.update_layout(margin={"l": 0, "b": 0, "t": 90, "r": 0})

            return fig_weibull

        return app

    elif style == "faceted":
        if share_yaxes:
            share_Yaxes = "all"
        else:
            share_Yaxes = None

        if share_xaxes:
            share_Xaxes = "all"
        else:
            share_Xaxes = None
        da_sector = ds.isel(sector=1).wsfreq
        yaxes_title = check_plotting_attrs(da_sector)
        xaxes_title = check_plotting_attrs(da_sector["wsbin"])

        num_plots = len(dss["sector"])
        num_rows, num_cols = _get_num_rows_cols(num_plots)

        fig_subplots = make_subplots(
            rows=num_rows,
            cols=num_cols,
            subplot_titles=[f"{i}°" for i in dss["sector"].values],
            shared_yaxes=share_Yaxes,
            shared_xaxes=share_Xaxes,
            y_title=yaxes_title,
            x_title=xaxes_title,
        )
        col_num = 0
        row_num = 1

        for i in range(len(dss["sector"])):
            if col_num < num_cols:
                col_num += 1
            else:
                row_num += 1
                col_num = 1

            df_sector = dff.copy()
            df_sector = df_sector[df_sector["sector"] == dss.sector[i].item()]
            da_sector = ds.isel(sector=i).wsfreq
            fig_weibull = _plot_weibull(
                df_sector, da_sector, dss.sector[i].item(), color, weibull, gap
            )

            for traces in fig_weibull["data"]:
                fig_subplots.add_trace(traces, row=row_num, col=col_num)

            fig_subplots.update_layout(hovermode="closest", showlegend=True)

            if not gap:
                fig_subplots = fig_subplots.update_layout(bargap=0)
        return fig_subplots
