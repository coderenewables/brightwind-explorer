# (c) 2026 DTU Wind Energy
"""
Spatial structure plotting for WindKit objects.

Functions for visualising the geometry of point, stacked_point, raster and
cuboid datasets in both plan-view (2D) and 3D perspectives.
"""

import numpy as np

from ..import_manager import _import_optional_dependency
from ..spatial._struct import get_spatial_struct


def _parse_ds_coords(ds, struct):
    """Return (x, y, z_or_None) raw arrays for the given spatial structure.

    For ``point``          z is a 1-D array aligned with x/y (height per point).
    For ``stacked_point``  z is the shared 1-D heights array.
    For ``cuboid``         z is the shared 1-D heights array.
    For ``raster``         z is None.
    """
    x = ds["west_east"].values
    y = ds["south_north"].values
    if struct in ("cuboid", "stacked_point"):
        z = ds["height"].values
    elif struct == "point" and "height" in ds.coords:
        z = ds["height"].values
    else:
        z = None
    return x, y, z


def spatial_structure_2d(
    ds,
    ax=None,
    subsample: int = 1,
    marker_size: float = 30,
    color: str = "steelblue",
    alpha: float = 0.8,
):
    """Plan-view (2D) plot of a WindKit spatial structure.

    Plots the horizontal footprint of a spatial dataset. All height levels
    collapse onto the same (west_east, south_north) plane.

    Parameters
    ----------
    ds : xarray.Dataset or xarray.DataArray
        WindKit spatial object. Recognised structures: ``point``,
        ``stacked_point``, ``raster``, ``cuboid``.
    ax : matplotlib.axes.Axes, optional
        Axes to draw on. A new figure is created when ``None``.
    subsample : int, optional
        Plot every *n*-th point. Useful for large rasters or cuboids.
    marker_size : float, optional
        Marker area in points squared (passed as ``s`` to ``scatter``).
    color : str, optional
        Marker face colour.
    alpha : float, optional
        Marker transparency (0–1).

    Returns
    -------
    matplotlib.axes.Axes
        The axes object that was drawn on.

    Raises
    ------
    ValueError
        If the spatial structure cannot be determined.
    NotImplementedError
        If an unrecognised spatial structure is encountered.
    """
    plt = _import_optional_dependency("matplotlib.pyplot")

    struct = get_spatial_struct(ds)
    if struct is None:
        raise ValueError("Cannot determine spatial structure of the input object.")

    if ax is None:
        _, ax = plt.subplots(figsize=(7, 6))

    x, y, _ = _parse_ds_coords(ds, struct)

    if struct in ("point", "stacked_point"):
        ax.scatter(
            x[::subsample], y[::subsample], s=marker_size, color=color, alpha=alpha
        )

    elif struct in ("raster", "cuboid"):
        X, Y = np.meshgrid(x, y)
        ax.scatter(
            X.ravel()[::subsample],
            Y.ravel()[::subsample],
            s=marker_size,
            color=color,
            alpha=alpha,
        )

    else:
        raise NotImplementedError(f"No 2D plotter for spatial structure '{struct}'.")

    ax.set_xlabel("West-East [m]")
    ax.set_ylabel("South-North [m]")
    ax.set_aspect("equal", adjustable="box")

    return ax


def spatial_structure_3d(
    ds,
    ax=None,
    subsample: int = 1,
    marker_size: float = 20,
    color: str = "steelblue",
    alpha: float = 0.8,
    show_tower_lines: bool = True,
):
    """3D perspective plot of a WindKit spatial structure.

    Shows where data points sit in (west_east, south_north, height) space.
    Vertical tower lines are drawn for ``stacked_point`` and ``cuboid``
    structures to highlight multi-height sampling.

    Parameters
    ----------
    ds : xarray.Dataset or xarray.DataArray
        WindKit spatial object. Recognised structures: ``point``,
        ``stacked_point``, ``raster``, ``cuboid``.
    ax : mpl_toolkits.mplot3d.Axes3D, optional
        3D axes to draw on. A new figure is created when ``None``.
    subsample : int, optional
        Plot every *n*-th point along horizontal axes. Tower lines are
        subsampled by the same factor.
    marker_size : float, optional
        Marker area in points squared passed to ``scatter``.
    color : str, optional
        Marker and line colour.
    alpha : float, optional
        Transparency for markers (0–1). Tower lines are drawn at a reduced
        opacity to stay in the background.
    show_tower_lines : bool, optional
        Draw vertical lines connecting height levels for structures that
        have multiple heights (``stacked_point``, ``cuboid``). Default True.

    Returns
    -------
    mpl_toolkits.mplot3d.Axes3D
        The axes object that was drawn on.

    Raises
    ------
    ValueError
        If the spatial structure cannot be determined.
    NotImplementedError
        If an unrecognised spatial structure is encountered.
    """
    plt = _import_optional_dependency("matplotlib.pyplot")
    _import_optional_dependency("mpl_toolkits.mplot3d")

    struct = get_spatial_struct(ds)
    if struct is None:
        raise ValueError("Cannot determine spatial structure of the input object.")

    if ax is None:
        fig = plt.figure(figsize=(8, 6))
        ax = fig.add_subplot(111, projection="3d")

    x, y, z = _parse_ds_coords(ds, struct)
    line_alpha = max(0.15, alpha * 0.4)

    if struct == "point":
        z_vals = z if z is not None else np.zeros(len(x))
        ax.scatter(
            x[::subsample],
            y[::subsample],
            z_vals[::subsample],
            s=marker_size,
            color=color,
            alpha=alpha,
            depthshade=True,
        )

    elif struct == "stacked_point":
        n_h = len(z)
        x_sub = x[::subsample]
        y_sub = y[::subsample]
        x_all = np.repeat(x_sub, n_h)
        y_all = np.repeat(y_sub, n_h)
        z_all = np.tile(z, len(x_sub))
        ax.scatter(
            x_all,
            y_all,
            z_all,
            s=marker_size,
            color=color,
            alpha=alpha,
            depthshade=True,
        )

        if show_tower_lines:
            for i in range(0, len(x), max(1, subsample)):
                ax.plot(
                    [x[i], x[i]],
                    [y[i], y[i]],
                    [z[0], z[-1]],
                    color=color,
                    linewidth=0.8,
                    alpha=line_alpha,
                )

    elif struct == "raster":
        X, Y = np.meshgrid(x, y)
        ax.scatter(
            X.ravel()[::subsample],
            Y.ravel()[::subsample],
            np.zeros(X.size)[::subsample],
            s=marker_size,
            color=color,
            alpha=alpha,
            depthshade=True,
        )

    elif struct == "cuboid":
        X, Y = np.meshgrid(x, y)
        n_h = len(z)
        x_flat = X.ravel()[::subsample]
        y_flat = Y.ravel()[::subsample]
        x_all = np.tile(x_flat, n_h)
        y_all = np.tile(y_flat, n_h)
        z_all = np.repeat(z, len(x_flat))
        ax.scatter(
            x_all,
            y_all,
            z_all,
            s=marker_size,
            color=color,
            alpha=alpha,
            depthshade=True,
        )

        if show_tower_lines:
            step_we = max(1, len(x) // max(1, 6 // subsample))
            step_sn = max(1, len(y) // max(1, 6 // subsample))
            for ix in range(0, len(x), step_we):
                for iy in range(0, len(y), step_sn):
                    ax.plot(
                        [x[ix], x[ix]],
                        [y[iy], y[iy]],
                        [z[0], z[-1]],
                        color=color,
                        linewidth=0.6,
                        alpha=line_alpha,
                    )

    else:
        raise NotImplementedError(f"No 3D plotter for spatial structure '{struct}'.")

    ax.set_xlabel("West-East [m]")
    ax.set_ylabel("South-North [m]")
    ax.set_zlabel("Height [m]")

    return ax
