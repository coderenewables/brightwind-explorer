
(c) DTU Wind Energy

# windkit.spatial

The WindKit spatial package is a collection of functions for working with
geospatial objects supported by WindKit.

The supported objects are vector maps, as geopandas `GeoDataFrame` and
`GeoSeries` objects, and array-like data, as xarray `DataArray` and `Dataset`
objects in one of the spatial structures below.

### Xarray spatial structures

A spatial structure defines how coordinates depend on spatial dimensions. It
does not prescribe where non-spatial dimensions such as `sector` or `year`
appear in a data variable:

- **point:** `west_east(point)`, `south_north(point)`, `height(point)`
- **stacked point:** `west_east(stacked_point)`,
  `south_north(stacked_point)`, `height(height)`
- **cuboid:** `west_east(west_east)`, `south_north(south_north)`,
  `height(height)`
- **raster:** `west_east(west_east)`, `south_north(south_north)`
- **vertical:** `height(height)`

Any of these coordinate axes may be scalar after selecting a single location
or height.

### Data layout and performance

An `xarray.Dataset` has no global dimension or memory order. Each `DataArray`
has its own labeled dimensions and physical strides. Dimension labels define
meaning; their order determines whether a consumer can transpose and reshape
into a view or must copy the data.

The canonical spatial dimension order is `(point,)`,
`(height, stacked_point)`, `(height, south_north, west_east)`,
`(south_north, west_east)` or `(height,)`, depending on the structure; scalar
axes are simply omitted. `_spatial_dims_in_order` returns it for any object.
Read it from there rather than from `Dataset.dims`, which iterates in
variable-insertion order and so gives two datasets with identical content
different answers.

A generated variable is stored C-contiguously as
`(*spatial_dims, *reversed(other_dims))`, which is what lets a compiled
consumer take a Fortran-ordered view of the same memory instead of a copy.
GEWC `max_wspd`, for example, is stored as:

```text
(height, south_north, west_east, year, sector)  # C-contiguous
```

Transposing that to `(sector, year, point)` and flattening the spatial axes
gives an F-contiguous array over the same buffer. Note that C-contiguity alone
is not the property that matters — every dimension order is C-contiguous as
written; it is the *order* that decides whether the consumer copies.

`create_cuboid` contains only one-dimensional coordinates and therefore has no
multidimensional memory order itself. Its canonical logical order keeps
`west_east` as the fastest-varying spatial axis when data are stored in C order.

### Overview of modules:
 * `spatial.py`: contains the user-facing API's and calls appropriate functions for each type+structure.
 * `crs.py`: code for working with Coordinate Reference System's.
 * `bbox.py`: Code for working with bounding boxes.
 * `vector.py`: contains vector related spatial functions.
 * `dimensions.py`: defines spatial dimension names and order for array objects
 * `struct.py`: functions for checking the structure of array objects
 * `point.py`: functions for working with point-like array objects
 * `raster.py`: functions for working with raster-like array objects (including cuboid's)
 * `vertical.py`: functions for working with vertical data.
 * `utm.py`: code for working with UTM zones.
