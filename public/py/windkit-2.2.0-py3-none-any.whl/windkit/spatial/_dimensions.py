# (c) 2026 DTU Wind Energy
"""
windkit.spatial module for code and metadata for working
with the supported WindKit xarray objects dimensions.

Supported spatial structures are:

point (public)
    dimensions: (..., 'point')
    coords:
        height: ('point',)
        south_north: ('point',)
        west_east: ('point',)

cuboid (public)
    dimensions: (..., 'height', 'south_north', 'west_east')
    coords:
        height: ('height',)
        south_north: ('south_north',)
        west_east: ('west_east',)

raster (partly public)
    dimensions: (..., south_north', 'west_east')
    coords:
        south_north: ('south_north',)
        west_east: ('west_east',)

vertical (partly public)
    dimensions: (..., 'height')
    coords:
        height: ('height',)

stacked_point (private)
    dimensions: (..., 'height', 'stacked_point')
    coords:
        south_north: ('stacked_point',)
        west_east: ('stacked_point',)
        height: ('height',)

"""

import xarray as xr

from windkit._errors import WindkitValidationError

_WINDKIT_X_DIM = "west_east"
_WINDKIT_Y_DIM = "south_north"
_WINDKIT_Z_DIM = "height"
_WINDKIT_STACKED_POINT_DIM = "stacked_point"
_WINDKIT_POINT_DIM = "point"


def _xy_dims():
    return _WINDKIT_X_DIM, _WINDKIT_Y_DIM


def _vertical_dim():
    return _WINDKIT_Z_DIM


def _point_dim():
    return _WINDKIT_POINT_DIM


def _stacked_point_dim():
    return _WINDKIT_STACKED_POINT_DIM


def _cuboid_dims():
    return _WINDKIT_X_DIM, _WINDKIT_Y_DIM, _WINDKIT_Z_DIM


#: Spatial dimensions in the canonical order this module documents above:
#: filtering it by the dimensions an object actually has reproduces
#: ``(..., 'point')``, ``(..., 'height', 'south_north', 'west_east')``,
#: ``(..., 'south_north', 'west_east')`` and ``(..., 'height',
#: 'stacked_point')`` for the four supported structures.
_SPATIAL_DIM_ORDER = (
    _WINDKIT_POINT_DIM,
    _WINDKIT_Z_DIM,
    _WINDKIT_STACKED_POINT_DIM,
    _WINDKIT_Y_DIM,
    _WINDKIT_X_DIM,
)


def _spatial_dims_in_order(obj):
    """Return the spatial dimensions of ``obj`` in canonical order.

    Never read this from ``xarray.Dataset.dims``, which iterates in
    variable-insertion order and so gives two datasets with identical content
    different answers. This tuple is also the order ``_spatial_stack`` flattens
    in, so laying a per-location result out over these dimensions puts every
    value back where the flat point axis had it.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Object to inspect.

    Returns
    -------
    tuple of str
        Present spatial dimensions, canonically ordered. Empty when ``obj``
        describes a single location with no spatial extent.
    """
    return tuple(dim for dim in _SPATIAL_DIM_ORDER if dim in obj.dims)


#: Spatial coordinates a constructor's ``output_locs`` may carry, and the
#: dimensions each is allowed to depend on. The empty tuple is a scalar
#: coordinate, which every structure may reduce to.
_LOCATION_COORDS = ("west_east", "south_north", "height")
_LOCATION_COORD_DIMS = {
    "west_east": {
        (),
        (_WINDKIT_POINT_DIM,),
        (_WINDKIT_STACKED_POINT_DIM,),
        (_WINDKIT_X_DIM,),
    },
    "south_north": {
        (),
        (_WINDKIT_POINT_DIM,),
        (_WINDKIT_STACKED_POINT_DIM,),
        (_WINDKIT_Y_DIM,),
    },
    "height": {(), (_WINDKIT_POINT_DIM,), (_WINDKIT_Z_DIM,)},
}


def _validate_location_coordinates(output_locs):
    """Reject spatial coordinates that no WindKit structure can produce.

    Scalar and reduced forms of all four structures are accepted. What is
    rejected is a coordinate on an unknown dimension, and a mixture of
    dimension families that no single structure has: ``point`` horizontal
    coordinates beside a ``height`` dimension, or ``point`` beside
    ``stacked_point`` or a grid axis.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Spatial locations to check.

    Raises
    ------
    WindkitValidationError
        If a spatial coordinate has unsupported dimensions, or the
        coordinates mix incompatible dimension families.
    """
    families = set()
    for name in _LOCATION_COORDS:
        if name not in output_locs.coords:
            continue
        dims = tuple(output_locs.coords[name].dims)
        if dims not in _LOCATION_COORD_DIMS[name]:
            allowed = ", ".join(
                "scalar" if not item else repr(item)
                for item in sorted(_LOCATION_COORD_DIMS[name], key=str)
            )
            raise WindkitValidationError(
                f"Spatial coordinate {name!r} has unsupported dimensions {dims!r}; "
                f"expected one of {allowed}."
            )
        if not dims:
            continue
        dim = dims[0]
        if dim == _WINDKIT_POINT_DIM:
            families.add("point")
        elif dim == _WINDKIT_STACKED_POINT_DIM:
            families.add("stacked_point")
        elif dim in {_WINDKIT_X_DIM, _WINDKIT_Y_DIM}:
            families.add("grid")
        elif dim == _WINDKIT_Z_DIM:
            families.add("vertical")

    horizontal_families = families - {"vertical"}
    if len(horizontal_families) > 1 or (
        "point" in horizontal_families and "vertical" in families
    ):
        details = ", ".join(
            f"{name}={tuple(output_locs.coords[name].dims)!r}"
            for name in _LOCATION_COORDS
            if name in output_locs.coords
        )
        raise WindkitValidationError(
            "Spatial coordinates use incompatible dimension families: " + details + "."
        )


def _validate_locations(output_locs):
    """Validate constructor ``output_locs`` and return its canonical dims.

    This is the check a constructor makes before laying its generated values
    out over ``output_locs``'s own dimensions. It replaces the implicit
    rejection that ``_spatial_stack`` used to perform on the way to ``point``.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Spatial locations to build on.

    Returns
    -------
    tuple of str
        Present spatial dimensions in canonical order, empty for a location
        with no spatial extent.

    Raises
    ------
    WindkitValidationError
        If ``output_locs`` is not a Dataset, is missing the horizontal
        coordinates, has unsupported or incompatible spatial coordinates, or
        carries non-spatial dimensions. Constructor semantics for extra
        dimensions are not defined, so they are rejected rather than guessed.
    """
    if not isinstance(output_locs, xr.Dataset):
        raise WindkitValidationError("output_locs must be an xarray.Dataset.")
    missing = [name for name in _LOCATION_COORDS[:2] if name not in output_locs.coords]
    if missing:
        raise WindkitValidationError(
            "output_locs is not a WindKit spatial object; missing required "
            "spatial coordinates: " + ", ".join(missing) + "."
        )
    _validate_location_coordinates(output_locs)
    dims = _spatial_dims_in_order(output_locs)
    extra_dims = [dim for dim in output_locs.dims if dim not in dims]
    if extra_dims:
        raise WindkitValidationError(
            "output_locs has unsupported non-spatial dimensions: "
            + ", ".join(extra_dims)
            + ". Select or drop these dimensions before passing locations "
            "to a constructor."
        )
    return dims
