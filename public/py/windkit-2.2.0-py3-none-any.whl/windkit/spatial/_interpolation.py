"""Internal interpolation routines.

These routines are used to resample and reproject source data to target grids.
"""

import functools
import warnings

import numpy as np
import scipy.interpolate
import xarray as xr
from scipy.spatial import Delaunay

from . import _metpy_natural_neighbors as metpy_nn
from ._crs import crs_are_equal, get_crs
from .spatial import (
    is_cuboid,
    is_point,
    is_raster,
)

SPATIAL_COORDS = ["height", "south_north", "west_east"]
HORIZONTAL_COORDS = ["south_north", "west_east"]
NUMERIC_DTYPE_KINDS = "fiuc"
NONNUMERIC_DTYPE_KINDS = "mMOSUV"


def _get_longitude_wrap_reference(longitudes):
    """Get a reference longitude for continuous interpolation.

    Parameters
    ----------
    longitudes : array-like
        Longitude values used to determine the wrap reference.

    Returns
    -------
    float
        Reference longitude for wrapping.
    """

    finite_longitudes = np.asarray(longitudes, dtype=float).ravel()
    finite_longitudes = finite_longitudes[np.isfinite(finite_longitudes)]
    if finite_longitudes.size == 0:
        return 0.0

    mean_angle = np.exp(1j * np.deg2rad(finite_longitudes)).mean()
    if np.isclose(np.abs(mean_angle), 0.0):
        return float(finite_longitudes[0])

    return float(np.rad2deg(np.angle(mean_angle)))


def _wrap_longitudes(longitudes, reference):
    """Wrap longitudes into the branch centered on a reference value.

    Parameters
    ----------
    longitudes : array-like
        Longitude values to wrap.
    reference : float
        Reference longitude.

    Returns
    -------
    array-like
        Wrapped longitude values.
    """

    return np.mod(longitudes - reference + 180.0, 360.0) - 180.0 + reference


def _prepare_unstructured_interp_coords(obj, coords_kwargs):
    """Prepare interpolation coordinates for geographic longitudes.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Source object containing the interpolation coordinates.
    coords_kwargs : dict
        Coordinate values passed to interpolation.

    Returns
    -------
    tuple of dict
        Source and target coordinate mappings, with geographic longitudes wrapped
        into a continuous branch when needed. If CRS metadata is absent, the
        coordinates are returned unchanged.
    """

    source_coords = {name: obj[name] for name in coords_kwargs}
    target_coords = dict(coords_kwargs)

    if "west_east" not in coords_kwargs or "crs" not in obj.coords:
        return source_coords, target_coords

    if not get_crs(obj).is_geographic:
        return source_coords, target_coords

    reference = _get_longitude_wrap_reference(target_coords["west_east"])
    source_coords["west_east"] = _wrap_longitudes(source_coords["west_east"], reference)
    target_coords["west_east"] = _wrap_longitudes(target_coords["west_east"], reference)
    return source_coords, target_coords


def interp_structured_like(source, target, exclude_dims=None, **kwargs):
    """
    Interpolate spatially from cuboid dataset/dataarray to another spatial dataset/dataarray

    Parameters
    ----------
    source : xarray.Dataset or xarray.DataArray
        Source dataset/dataarray with spatial coordinates. Must be a cuboid and have
        the same crs as target.
    target : xarray.Dataset or xarray.DataArray
        Target dataset/dataarray with spatial coordinates. Can be a cuboid, stacked_point or point.
        Must have the same crs as source.
    exclude_dims : list, optional
        List of dimensions to exclude from interpolation. Default is None

    Returns
    -------
    xarray.Dataset or xarray.DataArray
        Interpolated dataset/dataarray with spatial coordinates of target

    Raises
    ------
    ValueError
        If source and target are not xarray.Dataset or xarray.DataArray
    ValueError
        If source and target do not have the same crs

    Warnings
    --------
    If any of the variables in source are not numeric, they will be skipped and a warning will be raised.

    """

    if not isinstance(source, (xr.Dataset, xr.DataArray)):
        raise ValueError(
            "source must be an xarray.Dataset or xarray.DataArray. Got {}".format(
                type(source)
            )
        )

    if not isinstance(target, (xr.Dataset, xr.DataArray)):
        raise ValueError(
            "target must be an xarray.Dataset or xarray.DataArray. Got {}".format(
                type(target)
            )
        )

    if isinstance(source, xr.Dataset):
        if any(
            source[v].dtype.kind not in NUMERIC_DTYPE_KINDS for v in source.data_vars
        ):
            warnings.warn(
                "Skipping interpolation of non-numeric variables. "
                + "Only numeric variables are interpolated.",
                UserWarning,
            )
            source = source[
                [
                    v
                    for v in source.data_vars
                    if source[v].dtype.kind in NUMERIC_DTYPE_KINDS
                ]
            ]
    else:  # can only be a DataArray at this point.
        if source.dtype.kind not in NUMERIC_DTYPE_KINDS:
            raise ValueError(
                "source must be numeric. Got dtype {}".format(source.dtype)
            )

    if not crs_are_equal(source, target):
        raise ValueError(
            "source and target must have the same crs. Got {} and {}".format(
                source.crs, target.crs
            )
        )

    if not (is_cuboid(source) or is_raster(source)):
        raise ValueError("source must be a cuboid or raster. Got {}".format(source))

    if exclude_dims is None:
        exclude_dims = []

    coords_kwargs = {
        k: v
        for k, v in target.coords.items()
        if (k in SPATIAL_COORDS and k in source.dims and k not in exclude_dims)
    }

    for k, v in coords_kwargs.items():
        for e in exclude_dims:
            coords_kwargs[k] = v.drop_vars(e, errors="i")

    out = source.interp(**coords_kwargs, **kwargs)

    for e in exclude_dims:
        if e in out.dims and e not in target.dims:
            out = out.squeeze(e)
            out.coords[e] = target.coords[e]

    if isinstance(source, xr.Dataset):
        out = out.assign(
            {
                v: out[v].astype(source[v].dtype)
                for v in out.data_vars
                if v in source.data_vars
            }
        )
    else:
        out = out.astype(source.dtype)

    return out


def _prepare_unstructured_points(obj, coords_kwargs):
    """Stack a source onto ``__point__`` and build the interpolation arrays.

    Parameters
    ----------
    obj : xarray.DataArray
        Source dataarray in any spatial structure.
    coords_kwargs : dict
        Mapping from spatial coordinate name to the target coordinate DataArray.

    Returns
    -------
    tuple
        ``(obj, points, points_new, dims_result)``: the source stacked onto a
        ``__point__`` dimension, the ``(n_points, n_coords)`` array of source
        coordinates, the tuple of broadcast target coordinate DataArrays, and
        the dimensions of the broadcast target.

    Raises
    ------
    ValueError
        If a requested coordinate is missing from the source, or if the
        interpolation coordinates have inconsistent shapes.
    """

    if "point" not in obj.dims:
        stack_dims = []
        if "height" in coords_kwargs and "height" in obj.dims:
            stack_dims.append("height")

        if "stacked_point" in obj.dims:
            if any(c in coords_kwargs for c in HORIZONTAL_COORDS):
                stack_dims += ["stacked_point"]

        if all((c in coords_kwargs and c in obj.dims) for c in HORIZONTAL_COORDS):
            stack_dims += HORIZONTAL_COORDS

        if len(stack_dims) > 0:
            obj = obj.stack(__point__=stack_dims)
    else:
        obj = obj.rename({"point": "__point__"})

    if any(c not in obj.coords for c in coords_kwargs.keys()):
        raise ValueError(
            "All dimensions in coords_kwargs must be in obj. Got {}.".format(
                coords_kwargs.keys()
            )
        )

    coords_interp = tuple(coords_kwargs)
    coord_shapes = {c: np.shape(obj[c]) for c in coords_interp}
    expected_shape = next(iter(coord_shapes.values()))
    bad = [c for c, s in coord_shapes.items() if s != expected_shape]
    if bad:
        raise ValueError(
            "Cannot interpolate: coordinates have inconsistent shapes. "
            f"Expected shape {expected_shape!r} for all interpolation coordinates, "
            f"but {bad} have shape(s) {[coord_shapes[c] for c in bad]!r}. "
            "A scalar (0-dimensional) coordinate cannot be used as an interpolation "
            "axis together with array coordinates. Pass the scalar dimension via "
            "exclude_dims to skip it during interpolation."
        )
    source_coords, target_coords = _prepare_unstructured_interp_coords(
        obj, coords_kwargs
    )
    points = np.array(tuple(source_coords[coord] for coord in coords_interp)).T
    points_new = tuple(target_coords[dim] for dim in coords_interp)
    points_new = xr.broadcast(*points_new)
    dims_result = points_new[0].dims

    return obj, points, points_new, dims_result


def _interp_unstructured_da(
    obj, west_east=None, south_north=None, height=None, method="linear", **kwargs
):
    """
    Interpolate spatially from unstructured dataset/dataarray to new coordinates

    Parameters
    ----------
    obj : xarray.DataArray
        Source dataarray with spatial coordinates. Can be a cuboid, stacked_point or point.
        Must have the same crs as the west_east, south_north and height coordinates provided.
    west_east : xarray.DataArray, optional
        Target dataarray with spatial coordinates.
        Can be in cuboid, stacked_point or point structure
    south_north : xarray.DataArray, optional
        Target dataarray with spatial coordinates.
        Can be in cuboid, stacked_point or point structure
    height : xarray.DataArray, optional
        Target dataarray with spatial coordinates.
        Can be in cuboid, stacked_point or point structure
    method : str, optional
        Interpolation method. Must be 'nearest', 'linear', or 'cubic'. Default is 'linear'
    **kwargs : dict
        Keyword arguments passed to interpolation function

    Returns
    -------
    xarray.DataArray
        Interpolated dataarray with spatial coordinates of target

    Raises
    ------
    ValueError
        If obj is not an xarray.DataArray
    ValueError
        If any of the coordinates in coords_kwargs are not xarray.DataArray
    ValueError
        If any of the coordinates in coords_kwargs are not in obj

    Warnings
    --------
    If obj is not numeric, it will be skipped and a warning will be raised.

    """

    if not isinstance(obj, xr.DataArray):
        raise ValueError("obj must be an xarray.DataArray. Got {}".format(type(obj)))

    coords_kwargs = {
        name: coord
        for name, coord in zip(SPATIAL_COORDS, [height, south_north, west_east])
        if coord is not None
    }

    if not all(isinstance(coord, xr.DataArray) for coord in coords_kwargs.values()):
        raise ValueError(
            "All coordinates in coords_kwargs must be xarray.DataArray. Got {}".format(
                [type(coord) for coord in coords_kwargs.values()]
            )
        )

    obj, points, points_new, dims_result = _prepare_unstructured_points(
        obj, coords_kwargs
    )

    coords_interp = tuple(coords_kwargs)
    n_coords_interp = len(coords_interp)
    n_dims_interp = points_new[0].ndim
    # scipy converts the targets to numpy on every call; do it once, not per slice
    xi = tuple(coord.values for coord in points_new)

    if n_coords_interp == 1:

        def _interp(arr):
            return scipy.interpolate.griddata(points, arr, xi, method=method, **kwargs)

    else:
        if method == "cubic":
            if n_dims_interp > 2:
                raise ValueError(
                    "cubic interpolation only supported for 2D interpolation. Got {} dims".format(
                        n_dims_interp
                    )
                )
            interp_func = scipy.interpolate.CloughTocher2DInterpolator
        elif method == "linear":
            interp_func = scipy.interpolate.LinearNDInterpolator
        else:
            interp_func = scipy.interpolate.NearestNDInterpolator

        if method != "nearest":
            constant_dims = [
                dim
                for dim, col in zip(coords_interp, points.T)
                if np.unique(col).size == 1
            ]
            if constant_dims:
                raise ValueError(
                    f"Cannot build Delaunay triangulation: source coordinate(s) "
                    f"{constant_dims!r} have only a single unique value in the source "
                    f"dataset, making the point cloud degenerate. Pass these dimensions "
                    f"via exclude_dims (e.g. exclude_dims={constant_dims!r}) to skip "
                    f"them during spatial interpolation."
                )
            x = Delaunay(points)
        else:
            x = points

        def _interp(arr):
            # One interpolator for all slices: scipy interpolates each value
            # column independently, so this matches a per-slice loop exactly
            values = arr.reshape(-1, arr.shape[-1]).T
            out = interp_func(x, values, **kwargs)(xi)
            return np.moveaxis(out, -1, 0).reshape(arr.shape[:-1] + out.shape[:-1])

    result = xr.apply_ufunc(
        _interp,
        obj,
        input_core_dims=[["__point__"]],
        output_core_dims=[dims_result],
        vectorize=n_coords_interp == 1,
    )

    result = result.assign_coords(**coords_kwargs)

    result = result.astype(obj.dtype)

    return result


def _interp_unstructured_rbf(
    obj, west_east=None, south_north=None, height=None, **kwargs
):
    """
    Interpolate unstructured spatial data horizontally with radial basis functions.

    Parameters
    ----------
    obj : xarray.DataArray
        Source dataarray with spatial coordinates. Can be a cuboid, stacked_point or
        point. Must have the same crs as the coordinates provided.
    west_east : xarray.DataArray
        Target west_east coordinates. Can be in cuboid, stacked_point or point
        structure.
    south_north : xarray.DataArray
        Target south_north coordinates. Can be in cuboid, stacked_point or point
        structure.
    height : xarray.DataArray, optional
        Not supported. Radial basis functions measure isotropic distances, so
        heights must be excluded from the interpolation.
    **kwargs : dict
        Keyword arguments passed to :class:`scipy.interpolate.RBFInterpolator`,
        e.g. ``kernel``, ``neighbors``, ``smoothing``, ``epsilon`` and ``degree``.

    Returns
    -------
    xarray.DataArray
        Interpolated dataarray with the spatial coordinates provided.

    Raises
    ------
    ValueError
        If obj is not an xarray.DataArray
    ValueError
        If height is provided, or west_east or south_north is missing
    ValueError
        If the source contains non-finite or duplicate horizontal points
    ValueError
        If there are too few source points for the requested kernel and degree
    ValueError
        If the source points are degenerate for the polynomial term of the kernel

    Notes
    -----
    The interpolant is fitted once per dataarray with every non-point dimension
    flattened into the value axis, so extra dimensions such as ``sector`` share a
    single factorization. Unlike the 'linear' and 'cubic' methods, radial basis
    functions extrapolate outside the convex hull of the source points instead of
    returning NaN.

    Because the fit is global, a NaN value at any source point makes the whole
    slice it belongs to (e.g. one sector) NaN at every target, whereas the
    'linear' and 'cubic' methods confine NaN to the neighbouring simplices.
    Near-coincident source points pass the duplicate check but make the system
    ill-conditioned; pass ``smoothing`` to regularise it. Degenerate point
    clouds, such as collinear points under the default degree 1 polynomial
    term, raise a ValueError suggesting ``kernel='linear'`` or ``degree=0``.

    ``height`` can only be excluded when it is a dimension of the source, i.e.
    for ``stacked_point`` and ``cuboid`` structures. In ``point`` structure every
    (location, height) pair is a separate point, so a source with several
    heights per location fails the duplicate check; convert it with
    :func:`windkit.spatial.to_stacked_point` first.
    """

    if not isinstance(obj, xr.DataArray):
        raise ValueError("obj must be an xarray.DataArray. Got {}".format(type(obj)))

    if height is not None:
        raise ValueError(
            "method='rbf' interpolates horizontally only, but a 'height' coordinate "
            "was given. Pass exclude_dims=['height'] to interp_unstructured_like, or "
            "omit height in interp_unstructured, to skip it during interpolation."
        )

    if west_east is None or south_north is None:
        raise ValueError(
            "method='rbf' requires both west_east and south_north coordinates."
        )

    coords_kwargs = {"south_north": south_north, "west_east": west_east}

    if not all(isinstance(coord, xr.DataArray) for coord in coords_kwargs.values()):
        raise ValueError(
            "All coordinates in coords_kwargs must be xarray.DataArray. Got {}".format(
                [type(coord) for coord in coords_kwargs.values()]
            )
        )

    obj, points, points_new, dims_result = _prepare_unstructured_points(
        obj, coords_kwargs
    )

    n_points = points.shape[0]
    n_nonfinite = int((~np.isfinite(points).all(axis=1)).sum())
    if n_nonfinite:
        raise ValueError(
            f"Cannot build RBF interpolator: {n_nonfinite} of {n_points} source "
            "points have NaN or infinite horizontal coordinates. Drop those points "
            "before interpolating."
        )

    n_unique = np.unique(points, axis=0).shape[0]
    if n_unique < n_points:
        raise ValueError(
            f"Cannot build RBF interpolator: {n_points - n_unique} of {n_points} "
            "source points share their horizontal coordinates with another point, "
            "which makes the interpolation system singular. If the source is in "
            "point structure with several heights per location, convert it with "
            "windkit.spatial.to_stacked_point so that height becomes a dimension "
            "that exclude_dims can skip. Otherwise remove duplicate points or "
            "aggregate their values before interpolating."
        )

    query = np.column_stack([np.asarray(coord).ravel() for coord in points_new])
    target_shape = points_new[0].shape

    def _interp(arr):
        # apply_ufunc moves the core dimension last: arr is (..., n_points).
        rest_shape = arr.shape[:-1]
        values = arr.reshape(-1, n_points).T
        try:
            # With `neighbors` the local systems are solved lazily on call, so
            # both steps can raise for a degenerate point cloud.
            interpolator = scipy.interpolate.RBFInterpolator(points, values, **kwargs)
            out = interpolator(query)
        except np.linalg.LinAlgError as err:
            raise ValueError(
                f"Cannot build RBF interpolator: {err} The source points are "
                "degenerate for the polynomial term of the kernel, which happens "
                "when they are collinear (e.g. masts along a transect). Pass "
                "kernel='linear', which defaults to degree=0, or set degree=0 "
                "explicitly on method='rbf'."
            ) from err
        except ValueError as err:
            if "data points are required" in str(err):
                raise ValueError(
                    f"{err} With few source points, pass kernel='linear' or a "
                    "lower degree to method='rbf'."
                ) from err
            raise
        return out.T.reshape(rest_shape + target_shape)

    result = xr.apply_ufunc(
        _interp,
        obj,
        input_core_dims=[["__point__"]],
        output_core_dims=[dims_result],
    )

    result = result.assign_coords(**coords_kwargs)

    result = result.astype(obj.dtype)

    return result


def _interp_unstructured_natural_neighbor(obj, west_east, south_north):
    """
    Interpolate unstructured spatial data using natural neighbor interpolation.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Source dataset/dataarray with spatial coordinates. Must be in 'point' structure.
        Must have the same crs as the west_east and south_north coordinates provided.
    west_east : xarray.DataArray
        Target dataarray with west_east coordinates.
        Must be in 'point' structure
    south_north : xarray.DataArray
        Target dataarray with south_north coordinates.
        Must be in 'point' structure

    Returns
    -------
    xarray.Dataset or xarray.DataArray
        Interpolated dataset/dataarray with spatial coordinates of target

    Raises
    ------
    ValueError
        If obj is not an xarray.Dataset or xarray.DataArray
    ValueError
        If obj is not in 'point' structure
    ValueError
        If west_east or south_north are not xarray.DataArray
    ValueError
        If west_east or south_north are not in 'point' structure

    Warnings
    --------
    If any of the variables in obj are not numeric, they will be skipped and a warning will be raised.

    """

    if west_east is None or south_north is None:
        raise ValueError(
            "west_east and south_north must be provided for natural_neighbor interpolation"
        )

    if not all(is_point(c) for c in [west_east, south_north]):
        raise ValueError(
            "west_east and south_north must be in point structure for natural_neighbor interpolation"
        )

    if not west_east.ndim == south_north.ndim == 1:
        raise ValueError(
            "west_east and south_north must be 1D (point structure) for natural_neighbor interpolation"
        )

    if isinstance(obj, xr.Dataset):
        if any(obj[v].dtype.kind not in NUMERIC_DTYPE_KINDS for v in obj.data_vars):
            warnings.warn(
                "Skipping interpolation of non-numeric variables. "
                + "Only numeric variables are interpolated.",
                UserWarning,
            )
            obj = obj[
                [v for v in obj.data_vars if obj[v].dtype.kind in NUMERIC_DTYPE_KINDS]
            ]

    xy_coords = ["west_east", "south_north"]
    if not is_point(obj):
        obj = obj.stack(__point__=xy_coords)
    else:
        obj = obj.rename({"point": "__point__"})

    source_coords, target_coords = _prepare_unstructured_interp_coords(
        obj, {"west_east": west_east, "south_north": south_north}
    )
    points = np.array(tuple(source_coords[coord] for coord in xy_coords)).T
    points_new = np.array(tuple(target_coords[coord] for coord in xy_coords)).T

    tri = Delaunay(points)
    in_triangulation = tri.find_simplex(points_new) >= 0

    match = np.array([(pt == points).all(axis=1).any() for pt in points_new])
    nomatch = np.logical_not(match)

    use_natural = np.logical_and(in_triangulation, nomatch)
    use_nearest = np.logical_or(np.logical_not(in_triangulation), match)

    if isinstance(obj, xr.DataArray):

        def _interp(arr):
            arr_out = np.empty(points_new.shape[0])
            arr_out[use_natural] = metpy_nn.natural_neighbor_to_points(
                points, arr, points_new[use_natural]
            )
            arr_out[use_nearest] = np.nan
            return arr_out

    elif isinstance(obj, xr.Dataset):
        neighbors_list, weights_list = metpy_nn.find_all_neighbors_and_weights(
            points, points_new[use_natural]
        )

        def _interp(arr):
            arr_out = np.empty(points_new.shape[0])

            arr_out[use_natural] = metpy_nn.interpolate_natural_neighbors(
                points, arr, points_new[use_natural], neighbors_list, weights_list
            )
            arr_out[use_nearest] = np.nan
            return arr_out

    result = xr.apply_ufunc(
        _interp,
        obj,
        input_core_dims=[["__point__"]],
        output_core_dims=[["point"]],
        vectorize=True,
        keep_attrs=True,
    )

    result = result.assign_coords(
        {
            "west_east": west_east,
            "south_north": south_north,
        }
    )

    if isinstance(result, xr.Dataset):
        result = result.assign(
            {
                v: result[v].astype(obj[v].dtype)
                for v in result.data_vars
                if v in obj.data_vars
            }
        )
    else:
        result = result.astype(obj.dtype)

    return result


def interp_unstructured(
    obj, west_east=None, south_north=None, height=None, method="linear", **kwargs
):
    """
    Interpolate spatially from unstructured dataset/dataarray to new coordinates.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Source dataset/dataarray with spatial coordinates. Can be a cuboid, stacked_point or point.
        Must have the same crs as the west_east, south_north and height coordinates provided.
    west_east : xarray.DataArray, optional
        Target dataarray with spatial coordinates.
        Can be in cuboid, stacked_point or point structure
    south_north : xarray.DataArray, optional
        Target dataarray with spatial coordinates.
        Can be in cuboid, stacked_point or point structure
    height : xarray.DataArray, optional
        Target dataarray with spatial coordinates.
        Can be in cuboid, stacked_point or point structure
    method : str, optional
        Interpolation method. Must be 'nearest', 'linear', 'cubic', 'natural' or
        'rbf'. Default is 'linear'. The 'linear' and 'cubic' methods use Delaunay
        triangulation and return NaN outside the convex hull of the source
        points, while 'nearest' takes the value of the closest source point
        everywhere. 'natural' uses natural neighbor interpolation and requires
        point structured targets. 'rbf' uses radial basis functions, interpolates
        horizontally only (pass ``exclude_dims=["height"]`` or omit ``height``),
        extrapolates outside the convex hull, and works with as few as two source
        points when ``kernel="linear"`` is passed.
    **kwargs : dict
        Keyword arguments passed to the interpolation function. For 'nearest',
        'linear' and 'cubic' these are forwarded to the matching
        ``scipy.interpolate`` interpolator, e.g. ``fill_value`` for 'linear' and
        'cubic'. 'natural' takes none. For 'rbf' these are forwarded to
        :class:`scipy.interpolate.RBFInterpolator`: ``kernel``
        (default 'thin_plate_spline'), ``neighbors``, ``smoothing``, ``epsilon``
        and ``degree``. Note that the default global fit solves a dense linear
        system whose cost grows with the cube of the number of source points;
        pass ``neighbors`` to fit locally for large sources.

    Returns
    -------
    xarray.Dataset or xarray.DataArray
        Interpolated dataset/dataarray with spatial coordinates provided.

    Raises
    ------
    ValueError
        If obj is not an xarray.Dataset or xarray.DataArray
    ValueError
        If method is not one of the supported methods
    ValueError
        If keyword arguments are passed with method 'natural'
    ValueError
        If any of the coordinates in coords_kwargs are not xarray.DataArray
    ValueError
        If any of the coordinates in coords_kwargs are not in obj

    Warnings
    --------
    If any of the variables in obj are not numeric, they will be skipped and a warning will be raised.

    """

    if not isinstance(obj, (xr.DataArray, xr.Dataset)):
        raise ValueError(
            "obj must be an xarray.Dataset or xarray.DataArray. Got {}".format(
                type(obj)
            )
        )

    if method not in ("nearest", "linear", "cubic", "natural", "rbf"):
        raise ValueError(
            "method must be 'nearest', 'linear', 'cubic', 'natural' or 'rbf'. "
            f"Got {method!r}"
        )

    # Spatial case for natural neighbor interpolation
    if method == "natural":
        if kwargs:
            raise ValueError(
                f"method='natural' takes no keyword arguments, got {sorted(kwargs)}. "
                "Natural neighbor interpolation has no options."
            )
        return _interp_unstructured_natural_neighbor(obj, west_east, south_north)

    coords_kwargs = {
        name: coord
        for name, coord in zip(SPATIAL_COORDS, [height, south_north, west_east])
        if coord is not None
    }

    if method == "rbf":
        if "crs" in obj.coords and get_crs(obj).is_geographic:
            warnings.warn(
                "method='rbf' measures radial distances in the coordinate units, "
                "which are degrees for a geographic CRS and therefore anisotropic. "
                "Reproject the data to a projected CRS for meaningful results.",
                UserWarning,
                stacklevel=2,
            )
        interp_da = _interp_unstructured_rbf
    else:
        interp_da = functools.partial(_interp_unstructured_da, method=method)

    if isinstance(obj, xr.DataArray):
        return interp_da(obj, **coords_kwargs, **kwargs)

    results = []
    for var in obj.data_vars:
        coords_kwargs_da = {
            k: v for k, v in coords_kwargs.items() if k in obj[var].coords
        }

        if len(coords_kwargs_da.keys()) == 0:
            results.append(obj[var])
            continue

        if obj[var].dtype.kind not in NUMERIC_DTYPE_KINDS:
            warnings.warn(
                "Skipping interpolation of {}. Not a numeric type.".format(var),
                UserWarning,
            )
            continue

        results.append(interp_da(obj[var], **coords_kwargs_da, **kwargs))

    ds = xr.merge(results, compat="no_conflicts", join="outer")

    return ds


def interp_unstructured_like(source, target, exclude_dims=None, **kwargs):
    """
    Interpolate spatially from unstructured dataset/dataarray to another spatial dataset/dataarray

    Parameters
    ----------
    source : xarray.Dataset or xarray.DataArray
        Source dataset/dataarray with spatial coordinates. Can be a cuboid, stacked_point or point.
        Must have the same crs as target.
    target : xarray.Dataset or xarray.DataArray
        Target dataset/dataarray with spatial coordinates. Can be a cuboid, stacked_point or point.
        Must have the same crs as source.
    exclude_dims : list, optional
        List of dimensions to exclude from interpolation. Default is None
    **kwargs : dict
        Keyword arguments passed to :func:`interp_unstructured`, including
        ``method`` and any interpolator specific options.

    Returns
    -------
    xarray.Dataset or xarray.DataArray
        Interpolated dataset/dataarray with spatial coordinates of target

    Raises
    ------
    ValueError
        If source and target are not xarray.Dataset or xarray.DataArray
    ValueError
        If source and target do not have the same crs

    """

    if not isinstance(source, (xr.DataArray, xr.Dataset)):
        raise ValueError(
            "source must be an xarray.Dataset or xarray.DataArray. Got {}".format(
                type(source)
            )
        )

    if not isinstance(target, (xr.DataArray, xr.Dataset)):
        raise ValueError(
            "target must be an xarray.Dataset or xarray.DataArray. Got {}".format(
                type(target)
            )
        )

    if not crs_are_equal(source, target):
        raise ValueError(
            "source and target must have the same crs. Got {} and {}".format(
                source.crs, target.crs
            )
        )

    if exclude_dims is None:
        exclude_dims = []

    # special case where all dims are excluded
    if sorted(exclude_dims) == sorted(
        [k for k in SPATIAL_COORDS if k in source.coords]
    ):
        coords_kwargs = {
            k: v
            for k, v in target.coords.items()
            if k in SPATIAL_COORDS and k in source.coords
        }
        exclude_dims = []
    # general case
    else:
        coords_kwargs = {
            k: v
            for k, v in target.coords.items()
            if (k in SPATIAL_COORDS and k in source.coords and k not in exclude_dims)
        }

    result = interp_unstructured(source, **coords_kwargs, **kwargs)

    for e in exclude_dims:
        if e in result.dims and e not in target.dims:
            result = result.squeeze(e)
            result.coords[e] = target.coords[e]

    return result
