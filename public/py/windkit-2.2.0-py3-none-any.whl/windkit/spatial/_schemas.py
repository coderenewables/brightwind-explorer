# (c) 2026 DTU Wind Energy
"""Spatial validation schemas for windkit xarray objects.

Defines schemas for each spatial structure (point, stacked_point, raster,
cuboid) and convenience groups for composing with wind climate schemas.
"""

from windkit.xarray_structures._schema import DatasetSchema, any_of

_POINT_SCHEMA = DatasetSchema(
    name="point",
    dims=("point",),
    coords=("west_east", "south_north", "height"),
)

# NOTE: the mandatory ``height`` dim/coord becomes optional with windkit#766
# (see windkit#523).
_STACKED_POINT_SCHEMA = DatasetSchema(
    name="stacked_point",
    dims=("stacked_point", "height"),
    coords=("west_east", "south_north", "height"),
)

_RASTER_SCHEMA = DatasetSchema(
    name="raster",
    dims=("west_east", "south_north"),
    forbidden_dims=("height",),
    coords=("west_east", "south_north"),
)

_CUBOID_SCHEMA = DatasetSchema(
    name="cuboid",
    dims=("west_east", "south_north", "height"),
    coords=("west_east", "south_north", "height"),
)

_SCALAR_POINT_SCHEMA = DatasetSchema(
    name="scalar_point",
    dims=(),
    coords=("west_east", "south_north", "height"),
    forbidden_dims=("point", "stacked_point", "west_east", "south_north", "height"),
)

_ANY_SPATIAL = any_of(
    _POINT_SCHEMA,
    _STACKED_POINT_SCHEMA,
    _RASTER_SCHEMA,
    _CUBOID_SCHEMA,
    _SCALAR_POINT_SCHEMA,
    name="any spatial",
)

_ANY_3D_SPATIAL = any_of(
    _POINT_SCHEMA,
    _STACKED_POINT_SCHEMA,
    _CUBOID_SCHEMA,
    _SCALAR_POINT_SCHEMA,
    name="any 3D spatial",
)

_ANY_GRIDDED_SPATIAL = any_of(
    _RASTER_SCHEMA, _CUBOID_SCHEMA, name="any gridded spatial"
)
