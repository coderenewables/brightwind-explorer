# (c) 2026 DTU Wind Energy
"""
windkit.spatial functions for working with
the supported spatial structures of xarray objects.

The module includes functions for validating if objects are of a certain
spatial structure and getting the spatial structure
of an object.
"""

__all__ = [
    "is_point",
    "is_raster",
    "is_stacked_point",
    "is_cuboid",
    "get_spatial_struct",
]

import warnings

import numpy as np
import pandas as pd
import xarray as xr

from .._errors import WindkitError
from ._dimensions import (
    _cuboid_dims,
    _point_dim,
    _stacked_point_dim,
    _vertical_dim,
    _xy_dims,
)
from ._vertical import has_height_coord


def is_point(obj):
    """Check if object has 'point' spatial structure."""
    try:
        return _point_dim() in obj.dims
    except Exception:
        return False


def is_raster(obj):
    """
    Check if WindKit xarray object has raster-like dimensions.

    Parameters
    ----------
    obj : xarray.DataSet, xarray.DataArray
        object to check for spatial dimensions.

    Returns
    -------
    bool:
        True if spatial dimensions exists. False otherwise.

    """
    try:
        raster_dims = _xy_dims()
        return all(dim in obj.dims for dim in raster_dims)
    except Exception:
        return False


def _is_vertical(obj):
    """Check if object has vertical (height) dimension."""
    return "height" in getattr(obj, "dims", {})


def is_stacked_point(obj):
    """Check if object has 'stacked_point' spatial structure."""
    try:
        return _stacked_point_dim() in obj.dims
    except Exception:
        return False


def is_cuboid(obj):
    """Check if object has cuboid spatial structure."""
    try:
        return all(dim in obj.dims for dim in _cuboid_dims())
    except Exception:
        return False


def get_spatial_struct(obj):
    """Get the spatial structure of a WindKit xarray object.

    Parameters
    ----------
    obj : xarray.Dataset, xarray.DataArray
        Object to determine the spatial structure from.

    Returns
    -------
    string :
        Spatial structure name. Can be on of:
            - 'point'
            - 'stacked_point'
            - 'raster'
            - 'cuboid'
        If no spatial structure is found None is returned.
    """
    if is_point(obj):
        return "point"
    elif is_stacked_point(obj):
        return "stacked_point"
    elif is_cuboid(obj):
        return "cuboid"
    elif is_raster(obj):
        return "raster"
    else:
        return None


def get_spatial_dims(obj):
    """Get the spatial dimensions of a WindKit xarray object.

    Parameters
    ----------
    obj : xarray.Dataset, xarray.DataArray
        Object to determine the spatial structure from.

    Returns
    -------
    list :
        List of spatial dimension name(s).
        If no spatial structure is found None is returned.
    """
    struct = get_spatial_struct(obj)
    if struct == "point":
        return [_point_dim()]
    elif struct == "stacked_point":
        return [_stacked_point_dim(), _vertical_dim()]
    elif struct == "cuboid":
        return list(_cuboid_dims())
    elif struct == "raster":
        return list(_xy_dims())
    else:
        return None


def _from_scalar(obj):
    """
    Create a point spatial structure for a dataset with missing
    dimensions. The missing dimensions are built from coordinate
    information.

    Parameters
    ----------
    obj : xarray.Dataset, xarray.DataArray
        Object with missing dimensions to build a new one from.

    Returns
    -------
    obj_n : xarray.Dataset, xarray.DataArray
        Object with point dimensions.

    Raises
    ------
    WindkitError :  WindkitError if the scalar cannot be converted
        to a point.
    """

    # if the spatial structure is already right, return it as is
    spatial_struct = get_spatial_struct(obj)
    if spatial_struct is not None and spatial_struct not in ("raster", "stacked_point"):
        return obj

    z_dim = _vertical_dim()
    x_y_dim = _xy_dims()
    x_y_z_dim = list(x_y_dim) + [z_dim]
    stacked_point_dim = _stacked_point_dim()
    promoted_height = False

    if (
        z_dim in obj.dims
        and stacked_point_dim not in obj.dims
        and all(x in obj.coords for x in x_y_dim)
    ):
        # the scalar comes from a stacked point

        obj_n = (
            obj.reset_coords(x_y_dim)
            .expand_dims("stacked_point", -1)
            .set_coords(x_y_dim)
        )

    elif (
        all(x in obj.coords for x in x_y_z_dim)
        and all(x not in obj.dims for x in x_y_z_dim)
        and stacked_point_dim not in obj.dims
    ):
        obj_n = (
            obj.reset_coords(x_y_z_dim).expand_dims("point", -1).set_coords(x_y_z_dim)
        )
    elif (
        z_dim in obj.coords and z_dim not in obj.dims and stacked_point_dim in obj.dims
    ):
        # the scalar comes from a stacked point and the height is missing
        promoted_height = True
        obj_n = obj.expand_dims(z_dim)
        # the dimensions must be rearranged like (...,height,stacked_point)
        all_dims = list(obj_n.dims)
        if len(all_dims) > 2:
            # there are more dimensions apart from stacked_point,height
            other_dims = [x for x in all_dims if x not in (stacked_point_dim, z_dim)]

            rearranged_dims = other_dims + [z_dim, stacked_point_dim]
            obj_n = obj_n.transpose(*rearranged_dims)
        else:
            obj_n = obj_n.transpose(z_dim, stacked_point_dim)
    elif spatial_struct is None:
        raise WindkitError("Cannot convert scalar, unknown spatial structure.")
    else:
        # it was a stacked point or a raster that was not a scalar
        return obj
    # The contract applies only to the size-one height introduced above.
    if promoted_height:
        scalar_height = obj.coords.get(z_dim)
        obj_n = _apply_height_contract(obj_n, z_dim)
        if (
            isinstance(obj_n, xr.DataArray)
            and z_dim not in obj_n.coords
            and scalar_height is not None
        ):
            obj_n = obj_n.assign_coords({z_dim: scalar_height})
    return obj_n


def _get_xy_dims(obj):
    """Get the horizontal dimension(s) of a dataset.

    Parameters
    ----------
    ds : xr.Dataset
        Dataset to get the horizontal dimension(s) from.

    Returns
    -------
    tuple:
        Tuple containing the horizontal dimension(s) name(s).
        Results can be:
            ("point",)
            ("stacked_point",)
            ("west_east", "south_north")

    Raises
    ------
    ValueError
        Raised if no spatial dimension(s) could be found.

    """
    struct = get_spatial_struct(obj)
    if struct == "point":
        return ("point",)
    elif struct == "stacked_point":
        return ("stacked_point",)
    elif struct in ["cuboid", "raster"]:
        return ("west_east", "south_north")
    else:
        raise ValueError("Spatial struct not recognized!")


def _drop_pwio_attrs(obj):
    """Remove all internal ``_pwio*`` attributes from an xarray object.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Object to clean.

    Returns
    -------
    xarray.Dataset or xarray.DataArray
        Shallow copy of the input with ``_pwio*`` attributes removed
        from both dataset-level and variable-level attrs.
    """
    obj = obj.copy(deep=False)
    obj.attrs = {k: v for k, v in obj.attrs.items() if not k.startswith("_pwio")}
    if isinstance(obj, xr.Dataset):
        for var in obj.data_vars:
            for key in list(obj[var].attrs):
                if key.startswith("_pwio"):
                    del obj[var].attrs[key]
    return obj


def _drop_stale_pwio_index_attrs(obj):
    """Drop stale stack-restoration metadata while retaining shape flags.

    A subset can invalidate the dataset-level saved MultiIndex used by
    ``_spatial_stack`` without invalidating a variable-level
    ``_pwio_data_is_2d`` flag. The latter still records the original shape
    and must be honored by the regular fallback conversion.
    """
    obj = obj.copy(deep=False)
    obj.attrs = {k: v for k, v in obj.attrs.items() if not k.startswith("_pwio")}
    if isinstance(obj, xr.Dataset):
        for var in obj.data_vars:
            obj[var].attrs = {
                key: value
                for key, value in obj[var].attrs.items()
                if key == "_pwio_data_is_2d" or not key.startswith("_pwio")
            }
    return obj


def _squeeze_declared_2d(da, vertical_dim):
    """Collapse the vertical dimension of a variable declared 2D via metadata.

    Used when ``height_dim_policy: "forbidden"`` metadata declares a variable
    2D but a vertical dimension is present, e.g. from broadcasting through
    'point' structure. Duplicated values (from broadcasting) and NaN fill
    (from unstacking sparse height/location combinations) collapse losslessly
    by taking the first defined value per location; if values genuinely differ
    across height levels, a warning is raised. The collapse itself stays lazy
    for dask-backed variables, for which the verification is skipped rather
    than forcing a compute. (``bfill`` would express the collapse in one step
    but requires the optional ``bottleneck`` dependency.)

    Parameters
    ----------
    da : xarray.DataArray
        Variable declared 2D.
    vertical_dim : str
        Name of the vertical dimension.

    Returns
    -------
    xarray.DataArray
        Variable without the vertical dimension.
    """
    if vertical_dim not in da.dims:
        return da

    n_levels = da.sizes[vertical_dim]
    collapsed = da.isel({vertical_dim: 0}, drop=True)
    if n_levels == 1:
        return collapsed

    # Chunked data cannot be inspected without computing, so it always fills.
    is_lazy = da.chunks is not None
    missing = None if is_lazy else da.isnull()

    # Dense levels carry no fill to undo, so the first one is already exact.
    if is_lazy or bool(missing.any()):
        for level in range(1, n_levels):
            collapsed = collapsed.fillna(da.isel({vertical_dim: level}, drop=True))
        # fillna goes through apply_ufunc, which drops both attrs and encoding
        collapsed.attrs = dict(da.attrs)
        collapsed.encoding = dict(da.encoding)

    # Verifying the collapse would force a compute on dask-backed data, while
    # the collapse itself stays lazy; only check what is already in memory.
    if not is_lazy and not bool(((da == collapsed) | missing).all()):
        name = da.name if da.name is not None else "<unnamed>"
        warnings.warn(
            f"Variable {name!r} is declared 2D but its values vary across "
            f"the {n_levels} height levels; keeping the first "
            "defined value per location.",
            # report the converter that called _apply_height_contract
            stacklevel=4,
        )
    return collapsed


def _contract_var(da, vertical_dim, honor_pwio):
    """Apply the height-dimension contract of a single variable. See
    :func:`_apply_height_contract`."""
    if honor_pwio and "_pwio_data_is_2d" in da.attrs:
        # Recorded from the actual structure at stacking time, so it overrides
        # the declared metadata. The unstacked data is dense and duplicated by
        # construction, making plain first-level selection exact (and lazy);
        # a NaN legitimately masked at level 0 must survive.
        if bool(da.attrs.pop("_pwio_data_is_2d")) and vertical_dim in da.dims:
            return da.isel({vertical_dim: 0}, drop=True)
        return da

    if da.attrs.get("height_dim_policy") == "forbidden":
        return _squeeze_declared_2d(da, vertical_dim)

    return da


def _apply_height_contract(obj, vertical_dim, honor_pwio=False):
    """Drop the vertical dimension from variables that must not carry one.

    A variable declaring ``height_dim_policy: "forbidden"`` never carries a
    height dimension; one it picked up along the way (e.g. from broadcasting
    through 'point' structure) is collapsed by
    :func:`_squeeze_declared_2d`. ``"optional"`` and the absence of the key
    leave the variable untouched.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Object to apply the contract to. A shallow copy is returned so the
        caller-owned object is never mutated.
    vertical_dim : str
        Name of the vertical dimension.
    honor_pwio : bool, optional
        If True, let the private ``_pwio_data_is_2d`` attribute recorded by
        ``_spatial_stack`` take precedence over the declared metadata, and
        consume it. Only the unstacking of an internal round trip may do this;
        elsewhere the attribute is stale and dropped up front. Default False.

    Returns
    -------
    xarray.Dataset or xarray.DataArray
        Object whose variables satisfy the height-dimension contract.
    """
    obj = obj.copy(deep=False)
    if not isinstance(obj, xr.Dataset):
        return _contract_var(obj, vertical_dim, honor_pwio)

    for name in list(obj.data_vars):
        var = obj[name]
        contracted = _contract_var(var, vertical_dim, honor_pwio)
        if contracted is not var:
            obj[name] = contracted
    return obj


def _save_stacked_index(obj, mindex):
    """Save MultiIndex level values to dataset attributes for later restoration.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Object to save the stacked index information on.
    mindex : pandas.MultiIndex
        MultiIndex whose level names and values are stored as attributes.

    Returns
    -------
    xarray.Dataset or xarray.DataArray
        The input object with ``_pwio_stacked_index_names`` and
        ``_pwio_stacked_index_{i}`` attributes added.
    """
    obj.attrs["_pwio_stacked_index_names"] = list(mindex.names)
    for i in range(mindex.nlevels):
        obj.attrs[f"_pwio_stacked_index_{i}"] = mindex.get_level_values(i).values
    return obj


def _restore_from_pwio_attrs(obj):
    """
    Restore object from pwio attributes if they exist.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Object which may contain internal pwio stacked index attributes.

    Returns
    -------
    xarray.Dataset or xarray.DataArray or None
        Restored object if pwio attributes were present, otherwise None.

    Notes
    -----
    Reconstructs a pandas.MultiIndex from attributes named
    ``_pwio_stacked_index_names`` and ``_pwio_stacked_index_{i}``, converts it
    to xarray coordinates, performs an unstack of the point dimension, and
    cleans up internal attributes. Also adjusts coordinates and 2D variables
    when height coordinates are present.
    """
    if "_pwio_stacked_index_names" not in obj.attrs:
        return None

    point_dim = _point_dim()
    stacked_point_dim = _stacked_point_dim()
    vertical_dim = _vertical_dim()
    x_dim, y_dim = _xy_dims()

    point_size = obj.sizes.get(point_dim)

    names = obj.attrs["_pwio_stacked_index_names"]
    if isinstance(names, str):
        names = [names]
    arrays = [
        np.atleast_1d(obj.attrs[f"_pwio_stacked_index_{i}"]) for i in range(len(names))
    ]

    # If the stored stacked index no longer matches the current point dimension,
    # the metadata is stale (for example, after subsetting a stacked-point object).
    # In that case, fall back to the regular conversion path instead of trying to
    # unstack incompatible coordinates.
    if point_size is not None and any(arr.size != point_size for arr in arrays):
        warnings.warn(
            f"Stale _pwio stacked-index metadata detected (stored={arrays[0].size}, actual={point_size}); "
            "falling back to regular conversion."
        )
        return None

    mindex = pd.MultiIndex.from_arrays(arrays, names=names)

    mindex_coords = xr.Coordinates.from_pandas_multiindex(mindex, dim=point_dim)
    out_obj = obj.assign_coords(mindex_coords).unstack(point_dim)

    # Clean up the internal attributes
    del out_obj.attrs["_pwio_stacked_index_names"]
    for i in range(len(names)):
        key = f"_pwio_stacked_index_{i}"
        if key in out_obj.attrs:
            del out_obj.attrs[key]

    # Mimic cleanup of coordinates done in standard path
    if stacked_point_dim in out_obj.coords:
        del out_obj.coords[stacked_point_dim]

    if has_height_coord(out_obj):
        for dim in (x_dim, y_dim):
            if dim in out_obj.coords and vertical_dim in out_obj.coords[dim].dims:
                out_obj.coords[dim] = out_obj[dim].isel({vertical_dim: 0}, drop=True)

    return out_obj
