__all__ = [
    "lines_to_polygons",
    "polygons_to_lines",
    "snap_to_layer",
    "check_dead_ends",
    "check_lines_cross",
]

import warnings

import geopandas as gpd
import numpy as np
import pandas as pd
import shapely
from shapely import get_point
from shapely.geometry import box

from ._vectormap_helpers import (
    _LR_COLS,
    _check_map_columns,
    _check_map_errors,
    _explode_gdf,
    _get_map_type,
    _landcover_to_roughness,
)


def _detect_z0_external(polygons, line_segments, output_name, col_names):
    """
    Detects the z0 external from polygon and the line segments derived from it

    Parameters
    ----------
    polygons : geopandas.GeoDataFrame
        A GeoDataFrame containing line geometries.
    line_segments : geopandas.GeoDataFrame
        A GeoDataFrame containing line geometries
    output_name: str
        Name of output column
    col_names: tuple
        colnames denoting the change-line properties of the line (e.g z0_left,
        z0_right or id_left, id_right)

    Returns
    -------
    z0_ext: float
        Float of the external polygon surrounding all polygons
    """
    # get feature which contains the nan
    na_feature = polygons[polygons[output_name].isna()]

    # select the first interior ring from this feature
    first_interior = (
        gpd.GeoDataFrame(
            geometry=[[na for na in na_feature.interiors if na][-1][0]],
            crs=polygons.crs,
        )
        .sjoin(line_segments)
        .dropna()
    )
    # find the z0 external from the line segment
    z0_ext = (
        first_interior[col_names[1]]
        .where(line_segments["lines_same_dir"], line_segments[col_names[0]])
        .iloc[0]
    )

    return z0_ext


def check_lines_cross(lines_out, errors="raise", add_errors=False):
    """
    Detects and handles crossing line geometries in a GeoDataFrame.

    This function identifies line geometries that cross each other in the input GeoDataFrame.
    It can raise an error, issue a warning, or add a boolean column indicating crossing lines.

    Parameters
    ----------
    lines_out : geopandas.GeoDataFrame
        A GeoDataFrame containing line geometries to check for crossings.
    errors : {"raise", "warn", "ignore"}, optional
        Specifies how to handle detected crossings:
        - "raise": Raises a 'ValueError' if crossings are found.
        - "warn": Issues a warning if crossings are found.
        - "ignore": Does nothing.
        Default is "raise".
    add_errors : bool, optional
        If True, adds a boolean column named "crosses" to the input GeoDataFrame,
        indicating whether each line crosses another line. Default is True.

    Returns
    -------
    geopandas.GeoDataFrame
        The input GeoDataFrame with an optional "crosses" column added if 'add_errors' is True.

    Raises
    ------
    ValueError
        If 'errors' is set to "raise" and crossing lines are detected.

    Warns
    -----
    UserWarning
        If 'errors' is set to "warn" and crossing lines are detected.

    Notes
    -----
    - The function first uses a spatial join to detect crossings. If crossings are found,
      it performs a more precise check by splitting the lines into segments and rechecking
      for overlaps.
    - This secondary check is slower and is only performed if crossings are initially detected.

    Examples
    --------
    >>> import geopandas as gpd
    >>> from shapely.geometry import LineString
    >>> lines = gpd.GeoDataFrame({
    ...     "geometry": [LineString([(0, 0), (1, 1)]), LineString([(0, 1), (1, 0)])]
    ... })
    >>> check_lines_cross(lines, errors="warn")
    GeoDataFrame with a "crosses" column indicating crossing lines.
    """
    # remove any existing columns so we don't get duplicate column names when doing sjoin
    lines_out = lines_out.drop(columns=["crosses"], errors="ignore")

    crosses = lines_out[["geometry"]].sjoin(lines_out, predicate="crosses")
    crosses = crosses.drop_duplicates(subset=["geometry"])
    crosses["crosses"] = 1
    if crosses.shape[0] > 0:
        # this part is because two linestring that share one point
        # somehow can be labelled as crossing, perhaps due precision issues
        # here we split them up in seperate segments and check the overlaps
        # between those, which detects the true overlaps.
        # this is much slower then the sjoin statement above, so we only do
        # this in case there is any reported crossings.
        crosses_double_check = (
            crosses[["geometry"]]
            .overlay(crosses, keep_geom_type=True)
            .explode()
            .drop(columns="index_right")
        )
        true_cross = crosses_double_check[["geometry"]].sjoin(
            crosses_double_check, predicate="crosses"
        )
        crosses_double_check["crosses"] = 0
        crosses_double_check.loc[true_cross.index.unique(), "crosses"] = 1
        crosses_double_check = crosses_double_check[
            ~crosses_double_check.index.duplicated(keep="first")
        ]
        crosses["crosses"] = crosses_double_check["crosses"].values

    cross_series = crosses["crosses"].reindex(lines_out.index).fillna(0).astype(bool)

    cross_lines = ",".join(crosses["crosses"].index.astype(str))
    contains_errors = cross_series.any()
    if errors == "raise" and contains_errors:
        raise ValueError(
            f"Lines with index {cross_lines} are crossing each other in your map. Please fix these in a program like QGIS."
        )
    elif errors == "warn" and contains_errors:
        warnings.warn(
            f"Lines with index {cross_lines} are crossing each other in your map."
        )

    if add_errors:
        lines_out["crosses"] = cross_series

    return lines_out


def check_dead_ends(lines_out, errors="raise", add_errors=False):
    """
    Detects dead ends in a given set of lines.

    This function checks for dead ends in the provided GeoDataFrame of lines.
    A dead end is defined as a point where only one line segment ends or starts.

    Parameters
    ----------
    lines_out : GeoDataFrame
        A GeoDataFrame containing the line geometries to be checked for dead ends.
    errors : {"raise", "warn", "ignore"}, optional
        Specifies how to handle detected crossings:
        - "raise": Raises a `ValueError` if crossings are found.
        - "warn": Issues a warning if crossings are found.
        - "ignore": Does nothing.
        Default is "raise".
    add_errors : bool, optional
        If True, adds a boolean column named "crosses" to the input GeoDataFrame,
        indicating whether each line crosses another line. Default is True.

    Returns
    -------
    geopandas.GeoDataFrame
        The input GeoDataFrame with an optional "crosses" column added if 'add_errors' is True.

    Raises
    ------
    ValueError
        If 'errors' is set to "raise" and crossing lines are detected.

    Warns
    -----
    UserWarning
        If 'errors' is set to "warn" and crossing lines are detected.
    """
    # remove any existing columns so we don't get duplicate columnname when doing sjoin
    lines_out = lines_out.drop(columns=["nr_overlaps", "dead_end"], errors="ignore")
    end_points = gpd.GeoDataFrame(
        geometry=get_point(lines_out.geometry, -1),
        crs=lines_out.crs,
    )
    start_points = gpd.GeoDataFrame(
        geometry=get_point(lines_out.geometry, 0),
        crs=lines_out.crs,
    )
    points = pd.concat([start_points, end_points], ignore_index=True)
    points["nr_overlaps"] = np.bincount(
        points.sjoin(points, predicate="contains").index_right
    )
    points["dead_end"] = points["nr_overlaps"] == 1

    nr_dead_ends = points["dead_end"].astype(int).sum()
    contains_errors = points["dead_end"].any()
    if errors == "raise" and contains_errors:
        raise ValueError(
            f"Your map contains {nr_dead_ends} dead ends, please fix these in a program like QGIS. You can set the arguments errors to 'ignore' to ignore this error and get a column 'dead_end' which denotes where the problems occur."
        )
    elif errors == "warn" and contains_errors:
        warnings.warn(
            f"Your map contains {nr_dead_ends} dead ends, please fix these in a program like QGIS. You can set the arguments 'add_errors' to get a boolean column 'dead_end' which denotes which lines contains dead ends."
        )

    if add_errors:
        res = lines_out.sjoin(points)
        lines_out["dead_end"] = False
        lines_out.loc[res[res["dead_end"]].index, "dead_end"] = True

    return lines_out


def lines_to_polygons(lines, check_errors=False):
    """
    Converts a GeoDataFrame of lines into polygons.

    This function takes a GeoDataFrame containing line geometries and converts
    them into polygons. The resulting polygons are
    associated with attributes from the input lines.

    Parameters
    ----------
    lines : geopandas.GeoDataFrame
        A GeoDataFrame containing line geometries. The GeoDataFrame must have
        columns corresponding to the change lines type (e.g., z0_left, z0_right for
        roughness, id_left, id_right for landcover).
    check_errors: bool
        Check the input line map for errors, Default False

    Returns
    -------
    geopandas.GeoDataFrame
        A GeoDataFrame containing polygon geometries with associated attributes
        from the input lines.

    Raises
    ------
    ValueError
        If landcover could not be found for all created polygons due to issues
        in the input geometries.

    Warnings
    --------
    UserWarning
        If landcover could not be found for all created polygons, indicating
        potential issues in the input geometries such as dangles or unexpected
        geometries.

    Notes
    -----
    - The function creates outer boundary polygons to ensure complete coverage.
    - It uses spatial joins to associate attributes from the input lines with
      the resulting polygons.
    - The function assumes that the input lines are valid and do not contain
      invalid geometries.
    """
    if check_errors:
        _ = check_dead_ends(lines, errors="raise")
        _ = check_lines_cross(lines, errors="raise")

    map_type = _get_map_type(lines)  # get map type
    col_names = list(_LR_COLS[map_type])  # get column names of such a map type
    output_name = col_names[0].split("_")[
        0
    ]  # get name without the left and right identifiers

    # create outer boundary of all lines to also create outer polygons
    lines_ext = gpd.GeoDataFrame(
        {col_names[0]: np.nan, col_names[1]: np.nan},  # these are not used
        # this line could also use the minimum_rotated_rectangle:
        # currently it is a square but it could perhaps be a rotated square to support reprojected bounding boxes
        # geometry=[lines.dissolve().minimum_rotated_rectangle().iloc[0].boundary],
        geometry=[box(*lines.total_bounds).boundary],
        index=[0],
        crs=lines.crs,
    )
    # paste together normal lines and outer boundary line
    lines_out = pd.concat([lines, lines_ext], ignore_index=True)

    # make sure that all lines are split when they meet another line
    planar_graph = gpd.GeoDataFrame(
        geometry=[lines_out.geometry.union_all()], crs=lines.crs
    ).explode()
    lines_out = (
        lines_out.sjoin(planar_graph, how="right", predicate="contains")
        .reset_index()
        .drop(columns=["index_left", "index"], errors="ignore")
    )
    lines_out = lines_out.drop_duplicates("geometry")

    # convert all lines into polygons and drop invalid ones
    polygons = gpd.GeoDataFrame(geometry=lines_out.polygonize(node=False))

    # select only first two points of each lines that form the output polygon
    exteriors = polygons.exterior
    segment_points = np.stack(
        [
            shapely.get_coordinates(get_point(exteriors, 0)),
            shapely.get_coordinates(get_point(exteriors, 1)),
        ],
        axis=1,
    )
    segments_lines = gpd.GeoDataFrame(
        geometry=shapely.linestrings(segment_points), crs=lines.crs
    )

    # spatial join on the original lines that contain the segments
    fpsi = (
        lines_out.sjoin(segments_lines, predicate="contains")
        .set_index("index_right")
        .sort_index()
    )
    fpsi_points = np.stack(
        [
            shapely.get_coordinates(get_point(fpsi.geometry, 0)),
            shapely.get_coordinates(get_point(fpsi.geometry, 1)),
        ],
        axis=1,
    )
    fpsi["geometry"] = shapely.linestrings(fpsi_points)

    # find out if the line segment are oriented in the same direction or not:
    # two 2-point segments coincide exactly when their endpoints match in
    # order, so compare coordinates instead of computing a Fréchet distance.
    # Despite its (historical) name, lines_same_dir is True when the
    # coordinate arrays DIFFER, replicating the frechet_distance > 0 test
    # this replaced
    matched_points = segment_points[fpsi.index.to_numpy()]
    fpsi["lines_same_dir"] = (matched_points != fpsi_points).any(axis=(1, 2))
    # the correct ID of the polygon is on the left if the segments have
    # the same direction otherwise on the right
    fpsi[output_name] = fpsi[col_names[0]].where(
        fpsi["lines_same_dir"], fpsi[col_names[1]]
    )
    # join polygons with results from matching segments
    polygons = polygons.join(fpsi[[output_name]])[["geometry", output_name]]

    # if there is any nan's left it must mean they come from the outer boundary
    # so we fill them by selecting a interior ring, finding a line segment that
    # is on that interior ring and finding the z0 from the external side of
    # that polygon
    if polygons[output_name].isna().any():
        nr_nans = polygons[output_name].isna().sum()
        warnings.warn(
            f"""Landcover could not be found for {nr_nans} polygons! These
            will be filled with the external roughness of a random interior
            ring. Check your map in a program like QGIS and make sure that
            there is no dangles, overlapping lines and other unexpected
            geometries"""
        )
        z0_ext = _detect_z0_external(polygons, fpsi, output_name, col_names)
        polygons[output_name] = polygons[output_name].fillna(z0_ext)

    return polygons


def _create_lctable_from_gdf(gdf, lctable=None):
    """
    Create a land cover table from a GeoDataFrame.

    Parameters
    ----------
    gdf : GeoDataFrame
        The GeoDataFrame containing land cover data. Must have at least a "z0" column.
    lctable : windkit.LandCoverTable or None
        Landcover table specifying the landcover classes and their mappings to
        roughness and displacement height. Required for 'landcover' maps that
        only have an 'id' column. The default is None, which means that there
        is a 'z0' column in the dataframe that specifies the roughness length.
        The returned lctable is in that case made up of the unique ("z0","d")
        pairs in the gdf.

    Returns
    -------
    lctable : windkit.LandCoverTable
        A dictionary representing the new land cover table.

    Notes
    -----
    If 'lctable' is provided, it will be copied to ensure the original is not modified.
    If 'lctable' is None, the function will check for required columns in 'gdf' and create
    a new land cover table from unique pairs of "z0" and "d" values.
    """
    if lctable is not None:
        # make sure that we don't modify the original landcover table by copying
        # this also ensure that the landcovertable has the required columns z0,d,desc
        lctable_new = lctable.copy()
        # this is what it should be but couldn't import due to a circular import
        # I have made an issue about this here:
        # https://gitlab-internal.windenergy.dtu.dk/ram/software/pywasp/windkit/-/issues/639
        # lctnew = LandCoverTable(lctable.copy())
    else:
        _check_map_columns(gdf)  # check the the gdf has at least a "z0" column

        if "d" not in gdf.columns:
            gdf["d"] = 0.0

        if "desc" not in gdf.columns:
            gdf["desc"] = ""

        # create landcover table from unique pairs of z0/d
        id_cols = ["z0", "d", "id"] if "id" in gdf.columns else ["z0", "d"]
        unique_z0d = gdf.set_index(id_cols)
        unique_z0d = unique_z0d[~unique_z0d.index.duplicated(keep="first")]
        unique_z0d = unique_z0d.drop(columns="geometry", errors="i")
        if "id" not in unique_z0d.columns and "id" not in unique_z0d.index.names:
            unique_z0d["id"] = range(unique_z0d.index.drop_duplicates().size)
        unique_z0d = unique_z0d.reset_index().set_index("id")
        lctable_new = unique_z0d.T.to_dict()

    return lctable_new


def _preprocess_polygon_gdf(gdf, lctable, external_roughness, check_errors):
    """
    Preprocess a GeoDataFrame of polygons for conversion to line segments.

    This function prepares a GeoDataFrame containing polygon geometries for
    conversion into line segments. It ensures that the input data is valid,
    creates a landcover table if not provided, and checks for errors in the
    geometries.

    Parameters
    ----------
    gdf : geopandas.GeoDataFrame
        A GeoDataFrame containing polygon geometries. Must have at least a 'z0'
        column. If a landcover table is not provided, the GeoDataFrame can also
        contain a 'd' column for displacement height and a 'desc' column for
        descriptions of the landcover.
    lctable : windkit.LandCoverTable or None
        A landcover table specifying the mapping of landcover classes to
        roughness and displacement height. If None, a new landcover table is
        created from the unique ('z0', 'd') pairs in the GeoDataFrame.
    external_roughness : float or None
        The roughness value to assign to areas outside the polygons. If None,
        segments bordering unspecified areas are removed.
    check_errors : bool
        Whether to check for errors in the map. If True, the following checks
        are performed:
        1) No polygons are allowed to overlap.
        2) If 'external_roughness' is None, the bounding box of the polygons
           must not contain holes.
        3) If 'external_roughness' is a float, a warning is issued if there are
           holes in the polygons.

    Returns
    -------
    gdf : geopandas.GeoDataFrame
        A GeoDataFrame with LineString geometries and columns 'id_left' and
        'id_right'.
    lctable : windkit.LandCoverTable
        A landcover table containing the mapping of 'id_left' and 'id_right' to
        roughness length ('z0'), displacement height ('d'), and a description
        ('desc').
    unique_z0d : pandas.DataFrame
        A DataFrame containing unique ('z0', 'd') pairs and their corresponding
        IDs.
    newidx : int
        The ID assigned to the external roughness class, if applicable.

    Raises
    ------
    KeyError
        If there are duplicate ('z0', 'd') pairs with different IDs in the
        landcover table.
    ValueError
        If the GeoDataFrame contains invalid geometries or fails the error
        checks.

    Notes
    -----
    - This function ensures that only polygons (not multipolygons) are
      processed by exploding the GeoDataFrame.
    - If 'external_roughness' is specified, an additional landcover class is
      added to the landcover table for areas outside the polygons.
    """
    # only work with polygons not multipolygons
    gdf = _explode_gdf(gdf)

    # create landcover table if not specified
    lctable = _create_lctable_from_gdf(gdf, lctable)

    # check for errors in the geometries
    if check_errors:
        _check_map_errors(gdf, external_roughness=external_roughness, lctable=lctable)

    df = gpd.GeoDataFrame.from_dict(lctable).T
    df.index.name = "id"

    # find maximum possible land cover id we can use and extra landcover
    # class in case in case external_roughness has been specified
    newidx = int(df.index.max()) + 1  # new ID for external roughness
    lctable[newidx] = {
        "z0": 0.03 if external_roughness is None else external_roughness,
        "d": 0.0,
        "desc": "Roughness length beyond last line",
    }

    unique_z0d = df.reset_index().set_index(["z0", "d"])
    nonunique = unique_z0d.groupby(["id"]).count() > 1
    if any(nonunique.values.ravel()):
        wrong_id = nonunique[nonunique].index.values
        raise KeyError(
            f"Key {','.join(wrong_id.astype(str))} has more than one z0/d pair connected to it. Each combination of (z0,d) must have an unique id!"
        )

    if "id" not in gdf.columns:
        if "d" not in gdf.columns:
            gdf["d"] = 0.0
        gdf = gdf.drop(columns="desc", errors="ignore")
        gdf = gdf.set_index(["z0", "d"]).join(unique_z0d)
        gdf = gdf.reset_index()

    return gdf, lctable, unique_z0d, newidx


def _any_polygons_overlap(geoms):
    """Check whether any two polygons in the array overlap.

    Overlapping polygons have strictly overlapping bounding boxes in both
    axes, so the exact predicate only runs on those pairs (touching
    neighbours are excluded cheaply).
    """
    i, j = shapely.STRtree(geoms).query(geoms)
    keep = i < j
    i, j = i[keep], j[keep]
    b = shapely.bounds(geoms)
    strict = (np.maximum(b[i, 0], b[j, 0]) < np.minimum(b[i, 2], b[j, 2])) & (
        np.maximum(b[i, 1], b[j, 1]) < np.minimum(b[i, 3], b[j, 3])
    )
    i, j = i[strict], j[strict]
    return len(i) > 0 and shapely.overlaps(geoms[i], geoms[j]).any()


def polygons_to_lines(
    gdf,
    lctable=None,
    map_type="roughness",
    return_lctable=False,
    external_roughness=None,
    check_errors=True,
    snap=True,
    snap_tolerance=0.1,
):
    """
    Convert a GeoDataFrame of polygons into line segments.

    This function processes a GeoDataFrame containing polygon geometries and
    converts them into line segments. It ensures that the input data is valid,
    optionally snaps geometries to align vertices, and creates a landcover
    table if not provided.

    Parameters
    ----------
    gdf : geopandas.GeoDataFrame
        A GeoDataFrame containing polygon geometries. Must have at least a 'z0'
        column. If a landcover table is not provided, the GeoDataFrame can also
        contain a 'd' column for displacement height and a 'desc' column for
        descriptions of the landcover.
    lctable : windkit.LandCoverTable or None, optional
        A landcover table specifying the mapping of landcover classes to
        roughness and displacement height. If None, a new landcover table is
        created from the unique ('z0', 'd') pairs in the GeoDataFrame.
    map_type : {"roughness","landcover"}
        Whether the output is a geopandas dataframe with roughness (z0) or id change lines, default "roughness".
    return_lctable: bool
        Whether to return the landcover table, default False
    external_roughness : float or None, optional
        The roughness value to assign to areas outside the polygons. If None,
        segments bordering unspecified areas are removed.
    check_errors : bool, optional
        Whether to check for errors in the map. If True, the following checks
        are performed:
        1) No polygons are allowed to overlap.
        2) If 'external_roughness' is None, the bounding box of the polygons must not contain holes.
        3) If 'external_roughness' is a float, a warning is issued if there are holes in the polygons.
    snap : bool, optional
        If True, inserts extra vertices to align polygons that touch but do not
        share vertices. Default is True.
    snap_tolerance : float, optional
        The tolerance passed to `snap_to_layer` when ``snap`` is True, by default
        0.1.
    Returns
    -------
    gdf : geopandas.GeoDataFrame
        A GeoDataFrame with LineString geometries and columns 'id_left' and
        'id_right'.
    lctable : windkit.LandCoverTable
        A landcover table containing the mapping of 'id_left' and 'id_right' to
        roughness length ('z0'), displacement height ('d'), and a description
        ('desc').

    Raises
    ------
    ValueError
        If no line segments remain after processing or if the GeoDataFrame
        contains invalid geometries.
    KeyError
        If there are duplicate ('z0', 'd') pairs with different IDs in the
        landcover table.

    Notes
    -----
    - The twin-segment matching approach follows the conversion performed in
      the WAsP QGIS plugin.
    - If 'external_roughness' is specified, an additional landcover class is
      added to the landcover table for areas outside the polygons.
    - Equivalent functionality written in Fortran is available in the WAsP
      core at Rvea0287/poly2lines.f90.
    """

    # if we have a single polygon, we can just write a single line with
    # roughness length outside the same as inside, so we are still able to
    # retain a single feature in our map without any errors
    if gdf.geometry.size == 1:
        external_roughness = gdf["z0"].item()

    doclipping = True if external_roughness is None else False
    gdf, lctable, unique_z0d, newidx = _preprocess_polygon_gdf(
        gdf,
        lctable=lctable,
        external_roughness=external_roughness,
        check_errors=check_errors,
    )

    if snap:
        gdf = snap_to_layer(gdf, tolerance=snap_tolerance)
        # snapping cannot node boundary crossings from overlapping polygons
        # (check_errors tolerates tiny overlaps), so the union below is only
        # skippable when no polygons overlap
        segments_noded = not _any_polygons_overlap(gdf.geometry.to_numpy())
    else:
        segments_noded = False

    if gdf.geometry.size != 1:
        external_roughness = -999

    # decompose every polygon into rings, oriented so the polygon interior is
    # on the left of the traversal direction (exteriors counterclockwise,
    # holes clockwise)
    # get_rings yields each polygon's exterior first, then its holes, so a
    # ring is a hole exactly when the preceding ring belongs to the same
    # polygon (multipolygons were exploded during preprocessing)
    rings, ring_poly = shapely.get_rings(gdf.geometry.to_numpy(), return_index=True)
    ring_ids = gdf["id"].to_numpy()[ring_poly]
    ring_is_hole = np.r_[False, ring_poly[1:] == ring_poly[:-1]]
    reverse = shapely.is_ccw(rings) == ring_is_hole
    rings[reverse] = shapely.reverse(rings[reverse])

    # break the rings into directed segments; consecutive coordinates of the
    # same ring form a segment (rings are closed, so this covers every edge)
    coords, coord_ring = shapely.get_coordinates(rings, return_index=True)
    same_ring = coord_ring[:-1] == coord_ring[1:]
    directed = np.hstack([coords[:-1], coords[1:]])[same_ring]
    seg_ids = ring_ids[coord_ring[:-1][same_ring]]

    # match each segment with its twin traversed by the neighbouring polygon
    # in the opposite direction: canonicalize the endpoint order and group
    canonical = directed.copy()
    swap = (directed[:, 2] < directed[:, 0]) | (
        (directed[:, 2] == directed[:, 0]) & (directed[:, 3] < directed[:, 1])
    )
    canonical[swap] = directed[swap][:, [2, 3, 0, 1]]
    _, inverse, counts = np.unique(
        canonical, axis=0, return_inverse=True, return_counts=True
    )
    # the shape of `inverse` for axis-based unique differs between numpy
    # versions; always work with the flat form
    inverse = inverse.reshape(-1)

    # per group: the first occurrence keeps its direction and provides
    # id_left, the second (the twin) provides id_right.
    # order_by_group is a permutation of segment indices sorted by group;
    # group_start_pos holds the positions WITHIN that permutation where each
    # group starts, while first_seg holds the segment INDEX of each group's
    # first occurrence
    order_by_group = np.argsort(inverse, kind="stable")
    group_start_pos = np.flatnonzero(np.r_[True, np.diff(inverse[order_by_group]) > 0])
    first_seg = order_by_group[group_start_pos]
    has_twin = counts >= 2

    # the twin's id, valid only where has_twin (clamped to stay in bounds for
    # twinless groups at the end of the array; masked out below)
    twin_ids = seg_ids[
        order_by_group[np.minimum(group_start_pos + 1, len(order_by_group) - 1)]
    ]
    id_left = seg_ids[first_seg]

    # emit the lines in the order the segments were generated (polygon
    # traversal order), which determines the segment order within each
    # (id_left, id_right) group and thereby the exact line_merge output
    order = np.argsort(first_seg)
    first_seg = first_seg[order]
    id_left = id_left[order]
    twin_ids = twin_ids[order]
    has_twin = has_twin[order]
    endpoints = directed[first_seg]

    if doclipping:
        # drop lines on the edge of the domain (only one adjacent polygon)
        keep = (
            has_twin
            & (id_left != external_roughness)
            & (twin_ids != external_roughness)
        )
        id_left, id_right, endpoints = (
            id_left[keep],
            twin_ids[keep],
            endpoints[keep],
        )
    else:
        # lines on the edge of our domain get the background landcover id
        # in place of the missing twin
        id_right = np.where(has_twin, twin_ids, newidx)
        id_right = np.where(id_right == external_roughness, newidx, id_right)
        id_left = np.where(id_left == external_roughness, newidx, id_left)

    if len(id_left) == 0:
        raise ValueError(
            f"No roughness changes lines left after processing {len(gdf)} features, because the roughness on both sides of the lines was equal"
        )

    gdf_out = gpd.GeoDataFrame(
        {
            "id_left": id_left,
            "id_right": id_right,
            "geometry": shapely.linestrings(endpoints.reshape(-1, 2, 2)),
        },
        crs=gdf.crs,
    )
    # combine each (id_left, id_right) group into one geometry and merge
    # contiguous segments into lines; the union is only needed to node
    # segments that are not already unique, noded edges
    combine = shapely.multilinestrings if segments_noded else shapely.union_all
    gdf_out = gdf_out.groupby(["id_left", "id_right"])["geometry"].agg(
        lambda geoms: combine(geoms.to_numpy())
    )
    gdf_out = gpd.GeoSeries(
        shapely.line_merge(gdf_out.to_numpy()), index=gdf_out.index, crs=gdf.crs
    )
    gdf_out = gdf_out.reset_index(name="geometry").explode()
    gdf_out["geometry"] = gdf_out["geometry"].make_valid()
    gdf_out = _explode_gdf(gdf_out).reset_index().drop(columns="index")

    if map_type == "roughness":
        if (unique_z0d.reset_index()["d"] > 0).any():
            raise ValueError(
                "You map contains displacement heights. This information will be lost when map_type='roughness', use map_type='landcover' to keep this information"
            )
        if return_lctable:
            raise ValueError(
                "Cannot return a landcover table when using map_type='roughness', use map_type='landcover' instead if you want to obtain the landcover table."
            )
        return _landcover_to_roughness(gdf_out, lctable)
    else:
        if return_lctable:
            return (gdf_out, lctable)
        else:
            return gdf_out


def snap_to_layer(gdf, tolerance=0.1):
    """
    Snaps the geometries in a GeoDataFrame to each other within a specified tolerance.

    This function iterates over each geometry in the GeoDataFrame. For each geometry,
    it finds all other geometries that intersect it. It then snaps the geometry to each
    of the intersecting geometries within the specified tolerance. Snapping is
    repeated until an iteration inserts no new vertices.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame
        The GeoDataFrame containing the geometries to snap. The GeoDataFrame should
        contain a 'geometry' column with polygons.
    tolerance : float, optional
        The tolerance within which to snap geometries, by default 0.1. This is the maximum
        distance that points can be moved, in the GeoDataFrame's CRS units (metres for
        a projected CRS, degrees for a geographic one). Must be strictly greater than the
        median vertex spacing of every ring in the map.

    Returns
    -------
    GeoDataFrame
        The GeoDataFrame with the snapped geometries.

    Raises
    ------
    ValueError
        If the GeoDataFrame contains invalid geometries, or if any ring's
        median vertex spacing is at or below ``tolerance``. In the latter case,
        snapping cannot distinguish an intentional small gap between
        neighbouring polygons from the ring's own, normal vertex spacing,
        and will splice unrelated nearby vertices into every ring instead.

    Warns
    -----
    UserWarning
        If the GeoDataFrame is in a geographic CRS, as a reminder that
        ``tolerance`` is in degrees rather than metres.

    """
    gdf = gdf.copy()  # avoid modifying the caller's dataframe

    if gdf.crs is not None and gdf.crs.is_geographic:
        warnings.warn(
            "Your map is in a geographic CRS, so `tolerance` is in degrees, "
            "not metres. Make sure the value you passed is appropriate for "
            "degree units, e.g. 1e-4 for roughly 10 m."
        )

    if not all(gdf.is_valid):
        raise ValueError(
            "You have invalid geometries in your vector map. You can try to fix them by replacing the geometry with gdf.geometry.make_valid()"
        )

    geometries = gdf.geometry.to_numpy(copy=True)

    # tolerance must be small vs. each ring's own vertex spacing, checked per
    # ring so a single densely-vertexed ring can't be diluted by the rest.
    coords, coord_ring = shapely.get_coordinates(
        shapely.get_rings(shapely.get_parts(geometries)), return_index=True
    )
    same_ring = coord_ring[:-1] == coord_ring[1:]
    seg_lengths = np.hypot(*np.diff(coords, axis=0)[same_ring].T)
    medians = pd.Series(seg_lengths).groupby(coord_ring[:-1][same_ring]).median()

    below = medians <= tolerance
    if below.any():
        worst_median = medians[below].min()
        unit = gdf.crs.axis_info[0].unit_name if gdf.crs is not None else "CRS units"
        raise ValueError(
            f"Median spacing between consecutive vertices of a ring in your "
            f"map ({worst_median:g} {unit}) is at or below tolerance "
            f"({tolerance:g} {unit}). Use a smaller `tolerance`, or skip "
            "snapping entirely (`snap=False`)"
        )

    n_points = shapely.get_num_coordinates(geometries)
    # a geometry is done when an iteration inserted no vertices into it;
    # done geometries are not snapped again in later iterations
    done = np.zeros(len(geometries), dtype=bool)
    sum_vertices_old = -1

    while n_points.sum() != sum_vertices_old:
        sum_vertices_old = n_points.sum()
        left, right = shapely.STRtree(geometries).query(
            geometries, predicate="intersects"
        )
        keep = ~done[left]

        # snap each geometry to its intersecting neighbours one at a time,
        # always against the neighbours' geometries from the start of the
        # iteration. Self-pairs are kept on purpose: snapping a geometry to
        # its own original coordinates reverts any vertex moved less than
        # tolerance away from where it started, so of two mutually snapped
        # geometries only one moves and shared edges become coincident.
        # Which one moves depends on where the self-pair falls in the query
        # result order for that geometry (a revert only happens when the
        # self-pair comes after the neighbour that moved the vertex); the
        # STRtree query returns the same pair order the geopandas sjoin of
        # the previous implementation produced, and the jitter-alignment
        # tests in test_map_conversions.py pin the resulting behaviour.
        new_geometries = geometries.copy()
        for i, j in zip(left[keep], right[keep]):
            new_geometries[i] = shapely.snap(
                new_geometries[i], geometries[j], tolerance
            )

        new_n_points = shapely.get_num_coordinates(new_geometries)
        done = new_n_points == n_points
        geometries, n_points = new_geometries, new_n_points

    gdf["geometry"] = geometries
    return gdf
