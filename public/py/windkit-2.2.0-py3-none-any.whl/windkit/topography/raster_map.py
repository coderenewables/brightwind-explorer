# (c) 2026 DTU Wind Energy
"""
Contains class and class methods to manipulate topographic raster files

The data is read using rasterio, so all raster formats are supported, but only
GRD files are able for output. Data is stored in an xarray.DataArray.
"""

__all__ = [
    "create_raster_map",
    "fill_elevation_nodata",
]

import logging
import os
import warnings
import zipfile

import numpy as np
import pyproj
import rasterio as rio
import rioxarray
import xarray as xr
from scipy import ndimage
from scipy.interpolate import griddata
from scipy.spatial import QhullError, cKDTree

import windkit.spatial
from windkit.topography.landcover import LandCoverTable
from windkit.xarray_structures.metadata import (
    _MAP_TYPE_ATTRS,
    _update_history,
    _update_var_attrs,
)
from windkit.spatial import clip, crs_are_equal, get_crs, is_raster, set_crs
from windkit.utils import _infer_file_format, _zip_member_on_disk
from windkit.topography._vectormap_helpers import _MAP_TYPE_CODES

logger = logging.getLogger(__name__)


#: How many cells outward from an interior no-data patch are used as the source
#: for its interpolated fill.  Three is enough to bracket the patch on all sides
#: while keeping the triangulation proportional to the size of the holes.
_FILL_NEIGHBOURHOOD_CELLS = 3

#: Minimum number of source points a Delaunay triangulation needs.
_MIN_TRIANGULATION_PTS = 4


SUPPORTED_RASTER_FILE_FORMATS_READ = ["nc", "grd", "tif", "vrt"]
SUPPORTED_RASTER_FILE_FORMATS_WRITE = ["nc", "grd", "tif"]


def create_raster_map(output_locs, resolution, map_type="elevation"):
    """
    Create empty raster map data array The values in the raster map are a 2d
    gaussian and the boundaries are defined by output_locs.

    Parameters
    ----------
    output_locs : xarray.Dataset
        A windkit spatial object that defines the bounding box to create a raster map.
    resolution : float
        Resolution of the raster map.
    map_type : str
        Raster map type. Available options are "elevation", "roughness", or "landcover",
        defaults to "elevation".

    Returns
    -------
    raster_da : xarray.DataArray
        windkit raster map data array.
    """

    if map_type not in ["elevation", "landcover", "roughness"]:
        raise ValueError(
            f'map_type must be one of "elevation","landcover", or "roughness", got "{map_type}"'
        )

    # build the raster_structure
    bb = windkit.spatial.BBox.from_ds(output_locs)
    raster_ds = bb.to_grid(resolution, 10.0)  # this height is not used
    raster_da = raster_ds["output"].isel(height=0, drop=True).rename(map_type)

    if map_type == "elevation":
        raster_da = _fill_gaussian(raster_da)

    elif map_type in ["landcover", "roughness"]:
        raster_da = _fill_surface_patches(raster_da, map_type)

    raster_da = _update_var_attrs(raster_da, _MAP_TYPE_ATTRS)
    return _update_history(raster_da)


def _fill_gaussian(raster_da, amp=None, sigma=None, mu=0, seed=9876538):
    """
    Fill raster with a 2D Gaussian surface with randomly chosen amp and sigma,
    where sigma is scaled to the grid size

    Parameters
    ----------
    raster_da : xarray.DataArray
        Raster data array to be filled
    amp : float, optional
        Amplitude scaling factor of the Gaussian
    sigma : float, optional
        Standard deviation of the Gaussian
    mu : float, optional
        Mean (center) of the Gaussian
    seed : int
        Seed for the random data, defaults to 9876538

    Returns
    -------
    raster_da : xarray.DataArray
        windkit raster map filled with a 2D gaussian surface.
    """
    ny, nx = raster_da.shape
    rng = np.random.default_rng(seed)

    # randomly choose amp if not specified
    if amp is None:
        amp = rng.uniform(100, 700)

    # scale sigma to grid size if not specified
    if sigma is None:
        sigma = rng.uniform(0.1, 0.3) * min(nx, ny)

    y = np.arange(ny) - ny // 2
    x = np.arange(nx) - nx // 2

    val_y = np.exp(-0.5 * np.square((y - mu) / sigma))  # 1D Gaussian
    val_x = np.exp(-0.5 * np.square((x - mu) / sigma))

    # Create 2D Gaussian surface; +1 sets background at 1m above sea level
    z = amp * np.outer(val_y, val_x) + 1

    raster_da.values = np.round(z)
    return raster_da


def _fill_surface_patches(raster_da, map_type="roughness", block_size=5, seed=9876538):
    """
    Create a 2D roughness (landcover) raster map of size ny by nx.
    The grid is divided into smaller blocks of size block_size,
    where each block is randomly assigned roughness (landcover) values.

    Parameters
    ----------
    raster_da : xarray.DataArray
        Raster data array to be filled.
    map_type : str
        "roughness" (default) or "landcover"
    block_size : int, optional
        Number of grid cells in each direction which makes a block
        and share the same roughness/landcover values
    seed : int
        Seed for the random data, defaults to 9876538

    Returns
    -------
    raster_da : xarray.DataArray
        windkit 2D roughness/landcover raster map.
    """
    ny, nx = raster_da.shape

    # Dictionary of possible roughness and landcover values
    patch_values = [
        {"roughness": 0.0, "landcover": 0},
        {"roughness": 0.2, "landcover": 3},
        {"roughness": 1.0, "landcover": 5},
        {"roughness": 1.5, "landcover": 10},
    ]

    roughness_values = np.array([p["roughness"] for p in patch_values])
    landcover_values = np.array([p["landcover"] for p in patch_values])

    # Pad dimensions to be divisible by block_size
    pad_nx = nx + (-nx % block_size)
    pad_ny = ny + (-ny % block_size)

    n_blocks_x = pad_nx // block_size
    n_blocks_y = pad_ny // block_size

    rng = np.random.default_rng(seed)

    # Each block gets a random index into the patch_values table
    block_indices = rng.integers(len(patch_values), size=(n_blocks_y, n_blocks_x))

    # Expand blocks to full grid and trim to original size
    idx_grid = np.repeat(
        np.repeat(block_indices, block_size, axis=0), block_size, axis=1
    )[:ny, :nx]

    if map_type == "roughness":
        raster_da.values = roughness_values[idx_grid]
    elif map_type == "landcover":
        raster_da.values = landcover_values[idx_grid]

    return raster_da


def _fill_source_mask(
    hole_mask, valid_mask, struct, min_source_pts=_MIN_TRIANGULATION_PTS
):
    """Select the valid cells used as sources for a no-data fill.

    Grows a neighbourhood outward from the no-data patches until it holds enough
    valid cells, falling back to every valid cell if the raster is too sparse
    for that to happen. Used to bound both the interior Delaunay triangulation
    and the boundary nearest-neighbour search to a local ring around the holes,
    rather than every valid cell in the raster.

    Parameters
    ----------
    hole_mask : numpy.ndarray
        Boolean mask of the no-data cells to find sources for.
    valid_mask : numpy.ndarray
        Boolean mask of the cells holding finite data.
    struct : numpy.ndarray
        Binary structuring element used to dilate the mask.
    min_source_pts : int
        Minimum number of valid cells to grow the neighbourhood to.

    Returns
    -------
    numpy.ndarray
        Boolean mask of the valid cells to use as fill sources.
    """
    iterations = _FILL_NEIGHBOURHOOD_CELLS
    n_valid = int(valid_mask.sum())
    while True:
        neighbourhood = ndimage.binary_dilation(
            hole_mask, structure=struct, iterations=iterations
        )
        source_mask = neighbourhood & valid_mask
        n_source = int(source_mask.sum())
        if n_source >= min_source_pts or n_source == n_valid:
            return source_mask
        iterations *= 2


def fill_elevation_nodata(
    da: xr.DataArray, max_fill_fraction: float | None = 0.05
) -> xr.DataArray:
    """Fill NaN or Inf cells in an elevation raster.

    Boundary-connected no-data cells are filled with the nearest valid
    neighbour. Interior no-data cells are filled by local piecewise-linear
    interpolation, with nearest-neighbour fallback outside the interpolation
    hull. A warning is issued for each category of fill applied.

    Parameters
    ----------
    da : xarray.DataArray
        2-D raster DataArray with ``west_east`` and ``south_north`` dimensions.
        May contain NaN or Inf values. Dask-backed data is computed into
        memory.
    max_fill_fraction : float or None
        Refuse to fill when no-data cells exceed this fraction of the raster.
        Pass ``None`` to fill regardless of size.

    Returns
    -------
    xarray.DataArray
        Copy of ``da`` with all no-data cells replaced. Attributes, coordinates,
        and dtype are preserved. A clean raster is returned unchanged.

    Raises
    ------
    ValueError
        If the raster is not a 2-D ``(south_north, west_east)`` array, has no
        valid cell, or if no-data cells exceed ``max_fill_fraction``.

    Notes
    -----
    No-data cells are classified as boundary-connected or interior using
    8-connectivity, so a hole that touches the raster edge only diagonally is
    treated as boundary-connected. Boundary-connected cells are extended flat
    from the nearest valid cell rather than interpolated.

    Interior no-data cells are interpolated from a local neighbourhood of
    valid cells around each hole rather than the full raster, to keep the
    triangulation cheap. On a regular grid this makes the result
    neighbourhood-dependent: for holes several cells apart, it can differ
    from a full-raster triangulation by an amount comparable to the
    interpolation error itself.

    Examples
    --------
    >>> import numpy as np
    >>> import xarray as xr
    >>> da = xr.DataArray(
    ...     [[np.nan, 1.0], [2.0, 3.0]],
    ...     dims=["south_north", "west_east"],
    ... )
    >>> fill_elevation_nodata(da, max_fill_fraction=None).values
    array([[2., 1.],
           [2., 3.]])
    """
    if da.ndim != 2 or not is_raster(da):
        raise ValueError(
            "fill_elevation_nodata expects a 2-D raster DataArray with "
            f"dimensions ('south_north', 'west_east'), got dims {da.dims!r}."
        )
    # Canonicalize dimension order so positional edge/axis indexing below
    # (row 0/-1, column 0/-1) always lines up with south_north/west_east,
    # regardless of the order the caller's raster came in. Only transpose
    # when needed so an already-canonical, already-clean raster is returned
    # as the identical object below.
    if da.dims != ("south_north", "west_east"):
        da = da.transpose("south_north", "west_east")

    arr = da.values
    # Inf is no-data too, so it is handled alongside NaN.
    nan_mask = ~np.isfinite(arr)
    if not nan_mask.any():
        return da

    name = da.name or "elevation"
    n_nan = int(nan_mask.sum())
    n_total = int(nan_mask.size)
    if n_nan == n_total:
        raise ValueError(
            f"Elevation raster '{name}' holds no valid cell: all "
            f"{n_total:,} cells are NaN or Inf.  There is nothing to interpolate "
            "from; check that the raster covers your area of interest and "
            "that its no-data value was read correctly."
        )
    if max_fill_fraction is not None and n_nan > max_fill_fraction * n_total:
        raise ValueError(
            f"Filling elevation raster '{name}' would invent terrain for "
            f"{n_nan:,} cell(s) ({100 * n_nan / n_total:.1f}% of the grid), "
            f"above max_fill_fraction={max_fill_fraction}.  Large no-data "
            "regions are better excluded than filled: trim the raster to its "
            "valid extent, or pass a larger max_fill_fraction (or None) to "
            "accept the extrapolation."
        )

    # Identify boundary-connected NaN cells using 8-connectivity flood-fill.
    struct = ndimage.generate_binary_structure(2, 2)
    labeled, _ = ndimage.label(nan_mask, structure=struct)

    border_labels: set[int] = set()
    border_labels.update(labeled[0, :])
    border_labels.update(labeled[-1, :])
    border_labels.update(labeled[:, 0])
    border_labels.update(labeled[:, -1])
    border_labels.discard(0)

    boundary_nan_mask = np.isin(labeled, list(border_labels))
    interior_nan_mask = nan_mask & ~boundary_nan_mask

    filled_arr = arr.copy()

    # Fill boundary no-data cells with nearest-neighbour interpolation.  The
    # cKDTree is built over a dilated ring of valid cells around the boundary
    # patches (the same growing-neighbourhood search used for the interior
    # fill below), not every valid cell in the raster: a tree over the full
    # valid mask is itself an O(raster size) allocation regardless of how few
    # no-data cells there are, which is the same problem
    # ndimage.distance_transform_edt(..., return_indices=True) had. The
    # search grows until it holds at least one valid cell (or the raster has
    # none, which n_nan == n_total already ruled out), so the nearest valid
    # cell is always within the searched ring.
    if boundary_nan_mask.any():
        valid_mask = ~nan_mask
        source_mask = _fill_source_mask(
            boundary_nan_mask, valid_mask, struct, min_source_pts=1
        )
        source_coords = np.column_stack(np.nonzero(source_mask))
        boundary_coords = np.column_stack(np.nonzero(boundary_nan_mask))
        _, nearest = cKDTree(source_coords).query(boundary_coords)
        nearest_coords = source_coords[nearest]
        filled_arr[boundary_nan_mask] = arr[nearest_coords[:, 0], nearest_coords[:, 1]]
        warnings.warn(
            f"Filling {int(boundary_nan_mask.sum())} boundary no-data cell(s) in "
            f"elevation raster '{name}' using nearest-neighbour interpolation.",
            stacklevel=2,
        )

    # Fill interior no-data cells by piecewise-linear interpolation over a Delaunay
    # triangulation of the valid neighbours.  Points outside the convex hull of
    # those cells fall back to nearest-neighbour.
    #
    # This is local (a dilated neighbourhood of each hole, not every valid
    # cell), which keeps the triangulation cheap on realistic rasters but
    # means the result is neighbourhood-dependent: on a regular grid every
    # four points are cocircular, so the Delaunay diagonal orientation (and
    # hence the interpolated value) can differ from a full-raster
    # triangulation by an amount comparable to the interpolation error
    # itself when holes are several cells apart. See
    # TestBoundedElevationNodataInterpolation for the bound this can reach.
    if interior_nan_mask.any():
        valid_mask = ~nan_mask
        interior_pts = np.column_stack(np.nonzero(interior_nan_mask))

        # Interpolate from a dilated neighbourhood of the holes rather than from
        # every valid cell: a single interior NaN would otherwise trigger a
        # Delaunay triangulation of the whole DEM, which costs seconds and
        # gigabytes on rasters of a realistic size.  A degenerate neighbourhood
        # (too few or collinear points) falls back to the full valid set.
        source_mask = _fill_source_mask(interior_nan_mask, valid_mask, struct)
        source_pts = np.column_stack(np.nonzero(source_mask))
        source_vals = arr[source_mask]
        try:
            interpolated = griddata(
                source_pts, source_vals, interior_pts, method="linear"
            )
        except QhullError:
            source_pts = np.column_stack(np.nonzero(valid_mask))
            source_vals = arr[valid_mask]
            interpolated = griddata(
                source_pts, source_vals, interior_pts, method="linear"
            )

        # Fall back to nearest for cells outside the convex hull of the sources.
        hull_nan = np.isnan(interpolated)
        if hull_nan.any():
            interpolated[hull_nan] = griddata(
                source_pts, source_vals, interior_pts[hull_nan], method="nearest"
            )

        filled_arr[interior_nan_mask] = interpolated.astype(arr.dtype)
        warnings.warn(
            f"Filling {int(interior_nan_mask.sum())} interior no-data cell(s) in "
            f"elevation raster '{name}' using piecewise-linear interpolation.",
            stacklevel=2,
        )

    return _update_history(da.copy(data=filled_arr))


# Read raster_maps from different formats
def _read_raster_map_rio(filename, crs=None, zip_file=None, load=False):
    """
    Create a raster from 1-band GIS files able to be read by rasterio.

    Parameters
    ----------
    filename : str or pathlib.Path
        Path to file (on disk or in zipfile)
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    zip_file : ZipFile
        ZipFile object to extract mapfile from
    load : bool
        If True, read the data now and close the file, which the caller can
        then delete. Defaults to False, which reads the data lazily.

    Returns
    -------
    xarray.DataArray
        Raster object converted to WindKit conventions
    """
    logger.info("Reading raster_map %s using _read_raster_map_rio", filename)
    filename = str(filename)

    # Format zipfile for user (This should move to a generic function windkit#98)
    if zip_file is not None:  # pragma: no cover unsure
        filename = "zip://{" + zip_file.filename + "}!" + filename

    # Open file and format the match our expected coordinate names
    with rio.Env(OSR_WKT_FORMAT="WKT2_2018"):
        da = rioxarray.open_rasterio(filename)
        if load:
            with da:
                da.load()
        da = da.squeeze().drop_vars("band")
        da = da.rename({"x": "west_east", "y": "south_north"})

        # Add CRS to object using CF conventions
        if crs is None:
            try:
                da = da.rename({"spatial_ref": "crs"})
                file_crs = get_crs(da)
            except KeyError:
                err = f"Need to supply crs for file {filename}."
                raise ValueError(err)
        else:
            # Check that file crs matches provided
            if "spatial_ref" in da.coords:
                da = da.rename({"spatial_ref": "crs"})
                copy_attrs = da.coords["crs"].attrs[
                    "GeoTransform"
                ]  # get original transform
                try:
                    file_crs = get_crs(da)
                    out_crs = pyproj.CRS.from_user_input(crs)
                    # we consider projections the same if epsg codes match
                    if not crs_are_equal(file_crs, out_crs):
                        err = f"Supplied crs {crs}, does not match file crs."
                        raise ValueError(err)
                except KeyError:
                    err = f"No existing crs, will add {crs}"
                    logging.info(err)
                    set_crs(da, crs)  # assign new projection crs
                da.coords["crs"] = da.coords["crs"].assign_attrs(
                    {"GeoTransform": copy_attrs}
                )  # copy transform info

    # Check that raster is square
    _, dx, _, _, _, dy = [float(i) for i in da.crs.attrs["GeoTransform"].split(" ")]
    if round(abs(dx), 8) != round(abs(dy), 8):  # needs_test
        info_mes = f"""For RasterMap's dx ({dx}) and dy ({dy}) must
        be equal. There are differences after the 7 digit, but we
        will continue. Make sure this is the desired behaviour"""
        logging.info(info_mes)
    if round(abs(dx), 4) != round(abs(dy), 4):  # needs_test
        raise ValueError(f"For RasterMap's dx ({dx}) and dy ({dy}) must be equal.")

    if dy < 0:
        da = da.sortby("south_north")

    if dx < 0:
        da = da.sortby("west_east")

    # Remove rasterio attributes
    da.attrs = {}

    return da


def _read_raster_map_netcdf(filename, crs=None, load=False, **kwargs):
    """
    Create a raster from 1-variable 1-band netcdf file.

    Parameters
    ----------
    filename : str or pathlib.Path
        Path to file
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    load : bool
        If True, read the data now and close the file, which the caller can
        then delete. Defaults to False, which reads the data lazily.
    kwargs :
        Additional keyword arguments passed to open_dataarray

    Returns
    -------
    xarray.DataArray
        raster object
    """
    da = xr.open_dataarray(str(filename), **kwargs)
    if load:
        with da:
            da.load()

    # CRS check or add
    if crs is None:  # needs_test
        if "crs" not in da.coords:
            err = f"Need to supply crs for file {filename}."
            raise ValueError(err)
    else:  # needs_test
        # Check that file crs matches provided
        if "crs" in da.coords:
            if not crs_are_equal(da, crs):
                err = f"Supplied crs {crs}, does not match file crs."
                raise ValueError(err)
        else:
            da = set_crs(da, crs)

    return da


def _read_raster_map(
    filename,
    crs=None,
    map_type=None,
    clip_bbox=None,
    dtype=None,
    file_format="infer",
    convert_to_landcover=False,
    return_lctable=False,
    load=False,
    **kwargs,
):
    """
    Create a raster from 1-band rasterfile.

    GIS files are opened with rasterio
    .nc files are opened with xarray, but only single variable files are handled.

    Parameters
    ----------
    filename : str, pathlib.Path or zipfile.ZipExtFile
        File path, or an open member of a zip archive, whose format is taken
        from its name. A member is read into memory.
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    map_type : str
        name of the map one of (elevation, roughness, or landcover). Defaults to None.
    clip_bbox : shapely.geometry.LinearRing
        Linear Ring that forms a bounding box, must have the same crs as
        the raster that is being read. Defaults to None.
    dtype : numpy.dtype
        The type of the output array. If dtype is not given the file will determine it.
        Defaults to None.
    file_format : str
        File format of the raster map. Defaults to "infer".
    convert_to_landcover : bool
        Convert roughness map to landcover map. Defaults to False.
    load : bool
        If True, read the data now and close the file. Defaults to False,
        which reads the data lazily. A zip member is always read now.
    **kwargs : dict
        Additonal keyword arguments passed to reader.

    Returns
    -------
    xarray.DataArray, LandCoverTable
        raster_map object, if roughness map_type specified it will also return a
        LandCoverTable that maps the roughness values to IDs.
    """
    if isinstance(filename, zipfile.ZipExtFile):
        # Read from a copy on disk, which is deleted on return, so the data
        # is loaded now instead of lazily.
        with _zip_member_on_disk(filename) as path:
            return _read_raster_map(
                path,
                crs=crs,
                map_type=map_type,
                clip_bbox=clip_bbox,
                dtype=dtype,
                file_format=file_format,
                convert_to_landcover=convert_to_landcover,
                return_lctable=return_lctable,
                load=True,
                **kwargs,
            )

    if file_format == "infer":
        file_format = _infer_file_format(filename)

    if file_format not in SUPPORTED_RASTER_FILE_FORMATS_READ:
        raise ValueError(
            f"File format {file_format} is not supported. Supported formats are: {SUPPORTED_RASTER_FILE_FORMATS_READ}"
        )

    if file_format in ["nc"]:
        da = _read_raster_map_netcdf(filename, crs=crs, load=load, **kwargs)
    if file_format in ["grd", "tif", "vrt"]:
        da = _read_raster_map_rio(filename, crs=crs, load=load, **kwargs)

    # Set the map_type as the name of the DataArray
    map_types = _MAP_TYPE_CODES.keys()
    if map_type is None:
        if file_format != ".nc" or da.name not in map_types:  # needs_test
            raise ValueError(
                "Unable to determine map_type from file, please set map_type."
            )
    else:
        if da.name in map_types and da.name != map_type:  # needs_test
            raise ValueError(
                f"Provided map_type {map_type}, does not match file map_type {da.name}"
            )
        da.name = map_type

    # Clip data if requested
    if clip_bbox is not None:  # pragma: no cover already_tested_in_other_module
        da = clip(da, clip_bbox)

    # We never deal with roughness maps internally, always landcover
    if da.name == "roughness":
        da = _validate_roughness_raster_map(
            da, raise_or_warn="warn", max_roughness=5.0, n_max_unique=100
        )

        if convert_to_landcover:
            da, lct = _roughness_to_landcover(da)

    # Change datatype if requested
    if dtype is not None:
        da = da.astype(dtype)

    da = _update_var_attrs(da, _MAP_TYPE_ATTRS)
    da = _update_history(da)

    if convert_to_landcover:
        return da, lct
    else:
        return da


# Oputput raster_maps in different formats
def _raster_map_to_riofile(da, filename, kwargs={}):
    """
    Write raster to a GRD or geotiff file using rasterio.

    Parameters
    ----------
    da : xarray.DataArray
        Raster to write.
    filename : str or pathlib.Path
        Path to file.
    kwargs : dict
        Extra arguments.
    """

    filename = str(filename)
    file_ext = os.path.splitext(filename)[1]

    if file_ext == ".tif":
        driver = "GTiff"
    elif file_ext == ".grd":
        driver = "GSAG"

    x, y = da.west_east.values, da.south_north.values

    resx = x[1] - x[0]
    resy = y[1] - y[0]

    if np.abs(resx) != np.abs(resy):  # needs_test
        logging.warning("Resolution in x and y are not the same!")

    nx, ny = len(x), len(y)
    minx = x[0]
    miny = y[0]

    # Build Affine Transformation
    hresx = resx / 2.0
    hresy = resy / 2.0

    affine = rio.Affine(resx, 0, minx - hresx, 0, resy, miny - hresy)

    f_crs = pyproj.CRS.from_cf(da.crs.attrs)
    crs = rio.crs.CRS.from_user_input(f_crs.to_string())
    with rio.open(
        filename,
        "w",
        driver=driver,
        height=ny,
        width=nx,
        count=1,
        dtype=da.dtype,
        crs=crs,
        transform=affine,
        **kwargs,
    ) as new_ds:
        new_ds.write(da.values, 1)


def _raster_map_to_netcdf(da, filename, **kwargs):
    """
    Write raster to a netcdf file using xarray.

    Parameters
    ----------
    da : xarray.DataArray
        Raster to write.
    filename : str or pathlib.Path
        Path to file.

    """
    ds = _update_var_attrs(da.to_dataset(), _MAP_TYPE_ATTRS)

    ds.to_netcdf(filename, **kwargs)


def _raster_map_to_file(
    da,
    filename,
    lctable=None,
    lctable_var="id",
    save_lctable=False,
    file_format="infer",
    **kwargs,
):
    """
    Write raster to a Surfer ASCII Grid (GRD), geotiff or netcdf file.

    We recommend that unless you have a need for another format, that you write to
    netcdf, as this preserves all the metadata of the file. Next would be geotiff, and
    finally use GRD if you need compatability with tools that only support that format.

    Parameters
    ----------
    da : xarray.DataArray
        Raster to write.
    filename : str or pathlib.Path
        Path to file.
    lctable : LandCoverTable
        LandCoverTable used to write out landcover fields, required for landcover maps.
        Defaults to None.
    lctable_var : str
        If writing an lctable, you can specify the variable that you want to write
        to file. Defaults to "id".
    save_lctable : bool
        Save lctable table to a json file of the same name as the output file to retain
        all landcover metadata?. Defaults to False.
    kwargs : dict
        Extra arguments to pass to rasterio (geotiff) or xarray (netCDF).
    """

    if file_format == "infer":
        file_format = _infer_file_format(filename)

    err_msg_wrong_format = f"File format {file_format} is not supported. Supported formats are: {SUPPORTED_RASTER_FILE_FORMATS_WRITE}"
    if file_format not in SUPPORTED_RASTER_FILE_FORMATS_WRITE:
        raise ValueError(err_msg_wrong_format)

    filename = str(filename)
    file_root, file_ext = os.path.splitext(filename)

    # Handle special case of landcover
    if da.name == "landcover" and lctable is not None:
        if save_lctable:
            lctable.to_json(file_root + ".json")

    if file_format in ["grd", "tif"]:
        _raster_map_to_riofile(da, filename, **kwargs)
    elif file_format in ["nc"]:
        _raster_map_to_netcdf(da, filename, **kwargs)
    else:
        raise ValueError(err_msg_wrong_format)


def _roughness_to_landcover(rgh):
    """converts a roughness map to landcover

    Parameters
    ----------
    rgh : xarray.DataArray
        Roughness map in raster format

    Returns
    -------
    xr.DataArray:
        Landcover map in raster format
    LandCoverTable:
        Landcover table
    """
    rgh = rgh.copy()

    if isinstance(rgh, xr.DataArray):
        z0s = np.unique(rgh.values)
    else:
        z0s = np.unique(rgh)

    lct = LandCoverTable._from_z0s(z0s)

    def _roughness_to_landcover_array(arr):
        out = np.empty_like(arr, dtype="int32")
        for i, z0 in enumerate(z0s):
            out[arr == z0] = i + 1
        return out

    if isinstance(rgh, xr.DataArray):
        lc = xr.apply_ufunc(
            _roughness_to_landcover_array,
            rgh,
        )
        lc.name = "landcover"
    else:
        lc = _roughness_to_landcover_array(rgh)
    return lc, lct


def _landcover_to_roughness(lc, lctable, field="z0"):
    """
    Convert a landcover raster_map to roughness raster_map

    Parameters
    ----------
    lc : xarray.DataArray
        Landcover raster_map
    lctable : LandCoverTable
        Landcover table
    field : str
        Field to use for conversion. Defaults to "z0".

    Returns
    -------
    xarray.DataArray
        Roughness raster_map
    """

    lc = lc.copy()

    def _landcover_to_roughness_array(arr):
        out = np.empty_like(arr, dtype="float32")
        ids = np.unique(arr)
        for k, v in lctable.items():
            if k in ids:
                out[arr == k] = v[field]
        return out

    rgh = xr.apply_ufunc(
        _landcover_to_roughness_array,
        lc,
    )

    if isinstance(rgh, xr.DataArray):
        rgh.name = "roughness"

    return rgh


def _validate_roughness_raster_map(
    da, raise_or_warn="warn", max_roughness=5.0, n_max_unique=100
):
    """
    Validate roughness raster map. Some common issues are checked for and warnings are raised.

    # TODO: move PyWAsP related checks to pywasp in the future.

    .. warning::
        This function is experimental and its signature may change or it may be removed in the future.

    Parameters
    ----------
    da : xarray.DataArray
        Roughness raster map to validate
    raise_or_warn : str
        Whether to raise or warn on validation errors
    max_roughness : float
        Maximum roughness value
    n_max_unique : int
        Maximum number of unique roughness values

    Raises
    ------
    ValueError
        If the input raster map is not a raster and raise_or_warn is set to 'raise'
    ValueError
        If the input raster map is not named 'roughness' and raise_or_warn is set to 'raise'
    ValueError
        If the roughness map contains negative values and raise_or_warn is set to 'raise'
    ValueError
        If the roughness map contains values between 0 and 0.0002 and raise_or_warn is set to 'raise'
    ValueError
        If the roughness map contains values above max_roughness and raise_or_warn is set to 'raise'
    ValueError
        If the roughness map contains more than n_max_unique unique roughness values and raise_or_warn is set to 'raise'
    """

    def _raise_or_warn(msg, raise_or_warn):
        if raise_or_warn == "warn":
            warnings.warn(msg)
        elif raise_or_warn == "raise":
            raise ValueError(msg)

    if is_raster(da) is False:
        _raise_or_warn("Input raster map is not a raster!", raise_or_warn)

    if da.name != "roughness":
        _raise_or_warn("Input raster map is not named 'roughness'!", raise_or_warn)

    if da.min() < 0:
        _raise_or_warn("Roughness map contains negative values!", raise_or_warn)

    if ((da > 0.0) & (da < 0.0002)).any():
        _raise_or_warn(
            "PyWAsP Warning: Roughness map contains values between 0 and 0.0002! Are these water bodies? water bodies should be set to 0.0 m!",
            raise_or_warn,
        )

    if da.max() > max_roughness:
        _raise_or_warn(
            f"PyWAsP Warning: Roughness map contains values above {max_roughness} m! Is this a roughness map?",
            raise_or_warn,
        )

    n_unique = len(np.unique(da.values))
    if n_unique > n_max_unique:
        _raise_or_warn(
            f"PyWAsP Warning: Roughness map contains {n_unique} unique roughness values, above the limit of set at {n_max_unique}!",
            raise_or_warn,
        )

    return da
