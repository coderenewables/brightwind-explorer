# (c) 2026 DTU Wind Energy
"""
Module to handle elevation maps.
"""

__all__ = [
    "read_elevation_map",
    "read_roughness_map",
    "read_landcover_map",
    "elevation_map_to_file",
    "roughness_map_to_file",
    "landcover_map_to_file",
    "create_wasp_site_effects",
    "landcover_to_roughness",
    "roughness_to_landcover",
]
import zipfile
from pathlib import Path

import geopandas as gpd
import numpy as np
import xarray as xr

import windkit.topography.raster_map as _raster_map
import windkit.topography.vector_map as _vector_map

from .._errors import UnsupportedFileTypeError
from ..wind_climate._correlated_fields import _column_of
from ..xarray_structures.empty import (
    _copy_chunks,
    _native_batch,
    _native_batch_horizontal,
    _native_flat_coords,
    _native_frame,
    _native_store,
)
from ..xarray_structures.metadata import (
    _TOPO_EFFECTS_ATTRS,
    _update_history,
    _update_var_attrs,
)
from ..xarray_structures.sector import create_sector_coords


# Lower bound for generated roughness: the roughness length of a calm sea, which
# is about the smoothest surface the wind ever runs over. A roughness length is a
# length scale inside a logarithm - the surface layer profile goes as ln(z / z0) -
# so 0 is not a small value but a singularity, and `log(z0meso)` is taken directly
# when interpolating a generalized wind climate. Drawing from (0, ...) put values
# arbitrarily close to it; starting at the smoothest real surface instead keeps
# the logarithm finite and every generated value physically meaningful.
_MIN_ROUGHNESS = 0.0001

# Bounds of the site effects that are drawn at random, per point and sector.
_SITE_EFFECTS_RANGES = {
    "z0meso": (_MIN_ROUGHNESS, 1.2),
    "slfmeso": (0, 1),
    "displ": (0, 10),
    # The three speedups multiply, and a workflow that generalizes at one site
    # and downscales at another removes the first site's product and applies
    # the second's. These bounds therefore have to be read as a ratio between
    # two nearby sites, not as the envelope a single site can reach: (0.6, 1.5),
    # (0.6, 1.5) and (0.5, 1.0) put that ratio at (1.5*1.5*1.0)/(0.6*0.6*0.5) =
    # 12.5, so a generated mast and a generated prediction point could differ by
    # more than an order of magnitude in wind speed. Ranges wide enough to be
    # interesting per site are not plausible per pair, and the pair is what
    # these datasets are used for.
    "orographic_speedups": (0.85, 1.25),
    "roughness_speedups": (0.85, 1.15),
    # An obstacle shelters the site, it never accelerates the wind, so an
    # obstacle speedup stays at or below 1. The lower bound is well clear of 0
    # for the same reason the constants below are not 0: a speedup multiplies.
    "obstacle_speedups": (0.8, 1.0),
    "orographic_turnings": (-20, 20),
    "dirrix": (0, 0.5),
    "site_elev": (0, 100),
    "rix": (0, 0.5),
}

# Site effects that are held constant, at the value that leaves the wind
# unchanged. Speedups are multiplicative so their neutral value is 1; turnings
# are additive so theirs is 0. These are kept apart from the random ranges
# because filling a speedup with 0 rather than 1 does not weaken the wind, it
# removes it, and every calculation downstream then degenerates silently.
_SITE_EFFECTS_CONSTANTS = {
    "user_def_speedups": 1.0,
    "user_def_turnings": 0.0,
    "obstacle_turnings": 0.0,
    "roughness_turnings": 0.0,
    # A flow-separation diagnostic of 0 means no separation, which is the
    # neutral state rather than a degenerate one.
    "flow_sep_height": 0.0,
}

# The site effects that can be generated, grouped by the shape of the array they
# are stored in. Every one of them must appear in exactly one of the two tables
# above, so that the fill loop always knows what to put in it.
_SITE_EFFECTS_VARS_2D = ["site_elev", "rix"]
_SITE_EFFECTS_VARS_3D_NOHGT = ["z0meso", "slfmeso", "flow_sep_height", "dirrix"]
_SITE_EFFECTS_VARS_4D = [
    "displ",
    "user_def_speedups",
    "orographic_speedups",
    "obstacle_speedups",
    "roughness_speedups",
    "user_def_turnings",
    "orographic_turnings",
    "obstacle_turnings",
    "roughness_turnings",
]


def create_wasp_site_effects(
    output_locs,
    n_sectors=12,
    not_empty=True,
    site_effects=None,
    seed=9876538,
    **kwargs,
):
    """Create empty site-factors dataset.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Output geospatial information
    n_sectors : int
        Number of sectors. Defaults to 12.
    not_empty : bool
        If true, the empty dataset is filled with random
        meaningful data.
    site_effects : list of strings, string, or None
        Variables to include in the output. ``"all"`` includes every
        available variable, including ``flow_sep_height``. A single variable
        name is also accepted. If omitted, the legacy default variable list is
        preserved.
    seed : int
        Seed for the random data, defaults to 9876538.

    kwargs : dict
        Additional arguments.

    Returns
    -------
    ds : xarray.Dataset
        Empty site factors dataset.

    Notes
    -----
    Height-aware variables (``displ`` and the eight speedup/turning
    variables) are stored float32, C-contiguous, with ``sector`` trailing
    the full spatial batch. Height-independent variables (``site_elev``,
    ``rix``, ``z0meso``, ``slfmeso``, ``flow_sep_height``, ``dirrix``) use
    the horizontal batch instead — never a separate height axis — and are
    stored the same way. Both are the reverse of the compiled core's
    declared argument order, so PyWAsP's compiled boundary can take a
    Fortran-ordered view instead of converting a copy (windkit#807). In a
    ``point`` structure, points that share a ``(west_east, south_north)``
    location get the height-independent values of the first point at that
    location. Neither the dtype nor the dimension order is a supported API
    contract: ``create_wasp_site_effects`` is a test-data utility.
    """
    if site_effects is None:
        site_effects = (
            _SITE_EFFECTS_VARS_2D
            + [
                name
                for name in _SITE_EFFECTS_VARS_3D_NOHGT
                if name != "flow_sep_height"
            ]
            + _SITE_EFFECTS_VARS_4D
        )
    elif site_effects == "all":
        site_effects = (
            _SITE_EFFECTS_VARS_2D + _SITE_EFFECTS_VARS_3D_NOHGT + _SITE_EFFECTS_VARS_4D
        )
    elif isinstance(site_effects, str):
        site_effects = [site_effects]

    # site_elev/rix and z0meso/slfmeso/flow_sep_height/dirrix are declared
    # height-independent (height_dim_policy: "forbidden") and use the
    # horizontal batch, without a separate height axis, so a cuboid's or
    # stacked_point's height never enters their shape at all. displ and the
    # eight speedups/turnings are height-aware ("optional") and use the full
    # batch. Both stay height-free for the same reason a scalar height or a
    # reduced horizontal axis does elsewhere in this sweep: nothing here ever
    # stacks to a flat point axis for an unstack to promote back.
    horiz_dims, horiz_shape = _native_batch_horizontal(output_locs)
    full_dims, full_shape = _native_batch(output_locs)
    n_horiz = int(np.prod(horiz_shape, dtype=int))
    n_full = int(np.prod(full_shape, dtype=int))

    # A point structure folds height into the point axis, so its
    # height-independent variables are drawn per point; each point then takes
    # the draw of the first point at its location.
    first_at_location = _first_point_at_location(output_locs, full_dims, full_shape)

    rng = np.random.default_rng(seed) if not_empty else None
    ds = _native_frame(output_locs).assign_coords(
        create_sector_coords(n_sectors).coords
    )
    for var in site_effects:
        if var in _SITE_EFFECTS_VARS_2D:
            core_dims, dims, shape, raw_shape = (), horiz_dims, horiz_shape, [n_horiz]
        elif var in _SITE_EFFECTS_VARS_3D_NOHGT:
            core_dims = ("sector",)
            dims, shape, raw_shape = horiz_dims, horiz_shape, [n_sectors, n_horiz]
        elif var in _SITE_EFFECTS_VARS_4D:
            core_dims = ("sector",)
            dims, shape, raw_shape = full_dims, full_shape, [n_sectors, n_full]
        else:
            raise ValueError(f"Unknown  {var}, cannot add to result")

        if rng is None:
            values = np.full(raw_shape, np.nan)
        elif var in _SITE_EFFECTS_RANGES:
            values = rng.uniform(*_SITE_EFFECTS_RANGES[var], raw_shape)
        elif var in _SITE_EFFECTS_CONSTANTS:
            values = np.full(raw_shape, _SITE_EFFECTS_CONSTANTS[var])
        else:
            raise ValueError(
                f"No fill value known for {var}: it must be listed either in "
                "_SITE_EFFECTS_RANGES or in _SITE_EFFECTS_CONSTANTS."
            )

        if first_at_location is not None and var not in _SITE_EFFECTS_VARS_4D:
            values = values[..., first_at_location]
        out_dims, array = _native_store(values, dims, shape, core_dims=core_dims)
        policy = (
            "forbidden"
            if core_dims == () or var in _SITE_EFFECTS_VARS_3D_NOHGT
            else "optional"
        )
        ds[var] = xr.DataArray(
            array, dims=out_dims, attrs={"height_dim_policy": policy}
        )

    ds = _update_var_attrs(_copy_chunks(output_locs, ds), _TOPO_EFFECTS_ATTRS)

    return _update_history(ds)


def _first_point_at_location(output_locs, dims, shape):
    """Index of the first point at each point's horizontal location.

    The coordinates come from :func:`_native_flat_coords`, so a ``point``
    structure whose horizontal coordinates are scalars or otherwise partially
    shaped - a single-mast profile, say - is broadcast over the point axis
    first. Columns are then numbered by :func:`_column_of`, the same grouping
    ``create_tswc`` and ``create_surface_fields`` use.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Output geospatial information.
    dims, shape : tuple
        Batch dimensions and sizes, from :func:`_native_batch`.

    Returns
    -------
    numpy.ndarray or None
        For a ``point`` structure, the index of the first point with the same
        ``(west_east, south_north)`` for every point; otherwise None.
    """
    if "point" not in output_locs.dims:
        return None
    column = _column_of(*_native_flat_coords(output_locs, dims, shape))
    _, first = np.unique(column, return_index=True)
    return first[column]


def _create_z0meso(output_locs, n_sectors=12, **kwargs):
    """Empty site_effects with only z0meso and slfmeso.

    Parameters
    ----------
    out_grid : xarray.Dataset
        Output geospatial information.
    n_sectors : int
        Number of sectors, defaults to 12.
    kwargs : dict
        Additional arguments.

    Returns
    -------
    ds : xarray.Dataset
        Empty dataset.
    """

    empty_z0 = create_wasp_site_effects(output_locs, n_sectors)[["z0meso", "slfmeso"]]

    return _update_history(empty_z0)


def _infer_spatial_format(filename):
    """Derive if file is vector or raster."""
    if isinstance(filename, zipfile.ZipExtFile):
        filename = filename.name
    if not isinstance(filename, (str, Path)):
        raise TypeError(f"Filename must be a string or Path, not {type(filename)}.")

    suffix = Path(filename).suffix.lower()[1:]
    if suffix in _raster_map.SUPPORTED_RASTER_FILE_FORMATS_READ:
        return "raster"
    elif suffix in _vector_map.SUPPORTED_VECTOR_FILE_FORMATS_READ:
        return "vector"
    else:
        raise UnsupportedFileTypeError(f"Filetype {suffix} not supported for reading.")


def _read_topo_map(
    filename, map_type="elevation", crs=None, spatial_format="infer", **kwargs
):
    """Reads file into an elevation map.

    Parameters
    ----------
    filename : str or pathlib.Path
        Path to file
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    **kwargs : dict
        Additonal keyword arguments passed to reader.
    Returns
    -------
    xarray.DataArray
        elevation_map object
    """
    kwargs = {**kwargs, **{"map_type": map_type}}

    if spatial_format == "infer":
        spatial_format = _infer_spatial_format(filename)
    elif spatial_format not in ["raster", "vector"]:
        raise ValueError(
            f"Invalid spatial format: {spatial_format}. Must be 'raster' or 'vector'."
        )

    if spatial_format == "raster":
        return _raster_map._read_raster_map(filename, crs=crs, **kwargs)
    elif spatial_format == "vector":
        return _vector_map._read_vector_map(filename, crs=crs, **kwargs)
    else:
        err_msg = f"Filetype {filename.suffix[1:]} not supported for reading."
        err_msg += " Supported filetypes are: Raster: "
        err_msg += ", ".join(_raster_map.SUPPORTED_RASTER_FILE_FORMATS_READ)
        err_msg += ", Vector: "
        err_msg += ", ".join(_vector_map.SUPPORTED_VECTOR_FILE_FORMATS_READ)
        raise UnsupportedFileTypeError(err_msg)


def read_elevation_map(filename, crs=None, **kwargs):
    """
    Read elevation map from file.

    The file can be either a raster file or a vector file.

    If the file is a raster file, the following formats are supported:
       "grd" and "tif" (geoTIFF).

    If the file is a vector file, the following formats are supported:
        "gpkg", "gml", "map", "tmp", "zip"

    Parameters
    ----------
    filename : str, pathlib.Path or zipfile.ZipExtFile
        Path to file, or an open member of a zip archive, whose format is
        taken from its name.
    crs : int, dict, str or pyproj.crs.CRS, optional
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    **kwargs : dict
        Additonal keyword arguments passed to reader.

    Returns
    -------
    xarray.DataArray, gpd.GeoDataFrame
        elevation_map object

    """
    kwargs = {**kwargs, **{"map_type": "elevation"}}
    return _read_topo_map(filename, crs=crs, **kwargs)


def read_roughness_map(filename, crs=None, convert_to_landcover=False, **kwargs):
    """
    Read roughness map from file.

    The file can be either a raster file or a vector file.

    If the file is a raster file, the following formats are supported:
       "grd" and "tif" (geoTIFF).

    If the file is a vector file, the following formats are supported:
        "gpkg", "gml", "map", "tmp", "zip"

    Parameters
    ----------
    filename : str, pathlib.Path or zipfile.ZipExtFile
        Path to file, or an open member of a zip archive, whose format is
        taken from its name.
    crs : int, dict, str or pyproj.crs.CRS, optional
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    convert_to_landcover : bool
        Whether to convert the roughness map to a landcover map. Default is False.
    polygons: bool
        Whether to convert the opened file to polygons, default True. If False,
        opens the file as old fashioned change lines. You can try this if your
        file is not being opened correctly, but you are responsible for checking
        it's correctness, because there is less error checking for these types
        of files.
    check_errors: bool
        Whether to check for errors in the map, default True.
    **kwargs : dict
        Additonal keyword arguments passed to reader.

    Returns
    -------
    xarray.DataArray, gpd.GeoDataFrame
        roughness_map object

    """
    kwargs = {
        **kwargs,
        **{"map_type": "roughness", "convert_to_landcover": convert_to_landcover},
    }
    return _read_topo_map(filename, crs=crs, **kwargs)


def read_landcover_map(filename, crs=None, return_lctable=False, **kwargs):
    """
    Read landcover map from file.

    The file can be either a raster file or a vector file.

    If the file is a raster file, the following formats are supported:
       "grd" and "tif" (geoTIFF).

    If the file is a vector file, the following formats are supported:
        "gpkg", "gml", "map", "tmp", "zip"

    Parameters
    ----------
    filename : str, pathlib.Path or zipfile.ZipExtFile
        Path to file, or an open member of a zip archive, whose format is
        taken from its name.
    crs : int, dict, str or pyproj.crs.CRS, optional
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    return_lctable : bool
        Whether to return the landcover table. Default is False.
    polygons: bool
        Whether to convert the opened file to polygons, default True. If False,
        opens the file as old fashioned change lines. You can try this if your
        file is not being opened correctly, but you are responsible for checking
        it's correctness, because there is less error checking for these types of files.
    check_errors: bool
        Whether to check for errors in the map, default True.
    **kwargs : dict
        Additonal keyword arguments passed to reader.

    Returns
    -------
    xarray.DataArray, gpd.GeoDataFrame
        landcover_map object

    """
    kwargs = {**kwargs, **{"map_type": "landcover", "return_lctable": return_lctable}}
    return _read_topo_map(filename, crs=crs, **kwargs)


def _map_to_file(obj, filename, spatial_format="infer", **kwargs):
    """Write elevation map to file.

    Parameters
    ----------
    obj : xarray.DataArray or gpd.GeoDataFrame
        Map to write
    filename : str or pathlib.Path
        Path to file
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    **kwargs : dict
        Additonal keyword arguments passed to writer.
    """

    if spatial_format == "infer":
        spatial_format = _infer_spatial_format(filename)
    elif spatial_format not in ["raster", "vector"]:
        raise ValueError(
            f"Invalid spatial format: {spatial_format}. Must be 'raster' or 'vector'."
        )

    if spatial_format == "raster":
        return _raster_map._raster_map_to_file(obj, filename, **kwargs)
    elif spatial_format == "vector":
        return _vector_map._vector_map_to_file(obj, filename, **kwargs)
    else:
        err_msg = f"Filetype {filename.suffix[1:]} not supported for writing."
        err_msg += " Supported filetypes are: Raster: "
        err_msg += ", ".join(_raster_map.SUPPORTED_RASTER_FILE_FORMATS_WRITE)
        err_msg += ", Vector: "
        err_msg += ", ".join(_vector_map.SUPPORTED_VECTOR_FILE_FORMATS_WRITE)
        raise UnsupportedFileTypeError(err_msg)


def elevation_map_to_file(elevation_map, filename, **kwargs):
    """
    Write elevation map to file.

    The file can be either a raster file or a vector file.

    If the file is a raster file, the following formats are supported:
       "grd" and "tif" (geoTIFF).

    If the file is a vector file, the following formats are supported:
        "gpkg", "gml", "map"

    Parameters
    ----------
    filename : str or pathlib.Path
        Path to file
    elevation_map : xarray.DataArray
        Elevation map
    crs : int, dict, str or pyproj.crs.CRS, optional
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    **kwargs : dict
        Additonal keyword arguments passed to writer.
    """
    return _map_to_file(elevation_map, filename, **kwargs)


def roughness_map_to_file(roughness_map, filename, **kwargs):
    """
    Write roughness map to file.

    The file can be either a raster file or a vector file.

    If the file is a raster file, the following formats are supported:
       "grd" and "tif" (geoTIFF).

    If the file is a vector file, the following formats are supported:
        "gpkg", "gml", "map"

    Parameters
    ----------
    filename : str or pathlib.Path
        Path to file
    roughness_map : xarray.DataArray
        Roughness map
    crs : int, dict, str or pyproj.crs.CRS, optional
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    **kwargs : dict
        Additonal keyword arguments passed to writer.
    """
    return _map_to_file(roughness_map, filename, **kwargs)


def landcover_map_to_file(landcover_map, filename, **kwargs):
    """
    Write landcover map to file.

    The file can be either a raster file or a vector file.

    If the file is a raster file, the following formats are supported:
       "grd" and "tif" (geoTIFF).

    If the file is a vector file, the following formats are supported:
        "gpkg", "gml", "map"

    Parameters
    ----------
    filename : str or pathlib.Path
        Path to file
    landcover_map : xarray.DataArray
        Landcover map
    crs : int, dict, str or pyproj.crs.CRS, optional
        Value to initialize `pyproj.crs.CRS` (Default: read from file)
    **kwargs : dict
        Additonal keyword arguments passed to writer.
    """
    return _map_to_file(landcover_map, filename, **kwargs)


def _is_raster_map(map):
    """Check if map is a raster map."""
    return isinstance(map, xr.DataArray)


def _is_vector_map(map):
    """Check if map is a vector map."""
    return isinstance(map, gpd.GeoDataFrame)


def _obj_is_raster_or_vector_map(map):
    """Check if map is a raster or vector map."""
    if _is_raster_map(map):
        return "raster"
    elif _is_vector_map(map):
        return "vector"
    else:
        raise ValueError("Map is not a raster or vector map.")


def roughness_to_landcover(rgh):
    """Converts a roughness map to landcover map."""
    spatial_data_type = _obj_is_raster_or_vector_map(rgh)
    if spatial_data_type == "raster":
        return _raster_map._roughness_to_landcover(rgh)
    elif spatial_data_type == "vector":
        if not _vector_map._is_z0(rgh):
            raise ValueError("Vector map is not a roughness map.")
        return _vector_map._roughness_to_landcover(rgh)
    else:
        raise UnsupportedFileTypeError("Obj must be a roughness vector or raster map.")


def landcover_to_roughness(lc, lctable):
    """Converts a landcover map to roughness map."""
    spatial_data_type = _obj_is_raster_or_vector_map(lc)
    if spatial_data_type == "raster":
        return _raster_map._landcover_to_roughness(lc, lctable)
    elif spatial_data_type == "vector":
        return _vector_map._landcover_to_roughness(lc, lctable)
    else:
        raise UnsupportedFileTypeError("Obj must be a landcover vector or raster map.")
