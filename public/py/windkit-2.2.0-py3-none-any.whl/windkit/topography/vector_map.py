# (c) 2026 DTU Wind Energy
"""
Readers and writers for vectormap objects.

VectorMaps are defined as collections of linestrings and metadata that represent either
elevations, or the land-cover information. When working with land-cover lines, an
additional LandCoverTable is required to map the land-cover ids to relevant parameters.

Here VectorMaps are represented as geopandas.GeoDataFrame objects. They can be read
from and written to several different formats to support interoperability with different
tools. We recommend using the Geopackage (.gpkg) format if you do not need to use one of
the other formats. For interoperability with WAsP, you should use the .map format for
elevation maps, and .gml for land-cover maps.
"""

__all__ = ["create_vector_map", "add_landcover_table"]

import argparse
import logging
import warnings
import zipfile
from collections import defaultdict
from functools import lru_cache
from inspect import cleandoc
from pathlib import Path
from typing import Union

import geopandas as gpd
import numpy as np
import pandas as pd
import pyproj
from shapely.geometry import LineString, Polygon

from windkit.topography.landcover import LandCoverTable
from windkit.topography.map_conversions import lines_to_polygons, polygons_to_lines
from windkit.spatial import crs_are_equal
from windkit.utils import _infer_file_format, _zip_member_on_disk

from .._errors import UnsupportedFileTypeError
from ._vectormap_gml import _read_vector_map_gml, _write_vectormap_gml
from ._vectormap_helpers import (
    VECTORMAP_ALT_ELEV_COL,
    VECTORMAP_ELEV_COL,
    VECTORMAP_ID_COLS,
    VECTORMAP_LMASKL_COL,
    VECTORMAP_LMASKR_COL,
    VECTORMAP_META_COLS,
    VECTORMAP_ROU_COLS,
    VECTORMAP_ROUL_COL,
    VECTORMAP_ROUR_COL,
    _check_map_errors,
    _explode_gdf,
    _has_inline_lctable,
    _is_elev,
    _is_lc,
    _is_lines,
    _is_polygons,
    _is_z0,
    _landcover_to_roughness,
    _roughness_to_landcover,
)

try:
    import pyogrio  # noqa: F401

    HAS_PYOGRIO = True
except ImportError:
    HAS_PYOGRIO = False

try:
    import fiona  # noqa: F401

    HAS_FIONA = True
except ImportError:
    HAS_FIONA = False

logger = logging.getLogger("__name__")

SUPPORTED_VECTOR_FILE_FORMATS_READ = ["gpkg", "gml", "map", "tmp", "zip"]
SUPPORTED_VECTOR_FILE_FORMATS_WRITE = ["gpkg", "gml", "map"]


#: ``map_type`` values a .map file can express. Not "landcover":
#: _read_vector_map rejects it or rewrites it to "roughness".
_MAP_FILE_MAP_TYPES = ("elevation", "roughness", "landmask")


def _detect_map_type(filename, has_elev, has_z0):
    """Infer whether a .map file holds elevation or roughness lines."""
    if has_elev.any() and has_z0.any():
        raise ValueError(
            f"'{filename}' holds both elevation and roughness lines; pass "
            "map_type='elevation' or map_type='roughness'"
        )
    if has_elev.any():
        return "elevation"
    if has_z0.any():
        return "roughness"
    raise ValueError(f"No attributed lines found in '{filename}'")


def _map_to_gdf(filename, crs, map_type):
    """
    Read a .map vector_map file into a GeoDataFrame.

    A .map file may hold elevation lines, roughness change lines, combination
    lines carrying both, and lines with no attributes at all. ``map_type``
    picks which of them end up in the GeoDataFrame; when it is None, and the
    file holds only one kind, that kind is used.

    The file's ``z`` scale and offset are applied to the elevations. Its fixed
    points must describe the identity transform: windkit does not know how to
    map user coordinates onto metric ones.

    Parameters
    ----------
    filename : str or pathlib.Path
        File path
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`. When None, it is taken from the
        file header.
    map_type: str {elevation, roughness, landmask} or None
        Which lines to read from the .map. Inferred from the file when None.

    Returns
    -------
    geopandas.GeoDataFrame
        Vectormap as a geodataframe.

    Raises
    ------
    ValueError
        If ``map_type`` is not a type a .map file can hold, if the file holds
        no lines of the requested type, or if ``crs`` is neither given nor
        detectable from the file.
    NotImplementedError
        If the file's fixed points describe a non-identity transform.
    """
    from windkit.io.wasp.map import _is_identity_fixed_points, read_map

    if map_type is not None and map_type not in _MAP_FILE_MAP_TYPES:
        raise ValueError(
            f"map_type '{map_type}' cannot be read from a .map file; expected "
            f"one of {', '.join(_MAP_FILE_MAP_TYPES)}"
        )

    data = read_map(filename)
    header = data["header"]

    if crs is None:
        crs = header["epsg"]
        if crs is None:
            raise ValueError("'crs' cannot be detected from file")

    if not _is_identity_fixed_points(header["fixed_points"]):
        raise NotImplementedError(
            f"'{filename}' maps user coordinates onto metric ones with the "
            f"fixed points {header['fixed_points'].tolist()}; windkit only "
            "reads .map files whose coordinates are already metric."
        )

    # z_metric = z_scale * (z_user + z_offset); nan elevations stay nan.
    elev = header["z_scale"] * (data["elev"] + header["z_offset"])
    z0_left, z0_right = data["z0_left"], data["z0_right"]

    has_elev = ~np.isnan(elev)
    has_z0 = ~np.isnan(z0_left)

    if map_type is None:
        map_type = _detect_map_type(filename, has_elev, has_z0)

    if map_type == "elevation":
        keep = has_elev
        columns = {VECTORMAP_ELEV_COL: elev[keep]}
    else:
        keep = has_z0
        if map_type == "landmask":
            left, right = VECTORMAP_LMASKL_COL, VECTORMAP_LMASKR_COL
        else:
            left, right = VECTORMAP_ROUL_COL, VECTORMAP_ROUR_COL
        columns = {left: z0_left[keep], right: z0_right[keep]}

    if not keep.any():
        raise ValueError(f"No '{map_type}' lines found.")

    geometry = [
        LineString(points) for points, wanted in zip(data["points"], keep) if wanted
    ]
    return gpd.GeoDataFrame(columns, geometry=geometry, crs=crs)


def _read_vector_map(
    filename,
    crs=None,
    map_type=None,
    file_format="infer",
    external_roughness=None,
    return_lctable=False,
    convert_to_landcover=False,
    polygons=True,
    check_errors=True,
    layer=None,
):
    """
    Read a vector_map from a file.

    Parameters
    ----------
    filename : str, pathlib.Path or zipfile.ZipExtFile
        File path, or an open member of a zip archive, whose format is taken
        from its name.
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS` Default reads from file.
    map_type : str
        One of "elevation" or "roughness" to specify the type of map to create.
        Defaults to None.
    file_format: str
        Format of the file. Defaults to "infer", which will try to infer the format from the file extension.
    external_roughness: float, optional.
        This option is used for polygon based landcover files. It sets the roughness
        for all areas not covered by polygons.
    return_lctable: bool
        If True, attempt to read and return a LandCoverTable from the file. Defaults to False.
    convert_to_landcover: bool
        If True when reading a roughness map, convert it to a landcover map and return both the map and the
        lctable. Defaults to False.
    polygons: bool
        Whether to convert the opened file to polygons, default True.
    check_errors: bool
        Whether to check for errors in the map, default True.
    layer : str, optional
        Name of the layer to read from a multi-layer GeoPackage file.
        Defaults to None.

    Returns
    -------
    gdf: geopandas.GeoDataFrame
        Vectormap as a geodataframe.
    lc : LandCoverTable, optional
        LandCoverTable optional.
    """
    if isinstance(filename, zipfile.ZipExtFile):
        # Read from a copy on disk: fiona lists layers from a path only, and
        # GDAL warns about the extension-less name pyogrio gives a buffer.
        with _zip_member_on_disk(filename) as path:
            return _read_vector_map(
                path,
                crs=crs,
                map_type=map_type,
                file_format=file_format,
                external_roughness=external_roughness,
                return_lctable=return_lctable,
                convert_to_landcover=convert_to_landcover,
                polygons=polygons,
                check_errors=check_errors,
                layer=layer,
            )

    lctable = None
    if file_format == "infer":
        file_format = _infer_file_format(filename)

    unsupported_file_format_err = f"Unsupported file format: {file_format}. Supported formats are: {SUPPORTED_VECTOR_FILE_FORMATS_READ}"
    if file_format not in SUPPORTED_VECTOR_FILE_FORMATS_READ:
        raise UnsupportedFileTypeError(unsupported_file_format_err)

    if not Path(filename).exists():
        raise FileNotFoundError(filename)

    if file_format in ["map", "tmp"]:
        if not polygons and not convert_to_landcover and map_type == "landcover":
            raise ValueError(
                ".map files do not support landcover maps."
                + " If you want to read a roughness map and convert it to a landcover map,"
                + " use the 'convert_to_landcover' argument with 'read_roughness_map'."
            )
        elif map_type == "landcover":
            map_type = "roughness"
        gdf = _map_to_gdf(filename, crs=crs, map_type=map_type)
    elif file_format in ["gml"]:
        gdf, lctable = _read_vector_map_gml(filename)
    elif file_format in ["gpkg", "zip"]:
        engine = None  # Geopandas will use default available engine if None
        read_kwargs = {}
        if HAS_PYOGRIO:
            engine = "pyogrio"
        elif HAS_FIONA:
            engine = "fiona"
            read_kwargs["driver"] = "GPKG"
        else:
            raise ValueError("No suitable reader found for gpkg vector map.")

        available_layers = None
        if layer is None:
            if HAS_PYOGRIO:
                available_layers = gpd.list_layers(filename)["name"].tolist()
            elif HAS_FIONA:
                import fiona

                available_layers = fiona.listlayers(str(filename))

            if available_layers is not None:
                if len(available_layers) == 0:
                    raise ValueError(
                        f"No layers found in {filename}. The file may be empty or corrupted."
                    )
                elif len(available_layers) == 1:
                    layer = available_layers[0]
                elif (
                    map_type in ["roughness", "landcover", None]
                    and "landcover_lines" in available_layers
                ):
                    layer = "landcover_lines"
                else:
                    raise ValueError(
                        f"Multiple layers found in {filename}: {available_layers}. "
                        f"Specify 'layer' argument."
                    )

        gdf = gpd.read_file(filename, engine=engine, layer=layer, **read_kwargs)

    if crs is not None and gdf.crs is not None:
        if not crs_are_equal(gdf.crs, crs):
            raise ValueError(f"Dataset crs {gdf.crs} doesn't match crs argument {crs}.")
    elif crs is not None and gdf.crs is None:
        gdf = gdf.set_crs(crs)

    if _is_polygons(gdf):
        if check_errors:
            _check_map_errors(gdf, external_roughness, lctable)
        return gdf

    if _is_elev(gdf):
        gdf = gdf.rename(
            columns={v: VECTORMAP_ELEV_COL for v in VECTORMAP_ALT_ELEV_COL}
        )
        gdf[VECTORMAP_ELEV_COL] = gdf[VECTORMAP_ELEV_COL].astype(float)

    if _is_z0(gdf):
        gdf[list(VECTORMAP_ROU_COLS)] = gdf[list(VECTORMAP_ROU_COLS)].astype(float)
        if not polygons and convert_to_landcover:
            return _roughness_to_landcover(gdf)
        elif polygons:
            gdf, lctable = _roughness_to_landcover(gdf)

    if _is_lc(gdf):
        if (
            lctable is None
        ):  # Requires separate landcover table, either from gpkg or json
            gdf[list(VECTORMAP_ID_COLS)] = gdf[list(VECTORMAP_ID_COLS)].astype(int)

            if not polygons and not return_lctable:
                return gdf

            ###############################################
            # Get landcover table from file if it is there
            ###############################################

            if _has_inline_lctable(gdf):  # Landcover info is from each row of table
                lctable = LandCoverTable(
                    gdf[["id", "d", "z0", "desc"]]
                    .drop_duplicates()
                    .set_index("id")
                    .to_dict(orient="index")
                )
                if not polygons:
                    return gdf, lctable

            if available_layers is None:
                if HAS_PYOGRIO:
                    available_layers = gpd.list_layers(filename)["name"].tolist()
                elif HAS_FIONA:
                    import fiona

                    available_layers = fiona.listlayers(str(filename))
            if available_layers is not None:
                if "landcover_table" not in available_layers:
                    raise ValueError(
                        "Landcover table not found in GeoPackage, cannot return LandCoverTable."
                    )

            try:
                lcdf = gpd.read_file(filename, layer="landcover_table")
                if "index" in lcdf.columns:
                    lcdf = lcdf.rename(columns={"index": "id"})
                    warnings.warn(
                        "The use of the name 'index' to identify landcover ID's "
                        "in the landcover table is deprecated since windkit 0.6.3 "
                        "and will be removed in windkit 3.0. Use the name 'id' "
                        "instead.",
                        FutureWarning,
                        stacklevel=2,
                    )
                lcdf = lcdf.set_index("id")
                lctable = LandCoverTable(
                    lcdf.drop("geometry", axis=1, errors="ignore").transpose().to_dict()
                )
            except ValueError as e:
                raise e

        if not polygons and return_lctable:
            return (gdf, lctable)
        else:
            gdf = lines_to_polygons(gdf)
            gdf = add_landcover_table(gdf, lctable)

    return gdf


#: Decimals per coordinate. Metres need one, the WAsP GUI's decimetre
#: convention; degrees need more, or every coordinate rounds to ~11 km. An
#: unknown CRS takes the geographic count, because writing too many decimals
#: only enlarges the file where writing too few destroys the coordinates.
_PROJECTED_COORD_DECIMALS = 1
_GEOGRAPHIC_COORD_DECIMALS = 8


def _reject_nan(gdf, column):
    """Return *column* as a float array, raising if any value is nan.

    ``write_map`` reads a nan attribute as "this line carries no such
    attribute" and writes the line without it, which reads back as a line to
    discard. A nan in a GeoDataFrame column is corrupt data rather than a
    deliberate omission, so catch it here.

    Raises
    ------
    ValueError
        If any value in *column* is nan.
    """
    values = gdf[column].to_numpy(dtype=float)
    is_nan = np.isnan(values)
    if is_nan.any():
        # Index labels, not positions: a filtered or exploded gdf has labels
        # that no longer match positions, and it is the label that names a row.
        labels = gdf.index[np.flatnonzero(is_nan)]
        shown = ", ".join(str(label) for label in labels[:10])
        if labels.size > 10:
            shown += f", ... ({labels.size} rows in total)"
        raise ValueError(
            f"Column '{column}' holds nan at index label(s) {shown}; a .map line "
            f"cannot record a missing '{column}'. Drop these rows or fill them "
            "before writing."
        )
    return values


def _vector_map_to_mapfile(gdf, filename, description="WindKit"):
    """
    Write vector_map in GeoDataFrame format to WAsP mapfile format.

    Parameters
    ----------
    gdf : geopandas.GeoDataFrame
        Elevation or roughness change vector_map.
    filename : pathlib.Path or str
        Path to output file.
    description : str
        Description string added to the file (cannot be empty when reading with map editor).
        Defaults to "WindKit"

    Raises
    ------
    ValueError
        If *gdf* holds both elevation and roughness, if it holds neither, or if
        an attribute column holds nan.

    Notes
    -----
    Coordinates are written with one decimal for a projected CRS. A geographic
    CRS, and an unknown one, get eight: one decimal of a degree is ~11 km.
    """
    from windkit.io.wasp.map import _format_header, write_map

    if all(c in gdf.columns for c in VECTORMAP_META_COLS):  # pragma: no cover
        raise ValueError(
            cleandoc(
                """Both elevation and roughness values found! combo files are not supported! Please write them separately!"""
            )
        )

    if _is_elev(gdf):
        map_type = "elevation"
    elif _is_z0(gdf):
        map_type = "roughness"
    else:
        raise ValueError(
            "Only elevation and roughness data can be written to mapfile (.map) format."
        )

    header = {"description": _format_header(description, _epsg_from_crs(gdf.crs))}

    if gdf.crs is None or gdf.crs.is_geographic:
        coord_decimals = _GEOGRAPHIC_COORD_DECIMALS
    else:
        coord_decimals = _PROJECTED_COORD_DECIMALS

    points = [
        np.asarray((geom.boundary if isinstance(geom, Polygon) else geom).coords)[:, :2]
        for geom in gdf.geometry
    ]

    if map_type == "elevation":
        elev = _reject_nan(gdf, VECTORMAP_ELEV_COL)
        z0_left = z0_right = None
    else:
        elev = None
        z0_left = _reject_nan(gdf, VECTORMAP_ROUL_COL)
        z0_right = _reject_nan(gdf, VECTORMAP_ROUR_COL)

    write_map(
        filename,
        points,
        header,
        elev=elev,
        z0_left=z0_left,
        z0_right=z0_right,
        coord_decimals=coord_decimals,
    )


def _vector_map_to_gmlfile(
    gdf, filename, lctable=None, description="Windkit", **kwargs
):
    """
    Write vectormap in GeoDataFrame format to GML format.

    Parameters
    ----------
    gdf : geopandas.GeoDataFrame
        Elevation or roughness change vector_map.
    filename : pathlib.Path or str
        Path to output file.
    lctable : LandCoverTable
        Landcover table to map landcover and roughness / displacements. Defaults to None.
    description : str
        Description added to the file (cannot be empty when reading with map editor).
        Defaults to "Windkit"
    kwargs : dict
        Extra arguments.

    """
    _write_vectormap_gml(filename, gdf, lctable, description)


def _vector_map_to_gpdfile(gdf, filename, lctable=None, **kwargs):
    """
    Write vectormap in GeoDataFrame format to GeoPackage format.

    Parameters
    ----------
    gdf : geopandas.GeoDataFrame
        Elevation or roughness change vector_map.
    filename : pathlib.Path or str
        Path to output file.
    lctable : LandCoverTable
        Landcover table to map landcover and roughness / displacements. Defaults to None.
    kwargs : dict
        Extra arguments.

    """
    default_geopandas_kwargs = {"driver": "GPKG"}
    kwargs = {**default_geopandas_kwargs, **kwargs}
    if _is_lc(gdf):
        logger.debug("Adding landcover table to GeoPackage output")
        gdf.to_file(str(filename), layer="landcover_lines", **kwargs)
        lct_df = pd.DataFrame.from_dict(lctable, orient="index").reset_index(names="id")
        lct_df["geometry"] = None
        lct_gdf = gpd.GeoDataFrame(lct_df, geometry="geometry", crs=gdf.crs)
        return lct_gdf.to_file(
            str(filename),
            layer="landcover_table",
            **kwargs,
        )
    else:
        return gdf.to_file(str(filename), **kwargs)


def _force_to_lines(
    gdf,
    lctable,
    external_roughness=None,
    check_errors=True,
    snap=True,
    snap_tolerance=0.1,
):
    """
    Prepare a roughness GeoDataFrame for processing.

    Parameters
    ----------
    gdf : geopandas.GeoDataFrame
        The GeoDataFrame to prepare.
    lctable : LandCoverTable
        The landcover table to use.
    snap_tolerance : float, optional
        Snapping tolerance passed to `polygons_to_lines` when `snap` is
        True. See `snap_to_layer`.
    **kwargs : dict
        Additional arguments.

    Returns
    -------
    tuple
        A tuple containing the prepared GeoDataFrame and the landcover table.
    """
    gdf = _explode_gdf(gdf)
    if _is_polygons(gdf):
        return polygons_to_lines(
            gdf,
            lctable=lctable,
            map_type="landcover",
            return_lctable=True,
            external_roughness=external_roughness,
            check_errors=check_errors,
            snap=snap,
            snap_tolerance=snap_tolerance,
        )
    elif _is_lines(gdf):
        return (gdf, lctable)
    else:
        geom_types = "&".join(gdf.geom_type.unique())
        raise ValueError(
            f"Don't know how to deal with a combination of geometry types {geom_types}"
        )


def _vector_map_to_file(
    gdf,
    filename: Union[Path, str],
    lctable: LandCoverTable | None = None,
    file_format: str = "infer",
    external_roughness: float | None = None,
    check_errors: bool = True,
    snap: bool = True,
    polygons: bool = True,
    snap_tolerance: float = 0.1,
    **kwargs,
):
    """Write a GeoDataFrame vector map to a vectorfile.

    Filetypes are determined from the file extension.
    .map files passed to vector_to_mapfile()
    .gml files are passed to vector_to_gmlfile()
    all others use the geopandas .to_file() method

    Parameters
    ----------
    gdf : geopandas.GeoDataFrame
        Vector map to write
    filename : pathlib.Path or str
        Path to file to write to.
    lctable : LandCoverTable
        Landcover table to map landcover and roughness / displacements. Defaults to None.
    driver : str
        Name of the Fiona Driver to pass to geopandas.to_file(). Defaults to "GPKG"
    snap_tolerance : float, optional
        Snapping tolerance passed to `polygons_to_lines` when `snap` is
        True. See `snap_to_layer`.
    kwargs : dict
        Keyword arguments to pass to writer.
    """
    if file_format == "infer":
        file_format = _infer_file_format(filename)
    else:
        if file_format not in SUPPORTED_VECTOR_FILE_FORMATS_WRITE:
            raise ValueError(f"Unsupported file format: {file_format}")

    if _is_polygons(gdf) and polygons:
        if lctable is not None:
            raise ValueError(
                "Cannot write polygons with a landcover table. Add the landcover table using `windkit.add_landcover_table` first."
            )
        if file_format == "gpkg":
            return _vector_map_to_gpdfile(gdf, filename, **kwargs)

    gdf, lctable = _force_to_lines(
        gdf,
        lctable,
        external_roughness=external_roughness,
        check_errors=check_errors,
        snap=snap,
        snap_tolerance=snap_tolerance,
    )

    if not (_is_elev(gdf) or _is_lc(gdf) or _is_z0(gdf)):
        raise ValueError(
            "Only elevation, landcover, and roughness maps can be written to file."
        )

    if _is_lc(gdf):
        if lctable is None:
            raise ValueError("'lctable' not specified for landcover map")
        if file_format == "map":
            gdf = _landcover_to_roughness(gdf, lctable=lctable)
            if any([v["d"] > 0 for _, v in lctable.items()]):
                raise ValueError(
                    "Cannot write displacement heights to .map file. Use the .gpkg or .gml extension instead!"
                )

    if file_format == "map":
        return _vector_map_to_mapfile(gdf, filename, **kwargs)
    elif file_format == "gml":
        return _vector_map_to_gmlfile(gdf, filename, lctable=lctable, **kwargs)
    elif file_format == "gpkg":
        return _vector_map_to_gpdfile(gdf, filename, lctable=lctable, **kwargs)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")


def create_vector_map(
    bbox, map_type="elevation", elevation=0.0, roughness_change=(0.0, 0.0)
):
    """
    Create a square elevation or roughness map within the specified bounding box.

    Parameters
    ----------
    bbox : wk.spatial.BBox
        Bounding box to use for setting the boundary.
    map_type : str
        One of "elevation" or "roughness" to specify the type of map to create. Defaults
        to "elevation".
    elevation : float
        Elevation to set the line to if it is an elevation map. Defaults to 0.0.
    roughness_change : tuple of 2 floats
        Roughness values for the line describing what is inside (first element) and outside the line (second element). Defaults to (0.0,0.0).

    Returns
    -------
    vector_map: geopandas.GeoDataFrame
        Flat vector_map
    """
    minx, miny, maxx, maxy = bbox.bounds()

    z0_left, z0_right = roughness_change

    data = defaultdict(list)

    if map_type == "elevation":
        data[VECTORMAP_ELEV_COL].append(elevation)
    elif map_type in ["roughness", "landcover"]:
        data[VECTORMAP_ROUL_COL].append(z0_left)
        data[VECTORMAP_ROUR_COL].append(z0_right)

    geometry = LineString(
        [
            (minx, miny),
            (maxx, miny),
            (maxx, maxy),
            (minx, maxy),
            (minx, miny),
        ]
    )

    data["geometry"].append(geometry)
    gdf = gpd.GeoDataFrame(data, geometry="geometry", crs=bbox.crs)

    if map_type in ["elevation", "roughness"]:
        return gdf
    elif map_type in ["landcover"]:
        return _roughness_to_landcover(gdf)
    else:
        raise ValueError(f"Unsupported map type: {map_type}")


def _split_combo_parser():
    """
    Parser for the split_combo command line tool
    """
    p = argparse.ArgumentParser(
        description="Split a combo mapfile into elevation and roughness GML files."
    )
    p.add_argument("inputfile", help="File to split")
    p.add_argument(
        "crs", help="Projection of the map, can be an epsg code, proj4 string, or wkt"
    )

    return p


def _split_combo():
    """
    Split a combo mapfile into elevation and roughness files.

    The roughness and elevation files have the same name as the
    input file, but with _elev or _rou added at the end.
    """
    p = _split_combo_parser()
    args = p.parse_args()

    inputfile = args.inputfile
    try:
        crs = int(args.crs)
    except ValueError:
        crs = args.crs

    # Roughness
    lc_map, lc_table = _read_vector_map(
        inputfile, crs, map_type="roughness", convert_to_landcover=True, polygons=False
    )
    _vector_map_to_file(lc_map, inputfile[:-4] + "_landcover.gpkg", lc_table)

    # Elevation
    elev = _read_vector_map(inputfile, crs, map_type="elevation")
    _vector_map_to_file(elev, inputfile[:-4] + "_elevation.gpkg")


def _crs_from_map_file(filename):
    """
    Gets crs/epsg from .map file

    Parameters
    ----------
    filename : pathlib.Path or str
        Path to .map file

    Returns
    -------
    crs: int
        Integer representing EPSG zone
    """
    from windkit.io.wasp.map import _epsg_from_map_file

    if Path(filename).suffix == ".gml":
        gdf = gpd.read_file(filename, driver="GML", layer="ChangeLine")
        return gdf.crs.to_epsg()

    # Only the first line: a .wwh stores Surfer grids under the same .tmp
    # extension as its vector maps, and those must yield None, not raise.
    return _epsg_from_map_file(filename)


@lru_cache(maxsize=1)
def _epsg_candidates():
    """Return the codes the WAsP map editor names, each with its CRS.

    Built once, because constructing a CRS from its code is what makes the
    equivalence scan in :func:`_epsg_from_crs` slow; comparing two is cheap.

    Returns
    -------
    tuple of (int, pyproj.crs.CRS)
    """
    from windkit.io.wasp.map import _epsg_codes

    return tuple((code, pyproj.CRS.from_epsg(code)) for code in _epsg_codes())


def _epsg_from_crs(crs):
    """
    Returns the EPSG code to record for this CRS, preferring one the WAsP map
    editor can name.

    Parameters
    ----------
    crs: pyproj.crs.CRS
        crs object to look up

    Returns
    -------
    epsg : int or None
        A code the map editor names, when one can be found. Otherwise the CRS's
        own EPSG code, which the map editor cannot name -- a truthy return does
        **not** mean the CRS is writable; ``_format_header`` decides that and
        warns. None means the CRS is None, or carries no EPSG code and matches
        no candidate.
    """
    from windkit.io.wasp.map import _epsg_codes

    if crs is None:
        return None

    # to_epsg() first: it is broader than crs_are_equal, which does not match a
    # proj4 UTM32 CRS against EPSG:32632 even though to_epsg() resolves it.
    epsg = crs.to_epsg()
    if epsg is not None and epsg in _epsg_codes():
        return epsg

    # Then match by equivalence, which decides for exactly one code: the
    # deprecated EPSG:29900. Spelled as ESRI WKT or proj4 it holds no EPSG
    # authority, so to_epsg() identifies it by its parameters and answers with
    # the non-deprecated EPSG:29902, which the table lacks.
    for candidate, candidate_crs in _epsg_candidates():
        if crs_are_equal(candidate_crs, crs):
            return candidate

    return epsg


def add_landcover_table(gdf, lctable):
    """
    Add a landcover table to a GeoDataFrame.

    This function adds a landcover table to a GeoDataFrame containing polygon geometries.
    It ensures that all IDs in the GeoDataFrame are present in the landcover table.

    Parameters
    ----------
    gdf : GeoDataFrame
        The GeoDataFrame to which the landcover table will be added. Must contain polygon geometries.
    lctable : dict
        A dictionary representing the landcover table. The keys should be IDs corresponding to the IDs in the GeoDataFrame.

    Returns
    -------
    GeoDataFrame
        The original GeoDataFrame with the landcover table joined on the 'id' column.

    Raises
    ------
    ValueError
        If the GeoDataFrame contains non-polygon geometries or if any IDs in the GeoDataFrame are not present in the landcover table.
    """
    if not _is_polygons(gdf):
        raise ValueError("Can only add a landcover table to a polygon map")

    df_lct = gpd.GeoDataFrame.from_dict(lctable).T.astype(
        {"z0": float, "d": float, "desc": str}
    )

    id_is_present = [i in df_lct.index for i in gdf["id"].unique()]
    if not all(id_is_present):
        ids_not_present = ",".join(
            gdf["id"].unique()[np.invert(id_is_present)].astype(str)
        )
        raise ValueError(f"id '{ids_not_present}' not present in the landcover table")

    return gdf.set_index("id").join(df_lct).reset_index(names="id")
