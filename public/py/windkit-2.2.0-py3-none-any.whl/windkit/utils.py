# (c) 2026 DTU Wind Energy
"""
Collection of utility functions.
"""

__all__ = []

import re
import shutil
import tempfile
import zipfile
from contextlib import contextmanager
from pathlib import Path

#: File names Windows reserves for devices, with any extension after them.
_WINDOWS_DEVICE_NAME = re.compile(r"CON|PRN|AUX|NUL|COM\d|LPT\d", re.IGNORECASE)


def _infer_file_format(
    filename,
):
    """
    Infer the file format from the filename or type of file object.

    Parameters
    ----------
    filename : str or pathlib.Path
        File path

    Returns
    -------
    str
        File format.
    """

    if isinstance(filename, zipfile.ZipExtFile):
        file_format = "ZipExtFile"
    else:
        file_format = Path(filename).suffix.lower()[1:]

    return file_format


@contextmanager
def _zip_member_on_disk(fobj):
    """
    Copy an open zip archive member to a temporary file.

    The copy keeps the member's suffix, so readers that take a path can infer
    the format from it, and its stem, for their error messages. Both are cut
    down to characters and a length that every file system accepts. Only the
    member is copied: sidecar files next to it in the archive, such as a
    ``.aux.xml``, are not.

    Parameters
    ----------
    fobj : zipfile.ZipExtFile
        Open archive member. It is read from the start and rewound afterwards,
        as pyogrio and rasterio do with a file object, so it can be read again.

    Yields
    ------
    pathlib.Path
        Path to the copy, which is deleted when the context exits.
    """
    name = Path(fobj.name)
    stem = re.sub(r"[^\w-]", "_", name.stem, flags=re.ASCII)[:100] or "member"
    if _WINDOWS_DEVICE_NAME.fullmatch(stem):
        stem += "_"
    suffix = re.sub(r"[^\w.]", "_", name.suffix, flags=re.ASCII)[:16]
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
        path = Path(tmp) / f"{stem}{suffix}"
        if fobj.seekable():
            fobj.seek(0)
        with open(path, "wb") as dst:
            shutil.copyfileobj(fobj, dst)
        if fobj.seekable():
            fobj.seek(0)
        yield path
