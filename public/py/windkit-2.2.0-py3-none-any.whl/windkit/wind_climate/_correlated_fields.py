# (c) 2026 DTU Wind Energy
"""Bounded sinusoids reproducing a reference set of cross-field correlations.

The synthetic surface-layer generators - :func:`windkit.create_tswc`'s
``fields`` argument and :func:`windkit.create_surface_fields` - share one
engine: every field is a bounded multi-harmonic sinusoid, and within a point
the fields carry the correlations measured in a mesoscale reference run. This
module holds that engine, so that both generators can use it without either
importing the other.
"""

import numpy as np

_DIURNAL = 24 * 60 * 60.0
_ANNUAL = 365.25 * _DIURNAL
_PERIODS = (_DIURNAL, _ANNUAL)

# Cross-field correlations of the onshore (Cabauw) WRF reference time series
# over 2010-2018, at 30 min resolution. An onshore reference is used because
# its stability spans further into both the stable and the unstable range than
# an offshore one does; everything these generators produce is therefore a
# land surface. ZNT is absent from the reference, so it is left uncorrelated
# with the rest. The signs of the ``temp_scale`` row and column follow the
# convention in which T* carries the sign of the surface heat flux, so that
# T* > 0 is unstable and T* < 0 stable
# (https://doi.org/10.1007/s10546-023-00803-3).
_CORR_FIELDS = (
    "wind_speed", "PSFC", "T2", "UST", "HFX", "LH",
    "PBLH", "Q2", "temp_scale", "ustar_over_pblh", "ZNT",
)  # fmt: skip
_TARGET_CORR = np.array([
    (1.00, -0.32, -0.13, 0.61, -0.41, -0.16, 0.03, -0.12, -0.31, 0.03, 0.0),
    (-0.32, 1.00, -0.04, -0.26, 0.16, 0.02, -0.10, -0.09, 0.05, 0.09, 0.0),
    (-0.13, -0.04, 1.00, 0.28, 0.40, 0.62, 0.51, 0.90, 0.45, -0.28, 0.0),
    (0.61, -0.26, 0.28, 1.00, 0.30, 0.53, 0.62, 0.11, 0.51, -0.28, 0.0),
    (-0.41, 0.16, 0.40, 0.30, 1.00, 0.79, 0.54, 0.18, 0.83, -0.26, 0.0),
    (-0.16, 0.02, 0.62, 0.53, 0.79, 1.00, 0.77, 0.35, 0.77, -0.36, 0.0),
    (0.03, -0.10, 0.51, 0.62, 0.54, 0.77, 1.00, 0.22, 0.64, -0.61, 0.0),
    (-0.12, -0.09, 0.90, 0.11, 0.18, 0.35, 0.22, 1.00, 0.25, -0.15, 0.0),
    (-0.31, 0.05, 0.45, 0.51, 0.83, 0.77, 0.64, 0.25, 1.00, -0.35, 0.0),
    (0.03, 0.09, -0.28, -0.28, -0.26, -0.36, -0.61, -0.15, -0.35, 1.00, 0.0),
    (0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 1.0),
])  # fmt: skip


def _point_sinusoid(
    time_seconds,
    n_points,
    low,
    high,
    rng,
    periods=_PERIODS,
    amplitude_fraction=(0.35, 1.0),
):
    """Bounded sinusoid with per-point amplitude and phase.

    The returned values never leave ``[low, high]``: each point's harmonic
    amplitudes are drawn so that they sum to at most half the range.

    Parameters
    ----------
    time_seconds : array_like
        Time coordinate in seconds, shape ``(n_timesteps,)``.
    n_points : int
        Number of spatial points.
    low, high : float
        Bounds of the generated values.
    rng : numpy.random.Generator
        Random generator supplying the per-point amplitudes and phases.
    periods : tuple of float
        Harmonic periods in seconds. Defaults to a diurnal and an annual cycle.
    amplitude_fraction : tuple of float
        Range of the per-point total amplitude, as a fraction of half the
        ``high - low`` range. Defaults to ``(0.35, 1.0)``.

    Returns
    -------
    values : numpy.ndarray
        Array of shape ``(n_timesteps, n_points)``.
    """
    mid = 0.5 * (high + low)
    half = 0.5 * (high - low)
    periods = np.asarray(periods, dtype=float)
    n_harmonics = len(periods)

    # Per-point share of the available amplitude, split over the harmonics.
    total = rng.uniform(*amplitude_fraction, n_points)
    weights = rng.dirichlet(np.ones(n_harmonics), n_points)
    amplitude = half * total[:, np.newaxis] * weights
    phase = rng.uniform(0.0, 2 * np.pi, (n_points, n_harmonics))

    angle = (
        2
        * np.pi
        * np.asarray(time_seconds, dtype=float)[:, np.newaxis, np.newaxis]
        / periods
        + phase[np.newaxis, :, :]
    )
    return mid + (amplitude[np.newaxis, :, :] * np.sin(angle)).sum(axis=-1)


def _correlated_fields(ranges, time_seconds, n_points, rng, driver):
    """Bounded sinusoids reproducing the reference cross-field correlations.

    Every field in ``ranges`` (a mapping of name to ``(low, high)`` bounds) is
    a linear combination of latent series weighted by the Cholesky factor of
    :data:`_TARGET_CORR`, so that within a point the correlation between any
    two fields matches the WRF reference. Whitening the latents per point
    first makes that match exact; the three synoptic harmonics each latent
    carries on top of the shared diurnal and annual cycle keep them linearly
    independent enough to whiten. ``driver``, the wind speed from
    :func:`create_tswc`, is the first latent, so the fields correlate with the
    generated wind speed too.

    Returns
    -------
    fields : dict
        Mapping of field name to an array of shape ``(n_timesteps, n_points)``.

    Raises
    ------
    ValueError
        If a field has no entry in :data:`_TARGET_CORR`, or if the time series
        holds too few steps or spans too short a time to whiten the latents.
    """
    order = ["wind_speed"] + list(ranges)
    unknown = [n for n in order if n not in _CORR_FIELDS]
    if unknown:
        raise ValueError(
            f"No reference correlations for {sorted(unknown)}. Fields must be "
            f"one of {sorted(_CORR_FIELDS)}."
        )
    n_timesteps = len(time_seconds)
    if n_timesteps <= len(order):
        raise ValueError(
            f"{n_timesteps} time steps are too few to generate {len(order)} "
            f"correlated fields; more than {len(order)} are required."
        )
    span_days = (time_seconds[-1] - time_seconds[0]) / _DIURNAL
    if span_days <= 2.0:
        # Over a shorter span the diurnal and annual harmonics are close to
        # affine in time, so the centred latents are near-collinear and the
        # Cholesky below fails for some seeds and succeeds for others.
        raise ValueError(
            f"A time span of {span_days:.2f} days is too short to generate "
            f"{len(order)} correlated fields; over a span this short the "
            "harmonics of the latent series are nearly collinear and cannot be "
            "whitened. More than 2 days are required."
        )
    if not np.isfinite(driver).all():
        # An internal invariant: both callers branch on not_empty before they
        # reach the engine, so a non-finite driver means a bug, not bad input.
        raise ValueError(
            "The wind speed driving the correlated fields contains non-finite "
            "values; correlated fields need a filled wind time series."
        )
    idx = [_CORR_FIELDS.index(n) for n in order]
    latent = np.stack([driver] + [
        _point_sinusoid(
            time_seconds, n_points, -1.0, 1.0, rng,
            periods=(_DIURNAL, _ANNUAL, *(rng.uniform(2.0, 10.0, 3) * _DIURNAL)),
        )
        for _ in order[1:]
    ])  # fmt: skip
    latent -= latent.mean(axis=1, keepdims=True)
    cov = np.einsum("itp,jtp->pij", latent, latent) / latent.shape[1]
    whiten = np.linalg.inv(np.linalg.cholesky(cov))
    combined = np.einsum(
        "ij,jtp->itp",
        np.linalg.cholesky(_TARGET_CORR[np.ix_(idx, idx)]),
        np.einsum("pij,jtp->itp", whiten, latent),
    )

    fields = {}
    for i, (name, (low, high)) in enumerate(ranges.items(), start=1):
        # Scaling by the peak puts the extremes on the bounds; the slack keeps
        # rounding from pushing them a floating point step outside.
        y = combined[i] / (np.abs(combined[i]).max(0) * (1.0 + 1e-9))
        fields[name] = 0.5 * (high + low) + 0.5 * (high - low) * y
    return fields


def _column_of(west_east, south_north):
    """Return the column index of every location, ordered by sorted coordinate.

    Two locations share a column when their horizontal coordinates are
    exactly equal, which holds for every structure windkit builds. The
    ordering comes from ``np.unique``, so it depends only on the set of
    distinct coordinate pairs and not on the order they arrive in: an index
    built over a full point axis and one built over the horizontal axis alone
    number the same columns the same way.

    Parameters
    ----------
    west_east, south_north : array_like
        Coordinates of every location, shape ``(n_locations,)``.

    Returns
    -------
    numpy.ndarray
        Column index of every location, shape ``(n_locations,)``.
    """
    columns = np.stack([np.asarray(west_east), np.asarray(south_north)], axis=-1)
    _, column_of = np.unique(columns, axis=0, return_inverse=True)
    return np.reshape(column_of, -1)


def _column_index(west_east, south_north, height):
    """Map every point onto the horizontal column it stands in.

    Everything this module generates is a surface quantity, and a surface
    quantity has no vertical variation: the variables declare
    ``height_dim_policy: "forbidden"`` and are drawn once per
    ``(west_east, south_north)`` column, then repeated over the heights above
    it, so that the height dimension collapses losslessly when the result is
    unstacked. A column is identified by exact equality of its two
    coordinates, which holds for every structure windkit builds.

    Parameters
    ----------
    west_east, south_north, height : array_like
        Coordinates of every point, shape ``(n_points,)``.

    Returns
    -------
    column_of_point : numpy.ndarray
        Column index of every point, shape ``(n_points,)``.
    base_of_column : numpy.ndarray
        Index of the lowest point of every column, shape ``(n_columns,)``. It
        is the point whose wind speed drives the column's surface variables,
        being the closest one to the surface they describe.
    """
    column_of_point = _column_of(west_east, south_north)
    by_height = np.lexsort((np.asarray(height), column_of_point))
    base_of_column = by_height[
        np.searchsorted(
            column_of_point[by_height], np.arange(column_of_point.max() + 1)
        )
    ]
    return column_of_point, base_of_column


def _seconds_since_start(time_values):
    """Return the time coordinate as seconds elapsed since its first value."""
    return (time_values - time_values[0]).total_seconds().to_numpy()


# Bounds of the stability variables create_tswc can add, the 0.1st to 99.9th
# percentile of the same Cabauw reference. The boundary layer scale is bounded
# as the ratio z_i/u_* in seconds, which is the form with an intuitive range,
# and the bounds are inverted here so that the generated field is u_*/z_i, in
# the form the consumers expect.
_STABILITY_FIELD_RANGES = {
    "temp_scale": (-0.18, 0.13),
    "ustar_over_pblh": (1.0 / 33000.0, 1.0 / 180.0),
}


def _stability_field_ranges(fields):
    """Resolve :func:`windkit.create_tswc`'s ``fields`` argument into bounds.

    Parameters
    ----------
    fields : str, sequence of str or None
        ``None`` for no stability fields, ``"stability"`` or ``"all"`` for
        every one of them, or the names to generate.

    Returns
    -------
    ranges : dict
        Mapping of field name to ``(low, high)`` bounds, in the canonical
        order of :data:`_STABILITY_FIELD_RANGES` so that the generated values
        do not depend on the order the caller listed the fields in.

    Raises
    ------
    ValueError
        If a name is not one of the stability fields.
    """
    if fields is None:
        return {}
    if isinstance(fields, str):
        if fields in ("stability", "all"):
            return dict(_STABILITY_FIELD_RANGES)
        fields = [fields]
    unknown = sorted(set(fields) - set(_STABILITY_FIELD_RANGES))
    if unknown:
        raise ValueError(
            f"Unknown field(s) {unknown}, cannot add to result. 'fields' must be "
            f"'stability', 'all', or a subset of {sorted(_STABILITY_FIELD_RANGES)}."
        )
    return {k: v for k, v in _STABILITY_FIELD_RANGES.items() if k in set(fields)}
