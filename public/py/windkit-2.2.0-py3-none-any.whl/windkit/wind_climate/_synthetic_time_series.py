# (c) 2026 DTU Wind Energy
"""Core generation logic for realistic synthetic wind time series.

Uses AR(1) processes in Gaussian/circular space with Weibull transform
for speed and von Mises innovations for direction. Supports spatial
correlation across multiple points and generation of correlated
measurement + reference pairs.
"""

import warnings

import numpy as np
from scipy.linalg import cholesky
from scipy.ndimage import gaussian_filter1d
from scipy.signal import lfilter
from scipy.special import ndtr


def _spatial_correlation_cholesky(west_east, south_north, correlation_length):
    """Compute Cholesky factor of an exponential spatial correlation matrix.

    Parameters
    ----------
    west_east : array_like
        Easting coordinates of points.
    south_north : array_like
        Northing coordinates of points.
    correlation_length : float
        Spatial e-folding length scale [same unit as coordinates].

    Returns
    -------
    chol_L : numpy.ndarray
        Lower-triangular Cholesky factor, shape ``(n_points, n_points)``.
    """
    we = np.asarray(west_east, dtype=np.float64)
    sn = np.asarray(south_north, dtype=np.float64)

    n_points = len(we)
    if n_points == 1:
        return np.array([[1.0]])

    coords = np.column_stack([we, sn])
    diff = coords[:, np.newaxis, :] - coords[np.newaxis, :, :]
    dist = np.sqrt((diff**2).sum(axis=-1))

    C = np.exp(-dist / correlation_length)
    C += 1e-10 * np.eye(n_points)

    return cholesky(C, lower=True)


def _generate_latent_speed(n_timesteps, n_points, dt, speed_tau, chol_L, rng):
    """Generate spatially correlated AR(1) latent process for wind speed.

    Parameters
    ----------
    n_timesteps : int
        Number of time steps.
    n_points : int
        Number of spatial points.
    dt : float
        Time step in seconds.
    speed_tau : float
        Autocorrelation e-folding timescale [s].
    chol_L : numpy.ndarray
        Cholesky factor of spatial correlation matrix, shape ``(n_points, n_points)``.
    rng : numpy.random.Generator
        Random number generator.

    Returns
    -------
    z_latent : numpy.ndarray
        Latent Gaussian process, shape ``(n_timesteps, n_points)``.
    """
    alpha = np.exp(-dt / speed_tau)
    sigma = np.sqrt(1.0 - alpha**2)

    # Batch all random draws and spatially correlate in one matrix multiply
    raw = rng.standard_normal((n_points, n_timesteps))
    correlated = chol_L @ raw  # (n_points, n_timesteps)

    # Build lfilter input: first timestep is initial draw, rest scaled by sigma
    inp = correlated.copy()
    inp[:, 1:] *= sigma

    # AR(1) via lfilter: y[t] = x[t] + alpha * y[t-1], entirely in C
    z_rows = lfilter([1.0], [1.0, -alpha], inp, axis=1)

    return z_rows.T  # (n_timesteps, n_points)


def _latent_to_weibull(z_latent, weibull_A, weibull_k):
    """Transform latent Gaussian values to Weibull-distributed wind speeds.

    Uses probability integral transform: Gaussian CDF -> Weibull inverse CDF.

    Parameters
    ----------
    z_latent : numpy.ndarray
        Latent Gaussian values.
    weibull_A : float
        Weibull scale parameter [m/s].
    weibull_k : float
        Weibull shape parameter.

    Returns
    -------
    speed : numpy.ndarray
        Wind speeds with Weibull distribution.
    """
    u = np.clip(ndtr(z_latent), 1e-10, 1.0 - 1e-10)
    return weibull_A * (-np.log(1.0 - u)) ** (1.0 / weibull_k)


def _generate_latent_direction(
    n_timesteps,
    n_points,
    dt,
    direction_mean,
    direction_kappa,
    direction_tau,
    chol_L,
    rng,
):
    """Generate spatially correlated circular AR(1) wind direction process.

    Parameters
    ----------
    n_timesteps : int
        Number of time steps.
    n_points : int
        Number of spatial points.
    dt : float
        Time step in seconds.
    direction_mean : float
        Prevailing wind direction [degrees].
    direction_kappa : float
        Von Mises concentration parameter.
    direction_tau : float
        Autocorrelation timescale for direction [s].
    chol_L : numpy.ndarray
        Cholesky factor of spatial correlation matrix.
    rng : numpy.random.Generator
        Random number generator.

    Returns
    -------
    theta : numpy.ndarray
        Wind directions in radians, shape ``(n_timesteps, n_points)``.
    """
    alpha = np.exp(-dt / direction_tau)
    sigma_dir = np.sqrt(1.0 - alpha**2)
    mean_rad = np.deg2rad(direction_mean)

    # Batch all von Mises draws and spatially correlate in one matrix multiply
    all_innovations = rng.vonmises(0.0, direction_kappa, size=(n_points, n_timesteps))
    correlated_innovations = chol_L @ all_innovations  # (n_points, n_timesteps)

    theta = np.empty((n_timesteps, n_points))
    theta[0] = rng.vonmises(mean_rad, direction_kappa, size=n_points)

    # Loop is required due to nonlinear arctan2 wrapping
    for t in range(1, n_timesteps):
        dev = np.arctan2(
            np.sin(theta[t - 1] - mean_rad),
            np.cos(theta[t - 1] - mean_rad),
        )
        theta[t] = mean_rad + alpha * dev + sigma_dir * correlated_innovations[:, t]

    return theta


def _generate_reference(
    z_meas,
    theta_meas,
    ref_A,
    ref_k,
    target_r2,
    smooth_sigma,
    ref_direction_bias,
    ref_direction_noise_std,
    dt,
    speed_tau,
    rng,
):
    """Generate reference (reanalysis-like) wind data from measurement latents.

    Smooths the measurement latent process and mixes with temporally
    correlated AR(1) noise to achieve a target correlation, then transforms
    to Weibull-distributed speeds with different parameters (bias).

    Parameters
    ----------
    z_meas : numpy.ndarray
        Measurement latent Gaussian process, shape ``(n_timesteps, n_points)``.
    theta_meas : numpy.ndarray
        Measurement direction in radians, shape ``(n_timesteps, n_points)``.
    ref_A : float
        Reference Weibull scale parameter [m/s].
    ref_k : float
        Reference Weibull shape parameter.
    target_r2 : float
        Target Pearson r-squared between measurement and reference speeds.
    smooth_sigma : float
        Gaussian filter width in time steps for latent smoothing.
    ref_direction_bias : float
        Constant directional bias for reference [degrees].
    ref_direction_noise_std : float
        Std of Gaussian angular noise added to reference direction [degrees].
    dt : float
        Time step in seconds.
    speed_tau : float
        Autocorrelation e-folding timescale for speed [s].
    rng : numpy.random.Generator
        Random number generator.

    Returns
    -------
    ref_speed : numpy.ndarray
        Reference wind speeds, shape ``(n_timesteps, n_points)``.
    ref_direction : numpy.ndarray
        Reference wind directions in degrees [0, 360), shape ``(n_timesteps, n_points)``.
    """
    n_timesteps, n_points = z_meas.shape

    # AR(1) parameters — noise must have the same temporal correlation as the
    # measurement latent so the reference series is equally smooth.
    alpha = np.exp(-dt / speed_tau)
    sigma_ar = np.sqrt(1.0 - alpha**2)

    # Vectorized smoothing and normalization across all points
    z_synoptic = gaussian_filter1d(z_meas, sigma=smooth_sigma, axis=0, mode="nearest")
    z_synoptic = (z_synoptic - z_synoptic.mean(axis=0)) / z_synoptic.std(axis=0)

    # Pre-compute measurement speeds for all points
    meas_speed = _latent_to_weibull(z_meas, ref_A, ref_k)

    target_r = np.sqrt(np.clip(target_r2, 0.0, 0.999))

    ref_speeds = np.empty_like(z_meas)
    for p in range(n_points):
        # Generate AR(1) noise instead of white noise so the reference
        # series inherits the same temporal autocorrelation structure.
        raw = rng.standard_normal(n_timesteps)
        inp = raw.copy()
        inp[1:] *= sigma_ar
        eps = lfilter([1.0], [1.0, -alpha], inp)
        rho = min(target_r * 1.05, 0.999)

        ref_spd_trial = None
        for _ in range(20):
            z_ref = rho * z_synoptic[:, p] + np.sqrt(1.0 - rho**2) * eps
            z_ref = (z_ref - z_ref.mean()) / z_ref.std()

            ref_spd_trial = _latent_to_weibull(z_ref, ref_A, ref_k)
            r_actual = np.corrcoef(meas_speed[:, p], ref_spd_trial)[0, 1]

            if abs(r_actual**2 - target_r2) < 0.003:
                break
            rho = np.clip(rho * (target_r / max(r_actual, 0.01)), 0.01, 0.999)
        else:
            warnings.warn(
                f"Reference r² iteration did not converge for point {p}. "
                f"Achieved r²={r_actual**2:.4f}, target={target_r2:.4f}.",
                stacklevel=2,
            )

        ref_speeds[:, p] = ref_spd_trial

    noise_rad = np.deg2rad(ref_direction_noise_std) * rng.standard_normal(
        (n_timesteps, n_points)
    )
    # Vectorized smoothing across all points at once
    noise_rad = gaussian_filter1d(noise_rad, sigma=smooth_sigma, axis=0, mode="nearest")
    ref_theta = theta_meas + np.deg2rad(ref_direction_bias) + noise_rad
    ref_direction = np.rad2deg(ref_theta) % 360.0

    return ref_speeds, ref_direction
