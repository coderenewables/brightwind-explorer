# (c) 2026 DTU Wind Energy
"""Validation checks shared across wind climate types."""

import numpy as np


def _validate_freq_sums_to_one(ds, var, dim):
    """Check that ``var`` sums to 1 across ``dim``.

    Parameters
    ----------
    ds : xarray.Dataset
        Wind climate dataset.
    var : str
        Name of the frequency variable to check, e.g. 'wdfreq'.
    dim : str or tuple of str
        Dimension(s) that must sum to 1, e.g. 'sector' or ('sector', 'wsbin').

    Returns
    -------
    list of str
        Error message naming the offending locations and sums found, or an
        empty list if ``var`` sums to 1 everywhere.
    """
    dims = (dim,) if isinstance(dim, str) else tuple(dim)
    if var not in ds.data_vars or not set(dims) <= set(ds[var].dims):
        return []

    # Only a fully empty location is exempt, as an intentional placeholder;
    # a partially-NaN one sums to NaN (skipna=False) and is flagged.
    all_nan = ds[var].isnull().all(dim=dims).values
    sum_s = ds[var].sum(dim=dims, skipna=False)
    bad = sum_s.copy(data=~np.isclose(sum_s.values, 1.0) & ~all_nan)
    if not bad.any():
        return []

    dim_desc = " and ".join(dims)
    loc_dims = sum_s.dims
    # Only coordinates that actually label a location: real dim coordinates
    # (e.g. west_east on a cuboid) and non-dim ones (e.g. west_east on a
    # point structure). A bare dim without a coordinate (e.g. 'point') has
    # nothing to look up and is skipped.
    loc_coords = [c for c in sum_s.coords if c != "crs"]
    # Index plain arrays rather than re-selecting the DataArray per site,
    # since most/all sites can be flagged at once.
    sums = sum_s.values
    coord_values = {c: sum_s.coords[c].values for c in loc_coords}
    coord_dim_pos = {
        c: tuple(loc_dims.index(d) for d in ds[var].coords[c].dims if d in loc_dims)
        for c in loc_coords
        if ds[var].coords[c].dims and any(d in loc_dims for d in ds[var].coords[c].dims)
    }
    bad_idx = np.argwhere(bad.values)

    max_listed = 10
    lines = []
    for idx in bad_idx[:max_listed]:
        coord_str = ", ".join(
            f"{c}={coord_values[c][tuple(idx[p] for p in coord_dim_pos[c])] if c in coord_dim_pos else coord_values[c]}"
            for c in loc_coords
        )
        lines.append(f"  {coord_str}: sum={sums[tuple(idx)]:.6g}")
    if len(bad_idx) > max_listed:
        lines.append(f"  ... and {len(bad_idx) - max_listed} more location(s)")

    msg = (
        f"The following sites do not have '{var}' summing to 1 across "
        f"{dim_desc}:\n" + "\n".join(lines)
    )
    if np.any(np.isclose(sums[bad.values], 100.0, rtol=0.1)):
        msg += "\n  (some sums are near 100 — frequencies may be in percent; divide by 100)"
    return [msg]


def _validate_wdfreq_sums_to_one(ds):
    """Check that 'wdfreq' sums to 1 across the 'sector' dimension.

    Parameters
    ----------
    ds : xarray.Dataset
        Wind climate dataset with a 'wdfreq' data variable.

    Returns
    -------
    list of str
        Error message naming the offending locations and sums found, or an
        empty list if 'wdfreq' sums to 1 everywhere.
    """
    return _validate_freq_sums_to_one(ds, "wdfreq", "sector")
