# (c) 2026 DTU Wind Energy
"""Binned wind climate module

When measuring the wind speed and wind direction over a time period, one can
create a histogram by counting the frequency of occurence for each
wind speed and direction bin.

Because there can be large differences in the wind climate when the wind is
coming from different wind directions, a binned wind distribution is usually
specified per wind direction sector.

A valid Binned wind climate therefore has a dimension ``sector`` and the variables
``wsbin`` and ``wdfreq``. Also it must have a valid spatial structure. This module contains
functions that operate on and create binned wind climates.
This includes the ability to create bwc datasets both from files and from
existing data, the ability to calculate common parameters from the bwc object,
and the ability to write them to the legacy *.tab* format.
"""

__all__ = [
    "validate_bwc",
    "is_bwc",
    "create_bwc",
    "read_bwc",
    "bwc_from_tswc",
    "bwc_to_file",
    "combine_bwcs",
    "weibull_fit",
]

import logging
import warnings
from functools import wraps
from pathlib import Path

import numpy as np
import pandas as pd
import pyproj
import xarray as xr
from windkit import weibull
from windkit.xarray_structures._schema import (
    Check,
    DataVar,
    DatasetSchema,
    make_is_valid,
    make_validator,
    validate,
    validate_input,
)
from windkit.xarray_structures.empty import (
    _copy_chunks,
    _native_batch,
    _native_frame,
    _native_store,
)
from windkit.xarray_structures.metadata import (
    _BWC_ATTRS,
    _HIS_ATTRS,
    _WEIB_ATTRS,
    _WSBIN_COORD_ATTRS,
    _update_history,
    _update_var_attrs,
)
from windkit.xarray_structures.sector import (
    create_sector_coords,
)
from windkit.xarray_structures.wsbin import (
    create_wsbin_coords,
)
from windkit.spatial import (
    create_dataset,
    get_crs,
    grid_convergence,
    is_point,
    reproject,
    to_point,
)
from windkit.utils import _infer_file_format
from windkit.wind import wd_to_sector
from windkit.wind_climate._validation import _validate_wdfreq_sums_to_one
from windkit.wind_climate.time_series_wind_climate import _TSWC_SCHEMA

logger = logging.getLogger(__name__)

SUPPORTED_BWC_FILE_FORMATS_READ = ["tab", "owc", "omwc", "nc", "yml", "yaml"]
SUPPORTED_BWC_FILE_FORMATS_WRITE = ["tab", "yml", "yaml"]

WS = "wind_speed"
WD = "wind_direction"
VAR_WS_FREQ = "ws_freq"
VAR_WD_FREQ = "wdfreq"
VAR_WS_FREQ_BY_SECTOR = "wsfreq"
DIM_TIME = "time"
DIM_WS = "wsbin"
DIM_WD = "sector"
WV_COUNT = "wv_count"


def _validate_freqs_greater_than_zero(wwc):
    """Helper function to validate wdfreq and wsfreq are positive"""
    response_list = []

    if "wsfreq" in wwc.data_vars and any(
        xr.where(wwc.wsfreq.values < 0.0, True, False).flatten()
    ):
        response_list.append("'wsfreq' has negative values")

    if "wdfreq" in wwc.data_vars and any(
        xr.where(wwc.wdfreq.values < 0.0, True, False).flatten()
    ):
        response_list.append("'wdfreq' has negative values")

    return response_list


_BWC_SCHEMA = DatasetSchema(
    name="bwc",
    data_vars={
        "wsfreq": DataVar(dims=("wsbin", "sector")),
        "wdfreq": DataVar(dims=("sector",)),
    },
    dims=("wsbin", "sector"),
    coords=("sector",),
    extra_checks=(
        Check(_validate_freqs_greater_than_zero),
        Check(_validate_wdfreq_sums_to_one),
    ),
)

validate_bwc = make_validator(_BWC_SCHEMA)

is_bwc = make_is_valid(_BWC_SCHEMA)


def _wv_count_wrapper(func):
    """
    Decorator to handle wind vector count format.

    Handles the case where the parameter is an xarray.DataArray with a wv_count
    format or a xarray.Dataset with a 'wv_count' data variable, i.e. has wind
    counts by bin and sector. If so, returns a binned wind climate xarray.Dataset.
    If it is not the case, it does nothing.
    """

    @wraps(func)
    def wv_count_to_bwc(*args, **kwargs):
        obj = args[0]
        try:
            # handles the case of a xarray.Dataset
            obj = obj["wv_count"]
        except KeyError:
            pass
        if isinstance(obj, xr.DataArray) and obj.name == "wv_count":
            bwc = _bwc_from_counts(obj)
            result = func(bwc, *args[1:], **kwargs)
        else:
            result = func(*args, **kwargs)
        return result

    return wv_count_to_bwc


def _freqs_to_dataset(
    wsfreq,
    wdfreq,
    wsbins,
    south_north,
    west_east,
    height,
    crs,
    **kwargs,
):
    """
    Makes data variables, coordinates, and attributes ready for
    xarray.Dataset construction from a histogram of wind speeds and directions

    Parameters
    ----------
    wsfreq: np.array([n_wsbins, n_sectors]): float64
        Wind speed frequency by wind speed and sector
    wdfreq: np.array([n_sectors]): float64
        Wind direction frequency by sector
    wsbins: np.array([n_wsbins + 1]): float64
        Edges of wind speed bins
    south_north: float64
        Coordinate value in y-direction
    west_east: float64
        Coordinate value in x-direction
    height: float64
        Height above ground
    crs : int, dict, str or pyproj.crs.CRS
            Value to initialize `pyproj.crs.CRS`
    kwargs : dict
        Other kwargs are added as attributes to the dataset

    Returns
    -------
    xarray.Dataset
    """

    wsbins = np.asarray(wsbins, dtype=np.float64)

    _, n_sectors = wsfreq.shape

    wscenters = create_wsbin_coords(wsbins)
    wdcenters = create_sector_coords(n_sectors)

    na = np.newaxis

    wdfreq /= np.sum(wdfreq)
    with np.errstate(all="ignore"):
        wsfreq = wsfreq / np.sum(wsfreq, axis=0)[na, :]
    if np.isnan(wsfreq).any():
        logging.debug(
            "There are sectors with no wind observations (nan), which will be set to 0.0."
        )
        wsfreq = np.nan_to_num(wsfreq)

    # Build dataset
    ds = create_dataset(west_east, south_north, height, crs).drop_vars("output")
    ds["wdfreq"] = (("sector", "point"), wdfreq[:, na])
    ds["wsfreq"] = (("wsbin", "sector", "point"), wsfreq[:, :, na])

    ds = ds.assign_coords(
        {
            **wscenters.coords,
            **wdcenters.coords,
        }
    )

    ds = ds.assign_attrs(kwargs)

    ds = _update_var_attrs(ds, _BWC_ATTRS)
    return _update_history(ds)


def _assign_wind_dir_crs(bwc, wind_dir_crs):
    """Assign a wind-direction CRS to a BWC.

    Parameters
    ----------
    bwc : xarray.Dataset
        Binned wind climate dataset to update.
    wind_dir_crs : CRS-like or None
        CRS that defines the wind-direction frame. A projected CRS denotes a
        grid-north frame and a geographic CRS denotes a true-north frame. If
        ``None``, the dataset is returned unchanged.

    Returns
    -------
    xarray.Dataset
        The input BWC with ``wind_dir_crs`` stored in its attributes.

    Raises
    ------
    ValueError
        If ``wind_dir_crs`` conflicts with existing BWC metadata.
    """
    if wind_dir_crs is None:
        return bwc
    crs = pyproj.CRS.from_user_input(wind_dir_crs)
    existing = bwc.attrs.get("wind_dir_crs")
    if existing is not None and pyproj.CRS.from_user_input(existing) != crs:
        raise ValueError("wind_dir_crs conflicts with the BWC metadata")
    bwc.attrs["wind_dir_crs"] = crs.to_wkt()
    return bwc


# A distribution whose scale is too large for the wind speed axis gets cut off on
# its own slope. Normalising over `wsbin` afterwards hides that - the result still
# sums to 1 per sector - so the caller is warned instead.
# Two per cent beyond the final bin is comfortably above what the default axis
# gives and below the cases that actually break downstream code. Warning rather
# than rescaling the Weibull keeps the generated wind speeds physical - tying the
# scale to the axis, as the geostrophic generator does, would make a long axis
# produce surface winds nobody measures.
_MAX_TRUNCATED_FRACTION = 2e-2

# Surface wind: a scale of 5-10 m/s and a shape near 2 describe most sites.
_DEFAULT_A_RANGE = (5.0, 10.0)
_DEFAULT_K_RANGE = (1.5, 2.5)


def _weibull_param(value, default_range, n_sectors, n_pt, rng):
    """Resolve a Weibull parameter to a ``(n_sectors, n_pt)`` array.

    ``None`` draws from ``default_range``, a pair draws from that range, and a
    scalar pins every point and sector to it.
    """
    if value is None:
        value = default_range
    if np.ndim(value) == 1:
        return rng.uniform(*value, [n_sectors, n_pt])
    return np.full([n_sectors, n_pt], float(value))


def _weibull_over_bins(wsbin_coords, k, A, n_sectors, n_pt, what="wsfreq"):
    """Weibull density evaluated at the wind speed bin centres.

    The density has to be sampled at the bin centres it is assigned to. Sampling
    at the bin *indices* instead shifts the histogram half a bin, which biases the
    mean wind speed of the generated climate below the one its own ``A`` and ``k``
    imply.
    """
    import scipy.stats  # lazy: importing it eagerly slows every `import windkit`

    centres = wsbin_coords.values
    wsbin_full = np.broadcast_to(
        centres[:, np.newaxis, np.newaxis], (len(centres), n_sectors, n_pt)
    )
    density = scipy.stats.weibull_min.pdf(wsbin_full, k, scale=A)
    density_sum = density.sum(0)
    if not np.all(np.isfinite(density_sum) & (density_sum > 0)):
        raise ValueError(
            "The generated Weibull distribution has no finite, positive density "
            "within the wind speed bins. Increase weibull_A or use narrower wind "
            "speed bins."
        )
    freq = density / density_sum

    upper_edge = wsbin_coords["wsceil"].isel(wsbin=-1).item()
    tail = scipy.stats.weibull_min.sf(upper_edge, k, scale=A).max()
    if tail > _MAX_TRUNCATED_FRACTION:
        warnings.warn(
            f"The wind speed axis is too short for the generated distribution: "
            f"{tail:.1%} of {what} lies above the final bin, so the distribution "
            f"is truncated by the axis. Increase n_wsbins, or pass a smaller "
            f"weibull_A.",
            UserWarning,
            stacklevel=3,
        )
    return freq


def create_bwc(
    output_locs,
    n_sectors=12,
    n_wsbins=30,
    not_empty=True,
    seed=9876538,
    wind_dir_crs=None,
    wsbin_width=1.0,
    weibull_A=None,
    weibull_k=None,
):
    """
    Create empty binned wind climate dataset.

    If not_empty=True, the data variables are filled with meaninful random numbers,
    e.g. the sum of wdfreq is 1.

    Parameters
    ----------
    output_loc : xarray.Dataset
        Output geospatial information.
    n_sectors : int
        Number of sectors, defaults to 12.
    n_wsbins: int
        Number of histogram bins, defaults to 30.
    not_empty : bool
        If true, the empty dataset is filled with random
        meaningful data.
    seed : int
        Seed for the random data, defaults to 9876538.
    wind_dir_crs : CRS-like, optional
        CRS that defines the wind-direction frame. A projected CRS denotes
        grid north and a geographic CRS denotes true north.
    wsbin_width : float
        Width of each wind speed bin [m s-1], defaults to 1.0.
    weibull_A : float, tuple of float, or None
        Weibull scale parameter [m s-1]. A scalar pins it, a ``(low, high)`` pair
        draws it per point and sector, and None uses the default range
        ``(5, 10)``.
    weibull_k : float, tuple of float, or None
        Weibull shape parameter, resolved the same way. Defaults to the range
        ``(1.5, 2.5)``.

    Returns
    -------
    ds : xarray.Dataset
        Binned wind climate dataset either empty or filled with
        random numbers.

    Notes
    -----
    ``wsfreq`` and ``wdfreq`` are stored float32, C-contiguous, with
    ``(sector, wsbin)`` trailing the spatial batch dimensions — the reverse
    of ``weibull_fit_points``' declared ``wsfreq(nws, nwd, npoints)`` — so
    PyWAsP's compiled boundary can take a Fortran-ordered view instead of
    converting a copy (windkit#807). Neither the dtype nor the dimension
    order is a supported API contract: ``create_bwc`` is a test-data utility.
    """
    dims, shape = _native_batch(output_locs)
    n_pt = int(np.prod(shape, dtype=int))
    wsbin_coords = create_wsbin_coords(n_wsbins, width=wsbin_width)

    if not_empty:
        rng = np.random.default_rng(seed)
        k = _weibull_param(weibull_k, _DEFAULT_K_RANGE, n_sectors, n_pt, rng)
        A = _weibull_param(weibull_A, _DEFAULT_A_RANGE, n_sectors, n_pt, rng)
        wsbin_freq = _weibull_over_bins(wsbin_coords, k, A, n_sectors, n_pt, "wsfreq")
        wdfreq = rng.dirichlet(np.ones(n_sectors), n_pt).T
    else:
        wsbin_freq = np.full((n_wsbins, n_sectors, n_pt), np.nan)
        wdfreq = np.full((n_sectors, n_pt), np.nan)

    ds = _native_frame(output_locs).assign_coords(
        {**create_sector_coords(n_sectors).coords, **wsbin_coords.coords}
    )
    wsfreq_dims, wsfreq_array = _native_store(
        wsbin_freq, dims, shape, core_dims=("wsbin", "sector")
    )
    ds["wsfreq"] = xr.DataArray(
        wsfreq_array, dims=wsfreq_dims, attrs={"height_dim_policy": "optional"}
    )
    wdfreq_dims, wdfreq_array = _native_store(
        wdfreq, dims, shape, core_dims=("sector",)
    )
    ds["wdfreq"] = xr.DataArray(
        wdfreq_array, dims=wdfreq_dims, attrs={"height_dim_policy": "optional"}
    )

    ds = _update_var_attrs(_copy_chunks(output_locs, ds), _BWC_ATTRS)

    return _assign_wind_dir_crs(_update_history(ds), wind_dir_crs)


def _create_wv_count(
    output_locs, n_sectors=12, n_wsbins=30, not_empty=True, seed=9876538
):
    """
    Create empty wind vector count dataset.
    If not_empty=True, the data variables are filled with meaninful random numbers.

    Parameters
    ----------
    output_loc : xarray.Dataset
        Output geospatial information
    n_sectors : int
        Number of sectors, defaults to 12.
    not_empty : bool
        If true, the empty dataset is filled with random
        meaningful data, defaults to True.
    seed : int
        Seed for the random data, defaults to 9876538.

    Returns
    -------
    ds : xarray.Dataset
        Wind vector count dataset either empty or filled with
        random numbers.

    Notes
    -----
    ``wv_count`` shares ``wsfreq``'s shape family (windkit#807): float32,
    C-contiguous, with ``(sector, wsbin)`` trailing the spatial batch
    dimensions. Neither the dtype nor the dimension order is a supported API
    contract: ``_create_wv_count`` is a test-data utility.
    """
    dims, shape = _native_batch(output_locs)
    n_pt = int(np.prod(shape, dtype=int))
    wsbin_coords = create_wsbin_coords(n_wsbins, width=1.0)

    if not_empty:
        import scipy.stats

        rng = np.random.default_rng(seed)
        k = _weibull_param(None, _DEFAULT_K_RANGE, n_sectors, n_pt, rng)
        A = _weibull_param(None, _DEFAULT_A_RANGE, n_sectors, n_pt, rng)
        # Sampled at the bin centres the counts are assigned to, not at the bin
        # indices; the latter shifts the histogram half a bin.
        centres = wsbin_coords.values
        wsbin_full = np.broadcast_to(
            centres[:, np.newaxis, np.newaxis], (n_wsbins, n_sectors, n_pt)
        )
        scaling_fact = rng.uniform(500, 1000, [n_sectors, n_pt])
        wv_count_array = np.rint(
            np.multiply(
                scipy.stats.weibull_min.pdf(wsbin_full, k, scale=A),
                scaling_fact[np.newaxis, :, :],
            )
        )
    else:
        wv_count_array = np.full((n_wsbins, n_sectors, n_pt), np.nan)

    ds = _native_frame(output_locs).assign_coords(
        {**create_sector_coords(n_sectors).coords, **wsbin_coords.coords}
    )
    out_dims, array = _native_store(
        wv_count_array, dims, shape, core_dims=("wsbin", "sector")
    )
    ds["wv_count"] = xr.DataArray(
        array, dims=out_dims, attrs={"height_dim_policy": "optional"}
    )

    ds = _update_var_attrs(_copy_chunks(output_locs, ds), _HIS_ATTRS)

    return _update_history(ds)


def _read_windiofile(windiofile, crs=None, level="plant", **kwargs):
    """Read a windIO YAML file into a binned wind climate dataset.

    Parameters
    ----------
    windiofile : str or pathlib.Path
        Path to windIO YAML file.
    crs : int, dict, str or CRS
        Coordinate reference system. Required if not present in windIO file.
    level : str
        The windIO hierarchy level of the input file: 'plant', 'site',
        'energy_resource', or 'wind_resource'. Defaults to 'plant'.
    **kwargs
        Additional keyword arguments (unused, for API consistency).

    Returns
    -------
    xarray.Dataset
        Binned wind climate dataset.

    Raises
    ------
    ValueError
        If CRS is not provided and not present in windIO file.
    ValueError
        If level is not valid.
    """
    from windkit.io.windio.translate import bwc_from_windio
    from windkit.io.windio.utils import _read_windio_climate

    return _read_windio_climate(
        windiofile,
        bwc_from_windio,
        crs=crs,
        level=level,
    )


def read_bwc(filename, *, crs=None, file_format="infer", wind_dir_crs=None, **kwargs):
    """Creates binned wind climate xarray.Dataset from file.

    Parameters
    ----------
    filename : str or Path
        Path to a file that can be opened as a bwc. This includes .tab, .owc,
        .omwc, and .nc that were created as bwc files. The script will
        use the file extension to determine the file type and then parse it
        into a bwc DataSet object.
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`
        Defaults to 4326 (Lat-Lon/WGS84 geodetic datum) for .tab, .owc and .omwc files.
    file_format : str
        The file format of the input file. If 'infer', the file format will be inferred from the file extension.
        Supported formats are 'tab', 'owc', 'omwc', 'nc', 'yml', and 'yaml'. Defaults to 'infer'.
    wind_dir_crs : CRS-like, optional
        CRS that defines the wind-direction frame of the returned BWC. A
        projected CRS denotes grid north and a geographic CRS denotes true
        north.
    **kwargs : dict
        Additional arguments to be passed to the file reader.
        For windIO files, the 'level' argument can be specified to indicate the windIO hierarchy level.

    Returns
    -------
    ds : xarray.Dataset
        binned wind climate dataset that is formatted to match the bwc description.

    Raises
    ------
    ValueError
        If crs does not match dataset crs.
    ValueError
        If type of bwc is undetectable.
    """
    if file_format == "infer":
        file_format = _infer_file_format(filename)

    if file_format == "tab":
        if crs is None:
            crs = 4326
        bwc = _open_tabfile(filename, crs, **kwargs)
    elif file_format in ["owc", "omwc"]:
        if crs is None:
            crs = 4326
        bwc = _open_owcfile(str(filename), crs, **kwargs)
    elif file_format == "nc":
        bwc = xr.open_dataset(filename, **kwargs)
    elif file_format in ["yml", "yaml"]:
        bwc = _read_windiofile(filename, crs=crs, **kwargs)
    else:
        raise ValueError(
            f"Unable to detect type of bwc file {filename} with extension {file_format}"
        )
    validate(bwc, _BWC_SCHEMA, run_extra_checks=False)
    bwc = _update_var_attrs(bwc, _BWC_ATTRS)
    return _assign_wind_dir_crs(_update_history(bwc), wind_dir_crs)


def combine_bwcs(bwc_list):
    """Combines a list of bwc's into one binned wind climate.

    .. note:: The output is always an object with a point structure

    Parameters
    ----------
    bwc_list: list
        List of binned wind climate xarray.Dataset.

    Returns
    -------
    bwcs: xarray.Dataset
        xarray Dataset with merged binned wind climates.
    """
    first_sectors = bwc_list[0].coords["sector"].values
    for i, bwc in enumerate(bwc_list[1:], start=1):
        if not np.array_equal(bwc.coords["sector"].values, first_sectors):
            raise ValueError(
                f"combine_bwcs: bwc_list[{i}] has different sector coordinates "
                f"than bwc_list[0]. All BWCs must share the same sector grid."
            )

    max_bins = max([bwc.sizes["wsbin"] for bwc in bwc_list])
    filled_bwcs = []
    for bwc in bwc_list:
        if not is_point(bwc):
            bwc = to_point(bwc)
        filled_bwcs.append(_fill_wsbin(bwc, max_bins))

    bwcs = xr.concat(
        filled_bwcs, "point", data_vars="all", compat="equals", join="outer"
    )
    return _update_history(bwcs)


def _data_dict_to_dataset(data, crs):
    """Convert a wind climate data dict to a bwc xarray Dataset.

    Shared helper for _open_tabfile, _open_owcfile, and _parse_owc that
    unpacks the standard dict structure returned by read_tab, read_owc,
    and parse_owc_element into _freqs_to_dataset.

    Parameters
    ----------
    data : dict
        Dictionary with keys "wsfreq", "wdfreq", "wsbins", "coords", "metadata"
        as returned by the low-level I/O functions.
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`.

    Returns
    -------
    xr.Dataset
        Binned wind climate dataset.
    """
    return _freqs_to_dataset(
        data["wsfreq"],
        data["wdfreq"],
        data["wsbins"],
        south_north=data["coords"]["south_north"],
        west_east=data["coords"]["west_east"],
        height=data["coords"]["height"],
        description=data["metadata"]["description"],
        crs=crs,
    )


def _open_tabfile(tab_file, crs=4326, **kwargs):
    """Creates bwc object from a "tab" ascii file

    Parameters
    ----------
    tab_file: str
        Path to file tab file
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`
        Defaults to 4326 (Lat-Lon/WGS84 geodetic datum)

    Returns
    -------
    xr.DataSet
        xarray DataSet that is formatted to match the bwc description

    Raises
    ------
    ValueError
        If .tab file does not have appropriate string formatting
    """
    from windkit.io.wasp import read_tab

    return _data_dict_to_dataset(read_tab(tab_file, **kwargs), crs)


def _parse_owc(owc, crs=4326):
    """
    Parses an OWC element into a bwc dataset.

    Thin wrapper around :func:`windkit.io.wasp.parse_owc_element` that
    converts the raw dict into an xarray Dataset.

    Parameters
    ----------
    owc : lxml.etree._Element
        An XML element loaded by lxml
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`
        Defaults to 4326 (Lat-Lon/WGS84 geodetic datum)

    Returns
    -------
    xr.DataSet
        xarray DataSet that is formatted to match the bwc description
    """
    from windkit.io.wasp import parse_owc_element

    return _data_dict_to_dataset(parse_owc_element(owc), crs)


def _open_owcfile(xml_file, crs=4326):
    """Creates bwc object from a .owc xml file

    Parameters
    ----------
    xml_file : str or Path
        Path to xml file
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`
        Defaults to 4326 (Lat-Lon/WGS84 geodetic datum)

    Returns
    -------
    xr.DataSet
        xarray DataSet that is formatted to match the bwc description
    """
    from windkit.io.wasp import read_owc

    return _data_dict_to_dataset(read_owc(xml_file), crs)


def _count_to_wd_freq(wind_hist):
    """Convert wind vector count histogram to wind sector-wise relative frequency.

    Parameters
    ----------
    wind_hist : xarray.DataArray
        A valid pywasp wind-vector-count histogram DataArray


    Returns
    -------
    relfreq : xarray.DataArray
        Data array with sectorwise relative frequencies.
    """
    relfreq = wind_hist.sum(dim=[DIM_WS], skipna=False) / wind_hist.sum(
        dim=[DIM_WS] + [DIM_WD], skipna=False
    )
    relfreq.name = VAR_WD_FREQ
    return _update_var_attrs(relfreq, _BWC_ATTRS)


def _count_to_ws_freq_by_sector(wind_hist):
    """Convert wind vector count histogram to binned wind climate dataset.

    .. deprecated:: 0.7.0
        Use :func:`bwc_from_counts` instead. Will be removed in windkit 3.0.
    """
    warnings.warn(
        "'count_to_ws_freq_by_sector' is deprecated since windkit 0.7.0 and "
        "will be removed in windkit 3.0. Use 'bwc_from_counts' instead.",
        FutureWarning,
        stacklevel=2,
    )
    return _bwc_from_counts(wind_hist)


def _bwc_from_counts(wind_hist):
    """Convert wind vector count histogram to binned wind climate dataset.

    Parameters
    ----------
    wind_hist : xarray.DataArray
        A valid pywasp wind-vector-count histogram DataArray


    Returns
    -------
    relfreq : xarray.Dataset
        Dataset with wind speed frequencies
        normalized in each sector and the rel.
        frequency of occurance of wind direction.
    """
    if isinstance(wind_hist, xr.Dataset):
        wind_hist = wind_hist[WV_COUNT]

    wsfreq = wind_hist / wind_hist.sum(dim=DIM_WS, skipna=False)
    # sectors with zero frequencies result in nans
    # point which have some probability mass in some sectors
    # but not all, are manually set to 0.0
    point_not_empty = wsfreq.sum([DIM_WD, DIM_WS]) > 0
    wsfreq = wsfreq.where(~(point_not_empty & wsfreq.isnull()), 0.0)
    wdfreq = _count_to_wd_freq(wind_hist)

    # The Dataset takes its dimension order from the first variable inserted,
    # and a DataArray inserts its coordinates before its data. Insert
    # coordinate-free ``(dims, data, attrs)`` tuples, widest variable first,
    # then attach the coordinates.
    ds = xr.Dataset(
        {
            VAR_WS_FREQ_BY_SECTOR: (wsfreq.dims, wsfreq.data, wsfreq.attrs),
            VAR_WD_FREQ: (wdfreq.dims, wdfreq.data, wdfreq.attrs),
        }
    )
    ds = ds.assign_coords(wsfreq.coords)
    ds.attrs.update(wind_hist.attrs)

    ds = _update_var_attrs(ds, _BWC_ATTRS)
    return _update_history(ds)


@validate_input(_TSWC_SCHEMA)
def bwc_from_tswc(
    ts,
    wsbin_width=1.0,
    n_wsbins=30,
    n_sectors=12,
    normalize=True,
    wind_dir_crs=None,
    **kwargs,
):
    """Creates object from a timeseries.

    Parameters
    ----------
    ts : xarray.Dataset
        Xarray dataset with variables 'wind_speed'
        and 'wind_direction' and with a coordinate and
        dimension 'time'.
    wsbin_width: float
        Width of the wind speed bins, defaults to 1.0.
    n_wsbins : int
        Number of wind speed bins, defaults to 30.
    n_sectors : int
        Number of sectors, defaults to 12.
    normalize : bool
        If set to True, convert wind vector count histogram to
        wind sector-wise relative frequency. Defaults to True
    wind_dir_crs : CRS-like, optional
        CRS that defines the output wind-direction frame. If ``ts`` has a
        ``wind_dir_crs`` attribute, input directions are treated as already
        expressed in that CRS frame. Otherwise, input directions are assumed
        true-north-relative. Directions are rotated into a projected target
        CRS's grid-north frame before binning; a geographic target CRS retains
        them in the true-north frame.
    kwargs: dict
        Additional argument 'wasp_desription' can be added to the dataset.

    Returns
    -------
    bwc : xarray.Dataset
        Binned wind climate from the timeseries.
    """
    existing_wind_dir_crs = ts.attrs.get("wind_dir_crs")
    if existing_wind_dir_crs is not None:
        existing_wind_dir_crs = pyproj.CRS.from_user_input(existing_wind_dir_crs)

    target_wind_dir_crs = existing_wind_dir_crs
    if wind_dir_crs is not None:
        target_wind_dir_crs = pyproj.CRS.from_user_input(wind_dir_crs)
        ts = reproject(ts, target_wind_dir_crs)

    rotation = None
    if wind_dir_crs is not None and existing_wind_dir_crs is None:
        rotation = grid_convergence(ts)
    elif (
        wind_dir_crs is not None
        and existing_wind_dir_crs is not None
        and not existing_wind_dir_crs.equals(target_wind_dir_crs)
    ):
        rotation = grid_convergence(ts, source=existing_wind_dir_crs)

    if rotation is not None:
        rotated_wd = ((ts[WD] - rotation) % 360.0).assign_attrs(ts[WD].attrs)
        rotated_wd.encoding = ts[WD].encoding.copy()
        ts = ts.assign({WD: rotated_wd})

    ds_attrs = {
        "description": kwargs.get("wasp_desription", ""),
        **_create_time_attributes(ts),
    }

    # ignore times when any of wind speed or direction sample is missing anywhere.
    ts = ts.dropna(dim=DIM_TIME)
    if ts.sizes[DIM_TIME] < 1:
        raise ValueError("Need at least 1 sample to create a histogram")

    ws_bins = create_wsbin_coords(n_wsbins, width=wsbin_width)
    wd_bins = create_sector_coords(n_sectors)
    ws_bin_edges = np.append(0.0, ws_bins["wsceil"].values)

    batch_dims = [d for d in ts[WS].dims if d != DIM_TIME]
    batch_shape = tuple(ts.sizes[d] for d in batch_dims)
    npoints = int(np.prod(batch_shape)) if batch_shape else 1

    ws = (
        ts[WS]
        .transpose(DIM_TIME, *batch_dims)
        .values.reshape(ts.sizes[DIM_TIME], npoints)
    )
    wd_indices, _ = wd_to_sector(ts[WD], n_sectors, output_type="indices")
    wd = wd_indices.transpose(DIM_TIME, *batch_dims).values.reshape(
        ts.sizes[DIM_TIME], npoints
    )

    ws_bin_idx = np.searchsorted(ws_bin_edges, ws, side="right") - 1
    ws_bin_idx[ws == ws_bin_edges[-1]] = n_wsbins - 1

    wd_bin_edges = np.arange(n_sectors + 1)
    wd_bin_idx = np.searchsorted(wd_bin_edges, wd, side="right") - 1
    wd_bin_idx[wd == wd_bin_edges[-1]] = n_sectors - 1

    valid = (
        np.isfinite(ws)
        & np.isfinite(wd)
        & (ws_bin_idx >= 0)
        & (ws_bin_idx < n_wsbins)
        & (wd_bin_idx >= 0)
        & (wd_bin_idx < n_sectors)
    )
    point_idx = np.broadcast_to(np.arange(npoints), ws.shape)

    hist_arr = np.zeros((n_wsbins, n_sectors, npoints), dtype=float)
    np.add.at(
        hist_arr,
        (ws_bin_idx[valid], wd_bin_idx[valid], point_idx[valid]),
        1.0,
    )

    spatial_coords = {d: ts.coords[d] for d in batch_dims if d in ts.coords}
    wind_hist = xr.DataArray(
        hist_arr.reshape(n_wsbins, n_sectors, *batch_shape),
        dims=(DIM_WS, DIM_WD, *batch_dims),
        coords={**ws_bins.coords, **wd_bins.coords, **spatial_coords},
        name=WV_COUNT,
    )
    wind_hist.attrs.update(ts.attrs)

    if normalize:
        hist = _bwc_from_counts(wind_hist)
    else:
        hist = _update_var_attrs(wind_hist.to_dataset(), _HIS_ATTRS)

    if "_pwio_data_is_2d" in ts[WS].attrs:
        for var in hist.data_vars:
            hist[var].attrs["_pwio_data_is_2d"] = ts[WS].attrs["_pwio_data_is_2d"]
        hist.attrs.pop("_pwio_data_is_2d", None)

    skip_coords = {DIM_TIME, DIM_WS, DIM_WD, "wsceil", "wsfloor"}
    extra_coords = {
        coord_name: coord
        for coord_name, coord in ts.coords.items()
        if coord_name not in hist.coords
        and coord_name not in skip_coords
        and set(coord.dims).issubset(hist.dims)
    }
    if extra_coords:
        hist = hist.assign_coords(extra_coords)

    hist = hist.assign_attrs(ds_attrs)
    if target_wind_dir_crs is not None:
        hist.attrs["wind_dir_crs"] = target_wind_dir_crs.to_wkt()
    return _update_history(hist)


@validate_input(_TSWC_SCHEMA)
def _create_time_attributes(ds: xr.Dataset, hist=None):
    """Create time attributes for binned wind climate.

    We attached the time attributes to a new or existing
    binned wind climate. If it has existing attributes, these
    will be used as well when calculating the meta data.

    Parameters
    ----------
    ds : xarray.Dataset
        Xarray dataset with variables 'wind_speed'
        and 'wind_direction' and with a coordinate and
        dimension 'time'.
    hist : xarray.Dataset, optional
        A valid pywasp histogram dataset with, defaults to None

    Returns
    -------
    dic_result: dict
        Dictionary with 'start_time', 'end_time', 'interval',
        'count', 'count_missing', 'recovering_percentage'
    """
    # find the first and last time in the time series we process
    first_time = pd.Timestamp(ds["time"].min().values)
    last_time = pd.Timestamp(ds["time"].max().values)
    number_of_samples = int(ds.dropna(dim="time").sizes["time"])
    # find most frequent interval in minutes
    # currently when you provide an existing histogram
    # as input it will just overwrite the sampling interval
    # and recovery percentage. Since we only process model
    # data this way, it is probably OK for now.
    intervals, counts = np.unique(
        ds["time"].diff("time") / pd.Timedelta("1 ms"), return_counts=True
    )
    interval = intervals[counts.argmax()]
    series_start_to_end = np.arange(
        first_time, last_time, pd.Timedelta(f"{interval} ms")
    )
    # arange does not include the last step but we want
    # this for the max samples
    max_possible_samples = int(series_start_to_end.size + 1)

    # check for existing first and last time in input
    # it is assumed that this histogram has also been created
    # with this function and the attributes should be present
    try:
        first_time = np.min([first_time, pd.to_datetime(hist.attrs["start_time"])])
        last_time = np.max([last_time, pd.to_datetime(hist.attrs["end_time"])])
        max_possible_samples = max_possible_samples + hist.attrs["count_expected"]
        number_of_samples = number_of_samples + hist.attrs["count"]
    except (KeyError, AttributeError) as e:  # noqa
        logging.info("No attributes present yet, adding new ones.")

    dic_result = {
        "start_time": str(first_time),
        "end_time": str(last_time),
        "interval": str(pd.Timedelta(f"{interval} ms")),
        "count_expected": max_possible_samples,
        "count": number_of_samples,
        "count_missing": max_possible_samples - number_of_samples,
        "recovery_percentage": 100 * number_of_samples / max_possible_samples,
    }

    return dic_result


def _bwc_to_tab_arrays(bwc):
    """Extract normalized arrays from a bwc dataset for tab I/O.

    Parameters
    ----------
    bwc : xr.Dataset
        Binned wind climate xr.Dataset object (single point).

    Returns
    -------
    dict
        Dictionary with wsfreq, wdfreq, wsbins, coords, metadata
        matching the signature of ``format_tab`` and ``write_tab``.
    """
    node = bwc.squeeze()
    return {
        # format_tab's positional (n_wsbins, n_sectors) contract, not
        # create_bwc's own storage order (windkit#807, not a supported
        # constructor contract), decides this transpose.
        "wsfreq": node.wsfreq.transpose("wsbin", "sector").values,
        "wdfreq": node.wdfreq.transpose("sector").values,
        "wsbins": np.append(0, node.wsceil.values),
        "coords": {
            "south_north": node["south_north"].values.item(),
            "west_east": node["west_east"].values.item(),
            "height": node["height"].values.item(),
        },
        "metadata": {"description": node.attrs.get("description", "No Header")},
    }


def _tab_string(bwc):
    """Returns string representation of bwc dataset.

    Parameters
    ----------
    bwc: xr.Dataset
        Binned wind climate xr.Dataset object.

    Returns
    -------
    str
        String representation of bwc dataset.
    """
    from windkit.io.wasp import format_tab

    return format_tab(**_bwc_to_tab_arrays(bwc))


@_wv_count_wrapper
def _to_tabfile(bwc, /, path=None):
    """Write bwc to tab-style ascii file.

    Parameters
    ----------
    bwc: xr.Dataset
        Binned wind climate xr.Dataset object.

    path: str or pathlib.Path
        dir or file path to write the file. Default value set
        to the current working directory.

    """

    from windkit.io.wasp import write_tab

    def _write_bwc_node(node, fpath):
        write_tab(fpath, **_bwc_to_tab_arrays(node))

    def _fmt_single_point_filename(ds):
        h = ds["height"].values.flatten()[0]
        sn = ds["south_north"].values.flatten()[0]
        we = ds["west_east"].values.flatten()[0]
        return f"bwc_height{h}_south_north{sn}_west_east{we}.tab"

    if not get_crs(bwc).is_geographic:
        raise RuntimeError(
            "Binned wind climate dataset with projected coordinate systems cannot be written to a '.tab' file."
        )

    if path is None:
        path = Path.cwd()
    path = Path(path)
    if path.suffix == "":  # it is a Directory
        path.mkdir(parents=True, exist_ok=True)

    # If dataset has no extra dimensions (larger than size=1):
    # write file and return early.
    if bwc.squeeze().wsfreq.ndim == 2:
        if path.is_dir():
            fpath = path / _fmt_single_point_filename(bwc)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            fpath = path
        _write_bwc_node(bwc.squeeze(), fpath)
        return

    # If dataset has extra dimensions (of size > 1):
    # Stack extra dimensions, loop over them, and write to tab files
    # Using file_name that contains coordinate information.
    warnings.warn(
        "Writing multi-point datasets to multiple .tab files is deprecated "
        "since windkit 2.1.0 and will be removed in windkit 3.0. Write "
        "single-point datasets instead.",
        FutureWarning,
        stacklevel=2,
    )
    dims_extra = [d for d in bwc.wsfreq.dims if d not in ["wsbin", "sector"]]
    stacked = bwc.stack(point=dims_extra)

    if not path.is_dir():
        raise ValueError(
            "'path' argument is a filename, but the dataset has more than one point."
            " Try giving a directory as an argument."
        )

    file_name_fmt = "_".join(["bwc"] + [f"{d}{{{d}}}" for d in dims_extra]) + ".tab"

    for ipt in range(stacked.sizes["point"]):
        node = stacked.isel(point=slice(ipt, ipt + 1)).reset_index("point").squeeze()
        kw = {d: node[d].values for d in dims_extra}
        fpath = path / file_name_fmt.format(**kw)
        _write_bwc_node(node, fpath)


def _to_windiofile(bwc, windiofile, level="plant", **kwargs):
    """Write a binned wind climate dataset to windIO YAML format.

    Parameters
    ----------
    bwc : xarray.Dataset
        Binned wind climate dataset.
    windiofile : str or pathlib.Path
        Path to output windIO YAML file.
    level : str
        Export level: 'plant', 'site', 'energy_resource', or 'wind_resource'.
        Defaults to 'plant'.
    **kwargs
        Additional keyword arguments (unused, for API consistency).
    """
    from windkit.io.windio.translate import bwc_to_windio
    from windkit.io.windio.utils import _write_windio_climate

    _write_windio_climate(bwc, windiofile, bwc_to_windio, level=level)


@validate_input(_BWC_SCHEMA)
def bwc_to_file(bwc, filename, *, file_format="infer", **kwargs):
    """Write binned wind climate to file.

    Parameters
    ----------
    bwc: xr.Dataset
        Binned wind climate xr.Dataset object.
    filename: str or pathlib.Path
        Path to the file to write the binned wind climate to.
    file_format: str
        The file format of the output file. If 'infer', the file format will be inferred from the file extension.
        Supported formats are 'tab', 'yaml'. Defaults to 'infer'.
    **kwargs: dict
        Additional keyword arguments to pass to the writing function.
        For windIO files, the 'level' argument can be specified to indicate the windIO hierarchy level.
    """
    if file_format == "infer":
        file_format = _infer_file_format(filename)

    if file_format == "tab":
        _to_tabfile(bwc, filename, **kwargs)
    elif file_format in ["yaml", "yml"]:
        _to_windiofile(bwc, filename, **kwargs)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")


@_wv_count_wrapper
def _mean_ws_moment(bwc, /, moment=1.0, bysector=False):
    """Calculate the n^th moment of the wind speed from a bwc

    Parameters
    ----------
    bwc: xarray.Dataset
        Binned wind climate xr.Dataset object
    moment: float
        Moment to compute, defaults to 1.0.
    bysector: bool
        Whether to return the sectorwise wind speed moment or the
        all-sector mean moment. Defaults to False.

    Returns
    -------
    ws_moment: xarray.DataArray
        Array of wind speed moments.
    """
    if bysector:
        return (bwc.wsfreq * bwc.wsbin**moment).sum(dim=["wsbin"], skipna=False)
    return (bwc.wdfreq * bwc.wsfreq * bwc.wsbin**moment).sum(
        dim=["wsbin", "sector"], skipna=False
    )


@_wv_count_wrapper
def _ws_cdf(bwc, /, bysector=False):
    """Calculate the cumulative distribution function (CDF) of the wind speed from a bwc

    Parameters
    ----------
    bwc: xarray.Dataset
        Binned wind climate xr.Dataset object
    bysector: bool
        Whether to return the sectorwise wind speed cdf or the
        all-sector mean cdf. Defaults to False which returns the
        all-sector mean cdf.

    Returns
    -------
    ws_cdf: xarray.DataArray
        Array of wind speed cdf.
    """
    if bysector:
        return bwc.wsfreq.cumsum(dim=["wsbin"], skipna=False)
    return (
        (bwc.wdfreq * bwc.wsfreq)
        .sum(dim="sector", skipna=False)
        .cumsum(dim=["wsbin"], skipna=False)
    )


@_wv_count_wrapper
def _ws_freq_gt_mean(bwc, /, bysector=False):
    """Calculate the frequency of wind speeds greater than the mean wind speed.

    Parameters
    ----------
    bwc: xarray.Dataset
        Binned wind climate xr.Dataset object

    bysector: bool
        Whether to return the sectorwise wind speed cdf or the
        all-sector mean cdf. Defaults to False which returns the
        all-sector value.

    Returns
    -------
    freq_gt_mean: xarray.DataArray
        Array of fraction greater than the mean wind speed in the histograms

    """
    # check for dimensions with no coordinates and temporarily add them
    # to the dataset to avoid problems with xarrays .interp method.
    # This is due to an issue in xarray when we have dimensions
    # with no coordiatnes on both the dataset and interpolation coordinates.
    # We should make an issue on xarray to fix this and remove this workaround afterward.

    dims_no_coord = [d for d in bwc.dims if d not in bwc.coords]
    bwc = bwc.assign_coords({d: (d, np.arange(bwc[d].size)) for d in dims_no_coord})

    # We set the wsceil as the coordinate because we want to interpolate
    # between bin edges.
    cdf = _ws_cdf(bwc, bysector=bysector).set_index({"wsbin": "wsceil"})
    mean = _mean_wind_speed(bwc, bysector=bysector)
    fgtm = 1.0 - cdf.interp(wsbin=mean, method="linear")
    # If the mean wind speed is below the first bin ceiling or above the last, we get nan values back
    # We set these to 0.5, which is the value we would get if the mean wind speed was exactly in the middle
    fgtm = fgtm.fillna(0.5)

    # Remove variables related to the wind speed bins if present
    fgtm = fgtm.drop_vars([v for v in ["wsbin", "wsfloor"] if v in fgtm.coords])

    # remove temporary dimensions
    fgtm = fgtm.drop_vars(dims_no_coord)

    return fgtm


def _fill_wsbin(bwc, /, n_wsbins):
    """Expands a binned wind climate to n_wsbins number of bins
    This is a useful feature when you want to combine several
    binnen wind climates in one dataset, because that requires that they
    have the same dimensions. The last two bins of the histogram
    are used to extrapolate the spacing. Up to this point the bins
    can also be irregular.

    Parameters
    ----------
    bwc: :any:`windkit.bwc`
        Binned wind climate
    n_wsbins: int
        Number of wind speeds bins

    Returns
    -------
    filled_bwc: :any:`windkit.bwc`
        Binned wind climate with n_wsbins number of bins
    """
    extension_bin = -2  # index of second last bin of histogram
    owsbin = bwc.sizes["wsbin"]
    # get spacing between last two bins
    dws = np.diff(bwc.wsbin[extension_bin:])
    newbins = np.zeros(n_wsbins)  # create new array with desired length
    newbins[0:owsbin] = bwc.wsbin.values  # set old bins
    newbins[owsbin:n_wsbins] = newbins[owsbin - 1] + dws * np.arange(
        1, n_wsbins - owsbin + 1
    )  #
    wsceil = np.append(
        bwc.wsceil, bwc.wsceil[[-1]] + dws * np.arange(1, n_wsbins - owsbin + 1)
    )
    wsfloor = np.append(
        bwc.wsfloor, bwc.wsfloor[[-1]] + dws * np.arange(1, n_wsbins - owsbin + 1)
    )
    filled_bwc = bwc.interp(wsbin=newbins, kwargs={"fill_value": 0.0})
    filled_bwc["wsceil"] = (("wsbin"), wsceil, _WSBIN_COORD_ATTRS["wsceil"])
    filled_bwc["wsfloor"] = (("wsbin"), wsfloor, _WSBIN_COORD_ATTRS["wsfloor"])

    return filled_bwc


@validate_input(_BWC_SCHEMA)
def weibull_fit(bwc, include_met_fields=None, atol=1e-8):
    """
    Returns sectorwise Weibull parameters using WAsP's fitting algorithm.

    Parameters
    ----------
    bwc : xarray.Dataset
        Binned wind climate xr.Dataset object

    include_met_fields : bool
        Whether to include met fields in the output. Defaults to False.

    atol : float
        Absolute tolerance for the weibull-fitting algorithm, applied to 3 / k.
        Defaults to 1e-8.

    Returns
    -------
    xarray.Dataset
        Weibull Wind Climate of same spatial extent as the input bwc. Sectors
        whose moments cannot be fitted get NaN ``A`` and ``k``, see
        :func:`windkit.weibull.fit_weibull_wasp_m1_m3_fgtm`.
    """

    # Not implemtened yet # TODO: implement
    if include_met_fields is not None:
        raise NotImplementedError(
            "The include_met_fields argument is not implemented yet."
        )

    m1 = _mean_ws_moment(bwc, 1.0, bysector=True)
    m3 = _mean_ws_moment(bwc, 3.0, bysector=True)
    fgtm = _ws_freq_gt_mean(bwc, bysector=True)

    shape, scale = weibull.fit_weibull_wasp_m1_m3_fgtm(m1, m3, fgtm, atol=atol)

    # The fit keeps the attributes of m1, which describe neither A nor k
    shape.attrs, scale.attrs = {}, {}

    wb = bwc[["wdfreq"]].astype("float64").copy()
    wb["A"] = shape
    wb["k"] = scale

    wb = _update_var_attrs(wb, _WEIB_ATTRS)

    return _update_history(wb)


def _mean_wind_speed(bwc, bysector=False):
    """Calculate the mean wind speed.

    Parameters
    ----------
    bwc: xarray.Dataset
        Binned wind climate xr.Dataset object.
    bysector: bool
        Return sectorwise mean wind speed if True. Defaults to False.

    Returns
    -------
    bwc : xarray.DataArray
        Mean wind speed of the bwc.
    """
    return _mean_ws_moment(bwc, 1.0, bysector)


def _mean_power_density(bwc, bysector=False, air_density=1.225):
    """Calculate the power density

    Calculates the power density using a standard atmosphere air density of 1.225 kg m-3

    Parameters
    ----------
    bwc: xarray.Dataset
        Binned wind climate xr.Dataset object.
    bysector: bool
        Return sectorwise mean wind speed if True. Defaults to False.
    air_dens : float
        Air density. Default set to 1.225 kg.m^-3.

    Returns
    -------
    bwc : xarray.DataArray
        Power density of the bwc.
    """
    return 1 / 2 * air_density * _mean_ws_moment(bwc, 3.0, bysector)
