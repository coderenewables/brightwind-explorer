# (c) 2026 DTU Wind Energy
"""Synthetic extreme wind climates and LINCOM lookup tables.

Extreme wind assessment runs a three-step chain: a generalized extreme wind
climate (GEWC) holds the regional annual maximum wind per sector and year; a
lookup table converts those into local annual maxima at each site, giving a
predicted extreme wind climate (PEWC); and a Gumbel fit over the year axis of
the PEWC yields the 50-year return wind.

This module creates synthetic versions of all three inputs. The annual maxima
are drawn from a Gumbel distribution with per-point location and scale, which
is the distribution the downstream fit assumes, so a fit of the generated data
recovers roughly the parameters that produced it. That makes results checkable
by hand, and it keeps every horizontal location numerically distinct.
"""

__all__ = [
    "create_gewc",
    "create_pewc",
    "create_v50_lut",
]

from numbers import Real

import numpy as np

from windkit.xarray_structures.empty import (
    _native_batch,
    _native_flat_coords,
    _native_frame,
    _native_store,
)
from windkit.xarray_structures.metadata import (
    _GEWC_ATTRS,
    _LINCOM_V50_ATTRS,
    _LINCOM_V50_LUT_ATTRS,
    _update_history,
    _update_var_attrs,
)
from windkit.xarray_structures.sector import create_sector_coords

# Keep all 32 CFSR years by default. Using three years shrinks the generated
# arrays by about 90%, but benchmarks show negligible generator speedup because
# xarray dataset construction and spatial stack/unstack dominate. Tests that
# need smaller samples can pass ``years`` explicitly.
_DEFAULT_YEARS = np.arange(1979, 2011)

# A Gumbel's 50-year return wind is loc + 3.902 * scale, so these span 37.8-49.6
# m/s: IEC 61400-1 classes III through I, roughly GASP's spread over Denmark.
_DEFAULT_LOCATION_RANGE = (28.0, 32.0)
_DEFAULT_SCALE_RANGE = (2.5, 4.5)

# The three forcing levels GASP runs LINCOM at.
_DEFAULT_GEN_WSPD = (10.0, 25.0, 40.0)

# PyWAsP only considers lookup conditions less than 30 degrees from a query.
# Seven evenly spaced sectors are therefore the minimum that cover every direction.
_MIN_LUT_SECTORS = 7

# The generalized climate sits below the local one, which the terrain amplifies.
_DEFAULT_GEN_LOCATION_RANGE = (20.0, 25.0)
_DEFAULT_GEN_SCALE_RANGE = (1.2, 2.5)

_DEFAULT_PREVAILING = 270.0
# How much weaker the maxima are in the sector opposite the prevailing one.
_DEFAULT_DIRECTIONAL_CONTRAST = 0.35


def _validate_years(years):
    """Return a one-dimensional array containing at least two years."""
    years = _DEFAULT_YEARS if years is None else np.asarray(years)
    if years.ndim != 1 or years.size < 2:
        raise ValueError(
            "years must be a one-dimensional sequence containing at least two "
            f"entries, got shape {years.shape}."
        )
    return years


def _validate_positive_range(name, bounds):
    """Return two finite, positive bounds in nondecreasing order."""
    try:
        bounds_array = np.asarray(bounds, dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"{name} must contain two numeric bounds, got {bounds!r}."
        ) from exc
    if (
        bounds_array.shape != (2,)
        or not np.all(np.isfinite(bounds_array))
        or np.any(bounds_array <= 0.0)
        or bounds_array[1] < bounds_array[0]
    ):
        raise ValueError(
            f"{name} must contain two finite, strictly positive bounds in "
            f"nondecreasing order, got {bounds!r}."
        )
    return tuple(bounds_array)


def _sector_strength(sectors, prevailing, contrast):
    """Relative strength of each sector, peaking at the prevailing direction."""
    offset = np.deg2rad(np.asarray(sectors, dtype=float) - prevailing)
    return 1.0 - contrast * (1.0 - np.cos(offset)) / 2.0


def _gumbel_params(n_points, location_range, scale_range, rng, strength=None):
    """Draw per-point Gumbel location and scale, optionally scaled per sector.

    Returns arrays broadcast against ``strength``: ``(n_points,)`` when no
    sector strength is given, ``(n_sectors, n_points)`` when one is.
    """
    location = rng.uniform(*location_range, n_points)
    scale = rng.uniform(*scale_range, n_points)
    if strength is None:
        return location, scale
    return location * strength[:, np.newaxis], scale * strength[:, np.newaxis]


def _horizontal_point_index(west_east, south_north):
    """Map stacked points to unique horizontal locations."""
    horizontal = np.column_stack((west_east, south_north))
    locations, inverse = np.unique(horizontal, axis=0, return_inverse=True)
    return len(locations), inverse


def create_gewc(
    output_locs,
    years=None,
    n_sectors=12,
    seed=9876538,
    location_range=_DEFAULT_GEN_LOCATION_RANGE,
    scale_range=_DEFAULT_GEN_SCALE_RANGE,
    prevailing_direction=_DEFAULT_PREVAILING,
    directional_contrast=_DEFAULT_DIRECTIONAL_CONTRAST,
):
    """Create a synthetic generalized extreme wind climate.

    "Generalized" means 10 m above a homogeneous surface of roughness 0.05 m -
    the condition LINCOM downscales from, and ``pywasp.lincom.v50_lut``'s
    ``DEFAULT_HGT`` and ``DEFAULT_Z0``.

    The annual maxima are drawn per point and sector from a Gumbel
    distribution, with the location and scale reduced away from the prevailing
    direction so that the wind rose is not flat. Directions fall inside their
    own sector bin. Because the generalized condition is fixed at 10 m, points
    at the same horizontal location receive the same climate at every height.
    The repetition is deliberate and permitted by the ``"optional"`` height
    policy of the maxima: LINCOM consumes a generalized climate on the
    three-dimensional structure of its output points.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Output geospatial information.
    years : array_like or None
        Years to generate. If None, 1979 through 2010 is used, the CFSR
        period the defaults follow.
    n_sectors : int
        Number of direction sectors, defaults to 12.
    seed : int
        Seed for the random data, defaults to 9876538.
    location_range : tuple of float
        Bounds of the per-point Gumbel location parameter [m s-1]. Defaults to
        ``(20.0, 25.0)``, below the local defaults because the terrain
        downscaling amplifies these values.
    scale_range : tuple of float
        Bounds of the per-point Gumbel scale parameter [m s-1]. Defaults to
        ``(1.2, 2.5)``.
    prevailing_direction : float
        Direction of the strongest sector [degrees]. Defaults to 270.
    directional_contrast : float
        Fractional reduction of the maxima in the sector opposite the
        prevailing one. Defaults to 0.35.

    Returns
    -------
    ds : xarray.Dataset
        Generalized extreme wind climate with ``max_wspd`` and ``max_wdir``
        over ``(sector, year, <space>)``.

    Raises
    ------
    ValueError
        If ``years`` is not a one-dimensional sequence containing at least two
        entries.

    """
    years = _validate_years(years)
    dims, batch_shape = _native_batch(output_locs)
    n_horizontal, horizontal_index = _horizontal_point_index(
        *_native_flat_coords(output_locs, dims, batch_shape)
    )
    n_yr = len(years)

    sector_coords = create_sector_coords(n_sectors)
    sectors = sector_coords["sector"].values
    sector_width = 360.0 / n_sectors

    rng = np.random.default_rng(seed)
    strength = _sector_strength(sectors, prevailing_direction, directional_contrast)
    location, scale = _gumbel_params(
        n_horizontal, location_range, scale_range, rng, strength=strength
    )

    horizontal_shape = (n_sectors, n_yr, n_horizontal)
    horizontal_wspd = rng.gumbel(
        location[:, np.newaxis, :], scale[:, np.newaxis, :], horizontal_shape
    )
    # Each year's maximum blew from somewhere inside its own sector bin.
    within = rng.uniform(-sector_width / 2.0, sector_width / 2.0, horizontal_shape)
    horizontal_wdir = (sectors[:, np.newaxis, np.newaxis] + within) % 360.0
    max_wspd = horizontal_wspd[..., horizontal_index]
    max_wdir = horizontal_wdir[..., horizontal_index]

    ds = (
        _native_frame(output_locs)
        .assign_coords(sector_coords.coords)
        .assign_coords(year=years)
    )
    for name, values in (("max_wspd", max_wspd), ("max_wdir", max_wdir)):
        ds[name] = _native_store(
            values, dims, batch_shape, core_dims=("sector", "year")
        )

    return _finalize(ds, _GEWC_ATTRS)


def create_pewc(
    output_locs,
    years=None,
    seed=9876538,
    location_range=_DEFAULT_LOCATION_RANGE,
    scale_range=_DEFAULT_SCALE_RANGE,
    prevailing_direction=_DEFAULT_PREVAILING,
    direction_spread=40.0,
    max_interval=1.0,
):
    """Create a synthetic predicted extreme wind climate.

    One annual maximum per year per point, drawn from a per-point Gumbel
    distribution. This is the input a return-wind fit consumes, so fitting the
    result recovers approximately ``location_range`` and ``scale_range``. A real
    PEWC is the maximum over the sectors of a downscaled GEWC, which is only
    approximately Gumbel; drawing directly is what keeps that property exact.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Output geospatial information.
    years : array_like or None
        Years to generate. If None, 1979 through 2010 is used, the CFSR
        period the defaults follow.
    seed : int
        Seed for the random data, defaults to 9876538.
    location_range : tuple of float
        Bounds of the per-point Gumbel location parameter [m s-1]. Defaults to
        ``(28.0, 32.0)``.
    scale_range : tuple of float
        Bounds of the per-point Gumbel scale parameter [m s-1]. Defaults to
        ``(2.5, 4.5)``, which together with the location gives a 50-year
        return wind of 37.8-49.6 m s-1.
    prevailing_direction : float
        Mean direction of the annual maxima [degrees]. Defaults to 270.
    direction_spread : float
        Standard deviation of the direction of the annual maxima [degrees].
        Defaults to 40.
    max_interval : float
        Length of the interval each maximum is taken over [years], recorded as
        the ``max_interval`` attribute. Defaults to 1.0.

    Returns
    -------
    ds : xarray.Dataset
        Predicted extreme wind climate with ``max_wspd`` and ``max_wdir`` over
        ``(year, <space>)``.

    Raises
    ------
    ValueError
        If ``years`` is not a one-dimensional sequence containing at least two
        entries, or if ``max_interval`` is not finite and strictly positive.

    """
    years = _validate_years(years)
    if (
        isinstance(max_interval, (bool, np.bool_))
        or not isinstance(max_interval, Real)
        or not np.isfinite(max_interval)
        or max_interval <= 0.0
    ):
        raise ValueError(
            f"max_interval must be finite and strictly positive, got {max_interval!r}."
        )
    max_interval = float(max_interval)
    dims, batch_shape = _native_batch(output_locs)
    n_pt = int(np.prod(batch_shape, dtype=int))
    n_yr = len(years)

    rng = np.random.default_rng(seed)
    location, scale = _gumbel_params(n_pt, location_range, scale_range, rng)

    shape = (n_yr, n_pt)
    max_wspd = rng.gumbel(location, scale, shape)
    max_wdir = (prevailing_direction + rng.normal(0.0, direction_spread, shape)) % 360.0

    ds = _native_frame(output_locs).assign_coords(year=years)
    for name, values in (("max_wspd", max_wspd), ("max_wdir", max_wdir)):
        ds[name] = _native_store(values, dims, batch_shape, core_dims=("year",))

    out = _finalize(ds, _LINCOM_V50_ATTRS)
    return out.assign_attrs(max_interval=max_interval)


def create_v50_lut(
    output_locs,
    gen_wspd=_DEFAULT_GEN_WSPD,
    n_sectors=12,
    seed=9876538,
    speedup_range=(0.85, 1.35),
    veer_range=(-8.0, 8.0),
):
    """Create a synthetic LINCOM extreme wind lookup table.

    A lookup table answers "if the generalized wind is this fast, from this
    sector, what is the local wind here?". This builds one directly from a
    per-point, per-sector speedup and direction veer rather than by running
    LINCOM over terrain, so it is fast and every entry is distinct.

    The speedup does not depend on the generalized speed, which is what a
    linearised flow model gives; the local speed is therefore proportional to
    the generalized one at each anchor.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Output geospatial information.
    gen_wspd : array_like
        Generalized wind speeds to tabulate [m s-1], strictly increasing. A
        scalar is treated as a single anchor. Defaults to
        ``(10.0, 25.0, 40.0)``, the three forcing levels GASP runs LINCOM at.
        All anchors must be finite and strictly positive.
    n_sectors : int
        Number of direction sectors, defaults to 12. At least seven are required
        to cover every direction within PyWAsP's strict 30-degree lookup radius.
    seed : int
        Seed for the random data, defaults to 9876538.
    speedup_range : tuple of float
        Bounds of the per-point, per-sector speedup factor. Defaults to
        ``(0.85, 1.35)``, spanning sheltered to hilltop.
    veer_range : tuple of float
        Bounds of the per-point, per-sector direction change [degrees].
        Defaults to ``(-8.0, 8.0)``.

    Returns
    -------
    ds : xarray.Dataset
        Lookup table with ``WS`` and ``WD`` over
        ``(gen_wspd, sector, <space>)``.

    Raises
    ------
    ValueError
        If ``gen_wspd`` is not a non-empty, one-dimensional sequence of finite,
        strictly positive, strictly increasing anchors, or if ``n_sectors`` is
        not an integer of at least seven, or if ``speedup_range`` does not
        contain two finite, strictly positive bounds in nondecreasing order.
    """
    gen_wspd = np.atleast_1d(np.asarray(gen_wspd, dtype=float))
    if gen_wspd.ndim != 1 or gen_wspd.size == 0:
        raise ValueError(
            f"gen_wspd must be a non-empty one-dimensional sequence of anchors, "
            f"got shape {gen_wspd.shape}."
        )
    if not np.all(np.isfinite(gen_wspd)) or np.any(gen_wspd <= 0.0):
        raise ValueError(
            "gen_wspd anchors must all be finite and strictly positive, "
            f"got {gen_wspd.tolist()}."
        )
    if np.any(np.diff(gen_wspd) <= 0.0):
        # The lookup interpolates over this coordinate, which a repeated or
        # out-of-order anchor turns into a silently wrong interpolation.
        raise ValueError(f"gen_wspd must increase strictly, got {gen_wspd.tolist()}.")
    if not isinstance(n_sectors, (int, np.integer)) or n_sectors < _MIN_LUT_SECTORS:
        raise ValueError(
            f"n_sectors must be an integer of at least {_MIN_LUT_SECTORS}, "
            f"got {n_sectors!r}."
        )
    speedup_range = _validate_positive_range("speedup_range", speedup_range)
    dims, batch_shape = _native_batch(output_locs)
    n_pt = int(np.prod(batch_shape, dtype=int))

    sector_coords = create_sector_coords(n_sectors)
    sectors = sector_coords["sector"].values

    rng = np.random.default_rng(seed)
    speedup = rng.uniform(*speedup_range, (n_sectors, n_pt))
    veer = rng.uniform(*veer_range, (n_sectors, n_pt))

    ws = gen_wspd[:, np.newaxis, np.newaxis] * speedup[np.newaxis, :, :]
    wd = (sectors[np.newaxis, :, np.newaxis] + veer[np.newaxis, :, :]) % 360.0
    wd = np.broadcast_to(wd, ws.shape).copy()

    ds = (
        _native_frame(output_locs)
        .assign_coords(sector_coords.coords)
        .assign_coords(gen_wspd=("gen_wspd", gen_wspd))
    )
    for name, values in (("WS", ws), ("WD", wd)):
        ds[name] = _native_store(
            values, dims, batch_shape, core_dims=("gen_wspd", "sector"), core_last=False
        )

    return _finalize(ds, _LINCOM_V50_LUT_ATTRS)


def _finalize(ds, attrs):
    """Attach metadata to an object already built in its native layout."""
    return _update_history(_update_var_attrs(ds, attrs))
