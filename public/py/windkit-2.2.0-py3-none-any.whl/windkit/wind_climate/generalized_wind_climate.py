# (c) 2026 DTU Wind Energy
"""
Generalized wind climate module

This module contains the various functions for working with generalized wind climates.

Generalized wind climates can be created from .lib, .gwc and NetCDF files;
the file-format parsing itself lives in :mod:`windkit.io.wasp`.
"""

__all__ = [
    "validate_gwc",
    "is_gwc",
    "create_gwc",
    "read_gwc",
    "gwc_to_file",
]


import warnings
from pathlib import Path

import numpy as np
import xarray as xr
from windkit.xarray_structures._schema import (
    Check,
    DataVar,
    DatasetSchema,
    make_is_valid,
    make_validator,
    validate,
    validate_input,
)
from windkit.xarray_structures.empty import (
    _copy_chunks,
    _native_batch,
    _native_frame,
    _native_store,
)
from windkit.xarray_structures.metadata import (
    _WEIB_ATTRS,
    _ALL_VARS_META,
    _update_history,
    _update_var_attrs,
    _create_coords,
)
from windkit.xarray_structures.sector import create_sector_coords
from windkit.spatial import (
    create_dataset,
    crs_are_equal,
    reproject,
    to_point,
)
from windkit.utils import _infer_file_format
from windkit.wind_climate._validation import _validate_wdfreq_sums_to_one


SUPPORTED_GWC_FILE_FORMATS_READ = ["lib", "gwc", "nc"]
SUPPORTED_GWC_FILE_FORMATS_WRITE = ["lib"]

_GEN_COORDS_META = {
    "gen_height": _ALL_VARS_META["gen_height"],
    "gen_roughness": _ALL_VARS_META["gen_roughness"],
    "sector": _ALL_VARS_META["sector"],
}


def _validate_gen_height_min_entries(genwc):
    """Validate that gen_height has at least 2 entries."""
    if "gen_height" in genwc.dims and genwc.sizes["gen_height"] < 2:
        return ["gen_height needs at least 2 entries"]
    return []


def _validate_gen_roughness_min_entries(genwc):
    """Validate that gen_roughness has at least 2 entries."""
    if "gen_roughness" in genwc.dims and genwc.sizes["gen_roughness"] < 2:
        return ["gen_roughness needs at least 2 entries"]
    return []


def _validate_gen_roughness_starts_at_zero(genwc):
    """Validate that the first entry of gen_roughness is 0.0."""
    if "gen_roughness" in genwc.dims and genwc["gen_roughness"].min() != 0.0:
        return ["The first entry of gen_roughness must be 0.0"]
    return []


def _validate_gen_roughness_non_negative(genwc):
    """Validate that gen_roughness has no negative values."""
    if "gen_roughness" in genwc.dims and np.any(genwc.gen_roughness.values < 0.0):
        return ["'gen_roughness' has negative values"]
    return []


def _validate_gen_height_non_negative(genwc):
    """Validate that gen_height has no negative values."""
    if "gen_height" in genwc.dims and np.any(genwc.gen_height.values < 0.0):
        return ["'gen_height' has negative values"]
    return []


_GWC_SCHEMA = DatasetSchema(
    name="gwc",
    data_vars={
        "A": DataVar(dims=("sector", "gen_height", "gen_roughness")),
        "wdfreq": DataVar(dims=("sector", "gen_height", "gen_roughness")),
        "k": DataVar(dims=("sector", "gen_height", "gen_roughness")),
    },
    dims=("sector", "gen_height", "gen_roughness"),
    coords=("gen_height", "gen_roughness", "sector_ceil", "sector_floor", "sector"),
    extra_checks=(
        Check(_validate_gen_height_min_entries),
        Check(_validate_gen_roughness_min_entries),
        Check(_validate_gen_roughness_starts_at_zero),
        Check(_validate_gen_roughness_non_negative),
        Check(_validate_gen_height_non_negative),
        Check(_validate_wdfreq_sums_to_one),
    ),
)

validate_gwc = make_validator(_GWC_SCHEMA)

is_gwc = make_is_valid(_GWC_SCHEMA)


def create_gwc(
    output_locs,
    n_sectors=12,
    not_empty=True,
    seed=9876538,
    gen_heights=(10.0, 50.0, 100.0),
    gen_roughnesses=(0.0, 0.03, 0.1, 0.4, 1.5),
    wdfreq_constant=False,
    **kwargs,
):
    """Create empty generalized wind climate dataset.

    If not_empty=True, the data variables are filled with meaninful random numbers, e.g.
    the values from A are generated from a uniform function between 5
    and 10 and the values for k from a uniform function between 1.5 and 2.5.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Output geospatial information.
    n_sectors : int
        Number of sectors, defaults to 12.
    not_empty : bool
        If true, the empty dataset is filled with random
        meaningful data. Defaults to True.
    seed : int
        Seed for the random data, defaults to 9876538.
    gen_heights : list
        List of generalized heights to use for coordinates
    gen_roughnesses : list
        List of generalized roughnesses to use for coordinates
    wdfreq_constant: bool
        If True, the values of wdfreq do not change with along the dimension
        gen_heights. This is used when writing lib files. Defaults to False.
    kwargs : dict
        Additional arguments.
    Returns
    -------
    ds : xarray.Dataset
        Generalized wind climate dataset either empty or filled with
        random numbers.

    Notes
    -----
    ``A``, ``k`` and ``wdfreq`` are stored float32, C-contiguous, with
    ``(gen_roughness, gen_height, sector)`` trailing the spatial batch
    dimensions — the reverse of ``generalize_points``' declared
    ``(sector, gen_height, gen_roughness, npoints)`` — so PyWAsP's compiled
    boundary can take a Fortran-ordered view of this buffer instead of
    converting a copy (windkit#807). This is not a supported API contract:
    ``create_gwc`` is a test-data utility, and neither its dtype nor its
    dimension order is guaranteed to a caller.
    """
    dims, shape = _native_batch(output_locs)
    n_pt = int(np.prod(shape, dtype=int))
    gen_rou_coords = np.array(gen_roughnesses, dtype=float)
    gen_h_coords = np.array(gen_heights, dtype=float)
    n_gen_rou = len(gen_rou_coords)
    n_gen_h = len(gen_h_coords)

    if not_empty:
        rng = np.random.default_rng(seed)
        k = rng.uniform(1.5, 2.5, [n_gen_h, n_gen_rou, n_sectors, n_pt])
        A = rng.uniform(5, 10, [n_gen_h, n_gen_rou, n_sectors, n_pt])
        wdfreq = rng.dirichlet(np.ones(n_sectors), (n_gen_h, n_gen_rou, n_pt))
    else:
        k = A = np.full((n_gen_h, n_gen_rou, n_sectors, n_pt), np.nan)
        wdfreq = np.full((n_gen_h, n_gen_rou, n_pt, n_sectors), np.nan)

    # A/k are drawn (gen_height, gen_roughness, sector, *flat); wdfreq is
    # drawn (gen_height, gen_roughness, *flat, sector), because
    # rng.dirichlet appends its distribution axis last. _native_store wants
    # its core axes leading in declaration order (sector, gen_height,
    # gen_roughness), so both need their own transpose onto that order
    # before storing.
    core_dims = ("sector", "gen_height", "gen_roughness")
    ds = _native_frame(output_locs)
    ds = ds.assign_coords(
        {
            **create_sector_coords(n_sectors).coords,
            "gen_height": gen_h_coords,
            "gen_roughness": gen_rou_coords,
        }
    )
    for name, values in (
        ("A", A.transpose(2, 0, 1, *range(3, A.ndim))),
        ("k", k.transpose(2, 0, 1, *range(3, k.ndim))),
        ("wdfreq", wdfreq.transpose(3, 0, 1, 2)),
    ):
        out_dims, array = _native_store(values, dims, shape, core_dims=core_dims)
        ds[name] = xr.DataArray(
            array, dims=out_dims, attrs={"height_dim_policy": "optional"}
        )
    ds["gen_roughness"].attrs = {**_GEN_COORDS_META["gen_roughness"]}
    ds["gen_height"].attrs = {**_GEN_COORDS_META["gen_height"]}
    ds["sector"].attrs = {**_GEN_COORDS_META["sector"]}

    if wdfreq_constant:
        # Reinsert gen_height where _native_store put it, not wherever
        # expand_dims defaults to, so wdfreq keeps the same storage order
        # as A and k rather than gaining a one-off order of its own.
        original_dims = ds["wdfreq"].dims
        collapsed = ds["wdfreq"].isel(gen_height=0)
        reexpanded = collapsed.expand_dims(
            dim={"gen_height": ds["gen_height"].values},
            axis=original_dims.index("gen_height"),
        ).transpose(*original_dims)
        # expand_dims broadcasts, giving gen_height a zero stride; transpose
        # only permutes labels back, it does not materialize storage. An
        # explicit contiguous copy is needed to keep the boundary contract
        # _native_store established for A and k (windkit#807).
        ds["wdfreq"] = reexpanded.copy(data=np.ascontiguousarray(reexpanded.data))

    ds = _update_var_attrs(_copy_chunks(output_locs, ds), _WEIB_ATTRS)
    return _update_history(ds)


def _gwc_to_lib_arrays(gwc, gen_height=None):
    """Extract numpy arrays from a single-point gwc dataset for write_lib/format_lib.

    Parameters
    ----------
    gwc : xarray.Dataset
        Single-point GWC dataset (squeezed).
    gen_height : float, optional
        Value of gen_height to use for wdfreq. Required when wdfreq varies
        with gen_height.

    Returns
    -------
    dict
        Dictionary matching the signature of ``write_lib``/``format_lib``.
    """
    gwc = gwc.copy().transpose("gen_height", "gen_roughness", "sector", ...)

    if _wdfreq_constant_with_gen_height(gwc):
        gwc["wdfreq"] = gwc["wdfreq"].isel(gen_height=0)
    elif gen_height is None:
        raise ValueError(
            "Lib files do not support different 'wdfreq' values for different "
            "heights. Please specify the 'gen_height' for the 'wdfreq' values "
            "that you wish to use for all levels."
        )
    else:
        gwc["wdfreq"] = gwc["wdfreq"].sel(gen_height=gen_height, method="nearest")

    if "height" not in gwc.coords:
        gwc = gwc.expand_dims({"height": [0.0]}).isel(height=0)

    gwc = reproject(gwc, 4326).squeeze()

    # Transpose from (gen_height, gen_roughness, sector) to (sector, height, roughness)
    A = gwc.A.values.transpose(2, 0, 1)
    k = gwc.k.values.transpose(2, 0, 1)
    # wdfreq: (gen_roughness, sector) -> (sector, gen_roughness)
    wdfreq = gwc.wdfreq.values.T

    coords = {
        "west_east": float(gwc.west_east),
        "south_north": float(gwc.south_north),
        "height": float(gwc.height),
    }

    return {
        "A": A,
        "k": k,
        "wdfreq": wdfreq,
        "gen_roughness": gwc.gen_roughness.values,
        "gen_height": gwc.gen_height.values,
        "coords": coords,
        "metadata": {"description": gwc.attrs.get("description", "")},
    }


@validate_input(_GWC_SCHEMA)
def _lib_string(gwc, /, gen_height=None):
    """Generates string representation of gwc dataset.

    Parameters
    ----------
    gwc: xarray.Dataset
        Dataset containing A, k, and wdfreq.
        Dimensions should be ('gen_height', 'gen_roughness', 'sector')
    gen_height: float
        Value of gen_height to use for saving to libfile. Since libfiles only allow a
        single set of wdfreq values, when your data has varying wdfreq values, you need
        to set this value. It is selected using the .sel selector from xarray.

    Returns
    -------
    str
        String representation of gwc dataset.

    """
    from windkit.io.wasp.lib import format_lib

    if gwc.squeeze().A.ndim == 3:
        return format_lib(**_gwc_to_lib_arrays(gwc.squeeze(), gen_height=gen_height))

    dims_order = ["gen_height", "gen_roughness", "sector"]
    gwc = gwc.copy().transpose(*dims_order, ...)
    dims_extra = [d for d in gwc.A.dims if d not in dims_order]
    stacked = gwc.stack(point=dims_extra).transpose(*dims_order, "point")
    strings = []
    for ipt in range(stacked.sizes["point"]):
        node = stacked.isel(point=slice(ipt, ipt + 1)).reset_index("point").squeeze()
        strings.append(format_lib(**_gwc_to_lib_arrays(node, gen_height=gen_height)))
    return strings


def _wdfreq_constant_with_gen_height(gwc):
    """Check if 'wdfreq' is constant with 'gen_height' dimension.

    Parameters
    ----------
    gwc : xarray.Dataset
        Generalized wind climate dataset.

    Returns
    -------
    bool
        True if 'wdfreq' is constant with 'gen_height' dimension across whole dataset.
    """
    return np.isclose(gwc["wdfreq"].diff(dim="gen_height").max(), 0.0).all()


def _fmt_single_point_filename(ds):
    """Format a filename for a single-point gwc dataset."""
    h = ds["height"].values.flatten()[0]
    sn = ds["south_north"].values.flatten()[0]
    we = ds["west_east"].values.flatten()[0]
    return f"gwc_height{h}_south_north{sn}_west_east{we}.lib"


@validate_input(_GWC_SCHEMA)
def _to_libfile(gwc, /, path=None, gen_height=None):
    """Creates lib-style ascii file from gwc dataset

    Parameters
    ----------
    gwc : xarray.Dataset
        Generalized wind climate dataset.
    path : str
        dir or file path for storing lib file
        Default value set to the current working directory.
    gen_height: float
        Value of gen_height to use for saving to libfile. Since libfiles only allow a
        single set of wdfreq values, when your data has varying wdfreq values, you need
        to set this value. It is selected using the .sel selector from xarray.

    """
    gwc = gwc.copy()

    from windkit.io.wasp.lib import write_lib

    if path is None:
        path = Path.cwd()
    path = Path(path)

    if path.suffix == "":  # it is a directory
        path.mkdir(parents=True, exist_ok=True)

    if gwc.squeeze().A.ndim == 3:
        if path.is_dir():
            fpath = path / _fmt_single_point_filename(gwc)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            fpath = path
        lib_data = _gwc_to_lib_arrays(gwc.squeeze(), gen_height=gen_height)
        write_lib(fpath, **lib_data)
        return

    # If dataset has extra dimensions (of size > 1):
    # Stack extra dimensions, loop over them, and write to lib files
    warnings.warn(
        "Writing multi-point datasets to multiple .lib files is deprecated "
        "since windkit 2.1.0 and will be removed in windkit 3.0. Write "
        "single-point datasets instead.",
        FutureWarning,
        stacklevel=3,
    )
    dims_extra = [
        d for d in gwc.A.dims if d not in ["gen_height", "gen_roughness", "sector"]
    ]
    stacked = gwc.stack(point=dims_extra)

    # Create file_name format string
    if Path(path).is_dir():
        file_name_fmt = (
            "_".join(["gwc"] + [f"{d}" + "{" + f"{d}" + "}" for d in dims_extra])
            + ".lib"
        )
    else:
        raise ValueError(
            "'path' argument is a filename, but the dataset has more than one point."
            " Try giving a directory as an argument."
        )

    for ipt in range(stacked.sizes["point"]):
        node = stacked.isel(point=slice(ipt, ipt + 1)).reset_index("point").squeeze()
        kwds = {d: node[d].values for d in dims_extra}
        fpath = path / file_name_fmt.format(**kwds)
        lib_data = _gwc_to_lib_arrays(node, gen_height=gen_height)
        write_lib(fpath, **lib_data)


def gwc_to_file(gwc, filename, *, file_format="infer", **kwargs):
    """
    Write generalized wind climate to file.

    .. note::
        For most use cases, we recommend writing the dataset directly to netCDF
        using :meth:`xarray.Dataset.to_netcdf` and reading it back with
        :func:`xarray.open_dataset`. This preserves all metadata and precision
        and is more portable than format-specific writers.

    Parameters
    ----------
    gwc : xarray.Dataset
        Generalized wind climate dataset.
    filename : str or Path
        File path to write to.
    file_format : str
        File format to write to. Supported formats are 'lib'.
        Default value is 'infer' which will infer the file format from the file extension.
    kwargs : dict
        Additional arguments to pass to the file writer.

    """
    if file_format == "infer":
        file_format = _infer_file_format(filename)

    if file_format == "lib":
        _to_libfile(gwc, filename, **kwargs)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")


def read_gwc(
    filename,
    *,
    crs=None,
    west_east=None,
    south_north=None,
    height=None,
    description=None,
    file_format="infer",
    **kwargs,
):
    """Create gwc xarray.Dataset from file.

    Parameters
    ----------
    file : str or Path
        Path to a file that can be opened a gwc. This includes .lib, and .gwc
        files that were created as gwc files. The script will use the file
        extension to determine the file type and then parse it into a gwc object.
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`
        Defaults to 4326 (Lat-Lon on the WGS84 geodetic datum). for .lib and .gwc.
    west_east : float or None, optional
        West-East coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    south_north : float or None, optional
        South-North coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    height : float or None, optional
        Height coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    description : str or None, optional
        Header string to use for .lib and .gwc files, by default None, which will
        attempt to read from the file.
    file_format : str
        File format to read. Supported formats are 'lib', 'gwc', and 'nc'.
        Default value is 'infer' which will infer the file format from the file extension.
    **kwargs : dict

    Returns
    -------
    xarray.Dataset
        Generalized wind climate dataset.

    Raises
    ------
    ValueError
        If the file extension is not recognized.
    ValueError
        If the requested crs does not match the dataset crs.

    """
    if file_format == "infer":
        file_format = _infer_file_format(filename)

    if file_format == "lib":
        ds = _read_lib_file(
            filename,
            crs=crs,
            west_east=west_east,
            south_north=south_north,
            height=height,
            description=description,
        )
    elif file_format == "gwc":
        ds = _read_gwc_file(
            filename,
            crs=crs,
            west_east=west_east,
            south_north=south_north,
            height=height,
            description=description,
        )
    elif file_format == "nc":
        ds = xr.open_dataset(filename, **kwargs)
    else:
        raise ValueError(
            f"Unable to detect type of gwc file {filename} with extension {file_format}."
        )
    validate(ds, _GWC_SCHEMA)  # Validate for all file types
    ds = _update_var_attrs(ds, _WEIB_ATTRS)
    return _update_history(ds)


def _read_lib_file(
    lib_file, crs=None, west_east=None, south_north=None, height=None, description=None
):
    r"""
    Create GenWindClimate object from WAsP .lib file

    Parameters
    ----------
    lib_file : str, pathlib.Path
        Path to lib file
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`
        Defaults to 4326 (Lat-Lon on the WGS84 geodetic datum)
    west_east : float or None, optional
        West-East coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    south_north : float or None, optional
        South-North coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    height : float or None, optional
        Height coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    description : str or None, optional
        Header string to use for .lib and .gwc files, by default None, which will
        attempt to read from the file.

    Returns
    -------
    xr.DataSet
        xarray DataSet that is formatted to match the gwc description

    Raises
    ------
    ValueError
        If coordinates are not present in the file and are not provided as
        arguments.

    Notes
    -----
    Automatically adds lat, lon coords if present inside
    <coordinates>lon,lat,height<\coordinates> brackets
    """
    from windkit.io.wasp.lib import read_lib

    lib_data = read_lib(lib_file)

    if crs is None:
        crs = "EPSG:4326"

    # Fall back to file-embedded coordinates when none are provided
    if all(c is None for c in (west_east, south_north, height)):
        file_coords = lib_data["coords"]
        if file_coords["west_east"] is None:
            raise ValueError(
                f"Coordinates not found in {lib_file}, "
                "please set 'west_east', 'south_north', and 'height' explicitly. "
                "These values should be in the projection given by the 'crs' argument,"
                " which defaults to the WGS84 projection."
            )
        west_east = file_coords["west_east"]
        south_north = file_coords["south_north"]
        height = file_coords["height"]

    if description is None:
        description = lib_data["metadata"]["description"] or ""

    # Add height to wdfreq
    nhgt = len(lib_data["gen_height"])
    wdfreq = np.tile(lib_data["wdfreq"][:, np.newaxis, :], (1, nhgt, 1))

    return _weibull_to_dataset(
        wdfreq,
        lib_data["A"],
        lib_data["k"],
        lib_data["gen_roughness"],
        lib_data["gen_height"],
        south_north,
        west_east,
        height,
        crs,
        description=description,
    )


def _weibull_to_dataset(
    wdfreq,
    A,
    k,
    gen_roughness,
    gen_height,
    south_north,
    west_east,
    height,
    crs,
    **kwargs,
):
    """
    Converts parsed xml gwc object to WindKit gwc xarray dataset

    Parameters
    ----------
    wdfreq : 1-D sequence of floats
        Wind direction frequencies. Dimensions=[sector, gen_height, gen_roughnness]
    A : numpy
        Weibull A parameters.  Dimensions=[sector, gen_height, gen_roughnness]
    k : numpy
        Weibull k parameters.  Dimensions=[sector, gen_height, gen_roughnness]
    gen_roughness : numpy
        Array of generalized roughnesses
    gen_height : numpy
        Array of generalized heights
    west_east : float or None, optional
        West-East coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    south_north : float or None, optional
        South-North coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    height : float or None, optional
        Height coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`
        Defaults to 4326 (Lat-Lon on the WGS84 geodetic datum)

    kwargs : dict, optional
        Other key-word arguments are added as attributes to the dataset.

    Returns
    -------
    xarray.Dataset
        WindKit GWC dataset
    """

    n_sectors, _, _ = wdfreq.shape

    na = np.newaxis

    # Create dataset
    ds = create_dataset(west_east, south_north, height, crs).drop_vars("output")
    ds.attrs = kwargs

    # Add variables
    dims = ("sector", "gen_height", "gen_roughness", "point")
    ds["A"] = (dims, A[..., na])
    ds["k"] = (dims, k[..., na])
    ds["wdfreq"] = (dims, wdfreq[..., na])

    # Add coordinates
    ds = ds.assign_coords(
        {
            **_create_coords(gen_height, "gen_height", _GEN_COORDS_META).coords,
            **_create_coords(gen_roughness, "gen_roughness", _GEN_COORDS_META).coords,
            **create_sector_coords(n_sectors).coords,
        }
    )

    ds["wdfreq"] = ds["wdfreq"] / ds["wdfreq"].sum(dim="sector")

    return ds.transpose("gen_height", "gen_roughness", "sector", "point")


def _read_gwc_file(
    gwc_file,
    crs=None,
    west_east=None,
    south_north=None,
    height=None,
    description=None,
):
    """Read Generalized Wind Climate from XML-based .gwc file.

    Parameters
    ----------
    gwc_file : str, pathlib.Path
        input file
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`
        Defaults to 4326 (Lat-Lon on the WGS84 geodetic datum)
    west_east : float or None, optional
        West-East coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    south_north : float or None, optional
        South-North coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    height : float or None, optional
        Height coordinate of the GWC grid, by default None, which will attempt to
        read from the file.
    description : str or None, optional
        Header string to use for .lib and .gwc files, by default None, which will
        attempt to read from the file.

    Returns
    -------
    xarray.Dataset
        WindKit GWC dataset

    Raises
    ------
    ValueError
        If no RveaGeneralisedMeanWindClimate is found in the file.
    ValueError
        If coordinates are not found in the file and are not provided explicitly.

    Warns
    -----
    UserWarning
        If 'height' is not found in the file and are not provided explicitly.
        It will be set to 0.0

    """
    from windkit.io.wasp.gwc import read_gwc as _read_gwc_dict

    if crs is None:
        crs = "EPSG:4326"

    gwc_data = _read_gwc_dict(gwc_file)
    file_coords = gwc_data["coords"]

    if west_east is None:
        west_east = file_coords["west_east"]

    if south_north is None:
        south_north = file_coords["south_north"]

    if height is None:
        height = file_coords["height"]

    if description is None:
        description = gwc_data["metadata"]["description"] or ""

    if west_east is None or south_north is None:
        raise ValueError(
            "'west_east' or 'south_north' coordinate not found in file or provided as argument. "
            + "Please set 'west_east' and 'south_north' explicitly."
        )

    if height is None:
        height = 0.0
        warnings.warn(
            "No height found in file or provided as argument, using 0 m. Set 'height' explicitly to avoid this warning.",
        )

    return _weibull_to_dataset(
        wdfreq=gwc_data["wdfreq"],
        A=gwc_data["A"],
        k=gwc_data["k"],
        gen_roughness=gwc_data["gen_roughness"],
        gen_height=gwc_data["gen_height"],
        west_east=west_east,
        south_north=south_north,
        height=height,
        crs=crs,
        description=description,
    )


@validate_input(_GWC_SCHEMA)
def _reproject_gwc(gwc, /, to_crs):
    """Reprojects Generalized wind climate dataset.

    Parameters
    ----------
    gwc: xarray.Dataset
        Valid GWC dataset.
    crs : int, dict, str or pyproj.crs.CRS
        Value to initialize `pyproj.crs.CRS`

    Returns
    -------
    xarray.Dataset
        Point based generalized wind climate dataset in new projection.
    """
    if not crs_are_equal(gwc, to_crs):
        return reproject(gwc, to_crs)

    # Return point based dataset even if not reprojected
    ds = to_point(gwc)
    return _update_history(ds)
