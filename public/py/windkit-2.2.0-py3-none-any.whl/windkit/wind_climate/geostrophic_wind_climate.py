# (c) 2026 DTU Wind Energy
"""Geostrophic wind climate module

A geostrophic wind climate is somehwat similar as a binned wind climate, but
contains 6 variables:
geo_wv_freq is the geostrophic wind speed frequency binned by wind speed
and wind direction, where the whole histogram sums to 1 (note
that in a binned wind climate the frequency in one sector sums to one).
The geostrophic turning is the turning of the wind in the boundary layer
for each bin given by the geostrophic drag law.

A valid geostrophic wind climate therefore has dimensions ``sector`` and ``wsbin``
and variables ``geo_wv_freq``, ``geo_turn``, ``z0meso``, ``slfmeso``, ``displ``,
 ``flow_sep_height``. Also it must have a valid spatial structure.
"""

__all__ = ["create_geowc", "is_geowc", "validate_geowc"]

import numpy as np
import xarray as xr

from windkit.wind_climate._validation import _validate_freq_sums_to_one
from windkit.wind_climate.binned_wind_climate import create_bwc
from windkit.xarray_structures._schema import (
    Check,
    DatasetSchema,
    DataVar,
    make_is_valid,
    make_validator,
)
from windkit.xarray_structures.empty import _native_batch_horizontal, _native_store
from windkit.xarray_structures.metadata import (
    _GEOWC_ATTRS,
    _update_history,
    _update_var_attrs,
)

# How the geostrophic Weibull scale relates to the extent of the wind speed axis,
# taken from a geostrophic climate generalized from measurements: its axis reaches
# 58 m/s and its scale is near 18.
_A_OVER_AXIS = (0.26, 0.36)
# Geostrophic wind weibull K range
_GEOSTROPHIC_K_RANGE = (1.9, 2.6)


def _validate_geo_wv_freq_sums_to_one(ds):
    """Check that 'geo_wv_freq' sums to 1 across 'sector' and 'wsbin'.

    Parameters
    ----------
    ds : xarray.Dataset
        Geostrophic wind climate dataset with a 'geo_wv_freq' data variable.

    Returns
    -------
    list of str
        Error message naming the offending locations and sums found, or an
        empty list if 'geo_wv_freq' sums to 1 everywhere.
    """
    return _validate_freq_sums_to_one(ds, "geo_wv_freq", ("sector", "wsbin"))


_GEOWC_SCHEMA = DatasetSchema(
    name="geowc",
    data_vars={
        "geo_wv_freq": DataVar(dims=("wsbin", "sector")),
        "geo_turn": DataVar(dims=("wsbin", "sector")),
        "z0meso": DataVar(dims=("sector",)),
        "slfmeso": DataVar(dims=("sector",)),
        "displ": DataVar(dims=("sector",)),
        "flow_sep_height": DataVar(dims=("sector",)),
    },
    dims=("wsbin", "sector"),
    coords=("sector", "wsbin"),
    extra_checks=(Check(_validate_geo_wv_freq_sums_to_one),),
)

validate_geowc = make_validator(_GEOWC_SCHEMA)

is_geowc = make_is_valid(_GEOWC_SCHEMA)


def create_geowc(
    output_locs,
    n_sectors=4,
    n_wsbins=60,
    wsbin_width=1.0,
    not_empty=True,
    seed=9876538,
    weibull_A=None,
    weibull_k=None,
):
    """
    Create a geostrophic wind climate dataset.

    A geostrophic wind climate is a binned wind climate of the *geostrophic*
    wind, so this is :func:`create_bwc` with three differences:

    * the wind is stronger, so the Weibull scale and the wind speed axis both
      reach further - the default axis runs to 60 m s-1 and the distribution
      peaks near 14, against 30 and 5 for a surface climate;
    * the speed and direction frequencies are combined into a single
      ``geo_wv_freq``, which sums to 1 over the whole ``(wsbin, sector)`` array
      rather than to 1 within each sector; and
    * the mesoscale roughness description and the geostrophic turning are added.

    Everything else - sampling the Weibull at the bin centres, and keeping the
    distribution inside the wind speed axis instead of cutting it off on its own
    slope - comes from :func:`create_bwc`, so those rules are defined once.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Output geospatial information.
    n_sectors : int
        Number of sectors, defaults to 4.
    n_wsbins : int
        Number of wind speed bins, defaults to 60. Geostrophic winds are much
        stronger than surface winds, so the axis has to reach far higher than
        for a binned wind climate.
    wsbin_width : float
        Width of each wind speed bin [m s-1], defaults to 1.0.
    not_empty : bool
        If true, the empty dataset is filled with random meaningful data.
    seed : int
        Seed for the random data, defaults to 9876538.
    weibull_A : float, tuple of float, or None
        Weibull scale parameter [m s-1]. A scalar pins it and a ``(low, high)``
        pair draws it per point and sector. If None, it is derived from the
        extent of the wind speed axis, so the distribution decays within the
        axis for any ``n_wsbins`` and ``wsbin_width``.
    weibull_k : float, tuple of float, or None
        Weibull shape parameter, resolved as in :func:`create_bwc`. If None,
        drawn from ``(1.9, 2.6)``.

    Returns
    -------
    ds : xarray.Dataset
        Geostrophic wind climate dataset, either empty or filled with random
        numbers.
    """
    if weibull_A is None:
        # Scale to the axis, so the distribution decays inside it whatever bin
        # count and width are asked for. The fraction is taken from a
        # geostrophic climate generalized from measurements, whose axis reaches
        # 58 m/s with a Weibull scale near 18.
        max_speed = n_wsbins * wsbin_width
        weibull_A = (_A_OVER_AXIS[0] * max_speed, _A_OVER_AXIS[1] * max_speed)
    if weibull_k is None:
        weibull_k = _GEOSTROPHIC_K_RANGE

    bwc = create_bwc(
        output_locs,
        n_sectors=n_sectors,
        n_wsbins=n_wsbins,
        wsbin_width=wsbin_width,
        not_empty=not_empty,
        seed=seed,
        weibull_A=weibull_A,
        weibull_k=weibull_k,
    )

    ds = bwc.drop_vars(["wsfreq", "wdfreq"])
    # A binned wind climate keeps speed and direction frequencies apart, with the
    # speeds summing to 1 within each sector. A geostrophic one carries their
    # product, summing to 1 over the whole array.
    ds["geo_wv_freq"] = bwc["wsfreq"] * bwc["wdfreq"]
    ds["geo_turn"] = (
        xr.full_like(ds["geo_wv_freq"], 22.0) if not_empty else ds["geo_wv_freq"].copy()
    )

    # The mesoscale roughness description is a property of the location, not
    # of the height, and a synthetic climate has no site-effects producer to
    # apply a height-dependent flow transfer to `displ` either - so all four
    # are built directly on the horizontal batch, without a separate height
    # axis, rather than on `bwc`'s full shape with height collapsed
    # afterward. `z0meso`/`slfmeso`/`flow_sep_height` declare
    # `height_dim_policy="forbidden"`; `displ` declares `"optional"` because
    # a real (non-synthetic) GeoWC coming from a site-effects producer may
    # carry height, but this one never does.
    horiz_dims, horiz_shape = _native_batch_horizontal(output_locs)
    n_horiz = int(np.prod(horiz_shape, dtype=int))
    for name, value in (
        ("z0meso", 0.1),
        ("slfmeso", 1.0),
        ("flow_sep_height", 0.0),
        ("displ", 0.0),
    ):
        values = np.full((n_sectors, n_horiz), value if not_empty else np.nan)
        out_dims, array = _native_store(
            values, horiz_dims, horiz_shape, core_dims=("sector",)
        )
        da = xr.DataArray(array, dims=out_dims, attrs=dict(_GEOWC_ATTRS[name]))
        ds[name] = da

    ds = _update_var_attrs(ds, _GEOWC_ATTRS)
    return _update_history(ds)
