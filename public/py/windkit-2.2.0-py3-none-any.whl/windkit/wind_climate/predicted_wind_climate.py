"""
Module for working with predicted wind climates
"""

__all__ = [
    "create_pwc",
]

import xarray as xr

from windkit.xarray_structures.metadata import _update_history
from windkit.topography.topography import create_wasp_site_effects
from windkit.wind_climate.weibull_wind_climate import create_wwc
from windkit.wind_climate.wind_climate import create_met_fields


def create_pwc(
    output_locs,
    n_sectors=12,
    not_empty=True,
    seed=9876538,
    met_fields=["A_combined", "k_combined", "power_density"],
    site_effects=["site_elev"],
    include_name=True,
    **kwargs,
):
    """Empty predicted wind climate with optional variables.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Output geospatial information
    n_sectors : int
        Number of sectors, defaults to 12.
    not_empty : bool
        If true, the empty dataset is filled with random
        meaningful data. Defaults to True.
    seed : int
        Seed for the random data, defaults to 9876538.
    met_fields : list of str, string
        List of met fields variables to include in the output. If None, nothing
        is included. Defaults to A_combined, k_combined, power_density
    include_site_effects : list of str, str
        List of site factors variables to include in the output. If None, nothing
        is included. Defaults to site_elev.
    include_name : bool
        If true, include a "name" coordinate, which is a string associated
        with the output's spatial batch dimension(s) (``point``,
        ``stacked_point``, or the cuboid axes), as it is commonly seen in rsf
        and wrg files. Defaults to True.
    kwargs : dict
        Additional arguments.

    Returns
    -------
    ds : xarray.Dataset
        empty predicted wind climate dataset.
    """

    # output_locs is passed straight through: create_wwc,
    # create_wasp_site_effects and create_met_fields each build directly on
    # the caller's own spatial dimensions (windkit#805), so an outer stack and
    # unstack here would only reintroduce the promotion of a reduced axis to a
    # size-one dimension that they no longer perform.
    ds_list = [create_wwc(output_locs, n_sectors)]
    # increment seed +1
    seed += 1
    if site_effects:
        # ds_list.append(empty_wasp_site_effects(output_locs, n_sectors)[include_site_effects])
        ds_list.append(
            create_wasp_site_effects(
                output_locs,
                n_sectors,
                site_effects=site_effects,
                seed=seed,
                not_empty=not_empty,
            )
        )
    # increment seed +1
    seed += 1
    if met_fields is not None:
        ds_list.append(
            create_met_fields(
                output_locs,
                n_sectors,
                not_empty=not_empty,
                met_fields=met_fields,
                seed=seed,
            )
        )

    pwc = xr.merge(
        ds_list, combine_attrs="override", compat="no_conflicts", join="outer"
    )
    if include_name:
        if "point" in pwc.dims:
            name_dims = ("point",)
        elif "stacked_point" in pwc.dims:
            name_dims = ("stacked_point",)
        else:
            name_dims = tuple(
                dim for dim in ("height", "south_north", "west_east") if dim in pwc.dims
            )

        name = xr.DataArray("GridPoint")
        for dim in reversed(name_dims):
            name = name.expand_dims({dim: pwc.sizes[dim]})
        pwc = pwc.assign_coords(name=name)

    return _update_history(pwc)
