# (c) 2026 DTU Wind Energy
"""
WAsP Workspace module.

Module containing a class and related methods for importing WAsP workspace
XML and converting it to WindKit data structures. The workspace members are
parsed by :mod:`windkit.io.wasp.wwh`; this module turns the parsed data into
WindKit datasets.
"""

__all__ = ["Workspace"]

import tempfile
import warnings
import zipfile
from pathlib import Path

import lxml.etree as ET
import numpy as np
import pandas as pd
from packaging import version

from windkit.xarray_structures.metadata import (
    _AEP_ATTRS,
    _BWC_ATTRS,
    _MEAN_BARO_ATTRS,
    _MEAN_STAB_ATTRS,
    _MET_ATTRS,
    _TOPO_EFFECTS_ATTRS,
    _WEIB_ATTRS,
    _update_history,
    _update_var_attrs,
)
from windkit.spatial import create_dataset, crs_are_equal, set_crs
from windkit.topography.vector_map import _crs_from_map_file, _read_vector_map
from windkit.wind_climate.binned_wind_climate import _data_dict_to_dataset
from windkit.wind_climate.generalized_wind_climate import _weibull_to_dataset
from windkit.wind_farm.wind_turbine_generator import (
    _finalize_wtg_dataset,
    _wtg_dict_to_dataset,
)
from windkit.xarray_structures.sector import create_sector_coords

_MAP_TYPE_MAPPING = {
    "RoughnessChangeLines": "roughness",
    "ElevationContours": "elevation",
    "Boundaries": "boundaries",
}

# The oldest workspace format this module reads
_MIN_FORMAT_VERSION = "4.01.0002"

_PROJECT = "WAsP project"
_VECTOR_MAP = "Vector map"
_TURBINE_SITE = "Turbine site"
_TURBINE_SITE_GROUP = "Turbine site group"
# Objects that hold a site, and so its site effects and predicted wind climate
_SITE_OBJECTS = ("Met. station", "Reference site", _TURBINE_SITE, _TURBINE_SITE_GROUP)

_SITE_EFFECT_VARIABLES = (
    "z0meso",
    "slfmeso",
    "displ",
    "roughness_speedups",
    "roughness_turnings",
    "orographic_speedups",
    "orographic_turnings",
    "obstacle_speedups",
    "obstacle_turnings",
    "dirrix",
)

# WAsP stores energy in Wh/y; WindKit AEP variables are in GWh/y
_WH_PER_GWH = 1e9
_WASP_NET_AEP_DESCRIPTION = (
    "WAsP's net annual energy production: the gross annual energy production "
    "minus wake losses. WAsP does not model technical losses, so it is not net_aep."
)

# The reference values WAsP derives its air density from, which WindKit does
# not carry in its own metadata; the names are PyWAsP's for the same values
_AIR_DENSITY_REFERENCE_ATTRS = {
    "surface_pressure": {
        "standard_name": "surface_air_pressure",
        "long_name": "Reference surface air pressure",
        "units": "Pa",
    },
    "temperature_celcius": {
        "standard_name": "air_temperature",
        "long_name": "Reference air temperature",
        "units": "degC",
    },
    "relative_humidity": {
        "standard_name": "relative_humidity",
        "long_name": "Reference relative humidity",
        "units": "%",
    },
    "lapse_rate": {
        "standard_name": "air_temperature_lapse_rate",
        "long_name": "Temperature lapse rate",
        "units": "K m-1",
    },
    "source_elevation": {
        "standard_name": "surface_altitude",
        "long_name": "Elevation the reference pressure applies at",
        "units": "m",
    },
    "source_elevation_temperature": {
        "standard_name": "surface_altitude",
        "long_name": "Elevation the reference temperature applies at",
        "units": "m",
    },
}


def _add_point_variable(ds, key, parts):
    """Add the float ``key`` of each site's part as a (point) variable, NaN where not stored.

    Left out when no site stores it.
    """
    values = [part[key] for part in parts]
    if all(value is None for value in values):
        return
    ds[key] = (
        ("point",),
        np.array([np.nan if value is None else value for value in values]),
    )


def _stack_sites(parts, key):
    """Stack the per-sector arrays of ``key`` over the sites into a (sector, point) array."""
    return np.stack([part[key] for part in parts], axis=-1)


class Workspace:
    """
    Workspace class for interacting with WAsP workspace XML files

    Objects in the workspace are addressed by their integer ID in
    ``catalogue``. Printing the workspace lists the IDs, object descriptions
    and names of all objects as a tree, and :meth:`get_ids` finds them by
    object description and name. A getter called without an ID reads the only
    object of its kind in the workspace. Positions come from the workspace
    itself, and so does their CRS: the one the vector maps of the object's
    WAsP project state, else the one all vector maps of the workspace state.
    Every getter that returns positions takes a ``crs`` argument for a
    workspace that states none, which also overrides a stated CRS with a
    warning. Besides the inputs (observed and generalised wind
    climates, vector maps, turbine positions), the results WAsP stored in the
    workspace can be read:
    predicted wind climates, site effects, annual energy production and the
    Weibull fit of the observed wind climate. These are WAsP's values as
    stored, parsed without rounding by :mod:`windkit.io.wasp.wwh`.

    Parameters
    -------
    tree : lxml.etree._ElementTree
        WAsP workspace XML tree
    path: str or Path
        File path.

    """

    def __init__(self, tree, path):
        self.tree = tree
        self.path = path
        self.root = tree.getroot()
        self._vector_map_id = []
        self._met_mast_id = None
        self.mast_coords = None
        self._map_files = {}
        self.catalogue = {}
        self.crs = None
        try:
            self.format_version = self.root.attrib["FormatVersion"]
        except (AttributeError, KeyError):
            raise TypeError("Not a WWH file")
        if version.parse(self.format_version) < version.parse(_MIN_FORMAT_VERSION):
            raise NotImplementedError(
                f"The input WWH file has version {self.format_version} which is not "
                f"supported. Only version {_MIN_FORMAT_VERSION} and higher of WWH "
                "files can be loaded."
            )

        self._create_catalogue()
        self._get_vector_map_id()
        self._get_map_filenames()
        self._update_map_files_dict()
        self._update_met_mast_coords()

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        crs = "no single CRS" if self.crs is None else f"CRS EPSG:{self.crs}"
        return (
            f"WAsP workspace {Path(self.path).name} "
            f"(format version {self.format_version}, {crs})\n"
            + self._objects_table(self.catalogue, indent=True)
        )

    def _ancestors(self, ID):
        """IDs of the objects above an object in the workspace tree, nearest first."""
        ancestors = []
        parent = self.catalogue[ID]["ParentID"]
        while parent is not None:
            ancestors.append(parent)
            parent = self.catalogue[parent]["ParentID"]
        return ancestors

    def _depth(self, ID):
        """Number of objects above an object in the workspace tree."""
        return len(self._ancestors(ID))

    def _name(self, ID):
        """Name of an object as shown in WAsP, without surrounding whitespace."""
        return self._get_object_xml(ID).attrib["Description"].strip()

    def _objects_table(self, ids, indent=False):
        """
        Table of the IDs, object descriptions and names of objects.

        Parameters
        ----------
        ids : iterable of int
            IDs of the objects, in the order of the rows.
        indent : bool, optional
            If True, indent the object descriptions by their depth in the
            workspace tree. Defaults to False.

        Returns
        -------
        str
            One line per object below a header line.
        """
        rows = [
            (
                str(ID),
                "  " * (self._depth(ID) if indent else 0)
                + self.catalogue[ID]["ObjectDescription"],
                self._name(ID),
            )
            for ID in ids
        ]
        id_width = max([len("ID"), *(len(row[0]) for row in rows)])
        object_width = max([len("Object"), *(len(row[1]) for row in rows)])
        return "\n".join(
            f"{ID:>{id_width}}  {obj:<{object_width}}  {name}".rstrip()
            for ID, obj, name in [("ID", "Object", "Name"), *rows]
        )

    @classmethod
    def read_wwh(cls, path):
        """
        Instantiated Workspace class using WAsP Workspace Hierarchy (WWH) file.

        Parameters
        ----------
        path : str, path
            Path to WAsP Workspace Hierarchy file to read.

        Returns
        -------
        Workspace
            Instantiated Workspace class.

        Raises
        ------
        zipfile.BadZipFile
            If the file is not a zip archive.
        WindkitFileFormatError
            If the archive holds no ``Inventory.xml``.
        """
        from windkit.io.wasp.wwh import _parse_inventory

        return cls(_parse_inventory(path), path)

    def _create_catalogue(self):
        """
        Creates catalogue of objects from WAsP workspace XML tree.

        Each object holds its element as "Element", the ID of the object
        whose ``ChildMembers`` holds it as "ParentID" (None for the root) and
        the IDs of the objects its ``ChildMembers`` holds as "ChildrenID".
        """
        from windkit.io.wasp.wwh import _walk_hierarchy

        elements, parents, children = _walk_hierarchy(self.root)
        self.catalogue = {}
        for ID, element in enumerate(elements):
            object_description = element.attrib["ClassDescription"]
            self.catalogue[ID] = {
                "ObjectDescription": object_description,
                "Element": element,
                "ParentID": parents[ID],
                "ChildrenID": children[ID],
                "CRS": {},
            }
            if object_description == "Met. station":
                self._met_mast_id = ID

    def _get_vector_map_id(self):
        """
        Updates self._vector_map_id object ids corresponding to vector maps.
        """
        for obj_id, obj in self.catalogue.items():
            if obj["ObjectDescription"] == _VECTOR_MAP:
                self._vector_map_id += [obj_id]

    def _member(self, ID, *parts):
        """
        Identity and the given parts of the parsed data of an object.

        Only the parts asked for are parsed and validated, so a malformed part
        does not stop a getter that does not read it.

        Parameters
        ----------
        ID : int
            ID of the object.
        *parts : str
            Keys of the parts to parse, see
            :func:`windkit.io.wasp.parse_wwh_member_element`.

        Returns
        -------
        dict
            ``"id"``, ``"class_id"``, ``"class_description"``,
            ``"description"`` and the parts asked for.
        """
        from windkit.io.wasp.wwh import _parse_member

        return _parse_member(self._get_object_xml(ID), str(self.path), parts)

    def _get_map_filenames(self):
        """
        Updates self._map_files with file names of vector maps in .wwh file.

        A vector map keeps each layer in a child data layer; in format
        4.01.0002 it holds one file with both elevation and roughness lines.
        """
        for ID in self._vector_map_id:
            self._map_files[ID] = {}
            for child in self.catalogue[ID]["ChildrenID"]:
                layer = self._member(child, "data_layer")["data_layer"]
                map_type = (
                    None
                    if layer is None
                    else _MAP_TYPE_MAPPING.get(layer["phenomenon"])
                )
                if map_type is not None:
                    self._map_files[ID][map_type] = {
                        "filename": layer["archive_file"],
                        "crs": None,
                    }
            own = self._member(ID, "data_layer")["data_layer"]
            if not self._map_files[ID] and own is not None and own["archive_file"]:
                for map_type in ("elevation", "roughness"):
                    self._map_files[ID][map_type] = {
                        "filename": own["archive_file"],
                        "crs": None,
                    }

    def _update_map_files_dict(self):
        """
        Updates self._map_files with crs of vector maps in .wwh file
        """
        crs_ls = []
        for ID, metadata in self._map_files.items():
            with tempfile.TemporaryDirectory() as tempfolder:
                path_tmp = Path(tempfolder)
                for map_type, info in metadata.items():
                    with zipfile.ZipFile(self.path) as myZip:
                        myZip.extract(info["filename"], path_tmp)
                    crs = _crs_from_map_file(path_tmp.joinpath(info["filename"]))
                    self._map_files[ID][map_type]["crs"] = crs
                    self.catalogue[ID]["CRS"].update({map_type: crs})
                    if crs is not None:
                        crs_ls += [crs]
        crs_ls = np.unique(np.asarray(crs_ls))
        if len(crs_ls) == 1:
            self.crs = int(crs_ls[0])

    def _update_met_mast_coords(self):
        """
        Updates self.mast_coords which contains met mast position coordinates.
        """
        if self._met_mast_id is not None:
            member = self._member(self._met_mast_id, "coords")
            coords = member["coords"]

            self.mast_coords = {
                "height": float(coords["height"]),
                "west_east": float(coords["west_east"]),
                "south_north": float(coords["south_north"]),
                "description": member["description"],
                "crs": self.crs,
            }

    def _get_object_xml(self, ID):
        """
        Extracts objects XML from WAsP workspace XML

        Parameters
        ----------
        ID : int
            ID of object to be extracted

        Returns
        -------
        lxml.etree._Element
            Object XML representation
        """
        return self.catalogue[ID]["Element"]

    def _write_object(self, ID, path):  # pragma: no cover private_method
        """
        Write XML object to XML file

        Parameters
        ----------
        ID : int
            ID of object to be written to XML file
        path : str, path
            Path to XML file

        Returns
        -------
        file
            XML file on user machine
        """
        return ET.ElementTree(self._get_object_xml(ID)).write(path)

    def _print_object(self, ID):  # pragma: no cover private_method
        """
        Prints XML object

        Parameters
        ----------
        ID : int
            XML object ide

        Returns
        -------
        str
            String of XML object
        """
        return print(ET.tostring(self._get_object_xml(ID), encoding="unicode"))

    def _resolve_id(self, ID, object_descriptions, linked_to, default=None):
        """
        ID of the object a getter reads.

        Parameters
        ----------
        ID : int or None
            ID given to the getter.
        object_descriptions : tuple of str
            Object descriptions the getter can read.
        linked_to : str
            What the getter reads, for the error message of a wrong ID.
        default : tuple of str, optional
            Object descriptions to find the object among when ID is None.
            Defaults to ``object_descriptions``.

        Returns
        -------
        int
            ``ID``, or when it is None the ID of the only object of the
            ``default`` descriptions in the workspace.

        Raises
        ------
        ValueError
            If ID does not exist or is not an object of
            ``object_descriptions``, or if ID is None and the workspace holds
            no or several objects of the ``default`` descriptions.
        """
        if ID is not None:
            if ID not in self.catalogue:
                raise ValueError("ID does not exist in object catalogue")
            if self.catalogue[ID]["ObjectDescription"] not in object_descriptions:
                raise ValueError(f"ID is not linked to {linked_to}")
            return ID

        default = object_descriptions if default is None else default
        quoted = [f"'{description}'" for description in default]
        kinds = " or ".join(
            [", ".join(quoted[:-1]), quoted[-1]] if quoted[1:] else quoted
        )
        candidates = [
            candidate
            for candidate, obj in self.catalogue.items()
            if obj["ObjectDescription"] in default
        ]
        if len(candidates) == 0:
            raise ValueError(f"The workspace holds no {kinds} object")
        if len(candidates) > 1:
            raise ValueError(
                f"The workspace holds {len(candidates)} {kinds} objects, so ID "
                f"must be given. Candidates:\n{self._objects_table(candidates)}"
            )
        return candidates[0]

    def _site_ids(self, ID):
        """IDs of the sites of an object: itself, or the turbine sites of a turbine site group."""
        if self.catalogue[ID]["ObjectDescription"] != _TURBINE_SITE_GROUP:
            return [ID]
        return [
            child
            for child in self.catalogue[ID]["ChildrenID"]
            if self.catalogue[child]["ObjectDescription"] == _TURBINE_SITE
        ]

    def _flagged_ids(self, ID, site_ids):
        """IDs whose results flags apply to an object: itself, its sites and a turbine site's group."""
        parent = self.catalogue[ID]["ParentID"]
        if (
            self.catalogue[ID]["ObjectDescription"] == _TURBINE_SITE
            and self.catalogue[parent]["ObjectDescription"] == _TURBINE_SITE_GROUP
        ):
            return [parent, ID, *site_ids]
        return [ID, *site_ids]

    def _stated_crs(self, ID):
        """
        CRS the workspace states for the positions of an object, or None.

        That is the CRS the vector maps of the object's WAsP project agree
        on, else the one all vector maps of the workspace agree on.
        """
        project = next(
            (
                candidate
                for candidate in [ID, *self._ancestors(ID)]
                if self.catalogue[candidate]["ObjectDescription"] == _PROJECT
            ),
            None,
        )
        if project is not None:
            stated = {
                info["crs"]
                for map_id, layers in self._map_files.items()
                if project in self._ancestors(map_id)
                for info in layers.values()
                if info["crs"] is not None
            }
            if len(stated) == 1:
                return stated.pop()
        return self.crs

    def _crs(self, ID, crs=None, stated=None, stacklevel=3):
        """
        The CRS to label an object's positions with.

        Parameters
        ----------
        ID : int
            ID of the object.
        crs : int, dict, str, pyproj.crs.CRS or None
            CRS given to the getter.
        stated : int, str or None, optional
            CRS the positions are in. Defaults to None, which takes the one the
            workspace states for the object, see ``_stated_crs``.
        stacklevel : int, optional
            Stack level of the warning, so it points at the getter's caller.

        Returns
        -------
        int, dict, str or pyproj.crs.CRS
            ``crs`` when given, else the stated CRS.

        Raises
        ------
        ValueError
            If neither is known.

        Warns
        -----
        UserWarning
            If ``crs`` differs from the stated CRS.
        """
        if stated is None:
            stated = self._stated_crs(ID)
        if crs is None:
            if stated is None:
                raise ValueError(
                    f"No CRS associated with object {ID} ('{self._name(ID)}'): the "
                    "vector maps of its project and of the workspace state no CRS, "
                    "or different ones. Pass crs to give it."
                )
            return stated
        if stated is not None and not crs_are_equal(crs, stated):
            warnings.warn(
                f"crs={crs!r} overrides {stated!r}, the CRS the workspace states "
                f"for object {ID} ('{self._name(ID)}')",
                UserWarning,
                stacklevel=stacklevel,
            )
        return crs

    def _sites_dataset(self, site_ids, part, crs):
        """
        Point dataset of sites and the requested part of each site's parsed data.

        Parameters
        ----------
        site_ids : list of int
            IDs of the sites, in the order of the output points.
        part : str
            Key of the parsed member data to return per site, e.g.
            "predicted_wind_climate".
        crs : int, dict, str or pyproj.crs.CRS
            CRS of the site coordinates.

        Returns
        -------
        xarray.Dataset
            Point dataset with sector coordinates and the site names as the
            ``name`` coordinate.
        list of dict
            The ``part`` of each site.

        Raises
        ------
        ValueError
            If there are no sites, a site does not hold the part, or its
            sectors are not the ones windkit creates for its number of sectors.
        """
        if len(site_ids) == 0:
            raise ValueError("The turbine site group holds no turbine sites")

        members = [self._member(site_id, "coords", part) for site_id in site_ids]
        names = [member["description"].strip() for member in members]
        sector_coords = None
        parts = []
        for site_id, member, name in zip(site_ids, members, names):
            data = member[part]
            if data is None:
                raise ValueError(
                    f"Object {site_id} ('{name}') holds no {part.replace('_', ' ')}; "
                    "calculate it in WAsP and save the workspace"
                )
            if sector_coords is None:
                sector_coords = create_sector_coords(len(data["sector"]))
            expected = sector_coords["sector"].values
            if data["sector"].shape != expected.shape or not np.allclose(
                data["sector"], expected
            ):
                raise ValueError(
                    f"Object {site_id} ('{name}') has sector centres "
                    f"{data['sector']}, not {expected}"
                )
            parts.append(data)

        ds = create_dataset(
            [member["coords"]["west_east"] for member in members],
            [member["coords"]["south_north"] for member in members],
            [member["coords"]["height"] for member in members],
            crs,
            struct="point",
        ).drop_vars("output")
        ds = ds.assign_coords(
            {**sector_coords.coords, "name": ("point", np.array(names, dtype=object))}
        )
        return ds, parts

    def get_ids(self, object_description):
        """
        IDs of the objects of a kind.

        Parameters
        ----------
        object_description : str
            Object description, as in the catalogue, e.g. "Met. station",
            "Reference site" or "Turbine site group".

        Returns
        -------
        list of int
            IDs of the objects of that kind, in workspace order.

        Raises
        ------
        ValueError
            If the workspace holds no object of that description.
        """
        ids = [
            ID
            for ID, obj in self.catalogue.items()
            if obj["ObjectDescription"] == object_description
        ]
        if not ids:
            held = dict.fromkeys(
                obj["ObjectDescription"] for obj in self.catalogue.values()
            )
            raise ValueError(
                f"The workspace holds no '{object_description}' object. It holds: "
                + ", ".join(f"'{description}'" for description in held)
            )
        return ids

    def get_member(self, ID):
        """
        Parsed data of an object, as plain dicts of numpy arrays.

        Gives access to everything :func:`windkit.io.wasp.parse_wwh_member_element`
        reads, including what the other methods do not turn into datasets, such
        as wake modelling settings or the omnidirectional gross AEP.

        Parameters
        ----------
        ID : int
            ID of the object.

        Returns
        -------
        dict
            See :func:`windkit.io.wasp.parse_wwh_member_element`.

        Raises
        ------
        ValueError
            If the ID does not exist in the catalogue.
        """
        from windkit.io.wasp.wwh import parse_wwh_member_element

        if ID not in self.catalogue:
            raise ValueError("ID does not exist in object catalogue")
        return parse_wwh_member_element(
            self._get_object_xml(ID), context=str(self.path)
        )

    def _warn_outdated_results(self, ids):
        """
        Warn when WAsP marked results of any of the objects as not up to date.

        WAsP flags a calculation of an object as dirty when something it
        depends on changed after it was calculated, so results read from that
        object may not match the rest of the workspace.

        Parameters
        ----------
        ids : list of int
            IDs of the objects whose results are being read.

        Warns
        -----
        UserWarning
            If any of the objects has a calculation that is not up to date.
        """
        outdated = []
        for ID in dict.fromkeys(ids):
            member = self._member(ID, "results_dirty")
            dirty = [
                calculation
                for calculation, is_dirty in member["results_dirty"].items()
                if is_dirty
            ]
            if dirty:
                outdated.append(
                    f"object {ID} ('{member['description'].strip()}'): {', '.join(dirty)}"
                )
        if outdated:
            warnings.warn(
                f"WAsP marked results as not up to date for {'; '.join(outdated)} "
                f"in {self.path}. Recalculate them in WAsP and save the workspace "
                "to read current results.",
                UserWarning,
                stacklevel=3,
            )

    def get_owc(self, ID=None, crs=None):
        """
        Observed wind climate of a met station, as a binned wind climate.

        The position is that of the met station holding the observed wind
        climate in the workspace tree, at its working height, in the CRS the
        workspace states for it.

        Parameters
        ----------
        ID : int, optional
            ID of an observed wind climate. Defaults to None, which reads the
            only observed wind climate in the workspace.
        crs : int, dict, str or pyproj.crs.CRS, optional
            CRS of the position, for a workspace that states none. Overrides
            the stated CRS, with a warning. Defaults to None.

        Returns
        -------
        xarray.Dataset
            Binned wind climate at the position of its met station.

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to an observed wind
            climate, or ID is None and the workspace holds no or several
            observed wind climates.
        ValueError
            If the observed wind climate is not in a met station, or neither
            the workspace nor ``crs`` gives a CRS.

        Warns
        -----
        UserWarning
            If ``crs`` differs from the CRS the workspace states.
        """
        ID = self._resolve_id(ID, ("Observed wind climate",), "binned wind climate")
        station_id = self.catalogue[ID]["ParentID"]
        if self.catalogue[station_id]["ObjectDescription"] != "Met. station":
            raise ValueError(
                f"Object {ID} ('{self._name(ID)}') is not in a met station, so its "
                "position is unknown"
            )

        crs = self._crs(ID, crs)
        owc_data = self._member(ID, "observed_wind_climate")["observed_wind_climate"]
        coords = self._member(station_id, "coords")["coords"]
        bwc = _data_dict_to_dataset({**owc_data, "coords": coords}, crs)
        bwc = _update_var_attrs(bwc, _BWC_ATTRS)
        return _update_history(bwc)

    def get_gwc(
        self,
        ID=None,
        crs=None,
        west_east=None,
        south_north=None,
        height=None,
        description=None,
    ):
        """
        Generalised wind climate stored in the workspace.

        The position is that of the met station the generalised wind climate
        holds in the workspace tree, at its working height, in the CRS the
        workspace states for it, and the description is the met station's
        name. A generalised wind climate without a met station, e.g. one
        imported from a file, is placed at the latitude and longitude it
        stores (EPSG:4326) at 0 m, with its own description.

        Parameters
        ----------
        ID : int, optional
            ID of a generalised wind climate. Defaults to None, which reads the
            only generalised wind climate in the workspace.
        crs : int, dict, str or pyproj.crs.CRS, optional
            CRS of the position, for a workspace that states none. Overrides
            the stated CRS, with a warning. With ``west_east`` and
            ``south_north``, the CRS they are in. Defaults to None.
        west_east, south_north : float, optional
            Position to place the generalised wind climate at instead, in
            ``crs`` or the CRS the workspace states. Give both or neither.

            .. deprecated:: 2.2.0
                Will be removed in windkit 3.0. Assign the coordinates of the
                returned dataset instead.
        height : float, optional
            Height to place the generalised wind climate at instead.

            .. deprecated:: 2.2.0
                Will be removed in windkit 3.0. Assign the coordinate of the
                returned dataset instead.
        description : str, optional
            Description to give the generalised wind climate instead.

            .. deprecated:: 2.2.0
                Will be removed in windkit 3.0. Set the attribute of the
                returned dataset instead.

        Returns
        -------
        xarray.Dataset
            xarray Dataset that is formatted to match the gwc description.

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to a generalised wind
            climate, or ID is None and the workspace holds no or several
            generalised wind climates.
        ValueError
            If the generalised wind climate holds several met stations, has a
            met station but neither the workspace nor ``crs`` gives a CRS, or
            has no met station and stores no position; or if only one of
            ``west_east`` and ``south_north`` is given.

        Warns
        -----
        FutureWarning
            If ``west_east``, ``south_north``, ``height`` or ``description``
            is given.
        UserWarning
            If the generalised wind climate has no met station, so its height
            is set to 0 m.
        UserWarning
            If ``crs`` differs from the CRS the workspace states.
        UserWarning
            If WAsP marked the generalised wind climate as not up to date.

        """
        overrides = (west_east, south_north, height, description)
        if any(value is not None for value in overrides):
            warnings.warn(
                "The west_east, south_north, height and description arguments of "
                "Workspace.get_gwc are deprecated and will be removed in windkit "
                "3.0. Assign the coordinates or the description attribute of the "
                "returned dataset instead.",
                FutureWarning,
                stacklevel=2,
            )
        if (west_east is None) != (south_north is None):
            raise ValueError("west_east and south_north must be given together")
        ID = self._resolve_id(
            ID, ("Generalised wind climate",), "generalised wind climate"
        )
        self._warn_outdated_results([ID])
        gwc_data = self._gwc_data(ID)
        if west_east is None:
            coords, gwc_height, stated, gwc_description = self._gwc_location(
                ID, gwc_data
            )
            crs = self._crs(ID, crs, stated)
        else:
            coords = {"west_east": west_east, "south_north": south_north}
            crs = self._crs(ID) if crs is None else crs
            gwc_description = gwc_data["metadata"]["description"] or ""
            gwc_height = 0.0
            if height is None:
                warnings.warn("No height given, so it is set to 0 m", stacklevel=2)

        gwc = _weibull_to_dataset(
            wdfreq=gwc_data["wdfreq"],
            A=gwc_data["A"],
            k=gwc_data["k"],
            gen_roughness=gwc_data["gen_roughness"],
            gen_height=gwc_data["gen_height"],
            west_east=coords["west_east"],
            south_north=coords["south_north"],
            height=gwc_height if height is None else height,
            crs=crs,
            description=gwc_description if description is None else description,
        )

        gwc = set_crs(gwc, crs)
        gwc = _update_var_attrs(gwc, _WEIB_ATTRS)
        return _update_history(gwc)

    def _gwc_data(self, ID):
        """Parsed generalised wind climate of an object, raising when it holds none."""
        gwc_data = self._member(ID, "generalized_wind_climate")[
            "generalized_wind_climate"
        ]
        if gwc_data is None:
            raise ValueError(
                f"{self.path}: object {ID}: no RveaGeneralisedMeanWindClimate element found"
            )
        return gwc_data

    def _gwc_location(self, ID, gwc_data):
        """
        Where a generalised wind climate sits: its met station, or its own position.

        Parameters
        ----------
        ID : int
            ID of a generalised wind climate.
        gwc_data : dict
            Its parsed data, see :func:`windkit.io.wasp.parse_gwc_element`.

        Returns
        -------
        dict
            Coordinates with "west_east" and "south_north".
        float
            Height above ground.
        int, str or None
            CRS of the coordinates: the one the workspace states, which may
            be None, for a met station, and EPSG:4326 for a stored position.
        str
            Description: the met station's name, or the one stored with the
            generalised wind climate.

        Raises
        ------
        ValueError
            If the generalised wind climate holds several met stations, or has
            no met station and stores no position.

        Warns
        -----
        UserWarning
            If it has no met station, so its height is set to 0 m.
        """
        station_ids = [
            child
            for child in self.catalogue[ID]["ChildrenID"]
            if self.catalogue[child]["ObjectDescription"] == "Met. station"
        ]
        if len(station_ids) > 1:
            raise ValueError(
                f"Object {ID} ('{self._name(ID)}') holds {len(station_ids)} met "
                "stations, so its position is ambiguous"
            )
        if station_ids:
            coords = self._member(station_ids[0], "coords")["coords"]
            return (
                coords,
                coords["height"],
                self._stated_crs(ID),
                self._name(station_ids[0]),
            )

        coords = gwc_data["coords"]
        if coords["west_east"] is None or coords["south_north"] is None:
            raise ValueError(
                f"Object {ID} ('{self._name(ID)}') has no met station and "
                "stores no position"
            )
        warnings.warn(
            f"Object {ID} ('{self._name(ID)}') has no met station, so its "
            "height is set to 0 m"
        )
        return coords, 0.0, "EPSG:4326", gwc_data["metadata"]["description"] or ""

    def _gwc_point(self, ID, gwc_data, crs):
        """Point dataset at the position of a generalised wind climate, see get_gwc."""
        coords, height, stated, _ = self._gwc_location(ID, gwc_data)
        return create_dataset(
            [coords["west_east"]],
            [coords["south_north"]],
            [height],
            self._crs(ID, crs, stated, stacklevel=4),
            struct="point",
        ).drop_vars("output")

    def get_mesoclimate(self, ID=None, crs=None):
        """
        Mesoscale climate WAsP generalised with, at a generalised wind climate.

        These are the sector-wise stability and baroclinicity parameters WAsP
        stored with the generalised wind climate, under the names PyWAsP uses
        for them, so the result can be passed as the ``mesoclimate`` argument
        of PyWAsP's generalization and downscaling. WAsP writes them since
        12.8; older workspaces hold none. The reference values behind the air
        density are read with :meth:`get_air_density_reference`.

        Parameters
        ----------
        ID : int, optional
            ID of a generalised wind climate. Defaults to None, which reads the
            only generalised wind climate in the workspace.
        crs : int, dict, str or pyproj.crs.CRS, optional
            CRS of the position, as in :meth:`get_gwc`. Defaults to None.

        Returns
        -------
        xarray.Dataset
            ``mean_temp_scale_land``, ``rms_temp_scale_land``,
            ``mean_temp_scale_sea``, ``rms_temp_scale_sea``,
            ``mean_pblh_scale_land`` and ``mean_pblh_scale_sea`` (stability),
            and ``mean_dgdz`` and ``mean_dgdz_dir`` (baroclinicity), on
            (sector, point), at the position of the generalised wind climate.

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to a generalised wind
            climate, ID is None and the workspace holds no or several of them,
            the generalised wind climate stores no mesoscale climate, its
            sectors are not windkit's, or its position has no CRS, as in
            :meth:`get_gwc`.

        Warns
        -----
        UserWarning
            If WAsP marked the generalised wind climate as not up to date, or
            as in :meth:`get_gwc`.
        """
        ID = self._resolve_id(
            ID, ("Generalised wind climate",), "generalised wind climate"
        )
        self._warn_outdated_results([ID])
        gwc_data = self._gwc_data(ID)

        parts = {
            "StabilityInputs": gwc_data["stability_inputs"],
            "GeostrophicShearRose": gwc_data["geostrophic_shear"],
        }
        missing = [name for name, part in parts.items() if part is None]
        if missing:
            raise ValueError(
                f"Object {ID} ('{self._name(ID)}') stores no {' and no '.join(missing)}: "
                "only WAsP 12.8 and newer write the mesoscale climate into the workspace"
            )

        sector_coords = create_sector_coords(len(parts["StabilityInputs"]["sector"]))
        expected = sector_coords["sector"].values
        for name, part in parts.items():
            if part["sector"].shape != expected.shape or not np.allclose(
                part["sector"], expected
            ):
                raise ValueError(
                    f"Object {ID} ('{self._name(ID)}'): {name} has sector centres "
                    f"{part['sector']}, not {expected}"
                )

        ds = self._gwc_point(ID, gwc_data, crs).assign_coords(sector_coords.coords)
        for part in parts.values():
            for var, values in part.items():
                if var != "sector":
                    ds[var] = (("sector", "point"), values[:, np.newaxis])
        ds = _update_var_attrs(ds, {**_MEAN_STAB_ATTRS, **_MEAN_BARO_ATTRS})
        return _update_history(ds)

    def get_air_density_reference(self, ID=None, crs=None):
        """
        Reference values behind WAsP's air density, at a generalised wind climate.

        WAsP stores the climatological pressure, temperature and humidity it
        derived the air density from, together with the elevations they apply
        at. They are returned under the names PyWAsP uses when it writes them
        into a generalised wind climate.

        Parameters
        ----------
        ID : int, optional
            ID of a generalised wind climate. Defaults to None, which reads the
            only generalised wind climate in the workspace.
        crs : int, dict, str or pyproj.crs.CRS, optional
            CRS of the position, as in :meth:`get_gwc`. Defaults to None.

        Returns
        -------
        xarray.Dataset
            ``surface_pressure`` (Pa), ``temperature_celcius``,
            ``relative_humidity`` (%), ``lapse_rate`` (K/m, NaN before WAsP
            12.6), ``source_elevation`` and ``source_elevation_temperature``
            (m), on (point), at the position of the generalised wind climate.

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to a generalised wind
            climate, ID is None and the workspace holds no or several of them,
            the generalised wind climate stores no barometric reference data,
            or its position has no CRS, as in :meth:`get_gwc`.

        Warns
        -----
        UserWarning
            As in :meth:`get_gwc`.
        """
        ID = self._resolve_id(
            ID, ("Generalised wind climate",), "generalised wind climate"
        )
        gwc_data = self._gwc_data(ID)
        barometric = gwc_data["barometric_reference"]
        if barometric is None:
            raise ValueError(
                f"Object {ID} ('{self._name(ID)}') stores no BarometricReferenceData"
            )

        ds = self._gwc_point(ID, gwc_data, crs)
        for var, value in barometric.items():
            ds[var] = (("point",), np.array([np.nan if value is None else value]))
        ds = _update_var_attrs(ds, _AIR_DENSITY_REFERENCE_ATTRS)
        return _update_history(ds)

    def get_owc_weibull_fit(self, ID=None, crs=None):
        """
        WAsP's Weibull fit of the observed wind climate at a met station.

        The values are WAsP's as stored in the workspace, parsed without
        rounding. Unlike :meth:`get_wwc` at a met station, which is WAsP's
        self-prediction from the generalised wind climate, this is the fit of
        the observations themselves.

        Parameters
        ----------
        ID : int, optional
            ID of a met station. Defaults to None, which reads the only met
            station in the workspace.
        crs : int, dict, str or pyproj.crs.CRS, optional
            CRS of the positions, for a workspace that states none. Overrides
            the stated CRS, with a warning. Defaults to None.

        Returns
        -------
        xarray.Dataset
            Weibull wind climate with ``A``, ``k`` and ``wdfreq`` on
            (sector, point) at the met station position, with its name as the
            ``name`` coordinate and a ``description`` attribute saying what it
            is. The sector frequencies are not renormalized.

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to a met station, ID is
            None and the workspace holds no or several met stations, neither
            the workspace nor ``crs`` gives a CRS, the met station holds no
            Weibull fit, or its sectors are not windkit's.

        Warns
        -----
        UserWarning
            If WAsP marked the met station's results as not up to date.
        UserWarning
            If ``crs`` differs from the CRS the workspace states.
        """
        ID = self._resolve_id(ID, ("Met. station",), "met station")
        self._warn_outdated_results([ID])
        ds, parts = self._sites_dataset(
            [ID], "observed_wind_climate_weibull_fit", self._crs(ID, crs)
        )
        for var in ("A", "k", "wdfreq"):
            ds[var] = (("sector", "point"), _stack_sites(parts, var))
        ds = _update_var_attrs(ds, _WEIB_ATTRS)
        ds.attrs["description"] = (
            "WAsP Weibull fit of the observed wind climate at met station "
            f"'{self._name(ID)}'"
        )
        return _update_history(ds)

    def get_wwc(self, ID=None, crs=None):
        """
        Predicted wind climate WAsP stored for a site, or for the turbine sites of a group.

        WAsP stores the predicted wind climate as sector-wise Weibull
        distributions, so it is returned as a Weibull wind climate. The values
        are WAsP's as stored in the workspace, parsed without rounding. At a
        met station, it is WAsP's self-prediction from the generalised wind
        climate made from the station's own observations; the Weibull fit of
        those observations is read with :meth:`get_owc_weibull_fit`.

        Parameters
        ----------
        ID : int, optional
            ID of a met station, reference site, turbine site or turbine site
            group. Defaults to None, which reads the only such object in the
            workspace.
        crs : int, dict, str or pyproj.crs.CRS, optional
            CRS of the positions, for a workspace that states none. Overrides
            the stated CRS, with a warning. Defaults to None.

        Returns
        -------
        xarray.Dataset
            Weibull wind climate with ``A``, ``k`` and ``wdfreq`` on
            (sector, point) and ``air_density`` on (point), one point per site
            at its position and working height, with the site names as the
            ``name`` coordinate and a ``description`` attribute saying what it
            is. The sector frequencies are not renormalized. ``air_density``
            is left out when the workspace does not store it (format 3.03).

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to a site or turbine site
            group, ID is None and the workspace holds no or several of them,
            neither the workspace nor ``crs`` gives a CRS, a site holds no
            predicted wind climate, or its sectors are not windkit's.

        Warns
        -----
        UserWarning
            If WAsP marked the results of a site, or of its turbine site
            group, as not up to date.
        UserWarning
            If ``crs`` differs from the CRS the workspace states.
        """
        ID = self._resolve_id(
            ID,
            _SITE_OBJECTS,
            "met station, reference site, turbine site or turbine site group",
        )
        site_ids = self._site_ids(ID)
        self._warn_outdated_results(self._flagged_ids(ID, site_ids))
        ds, parts = self._sites_dataset(
            site_ids, "predicted_wind_climate", self._crs(ID, crs)
        )
        for var in ("A", "k", "wdfreq"):
            ds[var] = (("sector", "point"), _stack_sites(parts, var))
        _add_point_variable(ds, "air_density", parts)
        ds = _update_var_attrs(ds, {**_MET_ATTRS, **_WEIB_ATTRS})
        object_description = self.catalogue[ID]["ObjectDescription"]
        if object_description == "Met. station":
            parent = self.catalogue[ID]["ParentID"]
            source = (
                f" from generalised wind climate '{self._name(parent)}'"
                if self.catalogue[parent]["ObjectDescription"]
                == "Generalised wind climate"
                else ""
            )
            description = (
                f"WAsP self-prediction at met station '{self._name(ID)}'{source}"
            )
        else:
            description = (
                "WAsP predicted wind climate at "
                f"{object_description.lower()} '{self._name(ID)}'"
            )
        ds.attrs["description"] = description
        return _update_history(ds)

    def get_site_effects(self, ID=None, crs=None):
        """
        Site effects WAsP stored for a site, or for the turbine sites of a group.

        The values are WAsP's as stored in the workspace, parsed without
        rounding, and use the variable names and units of WindKit site effects.

        Parameters
        ----------
        ID : int, optional
            ID of a met station, reference site, turbine site or turbine site
            group. Defaults to None, which reads the only such object in the
            workspace.
        crs : int, dict, str or pyproj.crs.CRS, optional
            CRS of the positions, for a workspace that states none. Overrides
            the stated CRS, with a warning. Defaults to None.

        Returns
        -------
        xarray.Dataset
            Site effects ``z0meso``, ``slfmeso``, ``displ``,
            ``roughness_speedups``, ``roughness_turnings``,
            ``orographic_speedups``, ``orographic_turnings``,
            ``obstacle_speedups``, ``obstacle_turnings`` and ``dirrix`` on
            (sector, point), and ``site_elev`` and ``rix`` on (point), one point
            per site with the site names as the ``name`` coordinate. A variable
            the workspace does not store is left out, such as ``displ`` before
            format 4.01.0006, and ``dirrix``, ``rix`` and the separate
            roughness and orographic effects in format 4.01.0002.

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to a site or turbine site
            group, ID is None and the workspace holds no or several of them,
            neither the workspace nor ``crs`` gives a CRS, a site holds no
            site effects, or its sectors are not windkit's.

        Warns
        -----
        UserWarning
            If WAsP marked the results of a site, or of its turbine site
            group, as not up to date.
        UserWarning
            If ``crs`` differs from the CRS the workspace states.
        """
        ID = self._resolve_id(
            ID,
            _SITE_OBJECTS,
            "met station, reference site, turbine site or turbine site group",
        )
        site_ids = self._site_ids(ID)
        self._warn_outdated_results(self._flagged_ids(ID, site_ids))
        ds, parts = self._sites_dataset(site_ids, "site_assessment", self._crs(ID, crs))
        n_sectors = ds.sizes["sector"]
        for var in _SITE_EFFECT_VARIABLES:
            values = [part[var] for part in parts]
            if all(value is None for value in values):
                continue
            ds[var] = (
                ("sector", "point"),
                np.stack(
                    [
                        np.full(n_sectors, np.nan) if value is None else value
                        for value in values
                    ],
                    axis=-1,
                ),
            )
        for var in ("site_elev", "rix"):
            _add_point_variable(ds, var, parts)
        ds = _update_var_attrs(ds, _TOPO_EFFECTS_ATTRS)
        return _update_history(ds)

    def get_aep(self, ID=None, crs=None):
        """
        Annual energy production WAsP stored for a turbine site, or for the turbine sites of a group.

        The values are WAsP's as stored in the workspace, parsed without
        rounding and converted from Wh/y to GWh/y. The totals are WAsP's sums
        of the sector-wise values; the omnidirectional gross AEP, from the
        all-sector Weibull distribution, is available from :meth:`get_member`.

        WAsP's net AEP is the gross AEP minus the wake losses, which PyWAsP and
        WindKit call potential AEP, so it is returned as ``potential_aep``.
        WindKit's ``net_aep`` also subtracts technical losses, which WAsP does
        not model. The ``description`` attributes of the dataset and of the
        potential AEP variables say so.

        Parameters
        ----------
        ID : int, optional
            ID of a turbine site or turbine site group. Defaults to None, which
            reads the only turbine site group in the workspace.
        crs : int, dict, str or pyproj.crs.CRS, optional
            CRS of the positions, for a workspace that states none. Overrides
            the stated CRS, with a warning. Defaults to None.

        Returns
        -------
        xarray.Dataset
            ``gross_aep_sector`` and ``potential_aep_sector`` on (sector, point)
            and ``gross_aep`` and ``potential_aep`` on (point), in GWh/y, one
            point per turbine site with the site names as the ``name``
            coordinate and a ``description`` attribute saying what it is.

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to a turbine site or
            turbine site group, ID is None and the workspace holds no or
            several turbine site groups, neither the workspace nor ``crs``
            gives a CRS, a site holds no production, or its sectors are not
            windkit's.

        Warns
        -----
        UserWarning
            If WAsP marked the results of a turbine site, or of its turbine
            site group, as not up to date.
        UserWarning
            If ``crs`` differs from the CRS the workspace states.
        """
        ID = self._resolve_id(
            ID,
            (_TURBINE_SITE, _TURBINE_SITE_GROUP),
            "turbine site or turbine site group",
            default=(_TURBINE_SITE_GROUP,),
        )
        site_ids = self._site_ids(ID)
        self._warn_outdated_results(self._flagged_ids(ID, site_ids))
        ds, parts = self._sites_dataset(site_ids, "production", self._crs(ID, crs))
        # WAsP's "Net" is the wake-reduced AEP: potential AEP in PyWAsP and WindKit
        for wasp_name, name in (("gross", "gross"), ("net", "potential")):
            ds[f"{name}_aep_sector"] = (
                ("sector", "point"),
                _stack_sites(parts, wasp_name) / _WH_PER_GWH,
            )
            ds[f"{name}_aep"] = (
                ("point",),
                np.array([part[f"sum_of_sectors_{wasp_name}"] for part in parts])
                / _WH_PER_GWH,
            )
        ds = _update_var_attrs(ds, _AEP_ATTRS)
        for var in ("potential_aep", "potential_aep_sector"):
            ds[var].attrs["description"] = _WASP_NET_AEP_DESCRIPTION
        ds.attrs["description"] = (
            "WAsP annual energy production at "
            f"{self.catalogue[ID]['ObjectDescription'].lower()} '{self._name(ID)}', "
            "with WAsP's net AEP as potential_aep"
        )
        return _update_history(ds)

    def get_wtg(self, ID=None, regulation_type="pitch"):
        """
        Wind turbine generator stored in the workspace.

        Parameters
        ----------
        ID : int, optional
            ID of a wind turbine generator. Defaults to None, which reads the
            only wind turbine generator in the workspace.
        regulation_type : str or None
            One of "stall", "pitch" or None, used when the turbine does not
            define its regulation type, as in :func:`windkit.read_wtg`.
            (Default: "pitch")

        Returns
        -------
        xarray.Dataset
            WTG dataset, the same as :func:`windkit.read_wtg` returns for the
            turbine's ``.wtg`` file.

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to a wind turbine
            generator, ID is None and the workspace holds no or several wind
            turbine generators, or the turbine is malformed, as described in
            :func:`windkit.read_wtg`.
        """
        ID = self._resolve_id(ID, ("Wind turbine generator",), "wind turbine generator")
        wtg_data = self._member(ID, "wind_turbine_generator")["wind_turbine_generator"]
        if wtg_data is None:
            raise ValueError(
                f"{self.path}: object {ID}: no WindTurbineGenerator element found"
            )
        wtg = _wtg_dict_to_dataset(wtg_data, context=f"{self.path}: object {ID}")
        return _finalize_wtg_dataset(wtg, regulation_type)

    def get_parameters(self, ID=None):
        """
        WAsP parameters stored in the workspace.

        Parameters
        ----------
        ID : int, optional
            ID of the object whose parameters to return. Defaults to None,
            which returns the parameters of every object.

        Returns
        -------
        pandas.DataFrame
            One row per parameter, with the columns "Object ID", "Object
            description", "Source" ("settings" for the object's settings, or
            "profile model" for the parameters a generalised wind climate
            records from its generalisation), "Parameter" (the WAsP parameter
            ID, e.g. "DSECTORS"), "Value" (float, or the raw string when it is
            not a number) and "Is default".

        Raises
        ------
        ValueError
            If the ID does not exist in the catalogue.
        """
        if ID is not None and ID not in self.catalogue:
            raise ValueError("ID does not exist in object catalogue")
        rows = []
        for object_id in self.catalogue if ID is None else [ID]:
            member = self._member(object_id, "parameters", "profile_model_parameters")
            for source, key in (
                ("settings", "parameters"),
                ("profile model", "profile_model_parameters"),
            ):
                for parameter, entry in (member[key] or {}).items():
                    rows.append(
                        {
                            "Object ID": object_id,
                            "Object description": member["class_description"],
                            "Source": source,
                            "Parameter": parameter,
                            "Value": entry["value"],
                            "Is default": entry["is_default"],
                        }
                    )
        return pd.DataFrame(
            rows,
            columns=[
                "Object ID",
                "Object description",
                "Source",
                "Parameter",
                "Value",
                "Is default",
            ],
        )

    def get_elevation_map(self, ID=None, crs=None):
        """
        Extracts elevation map from WWH and creates VectorMap object.

        Parameters
        ----------
        ID : int, optional
            ID of vector map object to be extracted. Defaults to None, which
            reads the only vector map in the workspace.
        crs : int, dict, str or pyproj.crs.CRS
            Value to initialize `pyproj.crs.CRS` Default, use from file.

        Returns
        -------
        geopandas.GeoDataFrame
            Vector representation of the map.
        """
        ID = self._resolve_id(ID, ("Vector map",), "vector map")
        if crs is None and self._map_files[ID]["elevation"]["crs"] is None:
            raise ValueError(
                "No CRS associated with this vector map, CRS must be provided!"
            )
        if crs is None and self._map_files[ID]["elevation"]["crs"] is not None:
            crs = self._map_files[ID]["elevation"]["crs"]

        filename = self._map_files[ID]["elevation"]["filename"]
        tempfolder = tempfile.TemporaryDirectory()
        path_tmp = Path(tempfolder.name)

        with zipfile.ZipFile(self.path) as myZip:
            myZip.extract(filename, path_tmp)

        vector_map = _read_vector_map(
            path_tmp.joinpath(filename),
            crs,
            map_type="elevation",
        )
        tempfolder.cleanup()

        return vector_map

    def get_roughness_map(
        self,
        ID=None,
        crs=None,
        convert_to_landcover=False,
        polygons=True,
    ):
        """
        Extracts vector map from WWH and creates VectorMap object.

        Parameters
        ----------
        ID : int, optional
            ID of vector map object to be extracted. Defaults to None, which
            reads the only vector map in the workspace.
        crs : int, dict, str or pyproj.crs.CRS
            Value to initialize `pyproj.crs.CRS` Default, use from file.
        convert_to_landcover : bool, optional
            If True, convert roughness map to landcover map and landcover table.
            Defaults to False.
        polygons : bool, optional
            If True, convert roughness map to polygons. Defaults to True.

        Returns
        -------
        geopandas.GeoDataFrame
            Vector representation of the map.
        """
        map_type = "roughness"

        ID = self._resolve_id(ID, ("Vector map",), "vector map")
        if crs is None and self._map_files[ID][map_type]["crs"] is None:
            raise ValueError(
                "No CRS associated with this vector map, CRS must be provided!"
            )
        if crs is None and self._map_files[ID][map_type]["crs"] is not None:
            crs = self._map_files[ID][map_type]["crs"]

        filename = self._map_files[ID][map_type]["filename"]
        tempfolder = tempfile.TemporaryDirectory()
        path_tmp = Path(tempfolder.name)

        with zipfile.ZipFile(self.path) as myZip:
            myZip.extract(filename, path_tmp)

        vector_map = _read_vector_map(
            path_tmp.joinpath(filename),
            crs,
            map_type,
            convert_to_landcover=convert_to_landcover,
            polygons=polygons,
        )
        tempfolder.cleanup()

        return vector_map

    def get_turbines(self, ID=None, crs=None):
        """
        Extracts turbine positions from WWH and creates WindKit xarray DataArray.

        The positions are in the CRS the workspace states for the turbine site
        group.

        Parameters
        ----------
        ID : int, optional
            ID of turbine site group object to be converted. Defaults to None,
            which reads the only turbine site group in the workspace.
        crs : int, dict, str or pyproj.crs.CRS, optional
            CRS of the positions, for a workspace that states none. Overrides
            the stated CRS, with a warning. Defaults to None.

        Returns
        -------
        xarray.DataArray
            WindKit formated zero-filled data array with point dimension

        Raises
        ------
        ValueError
            If the ID does not exist or is not linked to a turbine site group,
            ID is None and the workspace holds no or several turbine site
            groups, or neither the workspace nor ``crs`` gives a CRS.

        Warns
        -----
        UserWarning
            If ``crs`` differs from the CRS the workspace states.
        """
        ID = self._resolve_id(ID, (_TURBINE_SITE_GROUP,), "turbine site group")
        crs = self._crs(ID, crs)
        height = []
        x = []
        y = []

        for child in self.catalogue[ID]["ChildrenID"]:
            if self.catalogue[child]["ObjectDescription"] == _TURBINE_SITE:
                coords = self._member(child, "coords")["coords"]
                height += [coords["height"]]
                x += [coords["west_east"]]
                y += [coords["south_north"]]

        return create_dataset(x, y, height, crs)

    def get_object(self, ID, map_type="elevation", crs=None):
        """
        Extracts object from .wwh file.

        .. deprecated:: 2.2.0
            Will be removed in windkit 3.0. Call the getter for the object
            instead: :meth:`get_elevation_map`, :meth:`get_roughness_map`,
            :meth:`get_gwc`, :meth:`get_owc` or :meth:`get_turbines`.

        Parameters
        ----------
        ID : int
            ID of object to be extracted.
        map_type : str, optional
            Feature type to extract from mapfile
            Possible values 'elevation', 'roughness'. Defaults to 'elevation'.
        crs : int, dict, str or pyproj.crs.CRS
            Value to initialize `pyproj.crs.CRS` Default, use from file.

        Returns
        -------
        gwc, bwc, vector map or xarray.Dataset of turbine positions

        Raises
        ------
        ValueError
            If the ID does not exist in the catalogue.
        TypeError
            If the object is not one of those listed above, or ``map_type`` is
            not "elevation" or "roughness".

        Warns
        -----
        FutureWarning
            Always.
        """
        warnings.warn(
            "Workspace.get_object is deprecated and will be removed in windkit 3.0. "
            "Call the getter for the object instead: get_elevation_map, "
            "get_roughness_map, get_gwc, get_owc or get_turbines.",
            FutureWarning,
            stacklevel=2,
        )
        if ID not in self.catalogue:
            raise ValueError("ID does not exist in object catalogue")
        object_description = self.catalogue[ID]["ObjectDescription"]
        if object_description == _VECTOR_MAP and map_type == "elevation":
            return self.get_elevation_map(ID, crs=crs)
        if object_description == _VECTOR_MAP and map_type == "roughness":
            return self.get_roughness_map(ID, crs=crs)
        if object_description == "Generalised wind climate":
            return self.get_gwc(ID, crs=crs)
        if object_description == "Observed wind climate":
            return self.get_owc(ID, crs=crs)
        if object_description == _TURBINE_SITE_GROUP:
            return self.get_turbines(ID, crs=crs)
        raise TypeError(
            "\nCan only convert: \n\t(1) Vector maps, \n\t(2) Generalised wind "
            "climate, \n\t(3) Observed wind climate and \n\t(4) Turbine site group"
        )
