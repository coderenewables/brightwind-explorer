# (c) 2026 DTU Wind Energy
"""Declarative validation schemas for xarray objects.

:class:`DatasetSchema` and :class:`DataArraySchema` describe the required
structure of an object; :class:`AnyOf` / :class:`AllOf` compose schemas.
The :func:`make_validator` / :func:`make_is_valid` factories build the
public ``validate_<type>`` / ``is_<type>`` functions.

Examples
--------
>>> from windkit.xarray_structures._schema import (
...     DatasetSchema, DataVar, make_validator, make_is_valid
... )
>>>
>>> bwc_schema = DatasetSchema(
...     name="bwc",
...     data_vars={
...         "wsfreq": DataVar(dims=("wsbin", "sector")),
...         "wdfreq": DataVar(dims=("sector",)),
...     },
...     dims=("wsbin", "sector"),
...     coords=("sector",),
... )
>>> validate_bwc = make_validator(bwc_schema)
>>> is_bwc = make_is_valid(bwc_schema)
"""

import abc
from dataclasses import dataclass
from functools import wraps

import xarray as xr

from .._errors import WindkitValidationError


def _format_errors(errors):
    """Format a flat list of error messages into a single numbered string."""
    numbered = [f"{i + 1}. {err}" for i, err in enumerate(errors)]
    return f"validate found {len(errors)} errors \n" + "\n".join(numbered)


class Schema(abc.ABC):
    """Abstract base for all schemas.

    Subclasses implement ``_collect_errors(obj, run_extra_checks) -> list[str]``
    and inherit :meth:`validate` and :meth:`is_valid`. Any schema can be a
    member of ``AnyOf``/``AllOf``.
    """

    name: str = ""

    @abc.abstractmethod
    def _collect_errors(self, obj, run_extra_checks):
        """Return an (unnumbered) list of error messages for ``obj``."""
        raise NotImplementedError

    def validate(self, obj, run_extra_checks=True):
        """Validate ``obj``, raising on failure.

        Parameters
        ----------
        obj : xarray.Dataset or xarray.DataArray
            Object to validate.
        run_extra_checks : bool
            Whether to run ``extra_checks`` callables, by default True.

        Raises
        ------
        WindkitValidationError
            If validation fails. The structured failures are available on
            ``exc.errors``.
        """
        errors = self._collect_errors(obj, run_extra_checks)
        if errors:
            raise WindkitValidationError(_format_errors(errors), errors=errors)

    def is_valid(self, obj, run_extra_checks=False):
        """Return whether ``obj`` matches this schema.

        Parameters
        ----------
        obj : xarray.Dataset or xarray.DataArray
            Object to check.
        run_extra_checks : bool
            Whether to run ``extra_checks`` callables, by default False.

        Returns
        -------
        bool
        """
        # non-xarray input is "not valid" rather than an error
        if not isinstance(obj, (xr.Dataset, xr.DataArray)):
            return False
        try:
            self.validate(obj, run_extra_checks=run_extra_checks)
            return True
        except WindkitValidationError:
            return False


@dataclass(frozen=True)
class DataVar:
    """A required data variable inside a :class:`DatasetSchema`.

    Parameters
    ----------
    dims : tuple of str
        Dimensions the variable must have. Empty tuple = existence-only check.

    Notes
    -----
    Gains a ``dtype`` field and a link into the typed variable-metadata
    registry with windkit#764.
    """

    dims: tuple = ()

    def __post_init__(self):
        object.__setattr__(self, "dims", tuple(self.dims))

    def _errors_for(self, obj, var_name):
        """Return errors for ``var_name`` within Dataset ``obj``."""
        if var_name not in obj.data_vars:
            return [f"Missing variable: {var_name}"]
        errors = []
        for dim in self.dims:
            if dim not in obj[var_name].dims:
                errors.append(f"Missing dimension {dim} on variable: {var_name}")
        return errors


@dataclass(frozen=True)
class Check:
    """A named value/semantic check wrapping a predicate callable.

    Usable in ``extra_checks`` anywhere a bare callable is.

    Parameters
    ----------
    fn : callable
        ``fn(obj) -> str | list[str] | None``.
    name : str
        Optional label prefixed onto each failure message.
    error : str, optional
        If given, overrides the message(s) returned by ``fn`` on failure.
    """

    fn: object
    name: str = ""
    error: str | None = None

    def __call__(self, obj):
        result = self.fn(obj)
        if result is None:
            return None
        if self.error is not None:
            return self.error
        if not self.name:
            return result
        if isinstance(result, str):
            return f"{self.name}: {result}"
        return [f"{self.name}: {r}" for r in result]


@dataclass(frozen=True)
class _StructuralSchema(Schema):
    """Structural checks shared by :class:`DatasetSchema` and
    :class:`DataArraySchema`. Not instantiated directly.

    Parameters
    ----------
    name : str
        Human-readable name for the schema.
    dims : tuple of str
        Required dimensions.
    coords : tuple of str
        Required coordinates (extended to ``Coordinate`` components with
        windkit#766).
    attrs : tuple of str
        Required attributes.
    forbidden_dims : tuple of str
        Dimensions that must NOT be present (subsumed by strict validation,
        windkit#724).
    check_monotonic : tuple of str
        Coordinates that must be monotonically increasing (folds into
        windkit#766's ``Coordinate``).
    extra_checks : tuple of callable
        Additional checks ``f(obj) -> str | list[str] | None`` (bare callables
        or :class:`Check` instances).
    """

    name: str = ""
    dims: tuple = ()
    coords: tuple = ()
    attrs: tuple = ()
    forbidden_dims: tuple = ()
    check_monotonic: tuple = ()
    extra_checks: tuple = ()

    def __post_init__(self):
        for f in (
            "dims",
            "coords",
            "attrs",
            "forbidden_dims",
            "check_monotonic",
            "extra_checks",
        ):
            object.__setattr__(self, f, tuple(getattr(self, f)))

    def _collect_errors(self, obj, run_extra_checks):
        errors = []

        for dim in self.dims:
            if dim not in obj.dims:
                errors.append(f"Missing dimension: {dim}")

        for coord in self.coords:
            if coord not in obj.coords:
                errors.append(f"Missing coordinate: {coord}")

        for attr in self.attrs:
            if attr not in obj.attrs:
                errors.append(f"Missing attribute: {attr}")

        for dim in self.forbidden_dims:
            if dim in obj.dims:
                errors.append(f"Forbidden dimension present: {dim}")

        for coord in self.check_monotonic:
            if coord not in obj.coords:
                continue
            values = obj.coords[coord].values
            if values.ndim == 0 or len(values) <= 1:  # monotonicity needs 2+ values
                continue
            if not all(a < b for a, b in zip(values, values[1:])):
                errors.append(f"Coordinate {coord} is not monotonically increasing")

        if run_extra_checks:
            for check in self.extra_checks:
                err_msg = check(obj)
                if err_msg is None:
                    continue
                if isinstance(err_msg, str):
                    err_msg = [err_msg]
                errors.extend(err_msg)

        return errors


@dataclass(frozen=True)
class DatasetSchema(_StructuralSchema):
    """Declarative schema for validating an :class:`xarray.Dataset`.

    Extends :class:`_StructuralSchema` with per-variable requirements.

    Parameters
    ----------
    data_vars : dict of str to DataVar
        Required data variables and their per-variable requirements.

    Notes
    -----
    See :class:`_StructuralSchema` for the inherited structural parameters.
    Cross-variable alignment and strict validation come with windkit#766 /
    windkit#724.
    """

    data_vars: tuple = ()

    def __post_init__(self):
        super().__post_init__()
        dv = self.data_vars
        dv = tuple(dv.items()) if isinstance(dv, dict) else tuple(dv)
        object.__setattr__(self, "data_vars", dv)

    def _collect_errors(self, obj, run_extra_checks):
        if isinstance(obj, xr.DataArray):
            return ["Expected an xarray.Dataset, got a DataArray"]
        # per-variable checks before structural checks: ordering is part of
        # the message contract
        errors = []
        for var_name, datavar in self.data_vars:
            errors.extend(datavar._errors_for(obj, var_name))
        errors.extend(super()._collect_errors(obj, run_extra_checks))
        return errors


@dataclass(frozen=True)
class DataArraySchema(_StructuralSchema):
    """Declarative schema for validating a standalone :class:`xarray.DataArray`.

    Validates the array's dims, coords, attrs, forbidden dims, monotonic
    coordinates and ``extra_checks`` (see :class:`_StructuralSchema`).

    Notes
    -----
    Gains array-specific fields (``dtype``, ``shape``, ``name``) with
    windkit#764.
    """

    def _collect_errors(self, obj, run_extra_checks):
        if isinstance(obj, xr.Dataset):
            return ["Expected an xarray.DataArray, got a Dataset"]
        return super()._collect_errors(obj, run_extra_checks)


@dataclass(frozen=True)
class _Combinator(Schema):
    """Shared fields for the OR/AND schema combinators. Not instantiated
    directly.

    Parameters
    ----------
    schemas : tuple of Schema
        Member schemas (may themselves be combinators).
    name : str
        Human-readable name for the group.
    """

    schemas: tuple = ()
    name: str = ""

    def __post_init__(self):
        object.__setattr__(self, "schemas", tuple(self.schemas))


@dataclass(frozen=True)
class AnyOf(_Combinator):
    """OR-composition of schemas: at least one must match.

    See :class:`_Combinator` for the ``schemas`` / ``name`` parameters.
    """

    def _collect_errors(self, obj, run_extra_checks):
        alt_results = []
        for alt in self.schemas:
            alt_errors = alt._collect_errors(obj, run_extra_checks)
            if not alt_errors:
                return []
            alt_results.append((alt.name or "unnamed", alt_errors))

        label = self.name or "unnamed"
        detail_lines = [
            f"    - {alt_name}: {err}"
            for alt_name, alt_errors in alt_results
            for err in alt_errors
        ]
        return [
            f"None of the following schemas matched: {label}\n"
            + "\n".join(detail_lines)
        ]


@dataclass(frozen=True)
class AllOf(_Combinator):
    """AND-composition of schemas: all must match.

    See :class:`_Combinator` for the ``schemas`` / ``name`` parameters.
    """

    def _collect_errors(self, obj, run_extra_checks):
        # de-duplicate errors shared by composed schemas, preserving order
        errors = []
        seen = set()
        for schema in self.schemas:
            for err in schema._collect_errors(obj, run_extra_checks):
                if err not in seen:
                    seen.add(err)
                    errors.append(err)
        return errors


def any_of(*schemas, name=""):
    """Create an :class:`AnyOf` group from multiple schemas.

    Parameters
    ----------
    *schemas : Schema
        Alternative schemas.
    name : str
        Human-readable name for the group.

    Returns
    -------
    AnyOf
    """
    return AnyOf(schemas=schemas, name=name)


def all_of(*schemas, name=""):
    """Create an :class:`AllOf` group from multiple schemas.

    Parameters
    ----------
    *schemas : Schema
        Schemas that must all pass.
    name : str
        Human-readable name for the group.

    Returns
    -------
    AllOf
    """
    return AllOf(schemas=schemas, name=name)


def validate(obj, *schemas, run_extra_checks=True):
    """Validate an xarray object against one or more schemas (AND semantics).

    Thin sugar over ``AllOf(*schemas).validate(obj)``.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Object to validate.
    *schemas : Schema
        Schemas to validate against.
    run_extra_checks : bool
        Whether to run extra_checks callables, by default True.

    Raises
    ------
    WindkitValidationError
        If validation fails.
    """
    AllOf(schemas=schemas).validate(obj, run_extra_checks=run_extra_checks)


def is_valid(obj, *schemas, run_extra_checks=False):
    """Check whether an xarray object matches the given schemas.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        Object to check.
    *schemas : Schema
        Schemas to check against.
    run_extra_checks : bool
        Whether to run extra_checks callables, by default False.

    Returns
    -------
    bool
    """
    return AllOf(schemas=schemas).is_valid(obj, run_extra_checks=run_extra_checks)


def validate_input(*schemas, index=0, run_extra_checks=False):
    """Decorator that validates a function argument before calling the function.

    Parameters
    ----------
    *schemas : Schema
        Schemas to validate against.
    index : int
        Positional index of the argument to validate, by default 0.
    run_extra_checks : bool
        Whether to run extra_checks callables, by default False.

    Returns
    -------
    callable
        Decorator.
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            validate(args[index], *schemas, run_extra_checks=run_extra_checks)
            return func(*args, **kwargs)

        return wrapper

    return decorator


def _schema_names(*schemas):
    """Extract non-empty names from schemas."""
    return [s.name for s in schemas if s.name]


def make_validator(*schemas, run_extra_checks=True):
    """Create a validator function from schemas.

    The returned function accepts ``run_extra_checks`` to override the default.

    Parameters
    ----------
    *schemas : Schema
        Schemas to validate against.
    run_extra_checks : bool
        Default value for run_extra_checks, by default True.

    Returns
    -------
    callable
        ``validator(obj, run_extra_checks=<default>)``
    """

    def validator(obj, run_extra_checks=run_extra_checks):
        validate(obj, *schemas, run_extra_checks=run_extra_checks)

    names = _schema_names(*schemas)
    # named from the first (primary type) schema, e.g. ``validate_windturbines``
    validator.__name__ = f"validate_{names[0]}" if names else "validate"
    validator.__qualname__ = validator.__name__
    validator.__doc__ = f"""Validate that obj matches: {", ".join(names)}.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        The object to validate.
    run_extra_checks : bool, optional
        Whether to run the schema's extra_checks callables,
        by default {run_extra_checks}.

    Raises
    ------
    WindkitValidationError
        If the object is not valid.
    """
    return validator


def make_is_valid(*schemas, run_extra_checks=False):
    """Create a boolean checker function from schemas.

    Parameters
    ----------
    *schemas : Schema
        Schemas to check against.
    run_extra_checks : bool
        Default value for run_extra_checks, by default False.

    Returns
    -------
    callable
        ``checker(obj, run_extra_checks=<default>) -> bool``
    """

    def checker(obj, run_extra_checks=run_extra_checks):
        return is_valid(obj, *schemas, run_extra_checks=run_extra_checks)

    names = _schema_names(*schemas)
    # named from the first (primary type) schema, e.g. ``is_windturbines``
    checker.__name__ = f"is_{names[0]}" if names else "is_valid"
    checker.__qualname__ = checker.__name__
    checker.__doc__ = f"""Check whether obj matches: {", ".join(names)}.

    Parameters
    ----------
    obj : xarray.Dataset or xarray.DataArray
        The object to check.
    run_extra_checks : bool, optional
        Whether to run the schema's extra_checks callables,
        by default {run_extra_checks}.

    Returns
    -------
    bool
        True if the object is valid, False otherwise.
    """
    return checker
