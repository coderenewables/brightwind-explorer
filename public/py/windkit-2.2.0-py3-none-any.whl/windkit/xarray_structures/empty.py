# (c) 2026 DTU Wind Energy
"""
Create empty datasets for various WindKit structures.

The datasets have the correct shape, dimensions, coordinates and data variables and
can also be filled with meaningful random data.
"""

import numpy as np

from windkit.spatial._dimensions import _validate_locations


def _native_batch(output_locs):
    """Validate ``output_locs`` and return its canonical dimensions and sizes.

    Dimensions come from :func:`_spatial_dims_in_order`, never from
    ``Dataset.dims``, which iterates in variable-insertion order and so gives
    two datasets with identical content different answers. Scalar and reduced
    axes come back exactly as present: there is no promotion to undo,
    because nothing here ever stacks to a flat ``point`` axis, the way the
    ``_define_std_arrays``/``_empty_unstack`` templates this module used to
    hand out did.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Spatial locations to build a constructor on.

    Returns
    -------
    dims : tuple of str
        Present spatial dimensions, canonically ordered; empty for a scalar
        location.
    shape : tuple of int
        Sizes of ``dims``, in the same order.

    Raises
    ------
    WindkitValidationError
        If ``output_locs`` is not a WindKit spatial object, its spatial
        coordinates are unsupported or mutually incompatible, or it carries
        non-spatial dimensions.
    """
    dims = _validate_locations(output_locs)
    return dims, tuple(output_locs.sizes[dim] for dim in dims)


def _native_batch_horizontal(output_locs):
    """Like :func:`_native_batch`, but without a separate ``height`` axis.

    For a constructor variable declared height-independent (windkit#807's
    ``*Bxy``): ``create_geowc``'s mesoscale roughness/displacement
    quantities, ``create_wasp_site_effects``'s ``z0meso``-like quantities,
    ``create_tswc``'s surface-layer scales, and every variable
    ``create_surface_fields`` adds.

    ``height`` is dropped from :func:`_native_batch`'s dims when it is a
    separate dimension (cuboid, stacked_point). A ``point`` structure, where
    height is folded into the flat point axis rather than kept apart, is
    returned unchanged: each of these constructors gives points at one
    horizontal location equal values itself, so there is nothing to separate
    out.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Spatial locations to build a constructor on.

    Returns
    -------
    dims : tuple of str
        :func:`_native_batch`'s dims with ``height`` removed, if present as
        its own dimension.
    shape : tuple of int
        Sizes of ``dims``, in the same order.

    Raises
    ------
    WindkitValidationError
        See :func:`_native_batch`.
    """
    dims, shape = _native_batch(output_locs)
    horizontal = [(dim, size) for dim, size in zip(dims, shape) if dim != "height"]
    return tuple(dim for dim, _ in horizontal), tuple(size for _, size in horizontal)


def _native_flat_coords(output_locs, dims, shape, names=("west_east", "south_north")):
    """Return coordinates broadcast over the batch and flattened.

    Each requested coordinate comes back with one value per generated
    location, in the order the generated arrays use, so that a computation
    needing every location side by side — a pairwise correlation matrix, or
    an index of which points share a horizontal column — can work on a flat
    axis without ever stacking the object to a ``point`` structure.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Spatial locations to build a constructor on.
    dims, shape : tuple
        Batch dimensions and sizes, from :func:`_native_batch` or
        :func:`_native_batch_horizontal`.
    names : iterable of str, optional
        Coordinates to flatten. Defaults to the two horizontal ones.

    Returns
    -------
    list of numpy.ndarray
        One flattened array per requested name, each of length
        ``prod(shape)``.
    """
    out = []
    for name in names:
        coord = output_locs.coords[name]
        expanded = coord.data.reshape(
            [coord.sizes[dim] if dim in coord.dims else 1 for dim in dims]
        )
        out.append(np.ravel(np.broadcast_to(expanded, shape)))
    return out


def _native_frame(output_locs):
    """Return the coordinates and attrs to build a constructor on.

    Drops data variables and any stale ``_pwio*`` stack metadata, which would
    otherwise describe a structure this object was never converted from.

    Parameters
    ----------
    output_locs : xarray.Dataset
        Spatial locations to build a constructor on.

    Returns
    -------
    xarray.Dataset
        Coordinates and attrs only, ready to receive data variables.

    Notes
    -----
    ``copy(deep=False)`` isolates the per-variable attrs dictionaries (Variable
    copies always get a fresh ``attrs`` dict) while still sharing the
    underlying coordinate data, so editing attrs below never mutates
    ``output_locs``.
    """
    ds = output_locs.drop_vars(output_locs.data_vars).copy(deep=False)
    ds.attrs = {
        key: value for key, value in ds.attrs.items() if not key.startswith("_pwio")
    }
    for name in ds.coords:
        ds[name].attrs = {
            key: value
            for key, value in ds[name].attrs.items()
            if not key.startswith("_pwio")
        }
    return ds


def _native_store(values, dims, shape, *, core_dims, core_last=True, dtype=np.float32):
    """Lay a ``(*core_dims, n_locations)`` array out for the compiled boundary.

    The result is float32 and C-contiguous with its dimensions in the reverse
    of the order the WAsP core declares them (``core_last=True``, the default)
    or in that order directly (``core_last=False``, for the one family of
    consumers that declares the location axis first). Either way, what lets
    PyWAsP's ``astype(np.float32, order="F", copy=False)`` return this very
    buffer instead of a converted copy is that the stored order is the exact
    reverse of the compiled declaration (windkit#807). Coordinates are not
    touched by this helper and stay float64: the core declares the location
    arguments of ``predict_*_points`` double precision, float32 cannot
    represent ``create_gwc``'s roughness values exactly enough to survive an
    inner join, and its spacing at 5e5 m is 0.031 m.

    Neither dtype nor dimension order is a supported contract of these
    test-data utilities; they are chosen so PyWAsP's compiled boundary does
    not have to copy them, and are documented as such by each caller.

    Parameters
    ----------
    values : numpy.ndarray
        Array of shape ``(*core_sizes, n_locations)``, in the order
        ``core_dims`` declares, with locations flattened in the order ``dims``
        gives batch elements.
    dims : tuple of str
        Batch dimensions, from :func:`_native_batch`.
    shape : tuple of int
        Sizes of ``dims``, from :func:`_native_batch`.
    core_dims : tuple of str
        Non-batch dimensions of ``values``, in the order they appear there.
    core_last : bool, optional
        If true (default), store as ``(*dims, *reversed(core_dims))``.
        Otherwise store as ``(*core_dims, *dims)``.
    dtype : numpy.dtype, optional
        Output dtype. Defaults to float32.

    Returns
    -------
    out_dims : tuple of str
        Dimensions of the returned array.
    array : numpy.ndarray
        C-contiguous array of dtype ``dtype``.
    """
    n_core = len(core_dims)
    # A single tuple argument, not unpacked positional ones: reshape() takes
    # no arguments at all when both a scalar core and a scalar location leave
    # that tuple empty, which is not the same as reshaping to "no shape".
    full = values.reshape((*values.shape[:n_core], *shape))
    if core_last:
        order = (*range(n_core, n_core + len(dims)), *reversed(range(n_core)))
        out_dims = (*dims, *reversed(core_dims))
    else:
        order = tuple(range(full.ndim))
        out_dims = (*core_dims, *dims)
    transposed = full.transpose(order)
    # np.ascontiguousarray promotes a 0-d array to shape (1,); reshape it back
    # so a fully scalar result (no core dims, no batch dims) keeps ndim == 0,
    # matching the empty out_dims a scalar location and no core dims give.
    return out_dims, np.ascontiguousarray(transposed, dtype=dtype).reshape(
        transposed.shape
    )


def _copy_chunks(in_ds, out_ds):
    """copy chunks from in_ds to out_ds"""
    # If input is not chunked it will have an emtpy chunks dict, so we need to build a
    # custom chunk_map based on the chunked dimensions of the original data.
    chunk_map = {}
    for i in in_ds.chunks:
        if i in out_ds.dims:
            chunk_map[i] = in_ds.chunks[i][0]

    # Remember in Python empty dictionaries are False
    if chunk_map:
        return out_ds.chunk(chunk_map)
    else:
        return out_ds
